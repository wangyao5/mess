package com.lemall.brd.bpo.test;

import com.lemall.brd.bpo.worker.UserDepToWFWorker;
import com.lemall.brd.bpo.test.common.BaseTest;
import org.junit.Test;

import javax.annotation.Resource;

public class UserDepToWFSnTest extends BaseTest {
    @Resource
    private UserDepToWFWorker userDepToWFWorker;

    @Test
    public void test() {
        userDepToWFWorker.run();
    }
}
