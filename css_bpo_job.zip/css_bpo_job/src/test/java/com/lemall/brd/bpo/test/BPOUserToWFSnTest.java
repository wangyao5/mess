package com.lemall.brd.bpo.test;

import com.lemall.brd.bpo.worker.BPOUserToWFWorker;
import com.lemall.brd.bpo.test.common.BaseTest;
import org.junit.Test;

import javax.annotation.Resource;

public class BPOUserToWFSnTest extends BaseTest {
	@Resource
	private BPOUserToWFWorker bpoUserToWFWorker;

	@Test
	public void test() {
		bpoUserToWFWorker.run();
	}
}
