package com.lemall.brd.bpo.test;

import com.lemall.brd.bpo.worker.BPOUserToCCWorker;
import org.junit.Test;

import javax.annotation.Resource;

import static org.junit.Assert.*;

/**
 * Created by yangxinghe on 2017/6/8.
 */
public class BPOUserToCCWorkerTest {
    @Resource
    private BPOUserToCCWorker bpoUserToCCWorker;
    @Test
    public void run(){
        bpoUserToCCWorker.run();
    }


}