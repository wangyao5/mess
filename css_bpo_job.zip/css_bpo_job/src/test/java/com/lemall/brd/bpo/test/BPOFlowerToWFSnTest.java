package com.lemall.brd.bpo.test;

import com.lemall.brd.bpo.worker.UserFlowerToWFWorker;
import com.lemall.brd.bpo.test.common.BaseTest;
import org.junit.Test;

import javax.annotation.Resource;

public class BPOFlowerToWFSnTest extends BaseTest {
    @Resource
    private UserFlowerToWFWorker userFlowerToWFWorker;

    @Test
    public void test() {
        userFlowerToWFWorker.run();
    }
}
