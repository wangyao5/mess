package com.lemall.brd.bpo.test;

import com.lemall.brd.bpo.test.common.BaseTest;
import com.lemall.brd.bpo.worker.UserDepToWFWorker;
import com.lemall.brd.bpo.worker.UserLeaveToLeflowWorker;
import org.junit.Test;

import javax.annotation.Resource;

public class UserLeaveToLeflowTest extends BaseTest {
    @Resource
    private UserLeaveToLeflowWorker userLeaveToLeflowWorker;

    @Test
    public void test() {
        userLeaveToLeflowWorker.run();
    }
}
