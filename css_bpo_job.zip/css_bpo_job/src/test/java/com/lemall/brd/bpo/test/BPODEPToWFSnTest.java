package com.lemall.brd.bpo.test;

import com.lemall.brd.bpo.worker.BPODEPToWFWorker;
import com.lemall.brd.bpo.test.common.BaseTest;
import org.junit.Test;

import javax.annotation.Resource;

public class BPODEPToWFSnTest extends BaseTest {
    @Resource
    private BPODEPToWFWorker bpodepToWFWorker;

    @Test
    public void test() {
        bpodepToWFWorker.run();
    }
}
