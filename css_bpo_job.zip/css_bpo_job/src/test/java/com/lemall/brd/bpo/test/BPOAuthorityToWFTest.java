package com.lemall.brd.bpo.test;

import com.lemall.brd.bpo.worker.BPOAuthorityToWFWorker;
import com.lemall.brd.bpo.test.common.BaseTest;
import org.junit.Test;

import javax.annotation.Resource;

/**
 * Created by jianghongwei on 2017/3/7.
 */
public class BPOAuthorityToWFTest extends BaseTest {
    @Resource
    BPOAuthorityToWFWorker bpoAuthorityToWFWorker;
    @Test
    public void test() {
        bpoAuthorityToWFWorker.run();
    }
}
