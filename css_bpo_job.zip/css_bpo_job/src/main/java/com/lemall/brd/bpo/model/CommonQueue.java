package com.lemall.brd.bpo.model;

import lombok.Data;

import java.util.Date;

/**
 * Created by jianghongwei on 2017/3/2.
 */
@Data
public class CommonQueue {
    private Long id;
    private Integer eventId;
    private Long onlyId;
    private Integer requestNum;
    private String requestRemake;
    private Integer status;
    private Date creationDate;
    private String createdBy;
    private Date changeDate;
    private String changedBy;
    private Integer dayNum;
    private String onlyType;
}
