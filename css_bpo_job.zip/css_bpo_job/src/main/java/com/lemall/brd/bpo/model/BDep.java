package com.lemall.brd.bpo.model;

import lombok.Data;

import java.util.Date;

@Data
public class BDep implements java.io.Serializable {

    private static final long serialVersionUID = -7865031984935951240L;

    /**
     * 自增ID
     */
    private Long id;

    /**
     * 部门编号，人工输入
     */
    private String num;

    /**
     * 人员数量，该字段不同步到数据库，用来保存计算后该部门的人员数量
     */
    private Integer personQuantity;

    /**
     * 部门编码，系统生成
     */
    private String code;

    /**
     * 部门名称
     */
    private String name;

    /**
     * 上级部门Id
     */
    private Long parentId;

    /**
     * 上级部门
     */
    private BDep parentBDep;

    /**
     * 是否有子节点
     */
    private Integer hasChild;

    /**
     * 层级
     */
    private Integer level;

    /**
     * 部门层级,1、内部 2、职场
     */
    private Integer hierarchy;

    /**
     * 优先级(顺序)
     */
    private Integer priority;

    /**
     * 负责人
     */
    private String personCharge;

    /**
     * 负责人ID
     */
    private Long personChargeId;

    /**
     * 部门性质：0内部，1外包
     */
    private Integer depType;

    /**
     * 部门状态，0禁用，1启用
     */
    private Integer depState;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新人
     */
    private String updateUser;

    /**
     * 是否有效： 0-无效； 1-有效
     */
    private Integer yn = 0;

    /**
     * 备注
     */
    private String remark;

    /**
     * 状态（对应集团系统是否有效）
     */
    private Integer effect;

    /**
     * 最后修改时间
     */
    private Date lastModifyTime;

}
