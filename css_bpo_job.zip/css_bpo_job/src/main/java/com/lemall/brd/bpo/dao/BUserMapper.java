package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.BUser;

/**
 * Created by jianghongwei on 2017/3/2.
 */
public interface BUserMapper {
    public BUser getUserById(Long id);
}
