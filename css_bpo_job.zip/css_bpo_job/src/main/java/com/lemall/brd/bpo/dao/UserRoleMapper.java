package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.query.UserRoleQuery;

import java.util.List;

/**
 * Created by jianghongwei on 2017/3/18.
 */
public interface UserRoleMapper {
    List<Long> queryUserRoleList(UserRoleQuery query);
}
