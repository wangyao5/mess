package com.lemall.brd.bpo.model;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class BStaff implements java.io.Serializable {

    private static final long serialVersionUID = -7865031984935951240L;

    /** Id自增 */
    private Long id;
    /**客服工号*/
    private String csId;
    /**员工编号*/
    private String employeeNum;
    /**用户id*/
    private Long uId;
    /**部门ID*/
    private Long depId;
    /** 姓名 */
    private String name;
    /**花名*/
    private String nickname;
    /**工作形式：实习生，正式工*/
    private Integer workingProperty;
    /** 联系方式 */
    private String phoneNo;
    /** 邮箱 */
    private String email;
    /**身份证号*/
    private String idNumber;
    /**客服经验年限*/
    private String csExperience;
    /**工作年限*/
    private String workExperience;
    /**出生日期*/
    private Date birthdate;
    /**入职日期*/
    private Date entryDate;
    /**离职日期*/
    private Date quitDate;
    /**状态（正常，离职，停职等），已弃用*/
    private String status;
    /**是否是负责人*/
    private Integer isCharged;
    /**0未婚、1已婚*/
    private Integer isMarried;
    /**0男、1女*/
    private Integer sex;
    /**毕业院校*/
    private String graduateSchool;
    /**0无子女、1一胎、2二胎*/
    private Integer children;
    /**专业*/
    private String major;
    /**1小学、2初中、3高中、4技校、5职高、6中专、7大专、8本科、9硕士、10博士、11其他*/
    private Integer education;
    /**面试官：上级部门经理*/
    private String interviewer;
    /**乐视复核人:高莉丽、梁春磊、岳金风、陈辽、李昂、冯冀垚、于思洋、陆旭、吴鑫、陈伟、王兵、陆依然、戴陆璐、郭彦峰、崔丽倩、崔亚运*/
    private Integer leReviewer;
    /**备注*/
    private String remark;
    /**员工合同性质：0乐视合同、1人瑞合同*/
    private Integer staffContract;
    /**费用所属公司：乐视（乐视电商、乐视致新……），人瑞（人瑞移动、人瑞商城……）*/
    private Integer costCompany;
    /**职位状态:1.培训，2.考核未通过，3.在职，4.离职*/
    private String positionStatus;
    /**上线日期*/
    private Date onlineDate;
    /**培训主任*/
    private String trainingOfficer;
    /**培训主讲*/
    private String traningSpeaker;
    /**平均成绩*/
    private String aveScore;
    /**通关成绩*/
    private String score;
    /**通关结果*/
    private Integer result;
    /**业务，枚举值*/
    private Integer service;
    /** 岗位 */
    private Integer jobTitle;
    /**上级(所在部门的负责人)*/
    private String superior;
    /**乐视账号，仅针对内部员工，外包员工没有账号。*/
    private String leAccount;
    /** 创建人 */
    private String createUser;
    /** 创建时间 */
    private Date createTime;
    /** 更新人 */
    private String updateUser;
    /** 更新时间 */
    private Date updateTime;
    /** 是否有效： 0-无效； 1-有效 */
    private Integer yn;
    /**最后修改时间*/
    private Date lastModifyTime;
    /**离职原因*/
    private String dimissionReason;
    /**离职日期*/
    private Date dimissionDate;
    /**岗位调整原因*/
    private String jobTitleAdjustmentReason;
    /**岗位调整日期*/
    private Date jobTitleAdjustmentDate;
    /**结构调整（部门调整）原因*/
    private String structAdjustReason;
    /**结构调整日期*/
    private Date structAdjustDate;
    /**职级*/
    private Integer rank;
    /**
     * CC系统从属组ID
     */
    private String ccRoleGroupId;
    /**
     * CC系统从数组名称
     */
    private String ccRoleGroupName;

}
