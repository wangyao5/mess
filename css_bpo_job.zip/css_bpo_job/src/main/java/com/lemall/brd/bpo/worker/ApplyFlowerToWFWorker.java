package com.lemall.brd.bpo.worker;

import com.lemall.brd.bpo.dao.BUserMapper;
import com.lemall.brd.bpo.dao.CommonQueueMapper;
import com.lemall.brd.bpo.dao.JsonDataMapper;
import com.lemall.brd.bpo.model.BUser;
import com.lemall.brd.bpo.model.CommonQueue;
import com.lemall.brd.bpo.model.Constants;
import com.lemall.brd.bpo.model.JsonData;
import com.lemall.brd.bpo.util.EventConstants;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service("applyFlowerToWFWorker")
public class ApplyFlowerToWFWorker extends Worker {
    private Logger LOGGER = LoggerFactory.getLogger(ApplyFlowerToWFWorker.class);

    @Value("${getWFUrl}")
    private String getWFUrl;
    @Value("${newInstance}")
    private String newInstance;

    @Autowired
    private CommonQueueMapper commonQueueMapper;
    @Autowired
    private JsonDataMapper jsonDataMapper;
    @Value("${secretKey}")
    private String secretKey;
    @Autowired
    private BUserMapper bUserMapper;

    @Override
    public void run() {
        MDC.put("APP_NAME", ApplyFlowerToWFWorker.class.getSimpleName());
        LOGGER.info("ApplyFlowerToWFWorker.run，流程作业开始");
        //支援
        applay(EventConstants.EVENT_SUPPORT, "bpoSupport", "supRequest", "申请支援");
        //班次调整
        applay(EventConstants.EVENT_ADJSUT, "bpoShiftsAdjust", "shiftsRequest", "调整班次");
        // 餐时
        applay(EventConstants.EVENT_MEAL, "bpoMealAdjust", "mealAdjustRequest", "调整餐时");
        //加班
        applay(EventConstants.EVENT_OVERTIME, "bpoOvertime", "overtimeRequest", "申请加班");
        // 请假
        applay(EventConstants.EVENT_TEMP_LEAVE, "bpoTempLeave", "tempLeaveRequest", "申请请假");
        // 换班
        applay(EventConstants.EVENT_SHIFT, "bpoShift", "shiftRequest", "申请换班");
        //预置班次
        applay(EventConstants.EVENT_PRE_SHIFTS, "bpoPreShifts", "preShiftsRequest", "申请预置班次");
        //审核排班
        applay(EventConstants.EVENT_SCHEDULING, "bpoAutoScheduling", "schedulingRequest", "申请审核排班");
        LOGGER.info("ApplyFlowerToWFWorker.run，流程作业结束");

    }

    /**
     * 支援
     */
    private void applay(int eventType, String flowId, String actionId, String title) {
        Map<String, String> result = new HashedMap();
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, eventType);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有"+ title + "流程");
        } else {
            for (CommonQueue commonQueue : commonQueueList) {
                try {
                    JsonData jsonData = jsonDataMapper.getById(commonQueue.getOnlyId());
                    if(jsonData==null){
                        throw new Exception(commonQueue.getOnlyId()+"不存在JosnData");
                    }
                    HashedMap param = new HashedMap();
                    param.put("flowId", flowId);
                    param.put("actionId", actionId);
                    //人员信息
                    BUser bUser = bUserMapper.getUserById(Long.parseLong(commonQueue.getCreatedBy()));
                    param.put("title", bUser.getName() + title);
                    result=flowQueue(commonQueue, jsonData, param);
                } catch (Exception e) {
                    e.printStackTrace();
                    LOGGER.info("get param sign error! and message is:{}", e.getMessage());
                } finally {
                    if (result.containsKey("status")&&"0".equals(result.get("status"))) {
                        commonQueue.setStatus(1);
                    } else {
                        commonQueue.setStatus(0);
                    }
                    commonQueue.setRequestRemake(result.containsKey("message")?result.get("message"):"失败");
                    commonQueue.setChangedBy(flowId);
                    commonQueue.setChangeDate(new Date());
                    commonQueue.setRequestNum(commonQueue.getRequestNum() + 1);
                    commonQueueMapper.update(commonQueue);
                }
            }
        }

    }


    private Map<String, String> flowQueue(CommonQueue commonQueue, JsonData jsonData, Map<String, String> param) throws IOException {
        String url = getWFUrl + newInstance;
        param.put("operatorType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
//        param.put("assignGroupType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
//        param.put("assignGroupId", "113");//分配处理组id 有按钮权限即可以处理
        param.put("outId", commonQueue.getOnlyId() + "");//外鍵ID
        param.put("operatorId", commonQueue.getCreatedBy());//接口调用人id
        param.put("data", jsonData.getJsonData());

        return CommonWorker.userToWF(url, param, secretKey);
    }
}
