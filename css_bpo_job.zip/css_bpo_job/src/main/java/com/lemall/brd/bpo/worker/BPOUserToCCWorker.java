package com.lemall.brd.bpo.worker;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.lemall.brd.bpo.dao.BStaffMapper;
import com.lemall.brd.bpo.dao.CommonQueueMapper;
import com.lemall.brd.bpo.model.BStaff;
import com.lemall.brd.bpo.model.CommonQueue;
import com.lemall.brd.bpo.util.EventConstants;
import com.lemall.brd.framework.util.MD5Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


/**
 * yxh
 * 2017-06-08 14:42:27
 */
@Service("bPOUserToCCWorker")
public class BPOUserToCCWorker extends Worker {
    private Logger LOGGER = LoggerFactory.getLogger(BPOUserToCCWorker.class);

    @Value("${getCCUrl}")
    private String getCCUrl;
    @Value("${CCSyncStaff}")
    private String CCSyncStaff;
    @Value("${SourceName}")
    private String SourceName;
    @Value("${InterfaceID}")
    private String InterfaceID;
    @Value("${ServiceVersion}")
    private String ServiceVersion;
    @Value("${SourceKey}")
    private String SourceKey;

    @Autowired
    private CommonQueueMapper commonQueueMapper;
    @Autowired
    private BStaffMapper bStaffMapper;

    @Override
    public void run() {
        MDC.put("APP_NAME", BPOUserToCCWorker.class.getSimpleName());
        LOGGER.info("BPOUserToCCWorker.run，工号导入人员信息同步CC开始");

        // 查询BPO工号导入员工信息推送CC系统
        pushNewStaffToCC(EventConstants.EVENT_SEND_STAFF_NEW, "1", "ONLINE");
        LOGGER.info("BPOUserToCCWorker.run，工号导入人员信息同步CC结束");

        LOGGER.info("BPOUserToCCWorker.run，人员离职信息同步CC开始");
        //员工离职信息推送CC系统
        pushNewStaffToCC(EventConstants.EVENT_SEND_STAFF_LEAVE, "3", "QUIT");

        LOGGER.info("BPOUserToCCWorker.run，人员离职信息同步CC结束");

    }

    private void pushNewStaffToCC(int EventType, String sendType, String workStatus) {
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventType);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有bStaff人员需要向CC系统推送");
        } else {
            for (CommonQueue commonQueue : commonQueueList) {
                boolean syncResult = false;
                String resultMessage;
                try {
                    LOGGER.info("开始向CC系统推送bStaff用户, id:{}", commonQueue.getId());
                    Long userId = commonQueue.getOnlyId();
                    if (userId == null) {
                        throw new Exception("bStaff用户ID为空");
                    }
                    BStaff bStaff = bStaffMapper.getById(userId);
                    if (null == bStaff) {
                        throw new Exception("查询不到bStaff用户信息");
                    } else {
                        JSONObject jsonObj = getSendJsonObj(bStaff, sendType, workStatus);
                        JSONObject resJson = CommonWorker.SendToCC(getCCUrl + CCSyncStaff, jsonObj.toString());

                        JSONObject jsonBody = (JSONObject) resJson.get("body");
                        resultMessage = jsonBody.get("MESSAGE").toString();
                        if ("0000".equals(jsonBody.get("CODE"))) {
                            syncResult = true;
                            LOGGER.info("向CC系统推送成功, id:{}", commonQueue.getId());
                        } else {
                            syncResult = false;
                            LOGGER.info("向CC系统推送失败, id:{}", commonQueue.getId() + resultMessage);
                        }
                    }
                } catch (Exception e) {
                    resultMessage = e.getMessage();
                    LOGGER.error("向CC系统推送失败, id:{}, error:{}", commonQueue.getId(), resultMessage);
                }
                // 更新queue表运行结果
                commonQueue.setChangedBy("BPOUserToCCWorker");
                commonQueue.setChangeDate(new Date());
                commonQueue.setRequestNum(commonQueue.getRequestNum() + 1);
                commonQueue.setRequestRemake(resultMessage);
                if (syncResult) {
                    commonQueue.setStatus(1);
                } else {
                    commonQueue.setStatus(0);
                }
                commonQueueMapper.update(commonQueue);
            }
        }
    }

    private JSONObject getSendJsonObj(BStaff bStaff, String sendType, String workStatus) {
        JSONObject json = new JSONObject();
        json.put("head", getJsonHead());
        JSONArray jsonArrBody = new JSONArray();
        //添加体
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        JSONObject DateJsonObject = new JSONObject();
        DateJsonObject.put("Agent_id", isNull(bStaff.getCsId()));//CC工号
        DateJsonObject.put("StaffName", isNull(bStaff.getName()));//姓名
        DateJsonObject.put("E_MAIL", isNull(bStaff.getEmail()));//电子邮箱
        DateJsonObject.put("Mobile", isNull(bStaff.getPhoneNo()));//手机
        DateJsonObject.put("Type", sendType);//类型（1：创建 ，2：修改，3：离职）
        DateJsonObject.put("LoginName", isNull(bStaff.getLeAccount()));//登录名（域名）
        DateJsonObject.put("Gender", isNull(bStaff.getSex().toString()));//性别（0：男，1：女）
        DateJsonObject.put("BOP_ID", isNull(bStaff.getId().toString()));//BPO系统唯一标示ID
        DateJsonObject.put("DEFAULTROLEGROUP", isNull(bStaff.getCcRoleGroupId()));//默认从属组ID
        DateJsonObject.put("WorkStatus", workStatus);//工作状态（ONLINE(在职),QUIT（离职））
        DateJsonObject.put("ModifiedDate", bStaff.getUpdateTime() != null ? sdf.format(bStaff.getUpdateTime()) : "");//修改时间（更新时间）
        jsonArrBody.add(DateJsonObject);
        json.put("body", jsonArrBody);
        System.out.println(json.toString());
        return json;
    }

    //HTTP请求head参数
    private JSONObject getJsonHead() {
        JSONObject jsonHead = new JSONObject();
        // 1. 流水号生成
        Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        int oneRandom = (int) (Math.random() * 1000);
        String serialNo = sdf.format(now) + oneRandom;
        // 2. 来源名称
        jsonHead.put("SourceName", SourceName);
        // 3. 接口编号
        jsonHead.put("InterfaceID", InterfaceID);
        // 4. 时间戳
        Long timeStamp = now.getTime();
        jsonHead.put("TimeStamp", timeStamp);
        // 5. 版本号
        jsonHead.put("ServiceVersion", ServiceVersion);
        // 6. 签名
        String sign = MD5Util.getMD5(SourceKey + "CC" + InterfaceID + "." + timeStamp).toUpperCase();
        jsonHead.put("Sign", sign);
        jsonHead.put("SerialNo", serialNo);
        return jsonHead;
    }

    private String isNull(String result) {
        if (result == null || result.length() == 0) {
            return "";
        } else {
            try {
                return URLEncoder.encode(result, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                LOGGER.error("转码失败，错误信息为：", e.getMessage());
                return result;
            }
        }
    }


    public static void main(String args[]) {
        String sign = MD5Util.getMD5("89370E804A8711E7BA6CFA168F11EB0A" + "CC" + "BPO001" + "." + "1496820999308");
        String md5Str = "F6BB798225671081F378B5E77D3AC46B";
        System.out.println(sign.toUpperCase());
        System.out.println(md5Str);
        System.out.println(sign.toUpperCase().equals(md5Str));
    }
}
