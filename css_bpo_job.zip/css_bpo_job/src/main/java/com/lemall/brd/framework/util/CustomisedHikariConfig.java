package com.lemall.brd.framework.util;

import com.zaxxer.hikari.HikariConfig;

import java.util.Properties;

/**
 * Created by ruanchangming on 2014/11/27.
 */
public class CustomisedHikariConfig extends HikariConfig {
	
    private static String oracle="oracle.";
    private static String mysql="mysql.";
    public CustomisedHikariConfig(String poolName, Properties props){
        super();
        this.setPoolName(poolName);
        Properties dataSourceProperties = new Properties();
        /**取出通用的
         *connectionTestQuery
         * dataSourceClassName
         * cachePrepStmts----
         * prepStmtCacheSize-----
         * prepStmtCacheSqlLimit----
         * useServerPrepStmts---
         * ***/
        if(((String) props.get("datasource.url." + poolName)).contains("oracle")){
            this.setConnectionTestQuery(props.getProperty(oracle+"connectionTestQuery"));
            this.setDataSourceClassName(props.getProperty(oracle+"dataSourceClassName"));
        }else{
            this.setConnectionTestQuery(props.getProperty(mysql+"connectionTestQuery"));
            this.setDataSourceClassName(props.getProperty(mysql+"dataSourceClassName"));
            dataSourceProperties.put("cachePrepStmts", props.getProperty(mysql+"cachePrepStmts"));
            dataSourceProperties.put("prepStmtCacheSize",props.getProperty(mysql+"prepStmtCacheSize"));
            dataSourceProperties.put("prepStmtCacheSqlLimit",props.getProperty(mysql+"prepStmtCacheSqlLimit"));
            dataSourceProperties.put("rewriteBatchedStatements",props.getProperty(mysql+"rewriteBatchedStatements"));
        }
        dataSourceProperties.put("url",(String) props.get("datasource.url." + poolName));
        dataSourceProperties.put("user",(String) props.get("datasource.username." + poolName));
        dataSourceProperties.put("password",(String) props.get("datasource.password." + poolName));
        this.setDataSourceProperties(dataSourceProperties);
        
        String maximumPoolSize = props.getProperty("datasource.maximumPoolSize." + poolName);
        if ( !( maximumPoolSize ==null || maximumPoolSize.isEmpty() ) ) {
        	this.setMaximumPoolSize(Integer.valueOf( maximumPoolSize ));
        }
        
        String maxLifetime = props.getProperty("datasource.maxLifetime." + poolName);
        if ( !( maxLifetime ==null || maxLifetime.isEmpty() ) ) {
        	this.setMaxLifetime(Integer.valueOf( maxLifetime ));
        }
        
        String idleTimeout = props.getProperty("datasource.idleTimeout." + poolName);
        if ( !( idleTimeout ==null || idleTimeout.isEmpty() ) ) {
        	this.setIdleTimeout(Integer.valueOf( idleTimeout ));
        }
    }
}
