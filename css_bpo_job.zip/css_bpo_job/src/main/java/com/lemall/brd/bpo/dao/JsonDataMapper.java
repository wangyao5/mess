package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.JsonData;

/***
 * 审批提交数据信息dao
 *
 * @Author yxh
 * @Version 2017-06-22 16:35:35
 */
public interface JsonDataMapper {

	public JsonData getById(Long id);
	
}
