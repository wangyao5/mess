package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.BWorkFlowDic;

import java.util.List;

/**
 * Created by jianghongwei on 2017/3/7.
 */
public interface BWorkFlowDicMapper {
    BWorkFlowDic getById(Long id);

    List<String> getByCode(List<String> codes);
}
