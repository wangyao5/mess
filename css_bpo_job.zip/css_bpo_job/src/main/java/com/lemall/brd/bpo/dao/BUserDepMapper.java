package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.BUserDep;

import java.util.List;

public interface BUserDepMapper {
    List<BUserDep> getByUserId(Long id);
}
