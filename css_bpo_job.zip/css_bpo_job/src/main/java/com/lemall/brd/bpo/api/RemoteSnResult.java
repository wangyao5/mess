package com.lemall.brd.bpo.api;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lemall.brd.bpo.api.ReData;

import java.util.List;

/**
 * Created by wangwentao on 2016/12/30.
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class RemoteSnResult {
    private String code;
    private String codeMsg;
    private List<ReData> reData;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCodeMsg() {
        return codeMsg;
    }

    public void setCodeMsg(String codeMsg) {
        this.codeMsg = codeMsg;
    }

    public List<ReData> getReData() {
        return reData;
    }

    public void setReData(List<ReData> reData) {
        this.reData = reData;
    }
}
