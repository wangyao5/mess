package com.lemall.brd.bpo.controller;
/**
 * 通过API接口手工运行作业
 */

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import com.lemall.brd.bpo.worker.*;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author yangxinghe
 */
@Controller
@RequestMapping("/worker")
public class WorkerController {
    @Resource
    ApplicationContext context;

    /**
     * 用户权限同步到工作流作业
     *
     * @return
     */
    @RequestMapping("/bPOAuthorityToWFWorker.do")
    @ResponseBody
    public Map<String, String> runInitStockListWorker() {
        Map<String, String> map = new HashMap<>();
        try {
            WorkerThread thread = new WorkerThread(BPOAuthorityToWFWorker.class, "bPOAuthorityToWFWorker", context);
            thread.start();
            map.put("message", "BPOAuthorityToWFWorker is running...");
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return map;
        }
        return map;
    }

    @RequestMapping("/bPODEPToWFWorker.do")
    @ResponseBody
    public Map<String, String> runInitBPODEPToWFWorkerr() {
        Map<String, String> map = new HashMap<>();
        try {
            WorkerThread thread = new WorkerThread(BPODEPToWFWorker.class, "bPODEPToWFWorker", context);
            thread.start();
            map.put("message", "BPODEPToWFWorker is running...");
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return map;
        }
        return map;
    }
    @RequestMapping("/bPOUserToWFWorker.do")
    @ResponseBody
    public Map<String, String> runInitBPOUserToWFWorker() {
        Map<String, String> map = new HashMap<>();
        try {
            WorkerThread thread = new WorkerThread(BPOUserToWFWorker.class, "bPOUserToWFWorker", context);
            thread.start();
            map.put("message", "BPOUserToWFWorker is running...");
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return map;
        }
        return map;
    }

    @RequestMapping("/userDepToWFWorker.do")
    @ResponseBody
    public Map<String, String> runInitUserDepToWFWorker() {
        Map<String, String> map = new HashMap<>();
        try {
            WorkerThread thread = new WorkerThread(UserDepToWFWorker.class, "userDepToWFWorker", context);
            thread.start();
            map.put("message", "UserDepToWFWorker is running...");
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return map;
        }
        return map;
    }

    @RequestMapping("/userFlowerToWFWorker.do")
    @ResponseBody
    public Map<String, String> runInitUserFlowerToWFWorker() {
        Map<String, String> map = new HashMap<>();
        try {
            WorkerThread thread = new WorkerThread(UserFlowerToWFWorker.class, "userFlowerToWFWorker", context);
            thread.start();
            map.put("message", "UserFlowerToWFWorker is running...");
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return map;
        }
        return map;
    }

    @RequestMapping("/userLeaveToLeflowWorker.do")
    @ResponseBody
    public Map<String, String> runUserLeaveToLeflowWorker() {
        Map<String, String> map = new HashMap<>();
        try {
            WorkerThread thread = new WorkerThread(UserLeaveToLeflowWorker.class, "userLeaveToLeflowWorker", context);
            thread.start();
            map.put("message", "UserLeaveToLeflowWorker is running...");
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return map;
        }
        return map;
    }
    @RequestMapping("/bPOUserToCCWorker.do")
    @ResponseBody
    public Map<String, String> runBPOUserToCCWorker() {
        Map<String, String> map = new HashMap<>();
        try {
            WorkerThread thread = new WorkerThread(BPOUserToCCWorker.class, "bPOUserToCCWorker", context);
            thread.start();
            map.put("message", "BPOUserToCCWorker is running...");
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return map;
        }
        return map;
    }
}
