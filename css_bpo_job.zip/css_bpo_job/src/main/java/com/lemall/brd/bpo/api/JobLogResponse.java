package com.lemall.brd.bpo.api;

import lombok.Data;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class JobLogResponse {
	String statusCode;
	
	String errorCode;
}
