package com.lemall.brd.bpo.controller;

import com.lemall.brd.bpo.dao.CommonQueueMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 通过API手动重启任务
 */
@Controller
@RequestMapping("/initQ")
public class InitCommonQueue {
    @Autowired
    private CommonQueueMapper commonQueueMapper;

    /**
     *
     * @param secret
     * @param eventId
     * @param dayNum
     * @return
     */
    @RequestMapping(value = "init.do",method = RequestMethod.POST)
    @ResponseBody
    public String index(@RequestParam("secret") String secret,
                                  @RequestParam("eventId") int eventId,
                                  @RequestParam("dayNum") int dayNum){
        try {
            if(!"965ea3bac761f14f".equals(secret)){
                return "禁止访问！";
            }
            if(dayNum <= 0){
                return "参数错误！";
            }
            commonQueueMapper.updateReqNumByType(eventId,dayNum);
            return "成功！";
        }catch (Exception e){
            e.printStackTrace();
            return "失败！";
        }
    }

}
