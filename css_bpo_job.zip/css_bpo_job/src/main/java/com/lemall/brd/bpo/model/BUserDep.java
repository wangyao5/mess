package com.lemall.brd.bpo.model;

import lombok.Data;

import java.util.Date;

@Data
public class BUserDep implements java.io.Serializable {

    private static final long serialVersionUID = -2404961758249150140L;

    /** 主键 */
    private Long id;

    /** 用户ID */
    private Long userId;

    /** 部门ID */
    private Long depId;

    /** 备注 */
    private String remark;

    /** 创建时间 */
    private Date createTime;

    /** 创建人 */
    private String createUser;

    /** 更新时间 */
    private Date updateTime;

    /** 更新人 */
    private String updateUser;

    /** 是否有效： 0-无效； 1-有效 */
    private Integer yn;
}
