package com.lemall.brd.bpo.worker;

import com.lemall.brd.bpo.dao.BAdjustChangeMapper;
import com.lemall.brd.bpo.dao.BDepMapper;
import com.lemall.brd.bpo.dao.BStaffMapper;
import com.lemall.brd.bpo.dao.CommonQueueMapper;
import com.lemall.brd.bpo.model.*;
import com.lemall.brd.bpo.util.EventConstants;
import com.lemall.brd.framework.util.JsonUtil;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service("userFlowerToWFWorker")
public class UserFlowerToWFWorker extends Worker {
    private Logger LOGGER = LoggerFactory.getLogger(UserFlowerToWFWorker.class);

    @Value("${getWFUrl}")
    private String getWFUrl;
    @Value("${newInstance}")
    private String newInstance;

    @Autowired
    private CommonQueueMapper commonQueueMapper;
    @Autowired
    private BStaffMapper bStaffMapper;
    @Autowired
    private BDepMapper bDepMapper;
    @Autowired
    private BAdjustChangeMapper bAdjustChangeMapper;
    @Value("${secretKey}")
    private String secretKey;

    @Override
    public void run() {
        MDC.put("APP_NAME", UserFlowerToWFWorker.class.getSimpleName());
        LOGGER.info("BPOUserToWFWorker.run，流程作业开始");

        //入职
        userEntry();
        //上线
        online();
//        //岗位调整//组织调整
        station();
//        //离职
        quit();

        LOGGER.info("BPOUserToWFWorker.run，流程作业结束");
    }

    /**
     * 入职
     */
    private void userEntry(){
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_ENTRY);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有入职流程");
        } else {
            String url = getWFUrl + newInstance;

            for (CommonQueue commonQueue : commonQueueList) {
                try {
                    //人员信息

                    BStaff staff = bStaffMapper.getById(commonQueue.getOnlyId());
                    HashedMap param = new HashedMap();

                    param.put("flowId", "bpoAdd");
                    param.put("actionId", "addRequest");
                    param.put("title", staff.getName() + "申请入职");
                    //扩展数据
                    HashedMap map = new HashedMap();
                    flowQueue(url, commonQueue, staff, param, map);

                } catch (Exception e) {
                    LOGGER.info("get param sign error! and message is:{}", e.getMessage());
                }
            }
        }

    }

    /**
     * 上线
     */
    private void online(){
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_ONLINE);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有上线流程");
        } else {
            String url = getWFUrl + newInstance;

            for (CommonQueue commonQueue : commonQueueList) {
                try {
                    //人员信息
                    BStaff staff = bStaffMapper.getById(commonQueue.getOnlyId());

                    HashedMap param = new HashedMap();
                    param.put("flowId", "bpoOnLine");
                    param.put("actionId", "onLineRequest");
                    param.put("title", staff.getName() + "的上线流程");
                    //扩展数据
                    HashedMap map = new HashedMap();
                    flowQueue(url, commonQueue, staff, param, map);

                } catch (Exception e) {
                    LOGGER.info("get param sign error! and message is:{}", e.getMessage());
                }
            }
        }
    }
    /**
     * 岗位部门调整
     */
    private void station(){
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_ORGANIZATION);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有岗位调整流程");
        } else {
            String url = getWFUrl + newInstance;

            for (CommonQueue commonQueue : commonQueueList) {
                try {
                    //人员信息
                    long adjustId = commonQueue.getOnlyId();
                    AdjustChange change = bAdjustChangeMapper.selectById(adjustId);
                    //岗位调整中间表

                    BStaff staff = bStaffMapper.getById(change.getStaffId());

                    HashedMap param = new HashedMap();
                    param.put("flowId", "bpoJobAdjust");
                    param.put("actionId", "jobAdjustRequest");
                    String str = change.getChangeType() == 0 ? "申请部门调整" :"申请岗位调整";
                    param.put("title", staff.getName() + str);
                    //扩展数据
                    HashedMap map = new HashedMap();
                    map.put("adjustId", adjustId);
                    flowQueue(url, commonQueue, staff, param, map);

                } catch (Exception e) {
                    LOGGER.info("get param sign error! and message is:{}", e.getMessage());
                }
            }
        }
    }
    /**
     * 离职
     */
    public void quit(){
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_QUIT);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有离职流程");
        } else {
            String url = getWFUrl + newInstance;

            for (CommonQueue commonQueue : commonQueueList) {
                try {
                    //人员信息
                    BStaff staff = bStaffMapper.getById(commonQueue.getOnlyId());

                    HashedMap param = new HashedMap();
                    param.put("flowId", "bpoDimission");
                    param.put("actionId", "dimissionRequest");
                    param.put("title", staff.getName() + "申请离职");
                    //扩展数据
                    HashedMap map = new HashedMap();
                    flowQueue(url, commonQueue, staff, param, map);

                } catch (Exception e) {
                    LOGGER.info("get param sign error! and message is:{}", e.getMessage());
                }
            }
        }
    }

    private void flowQueue(String url, CommonQueue commonQueue, BStaff staff, Map<String, String> param, HashedMap map) throws IOException {
        BDep dep = bDepMapper.getById(staff.getDepId());

        param.put("operatorType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
        param.put("assignGroupType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
        param.put("assignGroupId", staff.getDepId() + "");//分配处理组id
        param.put("operatorId", commonQueue.getCreatedBy());//分配处理组id

        map.put("depName", dep.getName());
        map.put("name", staff.getName());
        map.put("csId", staff.getCsId() == null ? "" : staff.getCsId());
        map.put("staffId", staff.getId());
        map.put("leAccount", staff.getLeAccount() == null ? "" : staff.getLeAccount());
        String data = JsonUtil.toJsonObject(map);
        param.put("data", data);

        Map<String, String> result = CommonWorker.userToWF(url, param, secretKey);
        if ("0".equals(result.get("status"))) {
            commonQueue.setStatus(1);
        }else{
            commonQueue.setStatus(0);
        }
        commonQueue.setRequestRemake(result.get("message"));
        commonQueue.setChangedBy("userEntry");
        commonQueue.setChangeDate(new Date());
        commonQueue.setRequestNum(commonQueue.getRequestNum() + 1);
        commonQueueMapper.update(commonQueue);
    }


}
