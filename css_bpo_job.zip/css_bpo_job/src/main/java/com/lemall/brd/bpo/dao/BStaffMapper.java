package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.BStaff;

public interface BStaffMapper {
    BStaff getById(Long id);
}
