package com.lemall.brd.bpo.model;

/**
 * 领域常量
 * 
 * @author 
 *
 */
public final class Constants {
    //发送到工作流url参数partner
    public final static String Send_WorkFlow_Url_Parameter_Partner="partner";
    //发送到工作流url参数partner value
    public final static String Send_WorkFlow_Url_Parameter_Partner_Value="BPO";
    //发送到工作流url参数sign
    public final static String Send_WorkFlow_Url_Parameter_Sign="sign";
    //发送到工作流url参数timestamp
    public final static String Send_WorkFlow_Url_Parameter_Timestamp="timestamp";
    //调用工作流签名
    public final static String SIGN_METHOD_MD5="secret";

    public final static String Send_WorkFlow_Url_Parameter_UserType_Value="css";
}
