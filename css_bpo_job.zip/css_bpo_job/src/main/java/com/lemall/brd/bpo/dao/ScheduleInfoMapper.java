package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.SchedulingInfo;
import com.lemall.brd.bpo.query.SchedulingInfoQuery;

import java.util.List;

/**
 * Created by yangxinghe on 2017/6/21.
 */
public interface ScheduleInfoMapper {
    List<SchedulingInfo> queryBySid(Long id);

    int insertsBySId(Long id);

    /**
     * 按时间段、部门删除数据
     * @param schedulingInfoQuery
     * @return
     */
    int deleteByQuery(SchedulingInfoQuery schedulingInfoQuery);

    /**
     * 查詢需要刪除的数据
     * @param schedulingInfoQuery
     * @return
     */
    List<Long> queryNeedDelInfoId(SchedulingInfoQuery schedulingInfoQuery);

    /**
     * 按部门、日期删除数据
     * @param schedulingInfoQuery
     * @retur
     */
    int deletesByDeptAndDate(SchedulingInfoQuery schedulingInfoQuery);

    /**
     * 根据id 删除记录
     * @param needDelIdList
     * @return
     */
    int deleteInfoBySiIds(List<Long> needDelIdList);
}
