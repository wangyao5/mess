package com.lemall.brd.bpo.model;

import java.util.Date;

/**
 * 员工信息类，区别于User（staff上线后变为user）
 *
 * @Author menghan
 * @Version 2017-01-05 18:08:42
 */
public class AdjustChange implements java.io.Serializable {

    private static final long serialVersionUID = -4249390515831267797L;

    private Long id;
    private Long staffId;
    private Integer oldPost;
    private Integer newPost;
    private Long oldDepartment;
    private Long newDepartment;
    private Date changeDate;
    private String reason;
    private int changeType;

    public int getChangeType() {
        return changeType;
    }

    public void setChangeType(int changeType) {
        this.changeType = changeType;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }

    public Integer getOldPost() {
        return oldPost;
    }

    public void setOldPost(Integer oldPost) {
        this.oldPost = oldPost;
    }

    public Integer getNewPost() {
        return newPost;
    }

    public void setNewPost(Integer newPost) {
        this.newPost = newPost;
    }

    public Long getOldDepartment() {
        return oldDepartment;
    }

    public void setOldDepartment(Long oldDepartment) {
        this.oldDepartment = oldDepartment;
    }

    public Long getNewDepartment() {
        return newDepartment;
    }

    public void setNewDepartment(Long newDepartment) {
        this.newDepartment = newDepartment;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
