package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.AdjustChange;

public interface BAdjustChangeMapper {
    AdjustChange selectById(Long id);
}
