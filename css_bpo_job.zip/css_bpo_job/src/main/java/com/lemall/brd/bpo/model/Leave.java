package com.lemall.brd.bpo.model;

import java.util.Date;

/**
 * 员工请假类
 */
public class Leave implements java.io.Serializable {

    private static final long serialVersionUID = -419586844223438610L;

    /**

     * Id自增
     */
    private Long id;
    /**
     * 员工ID
     */
    private Long staffId;
    /**
     * 请假类型
     */
    private Integer leaveType;
    /**
     * 请假开始时间
     */
    private Date leaveStartTime;
    /**
     * 请假结束时间
     */
    private Date leaveEndTime;
    /**
     * 请假天数
     */
    private Long leaveDays;
    /**
     * 原因说明
     */
    private String leaveDesc;
    /**
     * 审批状态
     */
    private Integer status;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 更新时间
     */
    private Date updateTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }

    public Integer getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(Integer leaveType) {
        this.leaveType = leaveType;
    }

    public Date getLeaveStartTime() {
        return leaveStartTime;
    }

    public void setLeaveStartTime(Date leaveStartTime) {
        this.leaveStartTime = leaveStartTime;
    }

    public Date getLeaveEndTime() {
        return leaveEndTime;
    }

    public void setLeaveEndTime(Date leaveEndTime) {
        this.leaveEndTime = leaveEndTime;
    }

    public Long getLeaveDays() {
        return leaveDays;
    }

    public void setLeaveDays(Long leaveDays) {
        this.leaveDays = leaveDays;
    }

    public String getLeaveDesc() {
        return leaveDesc;
    }

    public void setLeaveDesc(String leaveDesc) {
        this.leaveDesc = leaveDesc;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
