package com.lemall.brd.framework.exception;

/**
 * 接口服务异常
 */
public class ServiceException extends Exception {
	private static final long serialVersionUID = -4105545144097112952L;
	/**
	 * 状态码（0时表示正常,大于0的时候是一个9位的错误编码）
	 */
	private String status;

	/**
	 * 错误的附加信息（附加信息尽量是英文的,而且尽量是一个完整的陈述句）
	 */
	private String message;

	public ServiceException(String status, String message) {
		this.message = message;
		this.status = status;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

	public String getStatus() {
		return this.status;
	}
}
