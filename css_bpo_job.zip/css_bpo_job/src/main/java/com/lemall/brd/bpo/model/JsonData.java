package com.lemall.brd.bpo.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 审批管理中，使用json类型存储审批提交的数据
 *
 * @Author menghan
 * @Version 2017-06-22 16:31:34
 */
@Data
public class JsonData implements Serializable {

    private static final long serialVersionUID = 2133272270083558961L;
    /**
     * 主键
     */
    private Long id;
    /**
     * 审批类型：1支援  2班次调整  3餐时  4加班  5换班  6请假
     */
    private Integer type;
    /**
     * 审批提交的数据
     */
    private String jsonData;

    private String createUser;

    private Date createTime;

    private String updateUser;

    private Date updateTime;
    /**
     * 0无效，1有效
     */
    private Integer yn;
}
