package com.lemall.brd.bpo.controller;
/**
 * 作业运行线程类
 */
import com.lemall.brd.bpo.worker.Worker;
import org.springframework.context.ApplicationContext;

public class WorkerThread extends Thread  {
	
	private String workerName;
	
	ApplicationContext context;
	Class<? extends Worker> clazz;
	<T> WorkerThread(Class<? extends Worker> clazz, String workerName,ApplicationContext context){
		this.clazz=clazz;
		this.workerName=workerName;
		this.context=context;
	}

	@Override
	public void run() {
		((Worker) context.getBean(workerName,clazz)).run();
	}

}
