package com.lemall.brd.bpo.dao;

import java.util.List;

/**
 * Created by jianghongwei on 2017/3/18.
 */
public interface ResourceRoleMapper {
    List<Long> queryResourceListByRoleIds(List<Long> roleIds);

}
