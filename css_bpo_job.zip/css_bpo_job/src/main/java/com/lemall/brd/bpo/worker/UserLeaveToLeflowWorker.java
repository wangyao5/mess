package com.lemall.brd.bpo.worker;

import com.lemall.brd.bpo.dao.*;
import com.lemall.brd.bpo.model.*;
import com.lemall.brd.bpo.util.EventConstants;
import com.lemall.brd.framework.util.JsonUtil;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service("userLeaveToLeflowWorker")
public class UserLeaveToLeflowWorker extends Worker {
    private Logger LOGGER = LoggerFactory.getLogger(UserFlowerToWFWorker.class);

    @Value("${getWFUrl}")
    private String getWFUrl;
    @Value("${newInstance}")
    private String newInstance;

    @Autowired
    private CommonQueueMapper commonQueueMapper;
    @Autowired
    private BStaffMapper bStaffMapper;
    @Autowired
    private BDepMapper bDepMapper;
    @Autowired
    private LeaveMapper leaveMapper;
    @Autowired
    private BDicMapper bDicMapper;
    @Value("${secretKey}")
    private String secretKey;

    @Override
    public void run() {
        MDC.put("APP_NAME", UserLeaveToLeflowWorker.class.getSimpleName());
        LOGGER.info("BPOUserToWFWorker.run，流程作业开始");

        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_LEAVE);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有请假任务");
        } else {
            String url = getWFUrl + newInstance;

            for (CommonQueue commonQueue : commonQueueList) {
                try {
                    //请假任务信息
                    Leave leave = leaveMapper.getById(commonQueue.getOnlyId());
                    //人员信息
                    BStaff staff = bStaffMapper.getById(leave.getStaffId());
                    HashedMap param = new HashedMap();

                    String leaveType = "假";
                    Dic leaveTypeDic = bDicMapper.getDicByNum(19L, (long)leave.getLeaveType());
                    if ( leaveTypeDic != null ) {
                        leaveType = leaveTypeDic.getName();
                    }

                    String title = staff.getName() + "请" + leaveType + leave.getLeaveDays() + "天";

                    param.put("flowId", "bpoLeave");
                    param.put("actionId", "leaveRequest");
                    param.put("title", title);
                    //扩展数据
                    HashedMap map = new HashedMap();

                    BDep dep = bDepMapper.getById(staff.getDepId());

                    param.put("operatorType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
                    param.put("assignGroupType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
                    param.put("assignGroupId", staff.getDepId() + "");//分配处理组id
                    param.put("operatorId", commonQueue.getCreatedBy());//分配处理组id
                    param.put("outId", commonQueue.getOnlyId().toString());

                    map.put("depName", dep.getName());
                    map.put("name", staff.getName());
                    map.put("csId", staff.getCsId() == null ? "" : staff.getCsId());
                    map.put("staffId", staff.getId());
                    String data = JsonUtil.toJsonObject(map);
                    param.put("data", data);

                    Map<String, String> result = CommonWorker.userToWF(url, param, secretKey);
                    if ("0".equals(result.get("status"))) {
                        leave.setStatus(60);
                        leave.setUpdateUser("UserLeaveToLeflowWorker");
                        leaveMapper.updateStatus(leave);

                        processQueueStatus(commonQueue, true);
                    }else{
                        processQueueStatus(commonQueue, false);
                    }
                    commonQueue.setRequestRemake(result.get("message"));
                    commonQueue.setChangedBy("UserLeaveToLeflowWorker");
                    commonQueue.setChangeDate(new Date());
                    commonQueueMapper.update(commonQueue);
                } catch (Exception e) {
                    LOGGER.info("get param sign error! and message is:{}", e.getMessage());
                }
            }
        }

    }

    /**
     * 根据运行结果处理queue状态
     * 运行成功，更新queue为成功
     * 运行失败10次后，更新queue为失败
     * @param queue
     * @param rlt
     * @return
     */
    private void processQueueStatus(CommonQueue queue, boolean rlt) {
        queue.setRequestNum(queue.getRequestNum() + 1);
        if ( rlt == true ) {
            queue.setStatus(1);
        } else {
            if ( queue.getRequestNum() >= 10 ) {
                queue.setStatus(2);
            } else {
                queue.setStatus(0);
            }
        }
    }
}
