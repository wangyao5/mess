package com.lemall.brd.bpo.worker;

import com.alibaba.dubbo.common.json.Jackson;
import com.lemall.brd.bpo.dao.*;
import com.lemall.brd.bpo.model.*;
import com.lemall.brd.bpo.query.UserRoleQuery;
import com.lemall.brd.bpo.util.EventConstants;
import com.lemall.brd.framework.util.HttpClientUtil;
import com.lemall.brd.framework.util.JsonUtil;
import com.lemall.brd.framework.util.MD5Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * 延保获取Finish作业
 */
@Service("bPOAuthorityToWFWorker")
public class BPOAuthorityToWFWorker extends Worker {

    @Value("${getWFUrl}")
    private String getWFUrl;
    @Value("${getWFUrlAddAuth}")
    private String getWFUrlAddAuth;
    @Value("${syncAuth}")
    private String syncAuth;


    @Value("${getWFUrlDeleteAuth}")
    private String getWFUrlDeleteAuth;
    @Value("${secretKey}")
    private String secretKey;
    @Value("#{'${codeList}'.split(',')}")
    private List<String> codeList;

    private Logger LOGGER = LoggerFactory.getLogger(BPOAuthorityToWFWorker.class);


    @Autowired
    private CommonQueueMapper commonQueueMapper;
    @Autowired
    private BWorkFlowDicMapper bWorkFlowDicMapper;
    @Autowired
    private UserRoleMapper userRoleMapper;
    @Autowired
    private ResourceMapper resourceMapper;
    @Autowired
    private ResourceRoleMapper resourceRoleMapper;


    /**
     * 用户权限作业主函数
     */
    @Override
    public void run() {
        MDC.put("APP_NAME", BPOAuthorityToWFWorker.class.getSimpleName());
        LOGGER.info("BPOAuthorityToWFWorker.run，人员权限作业开始");
        // 查询初始状态的延保合同
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_ROLE);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有初始状态的人员权限信息");
        } else {
            for (CommonQueue commonQueue : commonQueueList) {
                try {
                Long onlyId = commonQueue.getOnlyId();
                UserRoleQuery query=new UserRoleQuery();
                query.setUserId(onlyId);
                    //根据人员ID查询用户角色ID
                List<Long> userRoleList=userRoleMapper.queryUserRoleList(query);
                    if(CollectionUtils.isEmpty(userRoleList)){
                        LOGGER.info("BPOAuthorityToWFWorker. get userRoleList is null ");
                        updateCommonQueue(commonQueue);
                        continue;
                    }
                    //查询用户角色ID对应的权限资源ID列表
                List<Long> rlist= resourceRoleMapper.queryResourceListByRoleIds(userRoleList);
                if(CollectionUtils.isEmpty(rlist)){
                    LOGGER.info("BPOAuthorityToWFWorker. get rlist is null ");
                    updateCommonQueue(commonQueue);
                    continue;
                }
                    //查询权限资源的信息CODE，并与配置中的信息进行比对，比对通过就推送
                List<String> scodelist=resourceMapper.queryCode(rlist);
                if(CollectionUtils.isEmpty(scodelist)){
                    LOGGER.info("BPOAuthorityToWFWorker. get scodelist is null ");
                    updateCommonQueue(commonQueue);
                    continue;
                }
                    //记录可以执行的资源
                List<String> tolist=new ArrayList<>();
                for(String c:scodelist){
                    if(codeList.contains(c)) {
                        tolist.add(c);
                    }
                }
                if(tolist.isEmpty()){
                    LOGGER.info("BPOAuthorityToWFWorker. get code list is null ");
                    updateCommonQueue(commonQueue);
                    continue;
                }
                    //根据资源CODE获取工作流配置的流程信息
                List<String> bfdlist= bWorkFlowDicMapper.getByCode(tolist);
                if(CollectionUtils.isEmpty(bfdlist)){
                    LOGGER.info("BPOAuthorityToWFWorker. 获取配置为空 bfdlist is null ");
                    updateCommonQueue(commonQueue);
                    continue;
                }
                    //开始推送数据
                boolean  isFinish=userAuthorityToWF(bfdlist,getWFUrl+syncAuth,onlyId,secretKey);


                    commonQueue.setChangedBy("BPOAuthorityToWFWorker");
                    commonQueue.setChangeDate(new Date());
                    commonQueue.setRequestNum(commonQueue.getRequestNum()+1);
                    if(isFinish) {
                        commonQueue.setStatus(1);
                    }
                    commonQueueMapper.update(commonQueue);
                } catch (Exception e) {
                    String message = "BPOAuthorityToWFWorker.updateStatus2Finish.error";
                    updateCommonQueue(commonQueue);
                    e.printStackTrace();
                }
            }
        }
        LOGGER.info("BPOAuthorityToWFWorker.run，BPO人员权限作业结束");
    }

    private void updateCommonQueue(CommonQueue commonQueue){
        commonQueue.setChangedBy("BPOAuthorityToWFWorker");
        commonQueue.setChangeDate(new Date());
        commonQueue.setRequestNum(commonQueue.getRequestNum()+1);
        commonQueueMapper.update(commonQueue);
    }



    private boolean userAuthorityToWF(List<String> list, String url,Long userId,String secretKey){
        Map<String, String> param = new HashMap<String, String>();
        param.put(Constants.Send_WorkFlow_Url_Parameter_Partner, Constants.Send_WorkFlow_Url_Parameter_Partner_Value);
        String timestamp=String.valueOf(System.currentTimeMillis());
        param.put(Constants.Send_WorkFlow_Url_Parameter_Timestamp, timestamp.substring(0, timestamp.length()-3));
        param.put("userType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
        param.put("userId", String.valueOf(userId));
        String json="[";
        int i=0;
        for (String s:list){
            i++;
            if(i<list.size()) {
                json += s + ",";
            }
            if(i==list.size()) {
                json += s + "]";
            }

        }
        param.put("authList", json);
        try {
            param.put("sign", MD5Util.signTopRequest(param,secretKey));
            LOGGER.info("start put param to workflow url:{} and map is:{}",url,param.toString());
            String r= HttpClientUtil.postForObject(url,"",param);
            LOGGER.info("get result from workflow :{} ",r);
            HashMap<String,String> rmap= JsonUtil.fromJsonObject(r,HashMap.class);
            if(!rmap.isEmpty()&&"0".equals(rmap.get("status"))) {
                return Boolean.TRUE;
            }
        } catch (Exception e) {
            LOGGER.info("get param sign error! and message is:{}",e.getMessage());
        }
        return Boolean.FALSE;

    }




}
 