package com.lemall.brd.bpo.model;

import lombok.Data;

import java.util.Date;

/**
 *  BPO排班表
 *  yangxinghe
 *  2017-05-31 21:59:56
 */
@Data
public class Schedule implements java.io.Serializable{
	private static final long serialVersionUID = -4678194852660102071L;
	/**主键*/
	private Long id;
	/**部门id-记录职场信息*/
	private Long depId;
	/**业务id*/
	private Long busId;
	/**导入起始日期*/
	private Date beginTime;
	/**导入结束日期*/
	private Date endTime;
	/**创建时间*/
	private Date createTime;
	/**创建人*/
	private String createUser;
	/**修改时间*/
	private Date updateTime;
	/**修改人*/
	private String updateUser;
	/**是否有效 0删除 1未删除*/
	private Integer yn;
}
