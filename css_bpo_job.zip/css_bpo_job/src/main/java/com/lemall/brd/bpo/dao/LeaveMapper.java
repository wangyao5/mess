package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.Leave;

public interface LeaveMapper {
    Leave getById(Long id);

    int updateStatus(Leave record);
}
