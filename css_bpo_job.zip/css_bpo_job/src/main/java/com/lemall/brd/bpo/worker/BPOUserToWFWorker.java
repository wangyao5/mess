package com.lemall.brd.bpo.worker;

import com.lemall.brd.bpo.dao.BUserMapper;
import com.lemall.brd.bpo.dao.CommonQueueMapper;
import com.lemall.brd.bpo.model.BUser;
import com.lemall.brd.bpo.model.CommonQueue;
import com.lemall.brd.bpo.model.Constants;
import com.lemall.brd.bpo.util.EventConstants;
import com.lemall.brd.framework.exception.ServiceException;
import com.lemall.brd.framework.util.HttpClientUtil;
import com.lemall.brd.framework.util.JsonUtil;
import com.lemall.brd.framework.util.MD5Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jianghongwei on 2017/3/3.
 */
@Service("bPOUserToWFWorker")
public class BPOUserToWFWorker extends Worker{
    private Logger LOGGER = LoggerFactory.getLogger(BPOUserToWFWorker.class);

    @Value("${getWFUrl}")
    private String getWFUrl;
    @Value("${getWFUrlCreatUser}")
    private String getWFUrlCreatUser;
    @Value("${secretKey}")
    private String secretKey;

    @Autowired
    private CommonQueueMapper commonQueueMapper;
    @Autowired
    private BUserMapper bUserMapper;
    @Override
    public void run() {
        MDC.put("APP_NAME", BPOUserToWFWorker.class.getSimpleName());
        // 查询初始状态的延保合同
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_STAFF_ADD);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有人员同步信息");
        } else {
            for (CommonQueue commonQueue : commonQueueList) {
                boolean syncResult = true;
                String resultMessage;
                try{
                    LOGGER.info("开始同步用户, id:{}",commonQueue.getId());

                    syncUserToLeflow(commonQueue.getOnlyId());

                    resultMessage = "同步用户成功";
                    syncResult = true;
                    LOGGER.info("同步用户成功, id:{}",commonQueue.getId());
                } catch (Exception e) {
                    syncResult = false;
                    resultMessage = e.getMessage();
                    LOGGER.error("同步用户失败, id:{}, error:{}",commonQueue.getId(),resultMessage);
                }

                // 更新queue表运行结果
                commonQueue.setChangedBy("BPOUserToWFWorker");
                commonQueue.setChangeDate(new Date());
                commonQueue.setRequestNum(commonQueue.getRequestNum() + 1);
                commonQueue.setRequestRemake(resultMessage);
                if (syncResult) {
                    commonQueue.setStatus(1);
                } else {
                    commonQueue.setStatus(0);
                }
                commonQueueMapper.update(commonQueue);
            }
        }
    }

    private void syncUserToLeflow(Long userId) throws Exception {
        if(userId==null){
            throw new Exception("用户ID为空");
        }

        BUser bUser=bUserMapper.getUserById(userId);
        if ( null == bUser ) {
            throw new Exception("查询不到用户信息");
        } else {
            userToWF(bUser, secretKey);
        }
    }

    private void userToWF(BUser bUser,String secretKey) throws ServiceException {
        HashMap<String,String> rmap = null; // 返回值
        String url=getWFUrl+getWFUrlCreatUser;
        Map<String, String> param = new HashMap<String, String>();
        param.put(Constants.Send_WorkFlow_Url_Parameter_Partner, Constants.Send_WorkFlow_Url_Parameter_Partner_Value);
        String timestamp=String.valueOf(System.currentTimeMillis());
        param.put(Constants.Send_WorkFlow_Url_Parameter_Timestamp, timestamp.substring(0, timestamp.length()-3));
        param.put("userType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
        param.put("userId", String.valueOf(bUser.getId()));
        param.put("userName", bUser.getName());
        try {
            param.put("sign", MD5Util.signTopRequest(param,secretKey));
            LOGGER.info("start put param to workflow url:{} and map is:{}",url,param.toString());
            String r=HttpClientUtil.postForObject(url,"",param);
            LOGGER.info("get result from workflow :{} ",r);
            rmap=JsonUtil.fromJsonObject(r,HashMap.class);
        } catch (Exception e) {
            LOGGER.info("get param sign error! and message is:{}",e.getMessage());
        }

        String status = rmap.get("status");
        String message = rmap.get("message");
        if(!"0".equals(status)) {
            throw new ServiceException(status, message);
        }
    }
}
