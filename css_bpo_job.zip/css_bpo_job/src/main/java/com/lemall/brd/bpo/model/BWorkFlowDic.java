package com.lemall.brd.bpo.model;

import lombok.Data;

import java.util.Date;

/**
 * Created by jianghongwei on 2017/3/7.
 */
@Data
public class BWorkFlowDic {
    private Long id;
    private String flowId;
    private String statusId;
    private String actionId;
    private Date creationDate;
    private String createdBy;
    private Date changeDate;
    private String changedBy;
    private String json;
    private String rCode;
}
