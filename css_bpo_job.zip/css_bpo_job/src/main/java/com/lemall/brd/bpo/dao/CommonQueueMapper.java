package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.CommonQueue;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CommonQueueMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CommonQueue record);

    int insertSelective(CommonQueue record);

    CommonQueue selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(CommonQueue record);

    int updateByPrimaryKey(CommonQueue record);

    Integer update(CommonQueue record);

    List<CommonQueue> getInitList(@Param("status")int status,@Param("eventId") int eventId);

    void updateReqNumByType(@Param("eventId") int eventId,@Param("dayNum") int dayNum);
}