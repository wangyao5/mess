package com.lemall.brd.bpo.worker;

import com.lemall.brd.bpo.dao.BDepMapper;
import com.lemall.brd.bpo.dao.CommonQueueMapper;
import com.lemall.brd.bpo.model.BDep;
import com.lemall.brd.bpo.model.CommonQueue;
import com.lemall.brd.bpo.model.Constants;
import com.lemall.brd.bpo.util.EventConstants;
import com.lemall.brd.framework.util.HttpClientUtil;
import com.lemall.brd.framework.util.JsonUtil;
import com.lemall.brd.framework.util.MD5Util;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("bPODEPToWFWorker")
public class BPODEPToWFWorker extends Worker {
    private Logger LOGGER = LoggerFactory.getLogger(BPODEPToWFWorker.class);

    @Value("${getWFUrl}")
    private String getWFUrl;
    @Value("${getWFURLCreateGroup}")
    private String getWFURLCreateGroup;
    @Value("${getWFURLDeleteGroup}")
    private String getWFURLDeleteGroup;
    @Value("${secretKey}")
    private String secretKey;

    @Autowired
    private CommonQueueMapper commonQueueMapper;
    @Autowired
    private BDepMapper bDepMapper;

    @Override
    public void run() {
        MDC.put("APP_NAME", BPODEPToWFWorker.class.getSimpleName());
        LOGGER.info("BPOUserToWFWorker.run，人员同步作业开始");

        //新增
        depAdd();
        //删除，因业务需要，禁用部门时，如果删除工作流中的部门数据，在BPO推送数据权限时，会检查问题，无法推送
//        depDelete();

        LOGGER.info("BPOUserToWFWorker.run，人员同步作业结束");
    }

    private void depAdd(){
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_DEP_ADD);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有BPO同步部门信息");
        } else {
            String url = getWFUrl + getWFURLCreateGroup;

            for (CommonQueue commonQueue : commonQueueList) {
                try {
                    BDep dep = bDepMapper.getById(commonQueue.getOnlyId());

                    Map<String, String> param = new HashedMap();
                    param.put("groupType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
                    param.put("groupId", String.valueOf(dep.getId()));
                    param.put("groupName", dep.getName());


                    Map<String, String> rmap = CommonWorker.userToWF(url, param, secretKey);
                    if ("0".equals(rmap.get("status"))) {
                        commonQueue.setStatus(1);
                    }else{
                        commonQueue.setStatus(0);
                    }
                    commonQueue.setRequestRemake(rmap.get("message"));
                    commonQueue.setChangedBy("BPODEPToWFWorker");
                    commonQueue.setChangeDate(new Date());
                    commonQueue.setRequestNum(commonQueue.getRequestNum() + 1);
                    commonQueueMapper.update(commonQueue);

                } catch (Exception e) {
                    LOGGER.info("get param sign error! and message is:{}", e.getMessage());
                }
             }
        }

    }
    public void depDelete(){
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_DEP_DISABLE);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有BPO同步部门信息");
        } else {
            String url = getWFUrl + getWFURLDeleteGroup;
            for (CommonQueue commonQueue : commonQueueList) {
                try {
                    BDep dep = bDepMapper.getById(commonQueue.getOnlyId());

                    Map<String, String> param = new HashedMap();
                    param.put("groupType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
                    param.put("groupId", String.valueOf(dep.getId()));
                    Map<String, String> rmap = CommonWorker.userToWF(url, param, secretKey);
                    if ("0".equals(rmap.get("status"))) {
                        commonQueue.setStatus(1);
                    }else{
                        commonQueue.setStatus(0);
                    }
                    commonQueue.setRequestRemake(rmap.get("message"));
                    commonQueue.setChangedBy("BPODEPToWFWorker");
                    commonQueue.setChangeDate(new Date());
                    commonQueue.setRequestNum(commonQueue.getRequestNum() + 1);
                    commonQueueMapper.update(commonQueue);
                } catch (Exception e) {
                    LOGGER.info("get param sign error! and message is:{}", e.getMessage());
                }
            }
        }
    }



}
