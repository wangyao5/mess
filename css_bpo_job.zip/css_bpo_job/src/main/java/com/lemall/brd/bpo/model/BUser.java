package com.lemall.brd.bpo.model;

import lombok.Data;

import java.util.Date;

/**
 * Created by jianghongwei on 2017/3/2.
 */
@Data
public class BUser {
    private Long id;
    private Long staffId;
    private Long depId;
    private String userName;
    private String passWord;
    private Integer isCharged;
    //中文名
    private String allowDepIds;
    private String name;
    private String eMail;
    private String createUser;
    private Date createTime;
    private String updateUser;
    private Date updateTime;
    private String remark;
    private Integer yn;
    private Date lastModifyTime;
    private String code;


}
