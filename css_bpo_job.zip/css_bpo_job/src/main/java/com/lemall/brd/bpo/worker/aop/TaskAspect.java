package com.lemall.brd.bpo.worker.aop;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.annotation.Resource;

import com.lemall.brd.bpo.api.JobLogRequest;
import com.lemall.brd.framework.util.JsonUtil;
import org.aspectj.lang.JoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;

import com.lemall.brd.framework.util.HttpClientUtil;
import com.lemall.brd.bpo.api.JobLogResponse;

public class TaskAspect {
	private static Logger LOGGER = LoggerFactory.getLogger(TaskAspect.class);

	@Resource
	private Properties configProperties;

	@Value("${job.enableMonitor}")
	private boolean enableMonitor;
	@Value("${job.monitorUrl}")
	private String url;

	private Date startTime;
	public void before(JoinPoint jp) {
		MDC.put("APP_NAME", jp.getTarget().getClass().getSimpleName());

		String method = jp.getSignature().toShortString();
		LOGGER.info("[Start]<{}>", method);
		startTime = new Date();
	}

	public void afterReturning(JoinPoint jp) {
		String method = jp.getSignature().toShortString();
		String workerName = jp.getTarget().getClass().getSimpleName();
		callJobLogApi(workerName);
		LOGGER.info("[End]<{}>", method);
	}

	public void afterThrowing(JoinPoint jp, Exception exception) {
		String method = jp.getSignature().toShortString();
		LOGGER.error("执行{}方法时抛出了异常: {}", method, exception);
	}

	private void callJobLogApi(String workerName) {
		// 调用job log监控接口
		if (enableMonitor) {
			String jobId = configProperties.getProperty("job." + workerName);
			if (null == jobId || jobId.isEmpty()) {
				LOGGER.warn("No job id for {}", workerName);
			} else {
				Map<String, String> map = new HashMap<>();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

				JobLogRequest requestObj = new JobLogRequest();
				requestObj.setJob_id(jobId);
				requestObj.setStart_time(formatter.format(startTime));
				requestObj.setRunning_ip( getLocalIP() );
				requestObj.setLast_processed_time(formatter.format(new Date()));
				String requestJson = "";
				try {
					requestJson = JsonUtil.toJsonObject(requestObj);
				} catch (IOException e1) {
					LOGGER.error("json转换出错, error:()", e1.getMessage());
				}
				map.put("data", requestJson);
				map.put("result_format", "JSON");

				try {
					String reponseStr = HttpClientUtil.postForObject(url, "", map);
					JobLogResponse reponse = JsonUtil.fromJsonObject(reponseStr,JobLogResponse.class);
					if ("0".equals(reponse.getStatusCode())) {
						LOGGER.info("Done job monitor for <{}>", workerName);
					} else {
						LOGGER.error("Job monitor error, statusCode:{}, errorCode:{}", reponse.getStatusCode(), reponse.getErrorCode());
					}
				} catch (Exception e) { 
					LOGGER.error("调用job log接口异常：", e);
				}
			}
		}
	}

	/**
	 * 判断是否Windows操作系统
	 * @return
     */
	public static boolean isWindowsOS(){
		boolean isWindowsOS = false;
		String osName = System.getProperty("os.name");
		if(osName.toLowerCase().indexOf("windows")>-1){
			isWindowsOS = true;
		}
		return isWindowsOS;
	}

	/**
	 * 获取本机ip地址，并自动区分Windows还是linux操作系统
	 * @return String
	 */
	public static String getLocalIP(){
		String sIP = "";
		InetAddress ip = null;
		try {
			//如果是Windows操作系统
			if(isWindowsOS()){
				ip = InetAddress.getLocalHost();
			}
			//如果是Linux操作系统
			else{
				boolean bFindIP = false;
				Enumeration<NetworkInterface> netInterfaces = (Enumeration<NetworkInterface>) NetworkInterface
						.getNetworkInterfaces();
				while (netInterfaces.hasMoreElements()) {
					if(bFindIP){
						break;
					}
					NetworkInterface ni = (NetworkInterface) netInterfaces.nextElement();
					//----------特定情况，可以考虑用ni.getName判断
					//遍历所有ip
					Enumeration<InetAddress> ips = ni.getInetAddresses();
					while (ips.hasMoreElements()) {
						ip = (InetAddress) ips.nextElement();
						if( ip.isSiteLocalAddress()
								&& !ip.isLoopbackAddress()   //127.开头的都是lookback地址
								&& ip.getHostAddress().indexOf(":")==-1){
							bFindIP = true;
							break;
						}
					}

				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		if(null != ip){
			sIP = ip.getHostAddress();
		}
		return sIP;
	}
}
