package com.lemall.brd.bpo.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by wangwentao on 2017/1/3.
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ImeiData {
    @JsonProperty(value = "_id")
    private String id;

    private String imei;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    @Override
    public String toString() {
        return "ImeiData{" +
                "id='" + id + '\'' +
                ", imei='" + imei + '\'' +
                '}';
    }
}
