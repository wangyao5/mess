package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.BDep;

public interface BDepMapper {
    BDep getById(Long id);
}
