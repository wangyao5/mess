package com.lemall.brd.bpo.model;

import lombok.Data;

import java.io.Serializable;
import java.sql.Time;
import java.util.Date;

/**
 * 员工实际排班信息表，用于记录排班信息
 *
 * @Author menghan
 * @Version 2017-06-21 10:56:18
 */
@Data
public class SchedulingInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7723973059071198500L;
	
	/**主键*/
	private Long id;
	/**总班表明细*/
	private Long spId;
	/**班表信息ID*/
	private Long sId;
	/**班表信息明细ID*/
	private Long sdId;
	/**部门ID-记录职场信息，用于存储部门及修改之后的部门信息*/
	private Long depId;
	/**员工ID*/
	private Long staffId;
	/**客服工号*/
	private String csId;
	/**业务id*/
	private Long busId;
	/**业务,不校验--只用作查看*/
	private String busName;
	/**排班日期*/
	private Date planDate;
	/**班次ID*/
	private Long shiftsId;
	/**班段ID,目前不存储*/
	private Long periodId;
	/**开始时间-存储时分*/
	private Time beginTime;
	/**结束时间-存储时分*/
	private Time endTime;
	/**餐时标准（min)*/
	private Integer mealStandard;
	/** 创建时间 */
    private Date createTime;
    /** 创建人 */
    private String createUser;
    /** 更新时间 */
    private Date updateTime;
    /** 更新人 */
    private String updateUser;
    /**备注*/
    private String remark;
    /** 是否有效： 0-无效； 1-有效 */
    private Integer yn;
}
