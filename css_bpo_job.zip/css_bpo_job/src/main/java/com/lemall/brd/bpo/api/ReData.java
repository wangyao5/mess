package com.lemall.brd.bpo.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by wangwentao on 2016/12/30.
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ReData {
    private String pcode;
    private String sn;

    public String getPcode() {
        return pcode;
    }

    public void setPcode(String pcode) {
        this.pcode = pcode;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }
}
