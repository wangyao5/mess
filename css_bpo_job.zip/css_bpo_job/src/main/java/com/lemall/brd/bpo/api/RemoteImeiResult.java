package com.lemall.brd.bpo.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * Created by wangwentao on 2017/1/3.
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class RemoteImeiResult {
    private String errno;
    private String errmsg;
    private List<ImeiData> data;

    public String getErrno() {
        return errno;
    }

    public void setErrno(String errno) {
        this.errno = errno;
    }

    public String getErrmsg() {
        return errmsg;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }

    public List<ImeiData> getData() {
        return data;
    }

    public void setData(List<ImeiData> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RemoteImeiResult{" +
                "errno='" + errno + '\'' +
                ", errmsg='" + errmsg + '\'' +
                ", data=" + data +
                '}';
    }
}
