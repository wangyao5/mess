package com.lemall.brd.bpo.worker;

import com.lemall.brd.bpo.model.Constants;
import com.lemall.brd.framework.util.HttpClientUtil;
import com.lemall.brd.framework.util.JsonUtil;
import com.lemall.brd.framework.util.MD5Util;

import java.util.HashMap;
import java.util.Map;

public abstract class Worker {
	public abstract void run();

}
