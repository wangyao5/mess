package com.lemall.brd.bpo.worker;

import com.lemall.brd.bpo.dao.CommonQueueMapper;
import com.lemall.brd.bpo.dao.ScheduleInfoMapper;
import com.lemall.brd.bpo.dao.ScheduleMapper;
import com.lemall.brd.bpo.model.CommonQueue;
import com.lemall.brd.bpo.model.Schedule;
import com.lemall.brd.bpo.query.SchedulingInfoQuery;
import com.lemall.brd.bpo.util.EventConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


/**
 * yxh
 * 2017-06-21 14:42:27
 */
@Service("bPOSchedulingInfoInitWorker")
public class BPOSchedulingInfoInitWorker extends Worker {
    private Logger LOGGER = LoggerFactory.getLogger(BPOSchedulingInfoInitWorker.class);

    @Autowired
    private CommonQueueMapper commonQueueMapper;
    @Autowired
    private ScheduleInfoMapper scheduleInfoMapper;
    @Autowired
    private ScheduleMapper scheduleMapper;

    @Override
    public void run() {
        MDC.put("APP_NAME", BPOSchedulingInfoInitWorker.class.getSimpleName());
        LOGGER.info("BPOSchedulingInfoInitWorker.run，排班信息生成班段信息开始");

        //标记删除排班班段信息根据班段
        disableSchedualeInfo();
        // 查询排班信息生成班段信息开始
        initSchedualeInfo();

        LOGGER.info("BPOSchedulingInfoInitWorker.run，排班信息生成班段信息结束");
    }

    // 查询排班信息生成班段信息开始
    private void disableSchedualeInfo() {
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_SCHEDULE_INFO_DISABLE);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有排班信息需要标记删除");
        } else {
            for (CommonQueue commonQueue : commonQueueList) {
                String resultMessage = "失败";
                try {
                    LOGGER.info("标记删除班段信息开始, id:{}", commonQueue.getId());
                    Long sId = commonQueue.getOnlyId();
                    if (sId == null) {
                        throw new Exception("排班明细ID为空");
                    }
                    //查询实体
                    Schedule schedule = scheduleMapper.getScheduleById(sId);
                    if (schedule == null) {
                        throw new Exception("无此排班信息");
                    }
                    //根据实体删除数据 机构、日期、业务线,不删除本地新导入的实体
                    SchedulingInfoQuery schedulingInfoQuery = new SchedulingInfoQuery();
                    schedulingInfoQuery.setSId(schedule.getId());
                    schedulingInfoQuery.setSDepId(schedule.getDepId());
                    schedulingInfoQuery.setBusId(schedule.getBusId());//业务线
                    schedulingInfoQuery.setCreateTime(schedule.getCreateTime());
                    if (scheduleInfoMapper.deletesByDeptAndDate(schedulingInfoQuery) >= 0) {
                        LOGGER.info("标记删除班段信息成功, id:{}", commonQueue.getId());
                        resultMessage = "成功";
                    } else {
                        LOGGER.info("标记删除班段信息失败, id:{}", commonQueue.getId());
                    }
                } catch (Exception e) {
                    resultMessage = "失败，标记删除失败";
                    LOGGER.error("标记删除班段信息失败, id:{}, error:{}", commonQueue.getId(), e.getMessage());
                }
                // 更新queue表运行结果
                commonQueue.setChangedBy("BPOSchedulingInfoInitWorker");
                commonQueue.setChangeDate(new Date());
                commonQueue.setRequestNum(commonQueue.getRequestNum() + 1);
                commonQueue.setRequestRemake(resultMessage);
                if ("成功".equals(resultMessage)) {
                    commonQueue.setStatus(1);
                } else {
                    commonQueue.setStatus(0);
                }
                commonQueueMapper.update(commonQueue);
            }
        }

    }

    //标记删除排班班段信息根据班段
    private void initSchedualeInfo() {
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_SCHEDULE_INFO_ADD);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有排班信息需要生成班段");
        } else {
            for (CommonQueue commonQueue : commonQueueList) {
                String resultMessage = "失败";
                try {
                    LOGGER.info("开始生成班段信息开始, id:{}", commonQueue.getId());
                    Long sId = commonQueue.getOnlyId();
                    if (sId == null) {
                        throw new Exception("排班明细ID为空");
                    }
                    List schedulingInfos = scheduleInfoMapper.queryBySid(sId);
                    if (!schedulingInfos.isEmpty()) {
                        throw new Exception("班段信息已经生成过，不可再次生成");
                    } else {
                        int count = scheduleInfoMapper.insertsBySId(sId);
                        if (count >= 0) {
                            LOGGER.info("生成班段信息成功, id:{},共{}条", commonQueue.getId(),count);
                            resultMessage = "成功";
                        } else {
                            LOGGER.info("生成班段信息失败, id:{}", commonQueue.getId());
                        }
                    }
                } catch (Exception e) {
                    resultMessage = "失败，生成班段信息失败";
                    LOGGER.error("生成班段信息失败, id:{}, error:{}", commonQueue.getId(), e.getMessage());
                }
                // 更新queue表运行结果
                commonQueue.setChangedBy("BPOSchedulingInfoInitWorker");
                commonQueue.setChangeDate(new Date());
                commonQueue.setRequestNum(commonQueue.getRequestNum() + 1);
                commonQueue.setRequestRemake(resultMessage);
                if ("成功".equals(resultMessage)) {
                    commonQueue.setStatus(1);
                } else {
                    commonQueue.setStatus(0);
                }
                commonQueueMapper.update(commonQueue);
            }
        }

    }
}
