package com.lemall.brd.bpo.model;

import java.util.Date;

/**
 * 数据字典类
 *
 * @Author menghan
 * @Version 2017-02-14 20:06:08
 */
public class Dic implements java.io.Serializable {

	private static final long serialVersionUID = 3044352441995680381L;
	/**主键*/
	private Long id;
	/**编号*/
	private Long num;
	/**名称*/
	private String name;
	/**类别*/
	private String type;
	/**父ID*/
	private Long parentId;
	/**父编号*/
	private Long parentNum;
	/**父名称*/
	private String parentName;
	/**父类别*/
	private String parentType;
	/**优先级*/
	private Integer priority;
	/**创建人*/
	private String createUser;
	/**创建时间*/
	private Date createTime;
	/**修改人*/
	private String updateUser;
	/**修改时间*/
	private Date updateTime;
	/**备注*/
	private String remark;
	/**是否有效，0无效、1有效*/
	private Integer yn;
	
	private Dic parentDic;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getNum() {
		return num;
	}
	public void setNum(Long num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public Long getParentNum() {
		return parentNum;
	}
	public void setParentNum(Long parentNum) {
		this.parentNum = parentNum;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getParentType() {
		return parentType;
	}
	public void setParentType(String parentType) {
		this.parentType = parentType;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getYn() {
		return yn;
	}
	public void setYn(Integer yn) {
		this.yn = yn;
	}
	public Dic getParentDic() {
		return parentDic;
	}
	public void setParentDic(Dic parentDic) {
		this.parentDic = parentDic;
	}
	
}
