package com.lemall.brd.bpo.util;

public class EventConstants {
    /**
     * 入职
     */
    public final static int EVENT_ENTRY = 100;
    /**
     * 添加用户同步到工作流
     */
    public final static int EVENT_STAFF_ADD =101;
    /**
     * 上线
     */
    public final static int EVENT_ONLINE = 110;
    /**
     * 岗位调整
     */
    public final static int EVENT_STATION = 120;
    /**
     * 组织调整
     */
    public final static int EVENT_ORGANIZATION = 130;
    /**
     * 离职
     */
    public final static int EVENT_QUIT = 140;
    /**
     * 用户角色
     */
    public final static int EVENT_ROLE = 200;
    /**
     * 部门数据
     */
    public final static int EVENT_DEP_ADD = 300;
    /**
     * 禁用部门
     */
    public final static int EVENT_DEP_DISABLE = 310;

    /**
     * 用户组
     */
    public final static int EVENT_USER_DEP = 400;
    /**
     * 请假事件
     */
    public final static int EVENT_LEAVE = 500;

    /**
     * 工号导入后推送
     */
    public final  static int EVENT_SEND_STAFF_NEW = 600;
    /**
     * staff员工信息修改后推送CC系统，预留
     */
    public final  static int EVENT_SEND_STAFF_UPDATE = 610;
    /**
     * 关闭工号推送数据状态
     */
    public final  static int EVENT_SEND_STAFF_LEAVE = 620;

    /**
     * 班表导入，生成排班班段信息
     */
    public final static int EVENT_SCHEDULE_INFO_ADD = 700;

    /**
     * 班表导入，排班班段信息标记删除
     */
    public final static int EVENT_SCHEDULE_INFO_DISABLE = 710;

    /**
     * 支援工单
     */
    public final static int EVENT_SUPPORT = 800;

    /**
     * 新增用餐
     */
    public final static int EVENT_MEAL = 900;
    /**
     * 换班
     */
    public final static int EVENT_SHIFT = 1000;
    /**
     * 班次调整
     */
    public final static int EVENT_ADJSUT = 1100;
    /**
     * 请假
     */
    public final static int EVENT_TEMP_LEAVE = 1200;
    /**
     * 加班
     */
    public final static int EVENT_OVERTIME = 1300;
    /**
     * 预置班次
     */
    public final static int EVENT_PRE_SHIFTS = 1400;
    /**
     * 排班申请
     */
    public final static int EVENT_SCHEDULING = 1500;

}
