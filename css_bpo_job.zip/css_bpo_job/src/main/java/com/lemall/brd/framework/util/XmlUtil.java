package com.lemall.brd.framework.util;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.basic.DateConverter;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.io.xml.XmlFriendlyNameCoder;

public class XmlUtil {
	/**
	 * java 转换成xml
	 * 
	 * @param obj
	 *            对象实例
	 * @return String xml字符串
	 */
	public static String toXml(Object obj) {
		XStream xstream = new XStream(new DomDriver("UTF-8",
				new XmlFriendlyNameCoder("-_", "_")));
		xstream.processAnnotations(obj.getClass()); // 通过注解方式的，一定要有这句话
		return xstream.toXML(obj);
	}

	/**
	 * xml转换为bean
	 * 
	 * @param xmlStr
	 * @param cls
	 * @return
	 */
	public static <T> T formXml(String xmlStr, Class<T> cls) {
		XStream xstream = new XStream();
		xstream.processAnnotations(cls);
		String dateFormat = "yyyy-MM-dd HH:mm:ss";
		String timeFormat = "yyyy-MM-dd HH:mm:ss";
		String[] acceptableFormats = {timeFormat};
		xstream.registerConverter(new DateConverter(dateFormat, acceptableFormats)); 
		xstream.ignoreUnknownElements(); // 忽略掉未知的XML要素
		@SuppressWarnings("unchecked")
		T obj = (T) xstream.fromXML(xmlStr);
		return obj;
	}

}