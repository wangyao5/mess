package com.lemall.brd.bpo.dao;

import com.lemall.brd.bpo.model.Dic;
import org.apache.ibatis.annotations.Param;

public interface BDicMapper {
    public Dic getDicByNum(@Param("parentNum")Long parentNum, @Param("num")Long num);
}
