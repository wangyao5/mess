package com.lemall.brd.framework.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {
	private JsonGenerator jsonGenerator = null;
	private static ObjectMapper objectMapper = null;

	public static HashMap<String, Object> jsonParse(String str) {
		objectMapper = new ObjectMapper();
		HashMap<String, Object> o = null;
		try {
			o = objectMapper.readValue(str, HashMap.class);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return o;
	}

	public static <T> List<T> fromJsonList(String json, Class<T> clazz)
			throws IOException {
		objectMapper = new ObjectMapper();
		return objectMapper.readValue(json, objectMapper.getTypeFactory()
				.constructCollectionType(List.class, clazz));
	}

	public static <T> T fromJsonObject(String json, Class<T> clazz)
			throws IOException {
		objectMapper = new ObjectMapper();
		return objectMapper.readValue(json, clazz);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T> T fromJsonObject(String json, TypeReference valueTypeRef)
			throws JsonParseException, JsonMappingException, IOException {
		objectMapper = new ObjectMapper();
		return (T) objectMapper.readValue(json, valueTypeRef);
	}

	public void destory() {
		try {
			if (jsonGenerator != null) {
				jsonGenerator.flush();
			}
			if (!jsonGenerator.isClosed()) {
				jsonGenerator.close();
			}
			jsonGenerator = null;
			objectMapper = null;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static String toJsonObject(Object obj)
			throws IOException {
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);  
		return objectMapper.writeValueAsString(obj);
	}
}
