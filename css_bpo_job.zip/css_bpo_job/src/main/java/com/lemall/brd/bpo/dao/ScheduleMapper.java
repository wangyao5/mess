package com.lemall.brd.bpo.dao;


import com.lemall.brd.bpo.model.Schedule;

/**
 * BPO排班表导入dao实现类
 *
 * @Author yxh
 * @Version 2017-05-31 22:08:26
 */
public interface ScheduleMapper{

	/**
	 * {@inheritDoc}
	 */
	public Schedule getScheduleById(Long id);
}
