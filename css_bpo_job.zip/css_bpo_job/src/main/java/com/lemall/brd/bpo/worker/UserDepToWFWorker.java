package com.lemall.brd.bpo.worker;

import com.lemall.brd.bpo.dao.BDepMapper;
import com.lemall.brd.bpo.dao.BUserDepMapper;
import com.lemall.brd.bpo.dao.CommonQueueMapper;
import com.lemall.brd.bpo.model.BDep;
import com.lemall.brd.bpo.model.BUserDep;
import com.lemall.brd.bpo.model.CommonQueue;
import com.lemall.brd.bpo.model.Constants;
import com.lemall.brd.bpo.util.EventConstants;
import com.lemall.brd.framework.util.JsonUtil;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service("userDepToWFWorker")
public class UserDepToWFWorker extends Worker {
    private Logger LOGGER = LoggerFactory.getLogger(UserDepToWFWorker.class);

    @Value("${getWFUrl}")
    private String getWFUrl;
    @Value("${syncGroup}")
    private String syncGroup;
    @Value("${secretKey}")
    private String secretKey;

    @Autowired
    private CommonQueueMapper commonQueueMapper;
    @Autowired
    private BUserDepMapper bUserDepMapper;

    @Override
    public void run() {
        MDC.put("APP_NAME", UserDepToWFWorker.class.getSimpleName());
        LOGGER.info("BPOUserToWFWorker.run，人员数据权限作业开始");

        userDep();

        LOGGER.info("BPOUserToWFWorker.run，人员数据权限作业结束");
    }

    private void userDep(){
        List<CommonQueue> commonQueueList = commonQueueMapper.getInitList(0, EventConstants.EVENT_USER_DEP);
        if (commonQueueList.isEmpty()) {
            LOGGER.info("没有用户数据权限信息");
        } else {
            String url = getWFUrl + syncGroup;

            for (CommonQueue commonQueue : commonQueueList) {
                try {
                    //查询用户所有数据权限
                    List<BUserDep> list = bUserDepMapper.getByUserId(commonQueue.getOnlyId());

                    Map<String, String> param = new HashedMap();
                    param.put("userType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
                    param.put("userId", String.valueOf(commonQueue.getOnlyId()));

                    List<Map<String, String>> groupList = new ArrayList<>();

                    for (BUserDep bUserDep : list) {
                        Map<String, String> groupMap = new HashedMap();
                        groupMap.put("groupId", bUserDep.getDepId() + "");
                        groupMap.put("groupType", Constants.Send_WorkFlow_Url_Parameter_UserType_Value);
                        groupList.add(groupMap);
                    }
                    String str = JsonUtil.toJsonObject(groupList);
                    param.put("groupList", str);

                    Map<String, String> rmap = CommonWorker.userToWF(url, param, secretKey);
                    if ("0".equals(rmap.get("status"))) {
                        commonQueue.setStatus(1);
                    }else{
                        commonQueue.setStatus(0);
                    }
                    commonQueue.setRequestRemake(rmap.get("message"));
                    commonQueue.setChangedBy("UserDepToWFWorker");
                    commonQueue.setChangeDate(new Date());
                    commonQueue.setRequestNum(commonQueue.getRequestNum() + 1);
                    commonQueueMapper.update(commonQueue);
                } catch (Exception e) {
                    LOGGER.info("get param sign error! and message is:{}", e.getMessage());
                }
            }
        }

    }



}
