package com.lemall.brd.bpo.worker;

import com.alibaba.fastjson.JSONObject;
import com.lemall.brd.bpo.model.Constants;
import com.lemall.brd.framework.util.HttpClientUtil;
import com.lemall.brd.framework.util.JsonUtil;
import com.lemall.brd.framework.util.MD5Util;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by shenguiqin on 2017/3/7.
 */
public class CommonWorker {
    private static Logger LOGGER = LoggerFactory.getLogger(BPODEPToWFWorker.class);

    public static Map<String, String> userToWF(String url, Map<String, String> param, String key) {
        Map<String, String> rmap = new HashedMap();
        param.put(Constants.Send_WorkFlow_Url_Parameter_Partner, Constants.Send_WorkFlow_Url_Parameter_Partner_Value);
        String timestamp = String.valueOf(System.currentTimeMillis());
        param.put(Constants.Send_WorkFlow_Url_Parameter_Timestamp, timestamp.substring(0, timestamp.length() - 3));
        try {
            param.put("sign", MD5Util.signTopRequest(param, key));
            LOGGER.info("start put param to workflow url:{} and map is:{}", url, param.toString());
            String r = HttpClientUtil.postForObject(url, "", param);
            LOGGER.info("get result from workflow :{} ", r);
            rmap = JsonUtil.fromJsonObject(r, HashMap.class);
        } catch (Exception e) {
            LOGGER.info("get param sign error! and message is:{}", e.getMessage());
        }
        return rmap;

    }

    public static JSONObject SendToCC(String url, String param) {
        JSONObject resJson = new JSONObject();
        try {
            LOGGER.info("start put param to CC  url:{} and json is:{}", url, param);
            String r = HttpClientUtil.postForObject(url, "application/json", param);
            //先解码，然后编码
            r=URLDecoder.decode(r,"UTF-8");
            LOGGER.info("get result from  CC PUSH :{} ", r + ",param:" + param);
            resJson = JSONObject.parseObject(r);
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.info("get param sign error! and message is:{} ", e.getMessage() + ",param:" + param);
        }
        return resJson;

    }
}
