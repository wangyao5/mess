package com.lemall.brd.framework.cache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
//import org.apache.log4j.Logger;

public abstract class BaseCache<K, T, D> {
    private static final Logger LOGGER = LoggerFactory.getLogger(BaseCache.class);
    public volatile int index = 0;
    protected Map<K, T> store0;
    protected Map<K, T> store1;
    protected String name;

    public void initCache(List<D> data) {
        store0 = put(data);
    }

    public void refreshCache(List<D> datas) {
        if (index == 0) {
            store1 = refresh(datas);
            index = 1;
            store0 = null;
        } else {
            store0 = refresh(datas);
            index = 0;
            store1 = null;
        }
//		logger.info(name + " refreshCache "+datas.size());
    }
    
    protected abstract Map<K, T> put(List<D> data);

    protected Map<K, T> refresh(List<D> data) {
        return put(data);
    }

    public T getValue(K key) {
        T value = null;
        if (index == 0 && null != store0) {
            value = store0.get(key);
        } else if (index == 1 && null != store1) {
            value = store1.get(key);
        }
        return value;
    }

    public Map<K, T> getStore() {
        if (index == 0) {
            return store0;
        } else {
            return store1;
        }
    }

    public void clear() {
        if (store0 != null) {
            store0.clear();
        }
        if (store1 != null) {
            store1.clear();
        }
    }
}
