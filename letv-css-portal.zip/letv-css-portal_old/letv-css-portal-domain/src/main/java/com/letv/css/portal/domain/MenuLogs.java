package com.letv.css.portal.domain;

import java.util.Date;

/**
 * 访问菜单日志记录
 *
 * @Author menghan
 * @Version 2017-05-17 17:55:36
 */
public class MenuLogs implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1657012374446112942L;
	
	/**主键*/
	private Long id;
	/**菜单的上级菜单名称，如果不存在则为无*/
	private String menuParentName;
	/**菜单名称*/
	private String menuName;
	/**菜单url*/
	private String menuUrl;
	/**用户id*/
	private Long userId;
	/**用户姓名*/
	private String userName;
	/**访问时间*/
	private Date createTime;
	/**是否有效*/
	private Integer yn;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMenuParentName() {
		return menuParentName;
	}

	public void setMenuParentName(String menuParentName) {
		this.menuParentName = menuParentName;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getMenuUrl() {
		return menuUrl;
	}

	public void setMenuUrl(String menuUrl) {
		this.menuUrl = menuUrl;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getYn() {
		return yn;
	}

	public void setYn(Integer yn) {
		this.yn = yn;
	}
	
	

}
