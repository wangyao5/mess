package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;
import com.letv.css.portal.domain.DepBusiness;

import java.util.List;

public class DicBusinessQuery extends Query {

    /**
     * 父名称
     */
    private String parentName;
    /**
     * 父类别
     */
    private List<DepBusiness> dicNums;

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public List<DepBusiness> getDicNums() {
        return dicNums;
    }

    public void setDicNums(List<DepBusiness> dicNums) {
        this.dicNums = dicNums;
    }
}
