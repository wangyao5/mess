package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

/**
 * 用户信息查询类
 *
 * @Author menghan
 * @Version 2017-01-05 18:34:11
 */
public class UserQuery extends Query {
	/** Id自增 */
    private Long id;
    /**员工ID*/
    private Long staffId;
    /**部门ID*/
    private Long depId;
    /**部门名称*/
    private String depName;
	/** 登录账号 */
    private String username;
    /** 登录密码 */
    private String password;
    /**姓名*/
    private String name;
    /**员工编号*/
    private String code;
    /**人员性质*/
    private String userType;
    /**可见部门集合*/
    private String depIds;
    /**员工合同性质*/
    private Integer staffContract;
    
    private String createUser;
    private String updateUser;
    private String remark;
    
    
    public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getDepName() {
		return depName;
	}
	public void setDepName(String depName) {
		this.depName = depName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	/**是否是所在部门负责人*/
    private String isCharged;
    /**可见部门ID集合*/
    private String allowDepIds;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getStaffId() {
		return staffId;
	}
	public void setStaffId(Long staffId) {
		this.staffId = staffId;
	}
	public Long getDepId() {
		return depId;
	}
	public void setDepId(Long depId) {
		this.depId = depId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getIsCharged() {
		return isCharged;
	}
	public void setIsCharged(String isCharged) {
		this.isCharged = isCharged;
	}
	public String getAllowDepIds() {
		return allowDepIds;
	}
	public void setAllowDepIds(String allowDepIds) {
		this.allowDepIds = allowDepIds;
	}
	public String getDepIds() {
		return depIds;
	}
	public void setDepIds(String depIds) {
		this.depIds = depIds;
	}
	public Integer getStaffContract() {
		return staffContract;
	}
	public void setStaffContract(Integer staffContract) {
		this.staffContract = staffContract;
	}
    
    
}
