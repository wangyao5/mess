package com.letv.css.portal.domain.dto;

import java.io.Serializable;

/**
 * 权限查询对象
 *
 * @Author menghan
 * @Version 2017-01-22 14:28:49
 */
public class PermissionDto implements Serializable{

	/** 
	* @Fields serialVersionUID  
	*/ 
	private static final long serialVersionUID = -9176308991029974283L;
	
	
	/** 资源名称 */ 
	private String resName;
	/** 角色名称 */
	private String roleName;
	/** 用户 */
	private String cnName;
	/** 用户帐号 */
	private String userName;
	
	public String getResName() {
		return resName;
	}
	public void setResName(String resName) {
		this.resName = resName;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getCnName() {
		return cnName;
	}
	public void setCnName(String cnName) {
		this.cnName = cnName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
