package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 总班表明细查询类
 *
 * @Author menghan
 * @Version 2017-05-24 17:13:13
 */
public class SchedulePlanDetailQuery extends Query {

    /**
     * 总班表id
     */
    private Long spId;
    /**
     * 部门id，职场
     */
    private Long depId;
    /**
     * 部门code，职场
     */
    private String depCode;
    /**
     * 班次id
     */
    private Long shiftsId;
    /**
     * 业务线num
     */
    private Integer busId;
    /**
     * 排班日期
     */
    private Date planDate;

    /**
     * 指定时间列表
     */
    private List<Date> querylanDate;

    public List<Date> getQuerylanDate() {
        return querylanDate;
    }

    public void setQuerylanDate(List<Date> querylanDate) {
        this.querylanDate = querylanDate;
    }

    public Long getDepId() {
        return depId;
    }

    public void setDepId(Long depId) {
        this.depId = depId;
    }

    public Long getShiftsId() {
        return shiftsId;
    }

    public void setShiftsId(Long shiftsId) {
        this.shiftsId = shiftsId;
    }

    public Integer getBusId() {
        return busId;
    }

    public void setBusId(Integer busId) {
        this.busId = busId;
    }

    public Date getPlanDate() {
        return planDate;
    }

    public void setPlanDate(Date planDate) {
        this.planDate = planDate;
    }

    public String getDepCode() {
        return depCode;
    }

    public void setDepCode(String depCode) {
        this.depCode = depCode;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }


}
