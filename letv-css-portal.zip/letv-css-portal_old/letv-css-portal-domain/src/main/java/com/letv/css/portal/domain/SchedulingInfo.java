package com.letv.css.portal.domain;

import java.io.Serializable;
import java.sql.Time;
import java.util.Date;

/**
 * 员工实际排班信息表，用于记录排班信息
 *
 * @Author menghan
 * @Version 2017-06-21 10:56:18
 */
public class SchedulingInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7723973059071198500L;
	
	/**主键*/
	private Long id;
	/**排班计划SchedulePlan主键ID*/
	private Long spId;
	/**班表信息ID*/
	private Long sId;
	/**班表信息明细ID*/
	private Long sdId;
	/**部门ID-记录职场信息，用于存储部门及修改之后的部门信息*/
	private Long depId;
	/**员工ID*/
	private Long staffId;
	/**客服工号*/
	private String csId;
	/**业务id*/
	private Long busId;
	/**业务,不校验--只用作查看*/
	private String busName;
	/**排班日期*/
	private Date planDate;
	/**班次ID*/
	private Long shiftsId;
	/**班段ID,目前不存储*/
	private Long periodId;
	/**开始时间-存储时分*/
	private Time beginTime;
	/**结束时间-存储时分*/
	private Time endTime;
	/**餐时标准（min)*/
	private Integer mealStandard;
	/** 创建时间 */
    private Date createTime;
    /** 创建人 */
    private String createUser;
    /** 更新时间 */
    private Date updateTime;
    /** 更新人 */
    private String updateUser;
    /**备注*/
    private String remark;
    /** 是否有效： 0-无效； 1-有效 */
    private Integer yn;
    
    private Schedule schedule;
    
    private ScheduleDetail scheduleDetail;
    
    private Dep dep;
    
    private Staff staff;

    private Shifts shifts;

    private ShiftsPeriod shiftsPeriod;

	private ApprovalManage approvalManage;

	public ApprovalManage getApprovalManage() {
		return approvalManage;
	}

	public void setApprovalManage(ApprovalManage approvalManage) {
		this.approvalManage = approvalManage;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getsId() {
		return sId;
	}
	public void setsId(Long sId) {
		this.sId = sId;
	}
	public Long getSdId() {
		return sdId;
	}
	public void setSdId(Long sdId) {
		this.sdId = sdId;
	}
	public Long getDepId() {
		return depId;
	}
	public void setDepId(Long depId) {
		this.depId = depId;
	}
	public Long getStaffId() {
		return staffId;
	}
	public void setStaffId(Long staffId) {
		this.staffId = staffId;
	}
	public String getCsId() {
		return csId;
	}
	public void setCsId(String csId) {
		this.csId = csId;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public Date getPlanDate() {
		return planDate;
	}
	public void setPlanDate(Date planDate) {
		this.planDate = planDate;
	}
	public Long getShiftsId() {
		return shiftsId;
	}
	public void setShiftsId(Long shiftsId) {
		this.shiftsId = shiftsId;
	}
	public Long getPeriodId() {
		return periodId;
	}
	public void setPeriodId(Long periodId) {
		this.periodId = periodId;
	}
	public Time getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Time beginTime) {
		this.beginTime = beginTime;
	}
	public Time getEndTime() {
		return endTime;
	}
	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}
	public Integer getMealStandard() {
		return mealStandard;
	}
	public void setMealStandard(Integer mealStandard) {
		this.mealStandard = mealStandard;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getYn() {
		return yn;
	}
	public void setYn(Integer yn) {
		this.yn = yn;
	}
	public Schedule getSchedule() {
		return schedule;
	}
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}
	public ScheduleDetail getScheduleDetail() {
		return scheduleDetail;
	}
	public void setScheduleDetail(ScheduleDetail scheduleDetail) {
		this.scheduleDetail = scheduleDetail;
	}
	public Dep getDep() {
		return dep;
	}
	public void setDep(Dep dep) {
		this.dep = dep;
	}
	public Staff getStaff() {
		return staff;
	}
	public void setStaff(Staff staff) {
		this.staff = staff;
	}
	public Shifts getShifts() {
		return shifts;
	}
	public void setShifts(Shifts shifts) {
		this.shifts = shifts;
	}
	public ShiftsPeriod getShiftsPeriod() {
		return shiftsPeriod;
	}
	public void setShiftsPeriod(ShiftsPeriod shiftsPeriod) {
		this.shiftsPeriod = shiftsPeriod;
	}

	public Long getSpId() {
		return spId;
	}

	public void setSpId(Long spId) {
		this.spId = spId;
	}

	public Long getBusId() {
		return busId;
	}

	public void setBusId(Long busId) {
		this.busId = busId;
	}
}
