package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

import java.sql.Time;

/**
 * 排班表信息查询类
 *
 * @Author menghan
 * @Version 2017-06-21 11:15:00
 */
public class SchedulingInfoQuery extends Query{
	/**主键*/
	private Long id;
	/**排班计划SchedulePlan主键ID*/
	private Long spId;
	/**主键集合*/
	private String ids;
	/**职场id*/
	private Long depId;
	/**职场code*/
	private String code;
	/**班次ID*/
	private Long shiftsId;
	/**班次名称*/
	private String shiftsName;
	/**班段ID*/
	private Long shiftPeriodId;
	/**班段名称*/
	private String shiftPeriodName;
	/**员工id*/
	private Long staffId;
	/**员工姓名*/
	private String staffName;
	/**业务id*/
	private Long busId;
	/**业务名称*/
	private String busName;
	/**开始时间*/
	private String startTime;
	/**结束时间*/
	private String endTime;
	/**在岗时间*/
	private String onTime;
	/**排班日期*/
	private String planDate;
	/**餐时*/
	private Integer mealStandard;
	/**客服工号*/
	private String csId;
	/**可见部门Ids*/
    private String depIds;
	private Long jdId;
	/** 更新人 */
	private String updateUser;
	/**备注*/
	private String remark;
	/** 是否有效： 0-无效； 1-有效 */
	private Integer yn;
	/**
	 * 开始时间需调整时间参数
	 */
	private Integer  adjBeginTime;
	/**
	 * 结束时间需调整时间参数
	 */
	private Integer adjEndTime;

	public Time getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Time beginTime) {
		this.beginTime = beginTime;
	}

	public String getCsId() {
		return csId;
	}

	public void setCsId(String csId) {
		this.csId = csId;
	}

	/**开始时间-存储时分*/
	private Time beginTime;

	public Integer getAdjBeginTime() {
		return adjBeginTime;
	}

	public void setAdjBeginTime(Integer adjBeginTime) {
		this.adjBeginTime = adjBeginTime;
	}

	public Integer getAdjEndTime() {
		return adjEndTime;
	}

	public void setAdjEndTime(Integer adjEndTime) {
		this.adjEndTime = adjEndTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getYn() {
		return yn;
	}

	public void setYn(Integer yn) {
		this.yn = yn;
	}
	public Long getJdId() {
		return jdId;
	}

	public void setJdId(Long jdId) {
		this.jdId = jdId;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getDepId() {
		return depId;
	}
	public void setDepId(Long depId) {
		this.depId = depId;
	}
	public Long getShiftsId() {
		return shiftsId;
	}
	public void setShiftsId(Long shiftsId) {
		this.shiftsId = shiftsId;
	}
	public Long getStaffId() {
		return staffId;
	}
	public void setStaffId(Long staffId) {
		this.staffId = staffId;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getOnTime() {
		return onTime;
	}
	public void setOnTime(String onTime) {
		this.onTime = onTime;
	}
	public String getPlanDate() {
		return planDate;
	}
	public void setPlanDate(String planDate) {
		this.planDate = planDate;
	}
	public Integer getMealStandard() {
		return mealStandard;
	}
	public void setMealStandard(Integer mealStandard) {
		this.mealStandard = mealStandard;
	}
	public String getDepIds() {
		return depIds;
	}
	public void setDepIds(String depIds) {
		this.depIds = depIds;
	}
	public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getIds() {
		return ids;
	}
	public void setIds(String ids) {
		this.ids = ids;
	}
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getShiftsName() {
		return shiftsName;
	}

	public void setShiftsName(String shiftsName) {
		this.shiftsName = shiftsName;
	}

	public Long getShiftPeriodId() {
		return shiftPeriodId;
	}

	public void setShiftPeriodId(Long shiftPeriodId) {
		this.shiftPeriodId = shiftPeriodId;
	}

	public String getShiftPeriodName() {
		return shiftPeriodName;
	}

	public void setShiftPeriodName(String shiftPeriodName) {
		this.shiftPeriodName = shiftPeriodName;
	}

	public Long getSpId() {
		return spId;
	}

	public void setSpId(Long spId) {
		this.spId = spId;
	}

	public Long getBusId() {
		return busId;
	}

	public void setBusId(Long busId) {
		this.busId = busId;
	}
}
