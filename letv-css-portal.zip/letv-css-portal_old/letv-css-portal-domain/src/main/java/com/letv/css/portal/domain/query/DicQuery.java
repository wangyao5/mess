package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

/**
 * 字典查询类
 *
 * @Author menghan
 * @Version 2017-02-14 20:21:55
 */
public class DicQuery extends Query{

	/**主键*/
	private Long id;
	/**编号*/
	private Integer num;
	/**类别*/
	private String type;
	/**名称*/
	private String name;
	/**父Id*/
	private Long parentId;
	/**父编号*/
	private Long parentNum;
	/**父名称*/
	private String parentName;
	/**父类别*/
	private String parentType;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public Long getParentNum() {
		return parentNum;
	}
	public void setParentNum(Long parentNum) {
		this.parentNum = parentNum;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getParentType() {
		return parentType;
	}
	public void setParentType(String parentType) {
		this.parentType = parentType;
	}
	
	
}
