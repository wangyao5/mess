package com.letv.css.portal.domain.vo.workflow.bean;

/**
 * Created by G on 2016/12/12.
 */
public class NewInstanceResult {
    private Integer id;
    private String status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
