package com.letv.css.portal.domain;

import java.util.Date;

/**
 *  BPO排班表
 *  yangxinghe
 *  2017-05-31 21:59:56
 */
public class Schedule implements java.io.Serializable{
	private static final long serialVersionUID = -4678194852660102071L;
	/**主键*/
	private Long id;
	/**排班计划SchedulePlan主键ID*/
	private Long spId;
	/**业务线id*/
	private Long busId;
	/**业务线名称*/
	private String busName;
	/**部门id-记录职场信息*/
	private Long depId;
	/**导入起始日期*/
	private Date beginTime;
	/**导入结束日期*/
	private Date endTime;
	/**任务状态 默认:0新建 1 已提交 2 驳回 3 完成 */
	private Integer status;
	/**创建时间*/
	private Date createTime;
	/**创建人*/
	private String createUser;
	/**修改时间*/
	private Date updateTime;
	/**修改人*/
	private String updateUser;
	/**是否有效 0删除 1未删除*/
	private Integer yn;
	
	private Dep dep;

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public Integer getYn() {
		return yn;
	}
	public void setYn(Integer yn) {
		this.yn = yn;
	}
	public Dep getDep() {
		return dep;
	}
	public void setDep(Dep dep) {
		this.dep = dep;
	}
	public Long getDepId() {
		return depId;
	}
	public void setDepId(Long depId) {
		this.depId = depId;
	}

	public Long getSpId() {
		return spId;
	}

	public void setSpId(Long spId) {
		this.spId = spId;
	}

	public Long getBusId() {
		return busId;
	}

	public void setBusId(Long busId) {
		this.busId = busId;
	}

	public String getBusName() {
		return busName;
	}

	public void setBusName(String busName) {
		this.busName = busName;
	}
}
