package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

/**
 * Created by yangxinghe on 2017/5/15.
 */
public class ShiftsQuery extends Query {
    /**
     * Id自增
     */
    private Long id;
    /**
     * '班次名称'
     */

    private String shiftsName;
    /**
     * 班次类型 1 普通班, 2临时班'
     */

    private Integer shiftsType;
    /**
     * 状态
     */
    private Integer status;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getShiftsName() {
        return shiftsName;
    }

    public void setShiftsName(String shiftsName) {
        this.shiftsName = shiftsName;
    }

    public Integer getShiftsType() {
        return shiftsType;
    }

    public void setShiftsType(Integer shiftsType) {
        this.shiftsType = shiftsType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }


}
