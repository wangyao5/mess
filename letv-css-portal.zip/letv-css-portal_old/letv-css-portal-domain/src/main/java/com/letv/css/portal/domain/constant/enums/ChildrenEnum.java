package com.letv.css.portal.domain.constant.enums;

/**
 * 子女枚举类
 *
 * @Author menghan
 * @Version 2017-01-09 18:14:47
 */
public enum ChildrenEnum {

	NO_CHILD(0,"无子女"),
	ONE_CHILD(1,"一胎"),
	TWO_CHILDREN(2,"二胎"),
	OTHER(3,"其他");
	
	private Integer key;
	private String value;
	
	private ChildrenEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
