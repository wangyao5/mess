package com.letv.css.portal.domain.vo.workflow.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

/**
 * Created by wangwentao on 2016/12/1.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Instance {
    @JsonProperty(value = "id")
    private Long id;
    @JsonProperty(value = "flowId")
    private String flowId;
    @JsonProperty(value = "flowName")
    private String flowName;
    @JsonProperty(value = "outId")
    private String outId;
    @JsonProperty(value = "statusId")
    private String statusId;
    @JsonProperty(value = "statusName")
    private String statusName;
    @JsonProperty(value = "Operator")
    private String operator;
    @JsonProperty(value = "Dept")
    private String dept;
    @JsonProperty(value = "CreationDate")
    private Date creationDate;
    @JsonProperty(value = "createrName")
    private String createrName;
    @JsonProperty(value = "ChangeDate")
    private Date changeDate;
    @JsonProperty(value = "ChangedBy")
    private String changedBy;
    @JsonProperty(value="modifyTime")
    private String modifyTime;
    private String imei;
    private String mobile;
    private String orderNo;
    @JsonProperty(value="name")
    private String name;
    private String depName;
    @JsonProperty(value="staffId")
    private String staffId;
    private String createUser;
    @JsonProperty(value="page")
    private String page;
    @JsonProperty(value="createTime")
    private Date createTime;
    @JsonProperty(value="adjustId")
    private Long adjustId;
    @JsonProperty(value="title")
    private String title;
    private String csId;
    private String leAccount;
    
    public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Long getAdjustId() {
		return adjustId;
	}

	public void setAdjustId(Long adjustId) {
		this.adjustId = adjustId;
	}

	public String getDepName() {
        return depName;
    }

    public void setDepName(String depName) {
        this.depName = depName;
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }
    

    public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId;
    }

    public String getFlowName() {
        return flowName;
    }

    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    public String getOutId() {
        return outId;
    }

    public void setOutId(String outId) {
        this.outId = outId;
    }

    public String getStatusId() {
        return statusId;
    }

    public void setStatusId(String statusId) {
        this.statusId = statusId;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }


    public String getCreaterName() {
		return createrName;
	}

	public void setCreaterName(String createrName) {
		this.createrName = createrName;
	}

	public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {

        this.statusName = statusName;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

	public String getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(String modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCsId() {
		return csId;
	}

	public void setCsId(String csId) {
		this.csId = csId;
	}

	public String getLeAccount() {
		return leAccount;
	}

	public void setLeAccount(String leAccount) {
		this.leAccount = leAccount;
	}
    

}
