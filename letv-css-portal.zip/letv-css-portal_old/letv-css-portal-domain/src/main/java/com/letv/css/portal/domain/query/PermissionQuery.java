package com.letv.css.portal.domain.query;

import java.util.List;

import com.letv.common.utils.page.Query;

/**   
* @Title: PermissionQuery.java 
* @Package com.letv.portal.domain.query 
* @Description: 权限查询QueryBean 
* @author zhangyao
* @date 2016年10月17日 下午6:08:55 
* @version V1.0 
* @since  jdk1.7.0_45 
*/
public class PermissionQuery extends Query {
	
	/** 用户中文名查询参数 */
	private String cnName;
	/** 角色名称查询参数 */
	private String roleName;
	/** 资源名称查询参数 */
	private String resName;
	/** 用户帐号查询参数 */
	private String userName;
	/** 排序 */
	private String order;

	/** 用户中文名查询参数 */
	private List<String> cnNames;
	/** 角色名称查询参数 */
	private List<String> roleNames;
	/** 资源名称查询参数 */
	private List<String> resNames;
	/** 用户帐号查询参数 */
	private List<String> userNames;

	public String getCnName() {
		return cnName;
	}

	public void setCnName(String cnName) {
		this.cnName = cnName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getResName() {
		return resName;
	}

	public void setResName(String resName) {
		this.resName = resName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<String> getCnNames() {
		return cnNames;
	}

	public void setCnNames(List<String> cnNames) {
		this.cnNames = cnNames;
	}

	public List<String> getRoleNames() {
		return roleNames;
	}

	public void setRoleNames(List<String> roleNames) {
		this.roleNames = roleNames;
	}

	public List<String> getResNames() {
		return resNames;
	}

	public void setResNames(List<String> resNames) {
		this.resNames = resNames;
	}

	public List<String> getUserNames() {
		return userNames;
	}

	public void setUserNames(List<String> userNames) {
		this.userNames = userNames;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}
}
