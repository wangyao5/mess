package com.letv.css.portal.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 修改记录日志
 *
 * @Author menghan
 * @Version 2017-01-14 11:10:15
 */
public class ModifyRecord implements Serializable{

	private static final long serialVersionUID = -6546240897435025737L;

	/**主键*/
	private Long id;
	/**修改类型*/
	private Integer modifyType;
	/**修改人(姓名+工号)*/
	private String modifyPerson;
	/**被修改人(姓名+工号)*/
	private String beModifiedPerson;
	/**修改时间*/
	private Date modifyTime;
	/**修改内容*/
	private String modifyContent;
	/**部门ID*/
	private Long depId;
	/**部门*/
	private Dep dep;
	/**员工ID*/
	private Long staffId;
	/**员工*/
	private Staff staff;
	/**创建者*/
	private String createUser;
	/**创建时间*/
	private Date createTime;
	/**修改者*/
	private String updateUser;
	/**修改时间*/
	private String updateTime;
	/**备注*/
	private String remark;
	/** 是否有效： 0-无效； 1-有效 */
	private Integer yn;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getModifyType() {
		return modifyType;
	}
	public void setModifyType(Integer modifyType) {
		this.modifyType = modifyType;
	}
	public String getModifyPerson() {
		return modifyPerson;
	}
	public void setModifyPerson(String modifyPerson) {
		this.modifyPerson = modifyPerson;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifyContent() {
		return modifyContent;
	}
	public void setModifyContent(String modifyContent) {
		this.modifyContent = modifyContent;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getYn() {
		return yn;
	}
	public void setYn(Integer yn) {
		this.yn = yn;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getBeModifiedPerson() {
		return beModifiedPerson;
	}
	public void setBeModifiedPerson(String beModifiedPerson) {
		this.beModifiedPerson = beModifiedPerson;
	}
	public Long getDepId() {
		return depId;
	}
	public void setDepId(Long depId) {
		this.depId = depId;
	}
	public Dep getDep() {
		return dep;
	}
	public void setDep(Dep dep) {
		this.dep = dep;
	}
	public Long getStaffId() {
		return staffId;
	}
	public void setStaffId(Long staffId) {
		this.staffId = staffId;
	}
	public Staff getStaff() {
		return staff;
	}
	public void setStaff(Staff staff) {
		this.staff = staff;
	}
	
	
}
