package com.letv.css.portal.domain;

import java.util.Date;
import java.util.List;

/**
 * 员工信息类，区别于User（staff上线后变为user）
 *
 * @Author menghan
 * @Version 2017-01-05 18:08:42
 */
public class Staff implements java.io.Serializable {

    private static final long serialVersionUID = -4249390515831267797L;
    /**
     * Id自增
     */
    private Long id;
    /**
     * 客服工号
     */
    private String csId;
    /**
     * 员工编号
     */
    private String employeeNum;
    /**
     * 用户id
     */
    private Long uId;
    /**
     * 部门ID
     */
    private Long depId;
    /**
     * 姓名
     */
    private String name;
    /**
     * 花名
     */
    private String nickname;
    /**
     * 工作形式：实习生，正式工
     */
    private Integer workingProperty;
    /**
     * 联系方式
     */
    private String phoneNo;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 身份证号
     */
    private String idNumber;
    /**
     * 客服经验年限
     */
    private String csExperience;
    /**
     * 工作年限
     */
    private String workExperience;
    /**
     * 出生日期
     */
    private Date birthdate;
    /**
     * 入职日期
     */
    private Date entryDate;
    /**
     * 离职日期
     */
    private Date quitDate;
    /**
     * 状态（正常，离职，停职等），已弃用
     */
    private String status;
    /**
     * 是否是负责人
     */
    private Integer isCharged;
    /**
     * 0未婚、1已婚
     */
    private Integer isMarried;
    /**
     * 0男、1女
     */
    private Integer sex;
    /**
     * 毕业院校
     */
    private String graduateSchool;
    /**
     * 0无子女、1一胎、2二胎
     */
    private Integer children;
    /**
     * 专业
     */
    private String major;
    /**
     * 1小学、2初中、3高中、4技校、5职高、6中专、7大专、8本科、9硕士、10博士、11其他
     */
    private Integer education;
    /**
     * 面试官：上级部门经理
     */
    private String interviewer;
    /**
     * 乐视复核人:高莉丽、梁春磊、岳金风、陈辽、李昂、冯冀垚、于思洋、陆旭、吴鑫、陈伟、王兵、陆依然、戴陆璐、郭彦峰、崔丽倩、崔亚运
     */
    private Integer leReviewer;
    /**
     * 备注
     */
    private String remark;
    /**
     * 员工合同性质：0乐视合同、1人瑞合同
     */
    private Integer staffContract;
    /**
     * 费用所属公司：乐视（乐视电商、乐视致新……），人瑞（人瑞移动、人瑞商城……）
     */
    private Integer costCompany;
    /**
     * 职位状态:1.培训，2.考核未通过，3.在职，4.离职
     */
    private String positionStatus;
    /**
     * 上线日期
     */
    private Date onlineDate;
    /**
     * 培训主任
     */
    private String trainingOfficer;
    /**
     * 培训主讲
     */
    private String traningSpeaker;
    /**
     * 平均成绩
     */
    private String aveScore;
    /**
     * 通关成绩
     */
    private String score;
    /**
     * 通关结果
     */
    private Integer result;
    /**
     * 业务，枚举值
     */
    private Integer service;
    /**
     * 岗位
     */
    private Integer jobTitle;
    /**
     * 上级(所在部门的负责人) 姓名
     */
    private String superior;
    /**
     * 上级(所在部门的负责人) 编号
     */
    private Long superiorId;
    
    /**
     * 乐视账号，仅针对内部员工，外包员工没有账号。
     */
    private String leAccount;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 是否有效： 0-无效； 1-有效
     */
    private Integer yn;
    /**
     * 最后修改时间
     */
    private Date lastModifyTime;
    /**
     * 所在部门
     */
    private Dep dep;
    /**
     * 可见部门
     */
    private List<Dep> deps;
    /**
     * 离职原因
     */
    private String dimissionReason;
    /**
     * 离职日期
     */
    private Date dimissionDate;
    /**
     * 岗位调整原因
     */
    private String jobTitleAdjustmentReason;
    /**
     * 岗位调整日期
     */
    private Date jobTitleAdjustmentDate;
    /**
     * 结构调整（部门调整）原因
     */
    private String structAdjustReason;
    /**
     * 结构调整日期
     */
    private Date structAdjustDate;
    /**
     * 职级
     */
    private Integer rank;
    /**
     * 姓名拼音
     */
    private String nameSpell;

    private Integer reviewedStatus;

    private Integer instanceId;
    /**
     * CC系统从属组ID
     */
    private String ccRoleGroupId;
    /**
     * CC系统从数组名称
     */
    private String ccRoleGroupName;

    /**
     * 推荐码-虚拟字段
     */
    private String autoCode;
    
    /**
     * 已排班日期
     */
    private List<Date> schedulingDates;
    /**
     * 已排班预置日期
     */
    private List<Date> preShiftsDates;
    /**
     * 排班计划数
     */
    private Integer schedulingPlanShiftNum;
    
    public Integer getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(Integer instanceId) {
        this.instanceId = instanceId;
    }

    public Integer getReviewedStatus() {
        return reviewedStatus;
    }

    public void setReviewedStatus(Integer reviewedStatus) {
        this.reviewedStatus = reviewedStatus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCsId() {
        return csId;
    }

    public void setCsId(String csId) {
        this.csId = csId;
    }

    public Long getuId() {
        return uId;
    }

    public void setuId(Long uId) {
        this.uId = uId;
    }

    public Long getDepId() {
        return depId;
    }

    public void setDepId(Long depId) {
        this.depId = depId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getWorkingProperty() {
        return workingProperty;
    }

    public void setWorkingProperty(Integer workingProperty) {
        this.workingProperty = workingProperty;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getCsExperience() {
        return csExperience;
    }

    public void setCsExperience(String csExperience) {
        this.csExperience = csExperience;
    }

    public String getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(String workExperience) {
        this.workExperience = workExperience;
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public Date getQuitDate() {
        return quitDate;
    }

    public void setQuitDate(Date quitDate) {
        this.quitDate = quitDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getIsCharged() {
        return isCharged;
    }

    public void setIsCharged(Integer isCharged) {
        this.isCharged = isCharged;
    }

    public Integer getIsMarried() {
        return isMarried;
    }

    public void setIsMarried(Integer isMarried) {
        this.isMarried = isMarried;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getGraduateSchool() {
        return graduateSchool;
    }

    public void setGraduateSchool(String graduateSchool) {
        this.graduateSchool = graduateSchool;
    }

    public Integer getChildren() {
        return children;
    }

    public void setChildren(Integer children) {
        this.children = children;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public Integer getEducation() {
        return education;
    }

    public void setEducation(Integer education) {
        this.education = education;
    }

    public String getInterviewer() {
        return interviewer;
    }

    public void setInterviewer(String interviewer) {
        this.interviewer = interviewer;
    }

    public Integer getLeReviewer() {
        return leReviewer;
    }

    public void setLeReviewer(Integer leReviewer) {
        this.leReviewer = leReviewer;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getStaffContract() {
        return staffContract;
    }

    public void setStaffContract(Integer staffContract) {
        this.staffContract = staffContract;
    }

    public Integer getCostCompany() {
        return costCompany;
    }

    public void setCostCompany(Integer costCompany) {
        this.costCompany = costCompany;
    }

    public String getPositionStatus() {
        return positionStatus;
    }

    public void setPositionStatus(String positionStatus) {
        this.positionStatus = positionStatus;
    }

    public Date getOnlineDate() {
        return onlineDate;
    }

    public void setOnlineDate(Date onlineDate) {
        this.onlineDate = onlineDate;
    }

    public String getTrainingOfficer() {
        return trainingOfficer;
    }

    public void setTrainingOfficer(String trainingOfficer) {
        this.trainingOfficer = trainingOfficer;
    }

    public String getTraningSpeaker() {
        return traningSpeaker;
    }

    public void setTraningSpeaker(String traningSpeaker) {
        this.traningSpeaker = traningSpeaker;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }

    public Integer getService() {
        return service;
    }

    public void setService(Integer service) {
        this.service = service;
    }

    public Integer getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(Integer jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getSuperior() {
        return superior;
    }

    public void setSuperior(String superior) {
        this.superior = superior;
    }

    public String getLeAccount() {
        return leAccount;
    }

    public void setLeAccount(String leAccount) {
        this.leAccount = leAccount;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getYn() {
        return yn;
    }

    public void setYn(Integer yn) {
        this.yn = yn;
    }

    public Date getLastModifyTime() {
        return lastModifyTime;
    }

    public void setLastModifyTime(Date lastModifyTime) {
        this.lastModifyTime = lastModifyTime;
    }

    public Dep getDep() {
        return dep;
    }

    public void setDep(Dep dep) {
        this.dep = dep;
    }

    public String getAveScore() {
        return aveScore;
    }

    public void setAveScore(String aveScore) {
        this.aveScore = aveScore;
    }

    public List<Dep> getDeps() {
        return deps;
    }

    public void setDeps(List<Dep> deps) {
        this.deps = deps;
    }

    public String getDimissionReason() {
        return dimissionReason;
    }

    public void setDimissionReason(String dimissionReason) {
        this.dimissionReason = dimissionReason;
    }

    public String getJobTitleAdjustmentReason() {
        return jobTitleAdjustmentReason;
    }

    public void setJobTitleAdjustmentReason(String jobTitleAdjustmentReason) {
        this.jobTitleAdjustmentReason = jobTitleAdjustmentReason;
    }

    public Date getJobTitleAdjustmentDate() {
        return jobTitleAdjustmentDate;
    }

    public void setJobTitleAdjustmentDate(Date jobTitleAdjustmentDate) {
        this.jobTitleAdjustmentDate = jobTitleAdjustmentDate;
    }

    public String getStructAdjustReason() {
        return structAdjustReason;
    }

    public void setStructAdjustReason(String structAdjustReason) {
        this.structAdjustReason = structAdjustReason;
    }

    public Date getStructAdjustDate() {
        return structAdjustDate;
    }

    public void setStructAdjustDate(Date structAdjustDate) {
        this.structAdjustDate = structAdjustDate;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getEmployeeNum() {
        return employeeNum;
    }

    public void setEmployeeNum(String employeeNum) {
        this.employeeNum = employeeNum;
    }

    public Date getDimissionDate() {
        return dimissionDate;
    }

    public void setDimissionDate(Date dimissionDate) {
        this.dimissionDate = dimissionDate;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

	public String getNameSpell() {
		return nameSpell;
	}

	public void setNameSpell(String nameSpell) {
		this.nameSpell = nameSpell;
	}

    public String getCcRoleGroupId() {
        return ccRoleGroupId;
    }

    public void setCcRoleGroupId(String ccRoleGroupId) {
        this.ccRoleGroupId = ccRoleGroupId;
    }

    public String getCcRoleGroupName() {
        return ccRoleGroupName;
    }

    public void setCcRoleGroupName(String ccRoleGroupName) {
        this.ccRoleGroupName = ccRoleGroupName;
    }

	public String getAutoCode() {
		return autoCode;
	}

	public void setAutoCode(String autoCode) {
		this.autoCode = autoCode;
	}

	public List<Date> getSchedulingDates() {
		return schedulingDates;
	}

	public void setSchedulingDates(List<Date> schedulingDates) {
		this.schedulingDates = schedulingDates;
	}

	public List<Date> getPreShiftsDates() {
		return preShiftsDates;
	}

	public void setPreShiftsDates(List<Date> preShiftsDates) {
		this.preShiftsDates = preShiftsDates;
	}

	public Integer getSchedulingPlanShiftNum() {
		return schedulingPlanShiftNum;
	}

	public void setSchedulingPlanShiftNum(Integer schedulingPlanShiftNum) {
		this.schedulingPlanShiftNum = schedulingPlanShiftNum;
	}

	public Long getSuperiorId() {
		return superiorId;
	}

	public void setSuperiorId(Long superiorId) {
		this.superiorId = superiorId;
	}
	
	
	
}
