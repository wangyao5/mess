package com.letv.css.portal.domain;

import java.io.Serializable;
import java.util.Date;

public class DepBusiness implements Serializable {

    private static final long serialVersionUID = -2404961758249150140L;

    private Integer id;
    private Long depId;
    private Integer dicNum;
    private String createUser;
    private String updateUser;
    private Date createTime;
    private Date updateTime;

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getDepId() {
        return depId;
    }

    public void setDepId(Long depId) {
        this.depId = depId;
    }

    public Integer getDicNum() {
        return dicNum;
    }

    public void setDicNum(Integer dicNum) {
        this.dicNum = dicNum;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }
}
