package com.letv.css.portal.domain.constant.enums;

/**
 * 乐视复核人枚举类
 *
 * @Author menghan
 * @Version 2017-01-09 15:52:08
 */
public enum LeReviewerEnum {

	GAO_LILI(1,"高莉丽"),
	LiANG_CHUNLEI(2,"梁春磊"),
	YUE_JINFENG(3,"岳进风"),
	CHEN_LIAO(4,"陈辽"),
	LI_ANG(5,"李昂"),
	FENG_JIGUI(6,"冯冀垚"),
	YU_SIYANG(7,"于思洋"),
	LU_XU(8,"陆旭"),
	WU_XIN(9,"吴鑫"),
	CHEN_WEI(10,"陈伟"),
	WANG_BING(11,"王兵"),
	LU_YIRANG(12,"陆依然"),
	DAI_LULU(13,"戴陆璐"),
	GUO_YANFENG(14,"郭彦峰"),
	CUI_LIQIAN(15,"崔丽倩"),
	CUI_YAYUN(16,"崔亚运");
	
	private Integer key;
	private String value;
	private LeReviewerEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
	
}
