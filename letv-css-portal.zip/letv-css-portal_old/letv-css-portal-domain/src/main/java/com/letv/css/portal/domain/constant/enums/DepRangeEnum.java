package com.letv.css.portal.domain.constant.enums;

/***
 * 部门范围枚举类
 *
 * @Author menghan
 * @Version 2017-01-06 14:31:13
 */
public enum DepRangeEnum {

	SUPERIOR_DEP(1,"上级部门"),
	
	SAME_DEP(2,"同部门"),
	
	SUBORDINATE_DEP(3,"下级部门");
	
	private Integer key;
	private String value;
	
	private DepRangeEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
