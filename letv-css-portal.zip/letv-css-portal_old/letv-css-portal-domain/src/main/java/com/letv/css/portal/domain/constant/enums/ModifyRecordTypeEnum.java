package com.letv.css.portal.domain.constant.enums;

/**
 * 修改记录类型枚举类
 *
 * @Author menghan
 * @Version 2017-01-14 10:58:31
 */
public enum ModifyRecordTypeEnum {

	ADD(1,"新增"),
	ONLINE(2,"上线"),
	JOB_TITLE_ADJUST(3,"岗位调整"),
	STRUCT_ADJUST(4,"结构调整"),
	MODIFY(5,"修改"),
	DIMISSION(6,"离职"),
	DELETE(7,"删除");
	
	private Integer key;
	private String value;
	private ModifyRecordTypeEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
