package com.letv.css.portal.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 * Created by yangxinghe on 2017/5/15.
 */
public class Shifts implements Serializable {
    private static final long serialVersionUID = 2808451825161320685L;
    private Long id;
    /**
     * '班次名称'
     */
    private String shiftsName;
    /**
     * 班次类型 1 普通班, 2临时班'
     */
    private Integer shiftsType;
    /**
     * 状态
     */
    private Integer status;
    /*
    * 创建人
     */
    private String createUser;
    /**
     * 创建时间
     */
    private Date createTime;

    /*
    * 修改人
     */
    private String updateUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /*
     * 班别：白班，晚班，天地班
     */
    private Integer shiftsClass;
    /*
    * 备注
     */
    private String remark;
    /*
    * '是否有效，0删除，1未删除'
     */
    private Integer yn;


    /**
     * Id自增
     */
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    /**
     * '班次名称'
     */
    public String getShiftsName() {
        return shiftsName;
    }

    public void setShiftsName(String shiftsName) {
        this.shiftsName = shiftsName;
    }

    /**
     * '班次类型： 1 普通班, 2临时班'
     */
    public Integer getShiftsType() {
        return shiftsType;
    }

    public void setShiftsType(Integer shiftsType) {
        this.shiftsType = shiftsType;
    }

    /**
     * '状态 1 启用,2禁用',
     */
    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    /**
     * 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    /**
     * 更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /*
     * 班别
     */
    public Integer getShiftsClass() {
        return shiftsClass;
    }

    public void setShiftsClass(Integer shiftsClass) {
        this.shiftsClass = shiftsClass;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getYn() {
        return yn;
    }

    public void setYn(Integer yn) {
        this.yn = yn;
    }
    
    //重写equals和hashCode方法
    @Override
    public boolean equals(Object obj) {
    	if(obj == this)
    		return true;
    	if(!(obj instanceof Shifts))
    		return false;
    	Shifts shifts = (Shifts) obj;
    	return Objects.equals(shiftsName, shifts.getShiftsName());
    }
    
    @Override
    public int hashCode() {
    	return Objects.hash(shiftsName);
    }
}
