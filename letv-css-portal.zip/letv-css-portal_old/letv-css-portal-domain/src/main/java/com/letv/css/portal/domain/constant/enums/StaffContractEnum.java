package com.letv.css.portal.domain.constant.enums;

/**
 * 合同性质
 *
 * @Author menghan
 * @Version 2017-01-22 20:57:05
 */
public enum StaffContractEnum {

	LE_CONTRACT(0,"乐视合同"),
	RENRUI_CONTRACT(1,"人瑞合同"),
	ZHI_XIN(101,"人瑞致新"),
	MOBILE(102,"人瑞移动"),
	MALL(103,"人瑞商城"),
	BPO_CONTRACT(2,"BPO类合同"),
	OTHER_CONTRACT(3,"其他合同");
	
	private Integer key;
	private String value;
	private StaffContractEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
