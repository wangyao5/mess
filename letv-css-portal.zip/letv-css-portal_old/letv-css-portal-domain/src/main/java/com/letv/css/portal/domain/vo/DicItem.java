package com.letv.css.portal.domain.vo;

public class DicItem {
    private long num;
    private String name;

    public long getNum() {
        return num;
    }

    public void setNum(long num) {
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}

