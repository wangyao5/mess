package com.letv.css.portal.domain.query;

import java.util.Date;
import java.util.List;

import com.letv.common.utils.page.Query;

/**
 * 数据权限查询类
 *
 * @Author menghan
 * @Version 2017-01-22 15:55:13
 */
public class UserDepQuery extends Query{

	/**主键*/
	private Long id;
	
	/**user表Id*/
	private Long userId;
	
	/**部门表Id*/
	private Long depId;
	
	/** 备注 */
    private String remark;

    /** 创建人 */
    private String createUser;

    /** 更新人 */
    private String updateUser;

    /** 开始时间 */
    private Date startTime;

    /** 结束时间 */
    private Date endTime;
	
    /** 用户集合 */
    private List<Long> userIds;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getDepId() {
		return depId;
	}

	public void setDepId(Long depId) {
		this.depId = depId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public List<Long> getUserIds() {
		return userIds;
	}

	public void setUserIds(List<Long> userIds) {
		this.userIds = userIds;
	}

    
    
}
