package com.letv.css.portal.domain.vo;

public class ScheduleInfoWithType {
    private int type;
    private ScheduleInfo[] schedules;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public ScheduleInfo[] getSchedules() {
        return schedules;
    }

    public void setSchedules(ScheduleInfo[] schedules) {
        this.schedules = schedules;
    }
}
