package com.letv.css.portal.domain.constant.enums;

/**
 * 学历枚举类
 *
 * @Author menghan
 * @Version 2017-01-06 17:36:17
 */
public enum EducationEnum {

	EDUCATION_PRIMARY_SCHOOL(1,"小学"),
	EDUCATION_MIDDLE_SCHOOL(2,"初中"),
	EDUCATION_HIGH_SCHOOL(3,"高中"),
	EDUCATION_TECHNICAL_SCHOOL(4,"技校"),
	EDUCATION_VOCATIONAL_SCHOOL(5,"职高"),
	EDUCATION_SPECIAL_SCHOOL(6,"中专"),
	EDUCATION_JUNIOR_COLLEGE(7,"大专"),
	EDUCATION_UNDERGRADUATE_COURS(8,"本科"),
	EDUCATION_MASTER(9,"硕士"),
	EDUCATION_DOCTOR(10,"博士"),
	EDUCATION_OTHER(11,"其他");
	
	private Integer key;
	private String value;
	
	private EducationEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
}
