package com.letv.css.portal.domain.query;

import java.io.Serializable;
import java.util.Date;

/**
 * 审批管理信息实体类
 *
 * @Author yxh
 * @Version 2017-06-26 16:20:05
 */
public class ApprovalManageQuery implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5472942907568172075L;
	/**主键*/
	private Long id;
	/**排班明细id*/
	private Long siId;
	private String siIds;
	/**json data id*/
	private Long jdId;
	/**审批支援类型：1支援  2班次调整  3餐时  4加班  5换班  6请假*/
	private Integer type;
	/**0 未确认 ，1 确认*/
	private Integer confirm;
	/**0 未完成 ，1 完成*/
	private Integer isFinished;

	private String createUser;
	
	private Date createTime;
	
	private String updateUser;
	
	private Date updateTime;
	/**0无效  1有效*/
	private Integer yn;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSiId() {
		return siId;
	}
	public void setSiId(Long siId) {
		this.siId = siId;
	}
	public Long getJdId() {
		return jdId;
	}
	public void setJdId(Long jdId) {
		this.jdId = jdId;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getIsFinished() {
		return isFinished;
	}

	public void setIsFinished(Integer isFinished) {
		this.isFinished = isFinished;
	}

	public Integer getConfirm() {
		return confirm;
	}
	public void setConfirm(Integer confirm) {
		this.confirm = confirm;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getYn() {
		return yn;
	}
	public void setYn(Integer yn) {
		this.yn = yn;
	}

	public String getSiIds() {
		return siIds;
	}

	public void setSiIds(String siIds) {
		this.siIds = siIds;
	}
}
