package com.letv.css.portal.domain.constant.enums;

/**
 * 职级枚举类
 *
 * @Author menghan
 * @Version 2017-01-19 09:32:22
 */
public enum RankEnum {

	SEAT(1,"普通员工"),
	GROUP_LEADER(2,"组长"),
	DIRECTOR(3,"主管"),
	MANAGER(4,"经理"),
	ABOVE_MANAGER(5,"经理以上");
	
	private Integer key;
	private String value;
	
	private RankEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
