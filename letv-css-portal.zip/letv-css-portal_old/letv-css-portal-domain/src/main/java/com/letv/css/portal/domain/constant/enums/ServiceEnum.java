package com.letv.css.portal.domain.constant.enums;

/**
 * 业务枚举类
 *
 * @Author menghan
 * @Version 2017-01-15 13:09:40
 */
public enum ServiceEnum {

	//热线
	VOICE_PHONE(1,"语音-手机"),
	VOICE_TV(2,"语音-电视"),
	VOICE_MALL(3,"语音-商城"),
	VOICE_INSTALLATION(4,"语音-安装"),
	VISIT(5,"回访"),
	//在线
	TM_PHONE(6,"天猫-手机"),
	TM_PHONE_CS(7,"天猫-手机售后"),
	JD_PHONE(8,"京东-手机"),
	JD_PHONE_CS(9,"京东-手机售后"),
	TM_PARTS(10,"天猫-配件"),
	JD_PARTS(11,"京东-配件"),
	TM_TV(12,"天猫-TV"),
	TM_TV_CS(13,"天猫-TV-售后"),
	TM_OFFICIAL_TV(14,"天猫-官旗TV"),
	TM_OFFICIAL_TV_CS(15,"天猫-官旗TV售后"),
	JD_TV(16,"京东-TV"),
	JD_TV_CS(17,"京东-TV售后"),
	SN_GM(18,"苏宁国美"),
	ONLINE_PHONE(19,"在线-手机"),
	ONLINE_TV(20,"在线-TV"),
	//营销
	MARKETING(21,"营销");
	
	private Integer key;
	
	private String value;

	private ServiceEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}

	public Integer getKey() {
		return key;
	}

	public void setKey(Integer key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
