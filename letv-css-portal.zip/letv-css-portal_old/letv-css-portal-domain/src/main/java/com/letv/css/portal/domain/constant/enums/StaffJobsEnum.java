package com.letv.css.portal.domain.constant.enums;

/***
 * 员工岗位
 *
 * @Author menghan
 * @Version 2017-01-06 14:48:19
 */
public enum StaffJobsEnum {

	JOBS_ALL(0,"全部"),
	
	JOBS_SEATING_TRAINNING(1,"坐席培训期"),
	
	JOBS_ADMINISTRATION_TECHNOLOGY(2,"行政及科技"),
	
	JOBS_DATA_STEWARD(3,"数据专员"),
	
	JOBS_SEATING(4,"坐席"),
	
	JOBS_SITE_MANAGEMENT_SPECIALIST(5,"现场管理专员WFM"),
	
	JOBS_TRAINER(6,"培训师"),
	
	JOBS_QC_ENGINEER(7,"质检师"),
	
	JOBS_SEATING_SUPERVISOR(8,"坐席组长"),
	
	JOBS_SITE_MANAGEMENT_SUPERVISOR(9,"现场管理主管WFM"),
	
	JOBS_QC_SUPERVISOR(10,"质检主管"),
	
	JOBS_TRAINING_DIRECTOR(11,"培训主管"),
	
	JOBS_SEATING_LEADER(12,"坐席主管"),
	
	JOBS_TRAINING_QUALITY_MANAGER(13,"培训质量经理"),
	
	JOBS_OPERATION_MANAGER(14,"运营经理"),
	
	JOBS_PROJECT_MANAGER(15,"项目经理");
	
	
	private Integer key;
	private String value;
	
	private StaffJobsEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
