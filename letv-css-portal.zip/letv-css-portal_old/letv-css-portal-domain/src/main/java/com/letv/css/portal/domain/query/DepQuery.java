package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

/**
 * 部门查询类
 *
 * @Author menghan
 * @Version 2017-01-06 16:38:17
 */
public class DepQuery extends Query {
	/**ID*/
	private Long id;
	/**部门编号*/
	private String num;
	/** 部门编号，系统生成 */
    private String code;
    /**父部门编号*/
    private Long parentId;
    /** 部门名称 */
    private String name;
    /** 范围：上级部门，同级部门，下级部门 */
    private Integer range;
	/**部门级别*/
    private Integer level;
    /** 负责人 */
    private String personCharge;
    /** 负责人Id */
    private Long personChargeId;
    /** 部门集合 */
    private String depIds;

    /** 上一级部门编号 */
    private String upperCode;
    
	/**部门状态**/
	private Integer depState;

	public Integer getDepState() {
		return depState;
	}

	public void setDepState(Integer depState) {
		this.depState = depState;
	}

    public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
    public Integer getRange() {
		return range;
	}
	public void setRange(Integer range) {
		this.range = range;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public String getPersonCharge() {
		return personCharge;
	}
	public void setPersonCharge(String personCharge) {
		this.personCharge = personCharge;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public String getDepIds() {
		return depIds;
	}
	public void setDepIds(String depIds) {
		this.depIds = depIds;
	}
	public Long getPersonChargeId() {
		return personChargeId;
	}
	public void setPersonChargeId(Long personChargeId) {
		this.personChargeId = personChargeId;
	}
	public String getUpperCode() {
		return upperCode;
	}
	public void setUpperCode(String upperCode) {
		this.upperCode = upperCode;
	}
	

}
