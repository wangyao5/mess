package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

/**
 * 修改记录查询类
 *
 * @Author menghan
 * @Version 2017-01-14 11:33:53
 */
/**
 *
 * @Author menghan
 * @Version 2017-02-17 10:32:31
 */
public class ModifyRecordQuery extends Query{
	
	/**部门编号*/
	private String code;
	/**岗位*/
	private Integer jobTitle;
	/**姓名*/
	private String name;
	/**工号(对应staff类里的客服工号)*/
	private String csId;
	/**上级(所在部门的负责人)*/
	private String superior;
	/**修改记录类型*/
	private Integer modifyRecordType;
	/**被修改人姓名*/
	private String beModifiedName;
	/**被修改人工号*/
	private String beModifiedCsId;
	/**部门ID*/
	private Long depId;
	/**可见部门id集合*/
	private String depIds;
	/**开始时间*/
	private String startTime;
	/**结束时间*/
	private String endTime;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Integer getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(Integer jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCsId() {
		return csId;
	}
	public void setCsId(String csId) {
		this.csId = csId;
	}
	public String getSuperior() {
		return superior;
	}
	public void setSuperior(String superior) {
		this.superior = superior;
	}
	public Integer getModifyRecordType() {
		return modifyRecordType;
	}
	public void setModifyRecordType(Integer modifyRecordType) {
		this.modifyRecordType = modifyRecordType;
	}
	public String getBeModifiedName() {
		return beModifiedName;
	}
	public void setBeModifiedName(String beModifiedName) {
		this.beModifiedName = beModifiedName;
	}
	public String getBeModifiedCsId() {
		return beModifiedCsId;
	}
	public void setBeModifiedCsId(String beModifiedCsId) {
		this.beModifiedCsId = beModifiedCsId;
	}
	public String getDepIds() {
		return depIds;
	}
	public void setDepIds(String depIds) {
		this.depIds = depIds;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public Long getDepId() {
		return depId;
	}
	public void setDepId(Long depId) {
		this.depId = depId;
	}
	
}
