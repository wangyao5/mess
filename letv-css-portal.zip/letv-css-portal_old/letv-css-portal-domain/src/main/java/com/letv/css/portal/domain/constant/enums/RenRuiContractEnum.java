package com.letv.css.portal.domain.constant.enums;

/**
 * 人瑞合同枚举类
 *
 * @Author menghan
 * @Version 2017-02-08 14:02:47
 */
public enum RenRuiContractEnum {
	
	//与StaffContractEnum关联，人瑞合同的key是1
	ZHI_XIN(101,"人瑞致新"),
	MOBILE(102,"人瑞移动"),
	MALL(103,"人瑞商城");
	
	RenRuiContractEnum(Integer key,String value){
		this.key = key;
		this.value = value;
	}
	
	private Integer key;
	
	private String value;
	
	public Integer getKey() {
		return key;
	}

	public void setKey(Integer key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
	
}
