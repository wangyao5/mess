package com.letv.css.portal.domain.vo.workflow.bean;

/**
 * Created by G on 2016/12/5.
 */
public class WorkFlowIndexQuery extends Query{

    public String qparam;

    public String flowId;

    public String statusId;
    
    public String instanceId;

    public String getQparam() {
        return qparam;
    }

    public void setQparam(String qparam) {
        this.qparam = qparam;
    }

    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId;
    }

    public String getStatusId() {
        return statusId;
    }

    public void setStatusId(String statusId) {
        this.statusId = statusId;
    }

	public String getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}
    
}
