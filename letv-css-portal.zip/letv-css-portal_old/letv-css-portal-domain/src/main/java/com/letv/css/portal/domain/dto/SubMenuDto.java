package com.letv.css.portal.domain.dto;

import java.io.Serializable;

/**
 * 子菜单（二级）对象
 * 
 * @author lijianzhong
 * @version 2014-12-10 下午12:49:53
 */
public class SubMenuDto implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 3060106837613141316L;
    /** 子菜单编码 */
    private String subMenuCode;
    /** 子菜单名称 */
    private String subMenuName;
    /** 子菜单名称英文 */
    private String subMenuENName;
    /** 子菜单名称 繁体*/
    private String subMenuHKName;
    /** 子菜单图标 */
    private String subMenuIcon;
    /** 子菜单URL */
    private String subMenuUrl;

    /**
	 * @return the subMenuENName
	 */
	public String getSubMenuENName() {
		return subMenuENName;
	}

	/**
	 * @param subMenuENName the subMenuENName to set
	 */
	public void setSubMenuENName(String subMenuENName) {
		this.subMenuENName = subMenuENName;
	}

	/**
	 * @return the subMenuHKName
	 */
	public String getSubMenuHKName() {
		return subMenuHKName;
	}

	/**
	 * @param subMenuHKName the subMenuHKName to set
	 */
	public void setSubMenuHKName(String subMenuHKName) {
		this.subMenuHKName = subMenuHKName;
	}

	/**
     * @return the subMenuCode
     */
    public String getSubMenuCode() {
        return subMenuCode;
    }

    /**
     * @param subMenuCode
     *            the subMenuCode to set
     */
    public void setSubMenuCode(String subMenuCode) {
        this.subMenuCode = subMenuCode;
    }

    /**
     * @return the subMenuName
     */
    public String getSubMenuName() {
        return subMenuName;
    }

    /**
     * @param subMenuName
     *            the subMenuName to set
     */
    public void setSubMenuName(String subMenuName) {
        this.subMenuName = subMenuName;
    }

    /**
     * @return the subMenuIcon
     */
    public String getSubMenuIcon() {
        return subMenuIcon;
    }

    /**
     * @param subMenuIcon
     *            the subMenuIcon to set
     */
    public void setSubMenuIcon(String subMenuIcon) {
        this.subMenuIcon = subMenuIcon;
    }

    /**
     * @return the subMenuUrl
     */
    public String getSubMenuUrl() {
        return subMenuUrl;
    }

    /**
     * @param subMenuUrl
     *            the subMenuUrl to set
     */
    public void setSubMenuUrl(String subMenuUrl) {
        this.subMenuUrl = subMenuUrl;
    }

}
