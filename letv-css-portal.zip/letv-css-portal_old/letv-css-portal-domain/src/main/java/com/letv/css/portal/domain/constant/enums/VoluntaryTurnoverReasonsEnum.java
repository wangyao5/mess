package com.letv.css.portal.domain.constant.enums;
/**
 * 主动离职原因
 *
 * @Author menghan
 * @Version 2017-01-13 17:28:52
 */
public enum VoluntaryTurnoverReasonsEnum {

	PHYSICAL_REASONS(1,"身体原因"),
	
	FAMILY_REASONS(2,"家庭原因"),
	
	PERSONAL_DEVELOPMENT(3,"个人发展（继续学业）"),
	
	SALARY_QUESTION(4,"薪资问题"),
	
	WORKING_PROPERTY(5,"工作性质"),
	
	TRAFFIC_DISTANCE(6,"交通距离");
	
	private Integer key;
	
	private String value;

	private VoluntaryTurnoverReasonsEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}

	public Integer getKey() {
		return key;
	}

	public void setKey(Integer key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
	
}
