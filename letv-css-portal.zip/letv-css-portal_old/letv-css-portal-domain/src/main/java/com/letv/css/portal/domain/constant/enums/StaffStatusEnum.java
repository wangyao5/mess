package com.letv.css.portal.domain.constant.enums;

/***
 * 员工状态枚举类
 *
 * @Author menghan
 * @Version 2017-01-06 14:22:14
 */
public enum StaffStatusEnum {

	STAFF_TRAIN(1,"培训"),
	
	STAFF_EXAMINATION_NOT(2,"考核未过"),
	
	STAFF_WORKING(3,"在职"),

	STAFF_QUIT(4,"离职");
	
	
	private Integer key;
	private String value;
	
	private StaffStatusEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
	
}
