package com.letv.css.portal.domain.vo;

public class SystemNotice {
}
