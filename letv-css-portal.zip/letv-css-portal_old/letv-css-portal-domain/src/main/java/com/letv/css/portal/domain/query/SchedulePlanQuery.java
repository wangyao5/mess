package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 总班表查询类
 *
 * @Author menghan
 * @Version 2017-05-24 11:35:56
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SchedulePlanQuery extends Query{

	/**部门id，职场*/
	private Long depId;
	/**业务id*/
	private Long busId;
	/**部门code*/
	private String code;
	/**状态*/
	private Integer status;
	/**查询--起始日期*/
	private String startTime;
	/**查询--结束日期*/
	private String endTime;
	/**
	 * 可见部门Ids
	 */
	private String depIds;
}
