package com.letv.css.portal.domain.vo.workflow.bean;

import com.letv.common.utils.DateHelper;

/**
 * Created by G on 2016/12/12.
 */
public class ProcessLog {
    private String operatorName;
    private String operateDate;
    private String log;
	public String getOperatorName() {
		return operatorName;
	}
	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	public String getOperateDate() {
		return DateHelper.format(DateHelper.parseDate(operateDate, "yyyy-MM-dd'T'HH:mm:ss'+08:00'"), "yyyy-MM-dd HH:mm:ss");
	}
	public void setOperateDate(String operateDate) {
		this.operateDate = operateDate;
	}
	public String getLog() {
		return log;
	}
	public void setLog(String log) {
		this.log = log;
	}


   
}
