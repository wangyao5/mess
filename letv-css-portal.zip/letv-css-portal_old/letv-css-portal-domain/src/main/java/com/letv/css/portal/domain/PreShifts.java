package com.letv.css.portal.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 考勤预制班次表，用于记录班次申请
 *
 * @Author yxh
 * @Version 2017-08-29 11:46:04
 */
public class PreShifts implements Serializable {
	private static final long serialVersionUID = -7722973059071198500L;

	/**主键*/
	private Long id;
	/**部门ID-记录职场信息，用于存储部门及修改之后的部门信息*/
	private Long depId;
	/**员工ID*/
	private Long staffId;
	/**员工ID*/
	private String staffName;
	/**客服工号*/
	private String csId;
	/**业务id*/
	private Long busId;
	/**业务,不校验--只用作查看*/
	private String busName;
	/**排班日期*/
	private Date planDate;
	/**班次ID*/
	private Long shiftsId;
	/**审批状态：1:审核中，2.驳回，3.完成*/
	private Integer status;
	/** 创建时间 */
    private Date createTime;
    /** 创建人 */
    private String createUser;
    /** 审批时间---每次审批的时候 更新这个时间和人 */
    private Date updateTime;
    /** 审批人 */
    private String updateUser;
    /**备注*/
    private String remark;
    /** 是否有效： 0-无效； 1-有效 */
    private Integer yn;

    private Dep dep;
    private Staff staff;

    public Shifts getShifts() {
        return shifts;
    }

    public void setShifts(Shifts shifts) {
        this.shifts = shifts;
    }

    private Shifts shifts;

    public Dep getDep() {
        return dep;
    }

    public void setDep(Dep dep) {
        this.dep = dep;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDepId() {
        return depId;
    }

    public void setDepId(Long depId) {
        this.depId = depId;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getCsId() {
        return csId;
    }

    public void setCsId(String csId) {
        this.csId = csId;
    }

    public Long getBusId() {
        return busId;
    }

    public void setBusId(Long busId) {
        this.busId = busId;
    }

    public String getBusName() {
        return busName;
    }

    public void setBusName(String busName) {
        this.busName = busName;
    }

    public Date getPlanDate() {
        return planDate;
    }

    public void setPlanDate(Date planDate) {
        this.planDate = planDate;
    }

    public Long getShiftsId() {
        return shiftsId;
    }

    public void setShiftsId(Long shiftsId) {
        this.shiftsId = shiftsId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getYn() {
        return yn;
    }

    public void setYn(Integer yn) {
        this.yn = yn;
    }
}
