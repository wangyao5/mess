package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

import java.io.Serializable;
import java.util.Date;

/**
 * 考勤预制班次表，用于记录班次申请
 *
 * @Author yxh
 * @Version 2017-08-29 11:46:04
 */
public class PreShiftsQuery extends Query implements Serializable {
	private static final long serialVersionUID = -7722973059071198500L;

	/**主键*/
	private Long id;
    /**主键集合*/
    private String ids;
	/**部门ID-记录职场信息，用于存储部门及修改之后的部门信息*/
	private Long depId;
	/**员工ID*/
	private Long staffId;
	/**员工ID*/
	private String staffName;
	/**客服工号*/
	private String csId;
	/**业务id*/
	private Long busId;
	/**业务,不校验--只用作查看*/
	private String busName;
	/**排班日期*/
	private String planDate;
	/**班次ID*/
	private Long shiftsId;
    /**班次名称*/
    private String shiftsName;
    /**可见部门Ids*/
    private String depIds;
    private String name;
    private String code;
    private String depName;

	/**审批状态：1:审核中，2.驳回，3.完成*/
	private Integer status;
	/** 创建时间 */
    private Date createTime;
    /** 创建人 */
    private String createUser;
    /** 审批时间 */
    private Date updateTime;
    /** 审批人 */
    private String updateUser;
    /**备注*/
    private String remark;
    /** 是否有效： 0-无效； 1-有效 */
    private Integer yn;
    //开始时间
    private String startPlanDate;
    //结束时间
    private String endPlanDate;

    /** 岗位编号 */
    private String jobTitle;
    /** 岗位编号集合 */
    private String jobTitles;

    public String getStartPlanDate() {
        return startPlanDate;
    }

    public void setStartPlanDate(String startPlanDate) {
        this.startPlanDate = startPlanDate;
    }

    public String getEndPlanDate() {
        return endPlanDate;
    }

    public void setEndPlanDate(String endPlanDate) {
        this.endPlanDate = endPlanDate;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDepName() {
        return depName;
    }

    public void setDepName(String depName) {
        this.depName = depName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String getShiftsName() {
        return shiftsName;
    }

    public void setShiftsName(String shiftsName) {
        this.shiftsName = shiftsName;
    }

    public String getDepIds() {
        return depIds;
    }

    public void setDepIds(String depIds) {
        this.depIds = depIds;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDepId() {
        return depId;
    }

    public void setDepId(Long depId) {
        this.depId = depId;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getCsId() {
        return csId;
    }

    public void setCsId(String csId) {
        this.csId = csId;
    }

    public Long getBusId() {
        return busId;
    }

    public void setBusId(Long busId) {
        this.busId = busId;
    }

    public String getBusName() {
        return busName;
    }

    public void setBusName(String busName) {
        this.busName = busName;
    }

    public String getPlanDate() {
        return planDate;
    }

    public void setPlanDate(String planDate) {
        this.planDate = planDate;
    }

    public Long getShiftsId() {
        return shiftsId;
    }

    public void setShiftsId(Long shiftsId) {
        this.shiftsId = shiftsId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getYn() {
        return yn;
    }

    public void setYn(Integer yn) {
        this.yn = yn;
    }

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getJobTitles() {
		return jobTitles;
	}

	public void setJobTitles(String jobTitles) {
		this.jobTitles = jobTitles;
	}
}
