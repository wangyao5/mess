package com.letv.css.portal.domain.constant.enums;

/**
 * 部门层级
 *
 * @Author menghan
 * @Version 2017-02-06 10:43:20
 */
public enum HierarchyEnum {

	INSIDE(1,"内部"),
	WORKPLACE(2,"职场");
	
	private HierarchyEnum(Integer key,String value){
		this.key = key;
		this.value = value;
	}
	
	private Integer key;
	
	private String value;
	
	public Integer getKey() {
		return key;
	}

	public void setKey(Integer key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
}
