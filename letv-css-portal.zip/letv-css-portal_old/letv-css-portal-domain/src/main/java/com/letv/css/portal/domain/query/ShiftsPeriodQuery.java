package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

import java.util.Date;

import java.sql.Time;


/**
 * Created by yangxinghe on 2017/5/23.
 * 班次实体
 */
public class ShiftsPeriodQuery extends Query {
    private Long id;
    /**
     * '班段名称 不能为空'
     */
    private String periodName;
    /**
     * '班次ID'
     */
    private Long shiftsId;
    /**
     * '开始时间：班段中的上班时间'
     */

    private Time beginTime;
    /**
     * '结束时间：班段中的下班时间'
     */
    private Time endTime;
    /**
     * '餐时标准（min)'
     */
    private Integer mealStandard;
    /*
   * 创建人
    */
    private String createUser;
    /**
     * 创建时间
     */
    private Date createTime;

    /*
    * 修改人
     */
    private String updateUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /*
    * 备注
     */
    private String remark;
    /*
    * '是否有效，0删除，1未删除'
     */
    private Integer yn;
    /*
  * 班段是否是第二天。1：是；2：否
   */
    private Integer isNextDay;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public Long getShiftsId() {
        return shiftsId;
    }

    public void setShiftsId(Long shiftsId) {
        this.shiftsId = shiftsId;
    }

    public Time getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(Time beginTime) {
        this.beginTime = beginTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }

    public Integer getMealStandard() {
        return mealStandard;
    }

    public void setMealStandard(Integer mealStandard) {
        this.mealStandard = mealStandard;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getYn() {
        return yn;
    }

    public void setYn(Integer yn) {
        this.yn = yn;
    }

    public Integer getIsNextDay() {
        return isNextDay;
    }

    public void setIsNextDay(Integer isNextDay) {
        this.isNextDay = isNextDay;
    }
}
