package com.letv.css.portal.domain.vo.workflow.bean;

/**
 * Created by G on 2016/11/30.
 */
public class QuerySumResult {
    public String statusId;
    public String statusName;
    public String count;

    public String getStatusId() {
        return statusId;
    }

    public void setStatusId(String statusId) {
        this.statusId = statusId;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    @Override
    public String toString() {
        return "QuerySumResult{" +
                "statusId='" + statusId + '\'' +
                ", statusName='" + statusName + '\'' +
                ", count='" + count + '\'' +
                '}';
    }
}
