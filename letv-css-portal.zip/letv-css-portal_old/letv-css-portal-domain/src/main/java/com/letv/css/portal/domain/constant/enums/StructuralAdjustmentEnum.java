package com.letv.css.portal.domain.constant.enums;

/**
 * 结构调整枚举值
 *
 * @Author menghan
 * @Version 2017-01-13 20:52:36
 */
public enum StructuralAdjustmentEnum {

	TEAM_OVERALL_ADJUSTMENT(1,"班组整体调整"),
	ORIGINAL_GROUP_DELEAVE(2,"原组拆散"),
	PERSONAL_REASONS(3,"个人原因"),
	OTHER_REASON(4,"其他");
	
	private Integer key;
	private String value;
	
	private StructuralAdjustmentEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
