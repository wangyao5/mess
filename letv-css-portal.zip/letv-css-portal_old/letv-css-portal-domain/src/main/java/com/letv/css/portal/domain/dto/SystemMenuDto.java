package com.letv.css.portal.domain.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 系统菜单（各自系统下菜单）对象
 *
 * @Author menghan
 * @Version 2017-01-22 13:59:47
 */
public class SystemMenuDto implements Serializable {
	
	private static final long serialVersionUID = 1564491142156275922L;
	/** 系统编码 */
    private String sysCode;
    /** 菜单的集合 */
    private List<MenuDto> menus;
	public String getSysCode() {
		return sysCode;
	}
	public void setSysCode(String sysCode) {
		this.sysCode = sysCode;
	}
	public List<MenuDto> getMenus() {
		return menus;
	}
	public void setMenus(List<MenuDto> menus) {
		this.menus = menus;
	}

}
