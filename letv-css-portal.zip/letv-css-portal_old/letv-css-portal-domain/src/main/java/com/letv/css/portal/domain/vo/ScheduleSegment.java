package com.letv.css.portal.domain.vo;

import java.util.Date;

/**
 * 排班时间段
 */
public class ScheduleSegment {
    private long spID;
    private Date beginDate;
    private Date endDate;

    public long getSpID() {
        return spID;
    }

    public void setSpID(long spID) {
        this.spID = spID;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
}
