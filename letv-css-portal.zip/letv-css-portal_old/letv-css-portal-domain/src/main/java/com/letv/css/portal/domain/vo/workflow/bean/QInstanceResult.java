package com.letv.css.portal.domain.vo.workflow.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * Created by G on 2016/12/1.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class QInstanceResult {
    public String total;
    public List<Instance> rows;

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public List<Instance> getInstance() {
        return rows;
    }

    public void setInstance(List<Instance> rows) {
        this.rows = rows;
    }
}
