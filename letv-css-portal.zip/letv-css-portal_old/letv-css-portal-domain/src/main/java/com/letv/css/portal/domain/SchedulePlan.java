package com.letv.css.portal.domain;

import java.util.Date;

/**
 * 总班表
 *
 * @Author menghan
 * @Version 2017-05-24 11:11:19
 */
public class SchedulePlan implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -635833750554176468L;
	/**主键*/
	private Long id;
	/**部门id-记录职场信息*/
	private Long depId;
	/**业务线id*/
	private Long busId;
	/**导入起始日期*/
	private Date beginTime;
	/**导入结束日期*/
	private Date endTime;
	/**状态 1已完成 2待排期 3 使用中*/
	private Integer status;
	/**创建时间*/
	private Date createTime;
	/**创建人*/
	private String createUser;
	/**修改时间*/
	private Date updateTime;
	/**修改人*/
	private String updateUser;
	/**是否有效 0删除 1未删除*/
	private Integer yn;
	
	private Dep dep;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public Integer getYn() {
		return yn;
	}
	public void setYn(Integer yn) {
		this.yn = yn;
	}
	public Dep getDep() {
		return dep;
	}
	public void setDep(Dep dep) {
		this.dep = dep;
	}
	public Long getDepId() {
		return depId;
	}
	public void setDepId(Long depId) {
		this.depId = depId;
	}
	public Long getBusId() {
		return busId;
	}
	public void setBusId(Long busId) {
		this.busId = busId;
	}
	
	
}
