package com.letv.css.portal.domain;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.letv.common.utils.serialize.CustomerDateSerializer;

/**
 * User: gaohongjing Date: 2014-04-09 Time: 10:39:34
 */
public class Dep implements java.io.Serializable {

    private static final long serialVersionUID = -7865031984935951240L;

    /** 自增ID */
    private Long id;

    /**部门编号，人工输入*/
    private String num;
    
    /**人员数量，该字段不同步到数据库，用来保存计算后该部门的人员数量*/
    private Integer personQuantity;

    private Integer bpoQuantity;
    private Integer hroQuantity;
    private Integer leQuantity;
    
	/** 部门编码，系统生成 */
    private String code;

    /** 部门名称 */
    private String name;

    /** 上级部门Id */
    private Long parentId;
    
    /** 上级部门 */
    private Dep parentDep;

    /** 是否有子节点 */
    private Integer hasChild;

    /** 层级 */
    private Integer level;
    
    /**部门层级,1、内部 2、职场*/
    private Integer hierarchy;

    /** 优先级(顺序) */
    private Integer priority;
    
    /**负责人*/
    private String personCharge;
    
    /**负责人ID*/
    private Long personChargeId;
    
    /**部门性质：0内部，1外包*/
    private Integer depType;
    
    /**部门状态，0禁用，1启用*/
    private Integer depState;
    
    /** 创建时间 */
    private Date createTime;

    /** 创建人 */
    private String createUser;

    /** 更新时间 */
    private Date updateTime;

    /** 更新人 */
    private String updateUser;

    /** 是否有效： 0-无效； 1-有效 */
    private Integer yn = 0;

    /** 备注 */
    private String remark;

    /** 状态（对应集团系统是否有效） */
    private Integer effect;

    /** 最后修改时间 */
    private Date lastModifyTime;

    public Integer getBpoQuantity() {
        return bpoQuantity;
    }

    public void setBpoQuantity(Integer bpoQuantity) {
        this.bpoQuantity = bpoQuantity;
    }

    public Integer getHroQuantity() {
        return hroQuantity;
    }

    public void setHroQuantity(Integer hroQuantity) {
        this.hroQuantity = hroQuantity;
    }

    public Integer getLeQuantity() {
        return leQuantity;
    }

    public void setLeQuantity(Integer leQuantity) {
        this.leQuantity = leQuantity;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public Integer getHasChild() {
        return hasChild;
    }

    public void setHasChild(Integer hasChild) {
        this.hasChild = hasChild;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    @JsonSerialize(using = CustomerDateSerializer.class)
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    @JsonSerialize(using = CustomerDateSerializer.class)
    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Integer getYn() {
        return yn;
    }

    public void setYn(Integer yn) {
        this.yn = yn;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getEffect() {
        return effect;
    }

    public void setEffect(Integer effect) {
        this.effect = effect;
    }

    @JsonSerialize(using = CustomerDateSerializer.class)
    public Date getLastModifyTime() {
        return lastModifyTime;
    }

    public void setLastModifyTime(Date lastModifyTime) {
        this.lastModifyTime = lastModifyTime;
    }

	public String getPersonCharge() {
		return personCharge;
	}

	public void setPersonCharge(String personCharge) {
		this.personCharge = personCharge;
	}

	public Integer getDepType() {
		return depType;
	}

	public void setDepType(Integer depType) {
		this.depType = depType;
	}

	public Integer getDepState() {
		return depState;
	}

	public void setDepState(Integer depState) {
		this.depState = depState;
	}

	public Dep getParentDep() {
		return parentDep;
	}

	public void setParentDep(Dep parentDep) {
		this.parentDep = parentDep;
	}
	
	 public Integer getPersonQuantity() {
		return personQuantity;
	}

	public void setPersonQuantity(Integer personQuantity) {
		this.personQuantity = personQuantity;
	}

	public Integer getHierarchy() {
		return hierarchy;
	}

	public void setHierarchy(Integer hierarchy) {
		this.hierarchy = hierarchy;
	}

	public Long getPersonChargeId() {
		return personChargeId;
	}

	public void setPersonChargeId(Long personChargeId) {
		this.personChargeId = personChargeId;
	}
	
}
