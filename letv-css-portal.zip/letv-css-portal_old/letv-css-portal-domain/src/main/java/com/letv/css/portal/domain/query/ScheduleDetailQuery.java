package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

import java.util.Date;
import java.util.List;

/**
 * BPO班表明细查询类
 *
 * @Author yxh
 * @Version 2017-05-31 22:55:37
 */
public class ScheduleDetailQuery extends Query{
	/**
	 * BPO班表信息ID
	 */
	private Long sId;
	/**
	 * 班表计划ID
	 */
	private Long spId;
	/**部门id，职场*/
	private Long depId;
	/**部门code，职场*/
	private String depCode;
	/**班次id*/
	private Long shiftsId;
	/**业务线num*/
	private Integer busId;
	/**排班日期*/
	private Date planDate;
	/**
	 * 指定时间列表
	 */
	private List<Date> querylanDate;
	
	/**
	 * 是否需要 STAFFID 为空
	 */
	private boolean needNullStaffId = false;
	
	private boolean needNotNullStaffId = false;
	
	private boolean needGroupPlanDate = false;

	private boolean needGroupShiftsId = false;
	
	private boolean needOrderAutoCode = false;
	
	private boolean needOrderPlanDate = false;
	
	
	public Long getDepId() {
		return depId;
	}
	public void setDepId(Long depId) {
		this.depId = depId;
	}
	public Long getShiftsId() {
		return shiftsId;
	}
	public void setShiftsId(Long shiftsId) {
		this.shiftsId = shiftsId;
	}
	public Integer getBusId() {
		return busId;
	}
	public void setBusId(Integer busId) {
		this.busId = busId;
	}
	public Date getPlanDate() {
		return planDate;
	}
	public void setPlanDate(Date planDate) {
		this.planDate = planDate;
	}
	public String getDepCode() {
		return depCode;
	}
	public void setDepCode(String depCode) {
		this.depCode = depCode;
	}

	public Long getsId() {
		return sId;
	}

	public void setsId(Long sId) {
		this.sId = sId;
	}

	public List<Date> getQuerylanDate() {
		return querylanDate;
	}

	public void setQuerylanDate(List<Date> querylanDate) {
		this.querylanDate = querylanDate;
	}
	public boolean isNeedNullStaffId() {
		return needNullStaffId;
	}
	public void setNeedNullStaffId(boolean needNullStaffId) {
		this.needNullStaffId = needNullStaffId;
	}
	public boolean isNeedGroupPlanDate() {
		return needGroupPlanDate;
	}
	public void setNeedGroupPlanDate(boolean needGroupPlanDate) {
		this.needGroupPlanDate = needGroupPlanDate;
	}
	public boolean isNeedOrderAutoCode() {
		return needOrderAutoCode;
	}
	public void setNeedOrderAutoCode(boolean needOrderAutoCode) {
		this.needOrderAutoCode = needOrderAutoCode;
	}
	public boolean isNeedOrderPlanDate() {
		return needOrderPlanDate;
	}
	public void setNeedOrderPlanDate(boolean needOrderPlanDate) {
		this.needOrderPlanDate = needOrderPlanDate;
	}
	public boolean isNeedGroupShiftsId() {
		return needGroupShiftsId;
	}
	public void setNeedGroupShiftsId(boolean needGroupShiftsId) {
		this.needGroupShiftsId = needGroupShiftsId;
	}
	public boolean isNeedNotNullStaffId() {
		return needNotNullStaffId;
	}
	public void setNeedNotNullStaffId(boolean needNotNullStaffId) {
		this.needNotNullStaffId = needNotNullStaffId;
	}
	public Long getSpId() {
		return spId;
	}
	public void setSpId(Long spId) {
		this.spId = spId;
	}
	
}
