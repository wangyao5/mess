package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

import java.util.Date;

/**
 * 员工信息查询类
 *
 * @Author menghan
 * @Version 2017-01-05 18:34:35
 */
public class StaffQuery extends Query {
    /**
     * Id自增
     */
    private Long id;
    /**
     * 姓名
     */
    private String name;
    /**
     * 联系方式
     */
    private String phoneNo;
    /**
     * 岗位
     */
    private String jobTitle;
    /**
     * 可见岗位
     */
    private String jobTitles;
    /**
     * 客服工号
     */
    private String csId;
    /**
     * 职位状态
     */
    private String positionStatus;
    /**
     * 层级：上级部门，同级部门，下级部门
     */
    private Integer range;
    /**
     * 部门层级
     */
    private Integer level;
    /**
     * 所在部门Id
     */
    private Integer depId;
    /**
     * 可见部门Ids
     */
    private String depIds;
    /**
     * 部门编码
     */
    private String code;
    private String leAccount;

    /**
     * 班次ID
     */
    private Long shiftsId;
    /**
     * 班段ID,目前不存储
     */
    private Long periodId;
    /**
     * 调整时间
     */
    private Date adjustTime;
    
    /**
     * 业务线编号
     */
    private Integer service;
    
    public Integer getService() {
        return service;
    }

    public void setService(Integer service) {
        this.service = service;
    }

    public Date getAdjustTime() {
        return adjustTime;
    }

    public void setAdjustTime(Date adjustTime) {
        this.adjustTime = adjustTime;
    }


    public Long getShiftsId() {
        return shiftsId;
    }

    public void setShiftsId(Long shiftsId) {
        this.shiftsId = shiftsId;
    }

    public Long getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Long periodId) {
        this.periodId = periodId;
    }

    public String getLeAccount() {
        return leAccount;
    }

    public void setLeAccount(String leAccount) {
        this.leAccount = leAccount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getCsId() {
        return csId;
    }

    public void setCsId(String csId) {
        this.csId = csId;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getPositionStatus() {
        return positionStatus;
    }

    public void setPositionStatus(String positionStatus) {
        this.positionStatus = positionStatus;
    }

    public Integer getDepId() {
        return depId;
    }

    public void setDepId(Integer depId) {
        this.depId = depId;
    }

    public String getDepIds() {
        return depIds;
    }

    public void setDepIds(String depIds) {
        this.depIds = depIds;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

	public String getJobTitles() {
		return jobTitles;
	}

	public void setJobTitles(String jobTitles) {
		this.jobTitles = jobTitles;
	}

}
