package com.letv.css.portal.domain.vo.workflow.bean;

import java.util.List;

/**
 * Created by G on 2016/11/30.
 */
public class QuerySumRow {
    public String flowId;
    public String flowName;
    public List<QuerySumResult> rows;

    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId;
    }

    public List<QuerySumResult> getRows() {
        return rows;
    }

    public void setRows(List<QuerySumResult> rows) {
        this.rows = rows;
    }

    public String getFlowName() {
        return flowName;
    }

    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    @Override
    public String toString() {
        return "QuerySumRow{" +
                "flowId='" + flowId + '\'' +
                ", flowName='" + flowName + '\'' +
                ", rows=" + rows +
                '}';
    }
}
