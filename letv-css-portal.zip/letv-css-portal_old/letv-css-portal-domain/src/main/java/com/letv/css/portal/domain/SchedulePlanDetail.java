package com.letv.css.portal.domain;

import java.util.Date;
import java.util.Objects;

/**
 * 总班表明细信息
 *
 * @Author menghan
 * @Version 2017-05-24 16:40:05
 */
public class SchedulePlanDetail implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8832166652064906471L;
	/**主键*/
	private Long id;
	/**总班表id*/
	private Long spId;
	/**部门id，职场*/
	private Long depId;
	/**班次Id*/
	private Long shiftsId;
	/**餐时标准*/
	private Integer mealStandard;
	/**业务线id，对应字典中业务的num*/
	private Integer busId;
	/**排班日期*/
	private Date planDate;
	/**排班计划人数*/
	private Integer num;
	/**创建人*/
	private String createUser;
	/**创建时间*/
	private Date createTime;
	/**修改人*/
	private String updateUser;
	/**修改时间*/
	private Date updateTime;
	/**备注*/
	private String remark;
	/**是否有效,0删除  1未删除*/
	private Integer yn;
	
	private SchedulePlan schedulePlan;
	
	private Dep dep;
	
	private Shifts shifts;
	
	/* GREG 已排班数 */
	private Integer scheduleCount;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSpId() {
		return spId;
	}

	public void setSpId(Long spId) {
		this.spId = spId;
	}

	public Long getDepId() {
		return depId;
	}

	public void setDepId(Long depId) {
		this.depId = depId;
	}

	public Long getShiftsId() {
		return shiftsId;
	}

	public void setShiftsId(Long shiftsId) {
		this.shiftsId = shiftsId;
	}

	public Integer getMealStandard() {
		return mealStandard;
	}

	public void setMealStandard(Integer mealStandard) {
		this.mealStandard = mealStandard;
	}

	public Integer getBusId() {
		return busId;
	}

	public void setBusId(Integer busId) {
		this.busId = busId;
	}

	public Date getPlanDate() {
		return planDate;
	}

	public void setPlanDate(Date planDate) {
		this.planDate = planDate;
	}

	public Integer getNum() {
		return num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getYn() {
		return yn;
	}

	public void setYn(Integer yn) {
		this.yn = yn;
	}

	public SchedulePlan getSchedulePlan() {
		return schedulePlan;
	}

	public void setSchedulePlan(SchedulePlan schedulePlan) {
		this.schedulePlan = schedulePlan;
	}

	public Dep getDep() {
		return dep;
	}

	public void setDep(Dep dep) {
		this.dep = dep;
	}

	public Shifts getShifts() {
		return shifts;
	}

	public void setShifts(Shifts shifts) {
		this.shifts = shifts;
	}

	public Integer getScheduleCount() {
		return scheduleCount;
	}

	public void setScheduleCount(Integer scheduleCount) {
		this.scheduleCount = scheduleCount;
	}

	//重写equals和hashCode方法
	@Override
	public boolean equals(Object obj) {
		if(obj == this)
			return true;
		if(!(obj instanceof SchedulePlanDetail))
			return false;
		SchedulePlanDetail schedulePlanDetail = (SchedulePlanDetail) obj;
		return Objects.equals(depId, schedulePlanDetail.getDepId())
				&& Objects.equals(planDate, schedulePlanDetail.getPlanDate())
				&& Objects.equals(shiftsId, schedulePlanDetail.getShiftsId());
	}

	@Override
	public int hashCode() {
		return Objects.hash(depId,planDate,shiftsId);
	}
}
