package com.letv.css.portal.domain.constant.enums;

/**
 * 岗位调整枚举值
 *
 * @Author menghan
 * @Version 2017-01-13 20:45:07
 */
public enum JobTitleAdjustmentEnum {

	SCALE_EXPANSION(1,"规模扩张"),
	DIMISSION_ALTERNATE(2,"原岗位人员离职递补"),
	NEW_POST_ESTABLISHMENT(3,"新岗位设立"),
	OTHER(4,"其他");
	
	private Integer key;
	private String value;
	
	private JobTitleAdjustmentEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
	
}
