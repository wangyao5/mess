package com.letv.css.portal.domain.query;

import java.util.Date;

/**
 * Created by shenguiqin on 2017/3/3.
 */
public class CommonQueue {
    private Long id;
    private Long onlyId;
    private String onlyType;
    private Integer eventId;
    private Integer requestNum;
    private String requestRemake;
    private Integer status;
    private Date creationDate;
    private String createdBy;
    private Date changeDate;
    private String changedBy;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOnlyId() {
        return onlyId;
    }

    public void setOnlyId(Long onlyId) {
        this.onlyId = onlyId;
    }

    public String getOnlyType() {
        return onlyType;
    }

    public void setOnlyType(String onlyType) {
        this.onlyType = onlyType;
    }

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public Integer getRequestNum() {
        return requestNum;
    }

    public void setRequestNum(Integer requestNum) {
        this.requestNum = requestNum;
    }

    public String getRequestRemake() {
        return requestRemake;
    }

    public void setRequestRemake(String requestRemake) {
        this.requestRemake = requestRemake;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }
}
