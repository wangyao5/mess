package com.letv.css.portal.domain.constant.enums;

/**
 * 工作性质
 *
 * @Author menghan
 * @Version 2017-02-08 13:37:52
 */
public enum WorkingPropertyEnum {

	INTERNSHIP(0,"实习"),
	FULL_TIME(1,"全职"),
	SOCIAL_PART_TIME(2,"社会兼职"),
	STUDENT_PART_TIME(3,"学生兼职");
	
	WorkingPropertyEnum(Integer key,String value){
		this.key = key;
		this.value = value;
	}
	private Integer key;
	private String value;
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
}
