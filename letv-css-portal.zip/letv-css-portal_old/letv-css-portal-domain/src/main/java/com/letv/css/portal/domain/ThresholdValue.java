package com.letv.css.portal.domain;

import java.util.Date;

/**
 * 阈值参数表
 * @author gexuliang
 *
 */
public class ThresholdValue {
	
	/**
	 * 排班算法-第一阶段结束-人均班次占比阈值
	 */
	public static String SCHEDULING_FIRST_PRE_SHIFTS_PROPORTION = "FIRST_PRE_SHIFTS_PROPORTION";
	
	
	/**
	 * 主键
	 */
	private Long id;
	/**
	 * 主键别名 唯一
	 */
	private String code;
	/**
	 * 阈值名称
	 */
	private String name;
	/**
	 * 阈值值
	 */
	private String value;
	/**
	 * 创建人
	 */
	private String createUser;
	/**
	 * 创建时间
	 */
	private Date createTime;
	/**
	 * 修改人
	 */
	private String updateUser;
	/**
	 * 修改时间
	 */
	private Date updateTime;

	/************************set and get**********************/
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
}
