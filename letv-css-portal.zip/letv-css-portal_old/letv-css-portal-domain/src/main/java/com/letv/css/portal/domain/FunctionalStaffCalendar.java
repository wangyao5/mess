package com.letv.css.portal.domain;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 职能岗位工作日历表
 * @author gexuliang
 */
public class FunctionalStaffCalendar {
	
	/**
	 * 流水号
	 */
	private Long id;
	/**
	 * 预计时间
	 */
	private Date planDate;
	/**
	 * 预计时间-字符串
	 */
	private String planDateStr;
	/**
	 * 工作状态
	 */
	private Integer workStatus;
	/**
	 * 班次编号
	 */
	private Long shiftsId;
	/**
	 * 排班状态
	 */
	private String schedulingStatus;
	/**
	 * 创建时间
	 */
	private Date createTime;
	/**
	 * 创建用户
	 */
	private String createUser;
	/**
	 * 修改用户
	 */
	private String updateUser;
	/**
	 * 修改时间
	 */
	private Date updateTime;
	/**
	 * 删除标示
	 */
	private Integer yn;
	/************************set and get**********************/
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getPlanDate() {
		return planDate;
	}
	public void setPlanDate(Date planDate) { 
		this.planDate = planDate;
	}
	public Integer getWorkStatus() {
		return workStatus;
	}
	public void setWorkStatus(Integer workStatus) {
		this.workStatus = workStatus;
	}
	public Long getShiftsId() {
		return shiftsId;
	}
	public void setShiftsId(Long shiftsId) {
		this.shiftsId = shiftsId;
	}
	public String getSchedulingStatus() {
		return schedulingStatus;
	}
	public void setSchedulingStatus(String schedulingStatus) {
		this.schedulingStatus = schedulingStatus;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getYn() {
		return yn;
	}
	public void setYn(Integer yn) {
		this.yn = yn;
	}
	public String getPlanDateStr() {
		if(planDate!=null){
			SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return dateFormater.format(planDate);
		}else{
			return "";
		}
	}
	
}
