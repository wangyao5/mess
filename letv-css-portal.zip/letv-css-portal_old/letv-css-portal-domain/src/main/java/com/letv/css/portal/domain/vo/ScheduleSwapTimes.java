package com.letv.css.portal.domain.vo;

/**
 * 实际换班次数
 */
public class ScheduleSwapTimes extends ScheduleSegment {
    /**
     * 主动换班次数
     */
    private int activeSwapTimes;
    /**
     * 被动换班次数
     */
    private int passiveSwapTimes;

    public int getActiveSwapTimes() {
        return activeSwapTimes;
    }

    public void setActiveSwapTimes(int activeSwapTimes) {
        this.activeSwapTimes = activeSwapTimes;
    }

    public int getPassiveSwapTimes() {
        return passiveSwapTimes;
    }

    public void setPassiveSwapTimes(int passiveSwapTimes) {
        this.passiveSwapTimes = passiveSwapTimes;
    }
}
