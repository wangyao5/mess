package com.letv.css.portal.domain.constant.enums;

/**
 * 通过结果枚举类
 *
 * @Author menghan
 * @Version 2017-01-10 18:38:44
 */
public enum ResultEnum {

	ONE_PASS(1,"一次通过"),
	MAKE_UP_PASS(2,"补考通过"),
	NOT_pass(3,"不通过"),
	ELIMINATE(4,"小测不达标淘汰");
	
	private Integer key;
	private String value;
	private ResultEnum(Integer key, String value) {
		this.key = key;
		this.value = value;
	}
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
