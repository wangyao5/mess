package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

import javax.xml.bind.annotation.XmlInlineBinaryData;
import java.util.Date;

/**
 * BPO排班表查询类
 *
 * @Author yxh
 * @Version 2017-05-31 22:02:37
 */
public class ScheduleQuery extends Query{
	/**业务id*/
	private Long busId;
	/**部门id，职场*/
	private Long depId;
	/**部门code*/
	private String code;
	/**查询--起始日期*/
	private String startTime;
	/**查询--结束日期*/
	private String endTime;
	/**任务状态 默认:0新建 1 已提交 2 驳回 3 完成 */
	private Integer status;
	/**
	 * 可见部门Ids
	 */
	private String depIds;

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getDepId() {
		return depId;
	}
	public void setDepId(Long depId) {
		this.depId = depId;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}

	public Long getBusId() {
		return busId;
	}

	public void setBusId(Long busId) {
		this.busId = busId;
	}

	public String getDepIds() {
		return depIds;
	}

	public void setDepIds(String depIds) {
		this.depIds = depIds;
	}
}
