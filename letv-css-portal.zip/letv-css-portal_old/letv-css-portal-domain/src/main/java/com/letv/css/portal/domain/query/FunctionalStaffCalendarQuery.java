package com.letv.css.portal.domain.query;

import com.letv.common.utils.page.Query;

/**
 * 职能岗位工作日历
 * @Author greg
 */
public class FunctionalStaffCalendarQuery extends Query{
	/* 年份. */
	private Integer planYear;
	/* 月份. */
	private Integer planMonth;
	/* 班次编号. */
	private String shiftsId;
	/* 工作状态集合. */
	private String workStatusJson;
	/* 排班状态. */
	private String schedulingStatus;
	
	public Integer getPlanYear() {
		return planYear;
	}

	public void setPlanYear(Integer planYear) {
		this.planYear = planYear;
	}

	public Integer getPlanMonth() {
		return planMonth;
	}

	public void setPlanMonth(Integer planMonth) {
		this.planMonth = planMonth;
	}

	public String getShiftsId() {
		return shiftsId;
	}

	public void setShiftsId(String shiftsId) {
		this.shiftsId = shiftsId;
	}

	public String getWorkStatusJson() {
		return workStatusJson;
	}

	public void setWorkStatusJson(String workStatusJson) {
		this.workStatusJson = workStatusJson;
	}

	public String getSchedulingStatus() {
		return schedulingStatus;
	}

	public void setSchedulingStatus(String schedulingStatus) {
		this.schedulingStatus = schedulingStatus;
	}
	
}
