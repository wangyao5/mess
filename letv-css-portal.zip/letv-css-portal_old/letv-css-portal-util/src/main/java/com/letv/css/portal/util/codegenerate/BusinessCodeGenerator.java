package com.letv.css.portal.util.codegenerate;

import com.letv.common.utils.Identities;

/**
 * 业务编码生成类
 * <p/>
 * 目前生成业务系统、角色、资源编码
 * <p/>
 * User: gaohongjing Date: 2014-6-6 Time: 上午10:08:28 Version: 1.0
 */
public class BusinessCodeGenerator {

    /** 业务系统编码前缀 */
    private final static String SYSTEM_CODE_PREFIX = "S";
    /** 角色编码前缀 */
    private final static String ROLE_CODE_PREFIX = "RO";
    /** 资源编码前缀 */
    private final static String RESOURCE_CODE_PREFIX = "RE";

    /**
     * 生成业务系统编码<br/>
     * 业务系统编码系统生成，规则S+NNN（三位序列） (例S001，NNN为自增序列，取ID值，若不超过三位数，前面用0补齐 否则规则为S+ID，比如1000 ，编码为S1000)
     * 
     * @param id
     *            业务系统ID
     * @return
     */
    public static String getSystemCode(Long id) {
        return Identities.generateCode(SYSTEM_CODE_PREFIX, id, 3);
    }

    /**
     * 生成角色编码<br/>
     * 角色编码，编码系统生成，规则ROXXXX (例RO0001，XXXX为自增序列，取ID值，若ID不超过四位数，前面用0补齐； 否则规则为S+ID，比如10000 ，编码为RO10000)
     * 
     * @param id
     *            业务系统ID
     * @return
     */
    public static String getRoleCode(Long id) {
        return Identities.generateCode(ROLE_CODE_PREFIX, id, 4);
    }

    /**
     * 生成资源编码<br/>
     * 资源编码系统生成，规则REXXXXX（五位序列） (例RE00001，XXXXX为自增序列，取ID值，若不超过五位数，前面用0补齐 否则规则为RE+ID，比如1000000 ，编码为RE1000000)
     * 
     * @param id
     *            资源ID
     * @return
     */
    public static String getResourceCode(Long id) {
        return Identities.generateCode(RESOURCE_CODE_PREFIX, id, 5);
    }

}
