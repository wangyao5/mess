package com.letv.css.portal.util.web;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import com.letv.common.utils.StringUtil;
import com.letv.common.utils.cookie.CookieUtils;

/**
 * Portal Web定义:域名、cookie等
 * 
 * @author lijianzhong
 * @version 2015-8-11 下午1:46:29
 */
public class PortalWeb implements InitializingBean, Serializable {

	/** 序列化标志 */
	private static final long serialVersionUID = -6969037352176720714L;
    /** 站点标识 */
    private String siteFlag;
    /** Web域名 */
    private String webDomain;
    /** 是否使用LDAP进行账号认证 */
    private boolean useLdap = true;
    /** cookie名称 */
    private String cookieNames;// = "_i_u_cookie_";
    /** cookie所属的domain */
    private String cookieDomain;
    /** cookies */
    private List<PortalCookie> cookies;

    protected final Log LOG = LogFactory.getLog(getClass());

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() throws Exception {
        Assert.hasText(siteFlag, "'siteFlag' must be not empty");
        Assert.hasText(webDomain, "'webDomain' must be not empty");
        Assert.hasText(cookieNames, "'cookieName' must be not empty");
        Assert.hasText(cookieDomain, "'cookieDomain' must be not empty");
        LOG.info("cookieNames=" + cookieNames);
        LOG.info("cookieDomain=" + cookieDomain);

        String[] names = cookieNames.split(StringUtil.SEP_COMMA);
        Assert.noNullElements(names, "names' must be not null");

        cookies = new ArrayList<PortalCookie>(names.length);
        for (int i = 0; i < names.length; i++) {
            String name = names[i];
            cookies.add(new PortalCookie(name, cookieDomain, CookieUtils.DEFAULT_COOKIE_PATH));
        }
    }

    /**
     * @return the siteFlag
     */
    public String getSiteFlag() {
        return siteFlag;
    }

    /**
     * @param siteFlag
     *            the siteFlag to set
     */
    public void setSiteFlag(String siteFlag) {
        this.siteFlag = siteFlag;
    }

    /**
     * @return the webDomain
     */
    public String getWebDomain() {
        return webDomain;
    }

    /**
     * @param webDomain
     *            the webDomain to set
     */
    public void setWebDomain(String webDomain) {
        this.webDomain = webDomain;
    }

    /**
     * @return the useLdap
     */
    public boolean isUseLdap() {
        return useLdap;
    }

    /**
     * @param useLdap
     *            the useLdap to set
     */
    public void setUseLdap(boolean useLdap) {
        this.useLdap = useLdap;
    }

    /**
     * @param cookieNames
     *            the cookieNames to set
     */
    public void setCookieNames(String cookieNames) {
        this.cookieNames = cookieNames;
    }

    /**
     * @param cookieDomain
     *            the cookieDomain to set
     */
    public void setCookieDomain(String cookieDomain) {
        this.cookieDomain = cookieDomain;
    }
    
    /**
	 * @return the cookieDomain
	 */
	public String getCookieDomain() {
		return cookieDomain;
	}

    /**
     * 写入portal定义的所有cookie
     * 
     * @param response
     * @param cookieValue
     */
    public void setCookies(HttpServletResponse response, String cookieValue) {
        for (PortalCookie cookie : this.cookies) {
            // 写入cookie
            CookieUtils.setCookie(response, cookie.getName(), cookieValue, cookie.getDomain(), cookie.getPath());
            LOG.debug("set cookie, name=" + cookie.getName() + ", domain= " + cookie.getDomain() + ", value= "
                    + cookieValue);
        }

    }

    /**
     * 设置portal定义的所有cookie失效
     * 
     * @param response
     */
    public void invalidateCookies(HttpServletResponse response) {
        for (PortalCookie cookie : this.cookies) {
            CookieUtils.invalidateCookie(response, cookie.getName(), cookie.getDomain(), cookie.getPath());
            LOG.debug("invalidate cookie, name=" + cookie.getName() + ", domain= " + cookie.getDomain());
        }
    }

}
