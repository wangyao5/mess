package com.letv.css.portal.util.web;

import com.letv.common.utils.DateHelper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by yangxinghe on 2017/6/12.
 */
public class ExcelUtil {
    /**
     * 创建EXL workbook
     * @param fileName
     * @param wb
     * @param in
     * @return
     * @throws IOException
     */
    public static Workbook createWorkbook(String fileName, Workbook wb, FileInputStream in) throws IOException {
        if (fileName.endsWith(".xls")) {
            // Excel2003
            wb = new HSSFWorkbook(in);
        } else {
            // Excel 2007
            wb = new XSSFWorkbook(in);
        }
        return wb;
    }
    //读取excel单元格中的数值
    public static String readValue(Cell cell) {
        if (cell == null) {
            return null;
        }
        String value = "";
        if (Cell.CELL_TYPE_STRING == cell.getCellType()) {
            value = cell.getStringCellValue();
        }else if (Cell.CELL_TYPE_NUMERIC == cell.getCellType()) {
            DecimalFormat df = new DecimalFormat("0");
            Number v = cell.getNumericCellValue();
            value = df.format(v);
        }
        return value;
    }

    //读取excel中的日期
    public static Date readDateValue(Cell cell) {
        int cellType = cell.getCellType();
        if (cellType == Cell.CELL_TYPE_STRING) {
        	Date resultDate = DateHelper.parseDate(cell.getStringCellValue(), "yyyy/MM/dd");
        	if(resultDate == null){
        		resultDate = DateHelper.parseDate(cell.getStringCellValue(), "yyyy-MM-dd");
        	}
            return resultDate;
        } else {
            return cell.getDateCellValue();
        }
    }
}
