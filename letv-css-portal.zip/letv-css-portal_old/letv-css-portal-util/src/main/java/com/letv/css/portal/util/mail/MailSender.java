package com.letv.css.portal.util.mail;

import java.util.Properties;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

public class MailSender{

	private static final Log LOG = LogFactory.getLog(MailSender.class);
	
	private static final JavaMailSenderImpl mailSender = new JavaMailSenderImpl();;
	//发件人username
	private static final String MAIL_USERNAME = "cc-bpo";
	//发件人邮箱密码
	private static final String MAIL_PASSWORD = "*?gJPU3@NLn:6F^pMI*!";
	//邮箱host
	private static final String MAIL_HOST = "smtp.letv.cn";
	//文本编码
	private static final String MAIL_TEXT_ENCODING = "utf8";
	//邮箱验证
	private static final String MAIL_IS_AUTH = "true";
	//发件人邮箱
	private static String FROM_USER = "cc-bpo@le.com";

	//邮箱认证
	static{
		mailSender.setUsername(MAIL_USERNAME);
		mailSender.setPassword(MAIL_PASSWORD);
		mailSender.setHost(MAIL_HOST);
		mailSender.setDefaultEncoding(MAIL_TEXT_ENCODING);
		Properties javaMailProperties = new Properties();
        javaMailProperties.put("mail.smtp.auth", MAIL_IS_AUTH);
        mailSender.setJavaMailProperties(javaMailProperties);
	}
	
	/**
	 * 发送邮件
	 * @param to:收件人地址；subject：主题；content：内容。
	 * @return
	 */
	public static boolean sendEmail(String[] to,String subject,String content){
		try {
			MimeMessage mimeMessage = mailSender.createMimeMessage();
			MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage);;
			mimeMessageHelper.setTo(to);
			mimeMessageHelper.setFrom(FROM_USER);
			mimeMessageHelper.setSubject(subject);
			mimeMessageHelper.setText(content,true);
			mailSender.send(mimeMessage);
			return true;
		} catch (Exception e) {
			LOG.error("邮件发送失败，to："+to+",subject:"+subject+",content:"+content,e);
			return false;
		}
	}
	
}
