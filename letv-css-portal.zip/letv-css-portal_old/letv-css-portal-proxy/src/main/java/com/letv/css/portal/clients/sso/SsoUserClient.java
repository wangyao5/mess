package com.letv.css.portal.clients.sso;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.letv.common.utils.security.MD5Util;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.css.portal.clients.sso.response.BaseSsoResponse;
import com.letv.css.portal.clients.sso.response.TransCodeResponse;
import com.letv.css.portal.clients.sso.response.UserQueryResponse;
import com.letv.css.portal.clients.sso.response.UserResponse;

/**
 * 单点登录服务客户端
 * 
 * @author lijianzhong
 * 
 */
public class SsoUserClient extends AbstractSsoClient {

    private static final String SUCCESS_STATUS = "1";
    private static final String ENCODE = "ENCODE";
    private static final String DECODE = "DECODE";

    private static final Log LOG = LogFactory.getLog(SsoUserClient.class);

    /**
     * 账号密码验证
     * 
     * @param name
     * @param password
     * @return
     */
    public boolean checkUser(String name, String password) {
        String url = super.getServiceUrlDomain() + "check_user.php";

        TreeMap<String, String> urlVariableMap = new TreeMap<String, String>();
        urlVariableMap.put("username", name);
        urlVariableMap.put("password", this.encode(password));
        urlVariableMap.put("site", this.getSite());
        urlVariableMap.put("time", this.getTimestamp());

        UserResponse response = this.getForEntity(url, UserResponse.class, urlVariableMap);
        return isSuccess(response);
    }

    /**
     * 依据账号查询详细信息
     * 
     * @param username
     * @return
     */
    public Map<String, Object> queryUser(String username) {
        String url = super.getServiceUrlDomain() + "user.php";

        TreeMap<String, String> urlVariableMap = new TreeMap<String, String>();
        urlVariableMap.put("username", username);
        urlVariableMap.put("site", this.getSite());
        urlVariableMap.put("time", this.getTimestamp());

        UserQueryResponse response = this.getForEntity(url, UserQueryResponse.class, urlVariableMap);
        if (isSuccess(response)) {
            return response.getObjects();
        }
        return null;
    }

    /**
     * 加密
     * 
     * @param value
     * @return
     */
    public String encode(String value) {
        return this.transcode(ENCODE, urlEncode(value));
    }

    /**
     * 解密
     * 
     * @param value
     * @return
     */
    public String decode(String value) {
        return this.transcode(DECODE, value);
    }

    /**
     * 调用单点登录系统进行加密解密
     * 
     * @param type
     * @param value
     * @return
     */
    protected String transcode(String type, String value) {
        String url = super.getServiceUrlDomain() + "transcode.php";

        TreeMap<String, String> urlVariableMap = new TreeMap<String, String>();
        urlVariableMap.put("v", value);
        urlVariableMap.put("type", type);
        urlVariableMap.put("site", this.getSite());
        urlVariableMap.put("time", this.getTimestamp());

        TransCodeResponse response = this.getForEntity(url, TransCodeResponse.class, urlVariableMap);

        if (isSuccess(response)) {
            return response.getObjects();
        }
        return null;
    }

    // letv sso接口调用要求url参数有序，故使用TreeMap有序的特点。
    protected <T> T getForEntity(String url, Class<T> responseType, TreeMap<String, String> urlVariableMap) {
        if (MapUtils.isEmpty(urlVariableMap)) {
            return null;
        }

        T response = null;
        try {
            StringBuilder builder = new StringBuilder();
            for (Map.Entry<String, String> entry : urlVariableMap.entrySet()) {
                builder.append("&").append(entry.getKey()).append("=").append(entry.getValue());
            }

            String signKey = getSignKey();
            String urlVariables = builder.substring(1);// 去掉第一个 &
            String sign = MD5Util.md5Hex(urlVariables + signKey);// md5 32位小写
            url = url + "?" + urlVariables + "&sign=" + sign;

            LOG.info("getForEntity url: " + url);
            String json = super.getRestTemplate().getForObject(url, String.class);

            LOG.info("getForEntity response data: " + json);
            response = JsonHelper.toBean(json, responseType);
        } catch (Exception e) {
            LOG.warn("getForEntity has error,", e);
        }
        return response;
    }

    /**
     * @param v
     * @return
     * 
     */
    private String urlEncode(String v) {
        try {
            return URLEncoder.encode(v, "UTF-8");
        } catch (UnsupportedEncodingException e) {
        }
        return null;
    }

    private boolean isSuccess(BaseSsoResponse<?> response) { 
        return null != response && null != response.getRespond()
                && SUCCESS_STATUS.equals(response.getRespond().getStatus());
    }

}
