/**
 * 
 */
package com.letv.css.portal.clients.sso.response;

import java.util.Map;

/**
 * 
 * 单点登录用户查询返回结果
 * 
 * @author lijianzhong
 * @version 2014-11-27 下午9:22:44
 */
public class UserQueryResponse extends BaseSsoResponse<Map<String, Object>> {

    /**
     * 
     */
    private static final long serialVersionUID = 1646151495578753240L;

}
