/**
 * 
 */
package com.letv.css.portal.clients.sso.response;

/**
 * 加解密 返回值
 * 
 * @author lijianzhong
 * @version 2014-11-27 下午9:26:15
 */
public class TransCodeResponse extends BaseSsoResponse<String> {

    /**
     * 
     */
    private static final long serialVersionUID = -1365674823465785653L;

}
