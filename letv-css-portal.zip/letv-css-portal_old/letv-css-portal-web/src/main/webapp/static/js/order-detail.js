//创建订单查询下拉列表
function createOrderDateSelect(){
//	var d = new Date();
	//var str = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate();
	//alert(str);
	//var curStamp = new Date().getTime();
	//var sixMonthStamp = curStamp - 1000*3600*24*30*6;
	//var curYearStamp = new Date(new Date().getFullYear()+'/1/1').getTime();
	//var preOneYearStamp = new Date((new Date().getFullYear()-1) + "/1/1").getTime();
	//当前日期
	//var cur = new Date(parseInt(curStamp)).getFullYear() + "-" + (new Date(parseInt(curStamp)).getMonth()+1) +"-"+ new Date(parseInt(curStamp)).getDate();
	//六个月前日期
	//var six = new Date(parseInt(sixMonthStamp)).getFullYear() + "-" + (new Date(parseInt(sixMonthStamp)).getMonth()+1) +"-"+ new Date(parseInt(sixMonthStamp)).getDate();
	//今年初日期
	//var cYear = new Date(parseInt(curYearStamp)).getFullYear() + "-" + (new Date(parseInt(curYearStamp)).getMonth()+1) +"-"+ new Date(parseInt(curYearStamp)).getDate();
	//去年初日期
	//var preYear = new Date(parseInt(preOneYearStamp)).getFullYear() + "-" + (new Date(parseInt(preOneYearStamp)).getMonth()+1) +"-"+ new Date(parseInt(preOneYearStamp)).getDate();

//	var select = $("#order-date-select");
//	select.append("<option value='1'>近六个月订单</option>");
//	select.append("<option value='2'>"+d.getFullYear()+"年内订单</option>");
//	select.append("<option value='3'>"+(d.getFullYear()-1)+"年的订单</option>");
//	select.append("<option value='4'>"+(d.getFullYear()-1)+"年之前的订单</option>");
}

//显示父子单信息
function clickFiliationOrder(){
	var orderId = $("#filiationVal").val();
	if(orderId=="" || orderId==undefined || orderId==null){
		return;
	}
	if($("#filiation").css("display")=="none"){
    	$("#filiation").css("display","block");
    }else{
      	$("#filiation").css("display","none");
    }
	jQuery.ajax({
		type: "GET",
		url: basePath + "/order/queryFiliationOrderList",
		dataType : 'json',
		data:{"orderId":orderId},
		success: function(data){
			if(data!=null && data.code==200 && data.result!=null){
				var result = data.result;
				var str = "";
				var parents = new Array();
				var children = new Array();
				$(result).each(function(i,v){
					if(v.isParent=="是"){
						parents.push(v.orderId);
					}else{
						children.push(v.orderId);
					}
				});
				//没有子单就不显示父子单信息
				if(children.length>=1){
    				for(var p in parents){
						if(orderId==parents[p]){
    						str += "<div style='background-color:#ffcccc;'>父单号："+parents[p]+"</div>";
						}else{
							str += "<div>父单号："+parents[p]+"</div>";
						}
    				}
    				for(var c in children){
						if(orderId==children[c]){
							str += "<div style='background-color:#ffcccc;'>子单号："+orderId+"</div>";
						}else{
    						str += "<div>子单号："+"<a href='javascript:void(0)' onclick='toDetail("+children[c]+")'>"+children[c]+"</a></div>";
						}
    				}
				}else{
					str = "<span style='color: red;'>没有子单信息</span>";
				}
				$("#filiationContent").html(str);
			}
		},
		error : function(data) {
			//alert("#springMessage('view.label.detail.error')");
		}
	});
	$("#filiation").click(function(){
        $("#filiation").css("display","none");
    });
}

//根据优惠劵编码获得优惠劵信息
function getCoupon(cardNo){
	//cardNo = "jbBQLkawimh6phzt";
	if($("#couponDiv").css("display")=="none"){
    	$("#couponDiv").css("display","block");
    }else{
      	$("#couponDiv").css("display","none");
    }

	jQuery.ajax({
	type: "GET",
	url: basePath + "/order/queryCouponByNo",
	dataType : 'json',
	data: "cardNo="+cardNo,
	
	success: function(data){
		$("#couponContent").empty();
		if(data!=null && data.code==200 && data.result!=null){
			var result = data.result;
			var str="";
			str += "<tr><td>绑定用户id：</td><td>"+toStr(result.bindUserId)+"</td><td>优惠劵码：</td><td>"+toStr(result.cardNo)+"</td></tr>"
				+  "<tr><td>优惠劵金额：</td><td>"+toStr(result.cash)+"</td><td>优惠劵使用金额：</td><td>"+toStr(result.usedAmount)+"</td></tr>"
				+  "<tr><td>优惠劵结束时间：</td><td>"+toStr(result.useEndDate)+"</td><td>优惠劵来源：</td><td>"+toStr(result.source)+"</td></tr>"
		} else{
			str = "<span style='color: red;'>没有查询到该优惠劵的信息！</span>";
		}
		$("#couponContent").append(str);
		},
		error : function(data) {
			//alert("#springMessage('view.label.detail.error')");
		}
	});
	$("#couponDiv").click(function(){
        $("#couponDiv").css("display","none");
    });
}

//将null的字符串转换成“”
function toStr(str){
	if(str==null){
		return "";
	}else if(str=="null"){
		return "";
	}else{
		return str;
	}
}