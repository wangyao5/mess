var errorMsg = "查询失败";
jQuery.validator.addMethod("checkInvoice", function(value, element) {
	var invoiceCategory = $("#invoiceCategory").val();
	var invoiceFlag = false;
	if( invoiceCategory==1 || (value!=null&&value!=""&&value!="undefined")){
		invoiceFlag = true;
	}
    return invoiceFlag;
}, "请填写发票抬头");
jQuery.validator.addMethod("isMobile", ismobile, "请正确填写您的手机号码");
//检测商品列表是否为空
function checkProductInfo(){
	var productFlag = false;
	var productChecked = $('input:checkbox[id=idcheckbox]:checked');
	if(productChecked!='undefined' && productChecked.length > 0){
		productFlag = true;
	}
	return productFlag;
}
//查询1级地址
function searchSelectArea1(){  
    var provinceId = 0;
    $('#city').empty();
    $('#district').empty();
    queryAreaInfo("province", provinceId);
}

function querySellerInfo(){
    var url = basePath+'/employee/query';
    var employee = $('#sellerName').val();
    var postData = {name:employee};

    jqueryPost(url, postData, function (data){

        if(data!=null){
             var r = data.result;
             if(r==null || r=='undefined' || r=='' || r=='null'||r.length!=1){
            	 alert("人员账号输入错误.");
                 $('#sellerName').val('');
                 $('#sellerId').val('');
            	 return false;
             }
			 alert("查询成功!");
             var _data = r[0];

             $('#sellerId').val(_data.name);
             $('#sellerName').val(_data.name);
         } else {
             alert(errorMsg);
                 $('#sellerName').val('');
                 $('#sellerId').val('');
         }
    });
}
//查询2级地址
function searchSelectArea2(){
    $('#city').empty();
    $('#district').empty();
    var provinceId = $('#province').find("option:selected").val();
    queryAreaInfo("city", provinceId);
}
//查询3级地址
function searchSelectArea3(){   
    $('#district').empty();
    var provinceId = $('#city').find("option:selected").val();
    queryAreaInfo("district", provinceId);
}
//三级地址公共查询
function queryAreaInfo(inputId, areaNo){
    var url = basePath+'/area/queryAreaInfo';
    var postData = {areaNo:areaNo};
    jqueryPost(url, postData, function (data){
    	$('#'+inputId).empty();
        if(data!=null){
             var r = data.result;
             if(r==null || r=='undefined' || r=='' || r=='null'){
             }
             $('#'+inputId).append("<option value=''>-请选择-</option>");
             for(var i = 0;i < r.length;i++){
                 var _data = r[i];  
                 _htmlcontent="<option value='" + _data.areaNo+ "'>" + _data.areaName + "</option>";
                 $('#'+inputId).append(_htmlcontent);
             }
         } else {
             alert(errorMsg);
         }
    });
}
//设置完整地址
function setFullAddress(){
    var provinceName = $('#province').find("option:selected").text();
    var cityName = $('#city').find("option:selected").text();
    var districtName = $('#district').find("option:selected").text();
    var address = $('#address').val();
    $('#fullAddress').val(provinceName+cityName+districtName+address);
}
//部门信息查询
function queryDepartmentInfo(departmentType){
    var url = basePath+'/department/query';
    var postData = {departmentType:departmentType,status:1};
    jqueryPost(url, postData, function (data){
        $('#department').empty();
        if(data!=null){
             var r = data.result;
             if(r==null || r=='undefined' || r=='' || r=='null'){
             }
             $('#department').append("<option value=''>请选择</option>");
             for(var i = 0;i < r.length;i++){
                 var _data = r[i];  
                 _htmlcontent="<option value='" + _data.departmentId+ "'>" + _data.departmentName+''+ "</option>";
                 $('#department').append(_htmlcontent);
             }
         } else {
             alert(errorMsg);
         }
    });
}
//员工信息查询
function queryEmployeeInfo(){
    var url = basePath+'/employee/query';
    var employee = $('#employeeName').val();
    var postData = {name:employee};

    jqueryPost(url, postData, function (data){

        if(data!=null){
             var r = data.result;
             if(r==null || r=='undefined' || r=='' || r=='null'||r.length!=1){
            	 alert("人员账号输入错误.");
                 $('#employee').val('');
                 $('#employeeName').val('');
                 $('#department').val('');
                 $('#departmentName').val('');
                 $('#costCenterId').val('');
            	 return false;
             }
             var _data = r[0];
             $('#employee').val(_data.name);
             $('#employeeName').val(_data.name);
             $('#department').val(_data.depCode);
             $('#departmentName').val(_data.depName);
             $('#costCenterId').val(_data.costCenter);
         } else {
             alert(errorMsg);
             $('#employee').val('');
             $('#employeeName').val('');
             $('#department').val('');
             $('#departmentName').val('');
             $('#costCenterId').val('');
         }
    });
}

//地址信息查询
function queryAddressInfo(id){
    var url = basePath+'/customerAddress/query';
    var postData = {id:id};

    jqueryPost(url, postData, function (data){

        if(data!=null){
             var r = data.result;
             if(r==null || r=='undefined' || r=='' || r=='null'||r.length!=1){
            	 alert("地址信息不存在.");
            	 return false;
             }
            var _data = r[0];
			$("#balanceType").val(_data.balanceType);
			$("#receiver").val(_data.receiver);
			$("#mobile").val(_data.mobile);
			$("#phone").val(_data.phone);
			
			$("#province").val(_data.province);
			searchSelectArea2();
			$("#city").val(_data.city);
			searchSelectArea3();
			$("#district").val(_data.district);
			$("#address").val(_data.address);
			$("#fullAddress").val(_data.fullAddress);

			$("#invoiceTitle").val(_data.invoiceTitle);
         } else {
             alert(errorMsg);
         }
    });
}
// 刷新下拉搜索框
function freshChosenSelect() {
	var config = {'.chosen-select':{width:"67%", search_contains:true}}
	for ( var selector in config) {
		$(selector).chosen(config[selector]);
		$('.chosen-select').trigger("chosen:updated");
	}
}
// jqueryPost查询
function jqueryPost(url, postData, callback){
    jQuery.ajax({
         cache: false,
         type: 'post',
         dataType:'json',
         url: url,
         data: postData,
         async: false,
         success: callback,
         error:function(XMLHttpRequest, textStatus, errorThrown) {
               alert(XMLHttpRequest.status);
               alert(XMLHttpRequest.readyState);
               alert(textStatus);
         }
    });
}

var skuModel = [
            {name: 'skuNo', index: 'skuNo', width: 100, sorttype: "int", hidden: true }, 
            {name: 'skuNo', index: 'skuNo', width: 120 }, 
            {name: 'skuName', index: 'skuName', width: 300 }, 
            {name: 'price', index: 'price', width: 80 }
        ];
var suiteModel = [
            {name: 'selectNo', index: 'selectNo', width: 100, sorttype: "int", hidden: true }, 
            {name: 'selectNo', index: 'selectNo', width: 120 }, 
            {name: 'suiteName', index: 'suiteName', width: 300 }, 
            {name: 'suitePrice', index: 'suitePrice', width: 80 }
        ];
var suiteSkuModel = [
                  {name: 'selectNo', index: 'selectNo', width: 100, sorttype: "int", hidden: true }, 
                  {name: 'skuNo', index: 'skuNo', width: 120 }, 
                  {name: 'suiteName', index: 'suiteName', width: 300 }, 
                  {name: 'suitePrice', index: 'suitePrice', width: 80 }
              ];
var skuNameModel = ['id', jQuery.i18nMessage['uos.skuPid'], jQuery.i18nMessage['uos.skuProductName'], jQuery.i18nMessage['uos.skuProductPrice']];
var suiteNameModel = ['id', jQuery.i18nMessage['uos.suitePid'], jQuery.i18nMessage['uos.suiteName'], jQuery.i18nMessage['uos.suitePrice']];
/**
 * 展示新增窗口
 * @param opt
 */
function showAddDialog(isSuite) {
    var pid = $('#skuPid').val().trim();
    var productName = $('#skuProductName').val().trim();
    var url = basePath + "/product/querySkuList";
    var model = skuModel;
    var nameModel = skuNameModel;
    var divModalId = "addSku-modal-form";
    var jqGridTableId = "skuProductInfoQueryTable";
    var jqGridPagerId = "skuProductInfoQueryTable";

    if(isSuite==1){
        var pid = $('#suitePid').val().trim();
        // 暂时不支持根据套装名称查询
//        var productName = $('#suiteProductName').val().trim();
        url = basePath + "/product/querySuitList";
        model = suiteModel;
        nameModel = suiteNameModel;
        divModalId = "addSuite-modal-form";
        jqGridTableId = "suiteProductInfoQueryTable";
        jqGridPagerId = "suiteProductInfoQueryPager";
    }
    if(isSuite==2){
        var pid = $('#suitePid').val().trim();
        // 暂时不支持根据套装名称查询
//        var productName = $('#suiteProductName').val().trim();
        url = basePath + "/product/querySuitSkuList";
        model = suiteSkuModel;
        nameModel = suiteNameModel;
        divModalId = "addSuite-modal-form";
        jqGridTableId = "suiteProductInfoQueryTable";
        jqGridPagerId = "suiteProductInfoQueryPager";
    }
    var postData = {code: pid, name: productName};
    jqGridFomart(postData,url,model,nameModel,divModalId,jqGridTableId,jqGridPagerId);
}
//表格结果格式化
function jqGridFomart(postData,url,model,nameModel,divModalId,jqGridTableId,jqGridPagerId){
    jQuery("#"+jqGridTableId).jqGrid({
        url: url,
        datatype: 'json',
        mtype: 'POST',
        shrinkToFit: true,
        width: '100%',
        height: '100%',
        autowidth: true,
        idPrefix: 'area',
        colNames: nameModel,
        colModel: model, 
        viewrecords: true,
        rowNum: 5,
        rowList: [5,10, 20, 30],
        pager: "#"+jqGridPagerId,
        altRows: true,
        //toppager: true,
        
        multiselect: true,
        //multikey: "ctrlKey",
        multiboxonly: true,
        
        jsonReader:{
            root:"result",
            total:"totalpages",
            page:"currpage",
            records:"totalrecords",
            repeatitems:false
        },
        sortname:'id',
        sortorder:"asc"
    }).navGrid('#'+jqGridPagerId,
        {
            add:false,
            addicon:'icon-plus green',
            addtext:'添加',
            edit:false,
            del:false,
            search:false,
            refresh:true,
            refreshicon : 'icon-refresh green'
        }, 
        {closeAfterEdit : true},  // settings for edit 
        {closeAfterAdd : true},   // settings for add
        {},
        {},
        {}
    );
    /**按商品ID，商品名称查询*/
    $("#"+jqGridTableId).jqGrid("setGridParam", {
        postData: postData 
    }).trigger("reloadGrid");
    $('#'+divModalId).modal('show');
}

var skuList = [];//已添加的商品列表，存skuCode
var count = 0;
var selectedData = [];
//添加商品
function addSku(isSuite) {
    var domIdPrex = "sku";
    var readOnly = "";
    var r = $("#isModify").val();
    if(r==0)
    	readOnly = "readOnly";

    if(isSuite){
        isSuite = true;
        domIdPrex = "suite";
        readOnly = "readOnly";
    }
    $("input[name^='jqg_"+domIdPrex+"']:checkbox:checked").each(function() {
        var tablerow = $(this).parent("td").parent("tr");
        var suitCode = tablerow.find("td[aria-describedby="+domIdPrex+"ProductInfoQueryTable_selectNo]").attr("title");
        var skuCode = tablerow.find("td[aria-describedby="+domIdPrex+"ProductInfoQueryTable_skuNo]").attr("title");
        var name = tablerow.find("td[aria-describedby="+domIdPrex+"ProductInfoQueryTable_skuName]").attr("title");
        var price = tablerow.find("td[aria-describedby="+domIdPrex+"ProductInfoQueryTable_price]").attr("title");
        if(isSuite){
            suitCode = tablerow.find("td[aria-describedby="+domIdPrex+"ProductInfoQueryTable_selectNo]").attr("title");
            skuCode = tablerow.find("td[aria-describedby="+domIdPrex+"ProductInfoQueryTable_selectNo]").attr("title");
            name = tablerow.find("td[aria-describedby="+domIdPrex+"ProductInfoQueryTable_suiteName]").attr("title");
            price = tablerow.find("td[aria-describedby="+domIdPrex+"ProductInfoQueryTable_suitePrice]").attr("title");
        }
        var num = 1;
        if (typeof(suitCode) == "undefined") {
            suitCode = "";
        }

        var skuIndex = skuList.length;
        //如果未添加进商品列表，则进行追加
        if (skuList.indexOf(skuCode) < 0) {
            selectedData.push({
                SuitCode: suitCode,
                SkuCode: skuCode,
                Name: name,
                Price: price,
                Num: num
            });
            skuList.push(skuCode);
            
            $("#productInfoTable").append(
                '<tr id="product_list_' + skuCode + '">' +
                '<th class="center"><input type="checkbox" id="idcheckbox" name="idcheckbox" checked value="'+skuCode+'"></th>' +
                '<th class="center" style="display:none;"><input name="productInfos['+count+'].suite" value="'+isSuite+'" />' + isSuite + '</th>' +
                '<th class="center" ><input style="display:none;" name="productInfos['+count+'].suiteNo" value="'+suitCode+'"/><a href="#" onclick="showProductInfoDialog(\'' + skuCode + '\')">' + suitCode + '</a></th>' +
                '<th class="center" ><input style="display:none;" name="productInfos['+count+'].skuNo" value="'+skuCode+'"/>' + skuCode + '</th>' +
                '<th class="center" ><input style="display:none;" name="productInfos['+count+'].name" value="'+name+'"/>' + name + '</th>' +
                '<th class="center" ><input style="display:none;" name="productInfos['+count+'].skuAmount" value="'+price+'"/><input type="text" name="productInfos['+count+'].price" role="textbox" value="' +parseFloat(price).toFixed(2) + '" onchange="changeSkuNum(\''+skuCode+'\')" size="1" class="center" style="width:70px;height:20px;padding:4px 0px;font-size:12px;" '+readOnly+'>' + '</th>' +
                '<th class="center" ><input style="display:none;" name="productInfos['+count+'].num" value="'+num+'"/><span id="skuNum_span_'+skuCode+'"><i class="icon-minus green btn-xs" style="cursor:pointer" onclick="changeSkuNum(\''+skuCode+'\','+(num-1)+')"/><input type="text" role="textbox" value="' + Number(num) + '" onblur="changeSkuNum(\''+skuCode+'\',this.value)" size="1" class="center" style="width:30px;height:20px;padding:4px 0px;font-size:12px;"><i class="icon-plus green btn-xs" style="cursor:pointer" onclick="changeSkuNum(\''+skuCode+'\','+(num+1)+')"/></span></th>' +
                '<th class="center" ><input style="display:none;" name="productInfos['+count+'].subtotal" value="'+Number(price) * num+'"/><span id="subtotal_span_'+skuCode+'">' + parseFloat(Number(price) * num).toFixed(2) + '</span></th>' +
                '<th class="center btn-xs btn-danger" style="cursor:pointer" onclick="deleteProduct(\'' + skuCode + '\')"><i class="icon-trash bigger-120"></i>删除</th>' +
                '</tr>'
            );
            count++;
        }
    });
    $('#addSku-modal-form').modal('hide');
    $('#addSuite-modal-form').modal('hide');
    //计算订单价格
    calcOrder();
}
//全选操作
function selectAllCheckBox(o) {
	var a = document.getElementsByName("idcheckbox");
	for ( var i = 0; i < a.length; i++) {
		a[i].checked = o.checked;
	}
}
//删除未选商品
function deleteNotSelected() {
	$("input[id='idcheckbox']").not("input:checked").each(function() {
		var skuNo = $(this).val();
		deleteProduct(skuNo);
	});
}
// 删除商品
function deleteProduct(skuCode){
	var k=0;
	for(var i=0;i<skuList.length;i++){
		if(skuList[i]==skuCode){
			k=i;
		}
	}
	skuList.splice(k,1);
    $("#product_list_"+skuCode).remove();
}
//增减商品
function changeSkuNum(skuCode, num){
    if(num<=0){
        if(confirm("确认删除商品？")){
            deleteProduct(skuCode);
        }else{
            return;
        }
    }  else {
        var parent = $("#skuNum_span_"+skuCode).parent('th').parent('tr');
    	if(num==undefined){
    		num = parent.find("input[name$='num']").val();
    	}
        var price = parent.find("input[name$='price']").val();
        var skuAmount = parent.find("input[name$='skuAmount']").val();
        if(!checkPrice(price)){
        	parent.find("input[name$='price']").val(parseFloat(skuAmount).toFixed(2));
        	price = skuAmount;
        }
        var subtotal = parseFloat(Number(price) * num).toFixed(2);
        //修改数量、小计的input框和显示值
        parent.find("input[name$='num']").attr("value",num);
        parent.find("input[name$='subtotal']").attr("value",subtotal);
        var skuNumHtml = '<i class="icon-minus green btn-xs" style="cursor:pointer" onclick="changeSkuNum(\''+skuCode+'\','+(num-1)+')"/><input type="text" role="textbox" value="' + Number(num) + '" onblur="changeSkuNum(\''+skuCode+'\',this.value)"  size="1" class="center" style="width:30px;height:20px;padding:4px 0px;font-size:12px;"><i class="icon-plus green btn-xs" style="cursor:pointer" onclick="changeSkuNum(\''+skuCode+'\','+(num+1)+')"/>';

        $("#skuNum_span_"+skuCode).html(skuNumHtml);
        $("#subtotal_span_"+skuCode).html(subtotal);
    }
    //重新计算订单价格
    calcOrder();
}
/** 
 *删除数组指定下标或指定对象
 */
Array.prototype.remove = function(obj) {
	for ( var i = 0; i < this.length; i++) {
		var temp = this[i];
		if (temp === obj) {
			this.splice(i,1);
		}
	}
}
// 计算订单价格
function calcOrder(){
	var orderAmount = 0;
	$("tr[id^='product_list_']").each(function() {
		var price = $(this).find("input[name$='price']").val();
		var num = $(this).find("input[name$='num']").val();
		var productPrice = parseFloat(Number(price)*Number(num)).toFixed(2);
		orderAmount = parseFloat(Number(orderAmount) + Number(productPrice)).toFixed(2);
	});
	$("#calcOrderAmount").val(orderAmount);
}
// 物流赔付下单，刷新商品 skuList信息
function refreshSkuList(){
    $("tr[id^='product_list_']").each(function() {
    	var skuNo = $(this).find("input[name$='skuNo']").val();
    	skuList.push(skuNo);
    });
}
//修改订单价格
function modifyOrder(){
    $("#isModify").val(1);
    $("#calcOrderAmount").removeAttr("readonly");
}

function showProductInfoDialog(selectNo) {
    var args = new Array();
    var url     = "../orders/querySuitInfoForward?selectNo="+selectNo;
    var opt		="status:no; help:no;dialogWidth:1000px; dialogHeight:1000px; resizable:yes; scroll:auto";  
    var result 	= window.showModalDialog(url, args, opt);
	 
    if (typeof(result) != "undefined") {
    
    } 
} 
function checkPrice(obj){
    var fix_price=obj;
    var fix_amount=/^(([1-9]\d*)|\d)(\.\d{1,2})?$/;
    if(fix_amount.test(fix_price)==false){
        alert("请输入有效金额");
        return false;
       }
    return true;
    }