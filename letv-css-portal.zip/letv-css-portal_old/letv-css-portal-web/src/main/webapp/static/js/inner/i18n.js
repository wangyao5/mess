
			
			//function relace springMessageText('key'[params...]) manually
			//params is an array
			jQuery.parseI18NWithParams=function(key,params){
				if(!jQuery.i18nMessage[key]){
					return key;
				}
				var msg = jQuery.i18nMessage[key];
				
				if((!params) || params.length == 0){
					return msg;
				}
				
				var re = /\{\d+\}/g; 
				var arr = msg.match(re);
				
				//return the msg if no placeholder
				if(!arr){
					return msg;
				}
				//if the given array's length is not match the placeholders' size (must be the same)
				if(arr.length != params.length){
					return msg;
				}
				//replace
				for(var i=0; i<arr.length; i++){
					if(params[i])
					msg = msg.replace(arr[i],params[i]);
				}
				return msg;
			}