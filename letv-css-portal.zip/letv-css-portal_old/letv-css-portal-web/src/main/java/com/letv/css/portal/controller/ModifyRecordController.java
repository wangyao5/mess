package com.letv.css.portal.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.ModifyRecord;
import com.letv.css.portal.domain.Resource;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.domain.query.ModifyRecordQuery;
import com.letv.css.portal.service.DepService;
import com.letv.css.portal.service.DicService;
import com.letv.css.portal.service.MenuService;
import com.letv.css.portal.service.ModifyRecordService;
import com.letv.css.portal.service.UserDepService;
import com.letv.css.portal.service.UserService;
import com.letv.css.web.common.utils.JsonResult;

/**
 * 修改记录页面
 *
 * @Author menghan
 * @Version 2017-02-07 11:45:20
 */
@Controller
@RequestMapping("modifyRecord")
public class ModifyRecordController extends BaseController{

	private static final Log LOG = LogFactory.getLog(ModifyRecordController.class);
	@Autowired
	private ModifyRecordService modifyRecordService;
	@Autowired
	private UserService userService;
	@Autowired
	private DepService depService;
	@Autowired
	private UserDepService userDepService;
	@Autowired
	private DicService dicService;
	@Autowired
	private MenuService menuService;
	
	/** 视图前缀 */
	private static final String VIEW_PREFIX = "modifyRecord";
	private static final String VIEW_INDEX = "index";
	
	@RequestMapping("")
	public String welcome(Model model, PageUtil page, ModifyRecordQuery query){
		return index(model,page,query);
	}
	
	@RequestMapping("index")
	public String index(Model model, PageUtil page, ModifyRecordQuery query){
		try {
			//数据权限控制
			User user = userService.getUserByUsername(getLoginUser().getUserName());
			String allowDepIds = getDepIds(user.getId());
			if(allowDepIds==null || "".equals(allowDepIds)){
				query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
			}else{
				query.setDepIds(allowDepIds);
			}
			List<ModifyRecord> dataList = modifyRecordService.queryModifyRecordListWithPage(query, page);
			model.addAttribute("dataList", dataList);//数据集合
			model.addAttribute("page", page);// 分页
			model.addAttribute("query", query);//查询条件
			addDepListToModel(model);
			addEnumToModel(model);
			addButtonPortals(model, user);
		} catch (Exception e) {
			LOG.error("ModifyRecordController index has error.", e);
		}
		return VIEW_PREFIX + "/" + VIEW_INDEX;
	}
	
	/**
	 * 添加修改记录信息
	 * @param
	 * @return
	 */
	@RequestMapping(value = "addRecord", method = RequestMethod.POST)
    @ResponseBody
	public JsonResult addRecord(ModifyRecord modifyRecord){
		User user = userService.getUserByUsername(getLoginUser().getUserName());
		modifyRecord.setModifyTime(new Date());
		String modifyPerson = user.getName() +"(工号：" + user.getCode() + ")";
		modifyRecord.setModifyPerson(modifyPerson);
		modifyRecord.setCreateUser(user.getName());
		modifyRecord.setCreateTime(new Date());
		boolean result = modifyRecordService.insert(modifyRecord);
		if(result){
			return new JsonResult(result);
		}else{
			return new JsonResult(JsonResult.CODE_SERVER_ERROR, JsonResult.MESSAGE_SERVER_ERROR, result);
		}
	}
	
	/**
	 * 流水明细导出
	 * @param
	 * @return
	 * @throws IOException 
	 * @throws WriteException 
	 */
	@RequestMapping("export")
	public void export(HttpServletResponse response,ModifyRecordQuery query) throws IOException, WriteException{
		
		//excel数据
		List<ModifyRecord> itemList = modifyRecordService.queryEntryFlow(query);
		
		//文件名 ，文件类型
	    String fileName = getFlowDetailExcelName(query);
	    
	    response.setContentType("application/x-excel");  
	    response.setCharacterEncoding("UTF-8");  
	    response.addHeader("Content-Disposition", "attachment;filename="  
	            + new String(fileName.getBytes(),"iso-8859-1"));// excel文件名  
	  
	    try {  
	        //创建excel文件  
	        WritableWorkbook book = Workbook.createWorkbook(response.getOutputStream());
            // 居中 ,orange背景色
            WritableCellFormat wf = new WritableCellFormat();
            wf.setAlignment(Alignment.CENTRE);
            wf.setBackground(Colour.ORANGE);
            wf.setBorder(Border.ALL, BorderLineStyle.THIN);
            
            if(query.getModifyRecordType()==2){
            	//入职流水中包括上线信息
            	createEntryFlowExcel(query,book,wf,itemList);
            }else if(query.getModifyRecordType()==6){
            	//离职流水
            	createDemissionFlowExcel(query,book,wf,itemList);
            }
	        //写入excel并关闭  
	        book.write();  
	        book.close();  
	    } catch (Exception e) {  
	        e.printStackTrace();  
	    } 
	}
	
	/**
     * 将枚举值加入到model
     * @param
     * @return
     */
    private void addEnumToModel(Model model){
    	DicQuery query = new DicQuery();
    	query.setParentName("修改记录类型");
    	List<Dic> modifyRecordTypes = dicService.queryDicList(query);
		model.addAttribute("modifyRecordTypes", modifyRecordTypes);//修改记录类型
    }
	
	/**
     * 将当前用户的可见部门信息加入model
     * @param
     * @return
     */
    private void addDepListToModel(Model model) {
		//获得当前用户
		User user = userService.getUserByUsername(getLoginUser().getUserName());
		//当前用户的可见部门列表
		if(user!=null){
			String allowDeps = getDepIds(user.getId());
			List<Dep> depList = depService.getDepListByIds(allowDeps);
			if(depList!=null && depList.size()!=0){
				for(Dep dep:depList){
					dep.setParentDep(depService.getDepById(dep.getParentId()));
				}
			}
			model.addAttribute("depList", depList);
		}
	}
    
    /**
     * 获取当前登录用户：从上下文获取，（cookie解析而得）
     * 
     * @return
     */
    private User getCurrentUser() {
        User user = userService.getUserByUsername(getLoginUserName());
        return user;
        
    }
    
    /***
     * 获得可见部门的id集合
     */
    private String getDepIds(Long userId){
    	List<UserDep> userDeps = userDepService.queryUserDepList(userId);
		StringBuilder sb = new StringBuilder();
		for(UserDep ud:userDeps){
			sb.append(ud.getDepId()+",");
		}
		String allowDeps = "";
		if(sb.length()>0){
			allowDeps = sb.substring(0, sb.length()-1);
		}
		return allowDeps;
    }
    
    /**
     * 添加按钮级别的权限
     * @param
     * @return
     */
    private void addButtonPortals(Model model,User user){
    	Set<String> set = new HashSet<String>();
    	List<Resource> resources = menuService.queryButtonResources(user);
    	for(Resource r:resources){
    		if(r.getParentId()!=null){
    			set.add(r.getUrl());
    		}
    	}
    	model.addAttribute("buttonPortals", set);
    }
    
    //获得员工性别
    private String getSex(Integer val){
    	if(val==0){
    		return "男";
    	}else if(val==1){
    		return "女";
    	}else{
    		return "";
    	}
    }
    
    //获得员工是否婚否
    private String getIsMarried(Integer val){
    	if(val==0){
    		return "未婚";
    	}else if(val==1){
    		return "已婚";
    	}else{
    		return "";
    	}
    }
    
    //根据num和父名称查询value
    private String getDicVal(String name,Integer val){
    	DicQuery query = new DicQuery();
    	query.setParentName(name);
    	query.setNum(val);
    	List<Dic> modifyRecordTypes = dicService.queryDicList(query);
    	if(CollectionUtils.isEmpty(modifyRecordTypes)){
    		return "";
    	}else{
    		return modifyRecordTypes.get(0).getName();
    	}
    }
    
    /**
	 * 根据流水明细类别获得流水明细excel名称
	 * @param
	 * @return
	 */
	private String getFlowDetailExcelName(ModifyRecordQuery query) {
		StringBuilder filename = new StringBuilder();
		if(query.getModifyRecordType()==2){
			filename.append("入职流水");
		}else if(query.getModifyRecordType()==6){
			filename.append("离职流水");
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		filename.append("-").append(sdf.format(new Date())).append(".xls");
		return filename.toString();
	}
    
    /**
     * 创建入职流水Excel
     * @param
     * @return
     */
    private void createEntryFlowExcel(ModifyRecordQuery query,WritableWorkbook book,WritableCellFormat wf,List<ModifyRecord> itemList) throws RowsExceededException, WriteException {
    	//从字典表里，获得入职流水字典
    	Map<Long,Map<Integer,String>> map = getEntryFlowDicMap(); 
    	//sheet
        WritableSheet sheet = book.createSheet("入职流水", 0);
        //添加标题数据 
        sheet.addCell(new Label(0, 0, "职场", wf));
        sheet.addCell(new Label(1, 0, "工号", wf));
        sheet.addCell(new Label(2, 0, "乐视账号", wf));
        sheet.addCell(new Label(3, 0, "姓名", wf));
        sheet.addCell(new Label(4, 0, "身份证号", wf));
        sheet.addCell(new Label(5, 0, "工作年限", wf));
        sheet.addCell(new Label(6, 0, "客服工作年限", wf));
        sheet.addCell(new Label(7, 0, "入职日期", wf));
        sheet.addCell(new Label(8, 0, "出生日期", wf));
        sheet.addCell(new Label(9, 0, "性别", wf));
        sheet.addCell(new Label(10, 0, "婚否", wf));
        sheet.addCell(new Label(11, 0, "子女", wf));
        sheet.addCell(new Label(12, 0, "毕业院校", wf));
        sheet.addCell(new Label(13, 0, "学历", wf));
        sheet.addCell(new Label(14, 0, "专业", wf));
        sheet.addCell(new Label(15, 0, "上线日期", wf));
        sheet.addCell(new Label(16, 0, "培训班主任", wf));
        sheet.addCell(new Label(17, 0, "培训主讲", wf));
        sheet.addCell(new Label(18, 0, "平均成绩", wf));
        sheet.addCell(new Label(19, 0, "通关考核成绩", wf));
        sheet.addCell(new Label(20, 0, "通过考核结果", wf));
        sheet.addCell(new Label(21, 0, "岗位", wf));
        sheet.addCell(new Label(22, 0, "业务", wf));
        sheet.addCell(new Label(23, 0, "上级", wf));
	        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        
        WritableCellFormat wcf = new WritableCellFormat();
        wcf.setAlignment(Alignment.CENTRE);
        if (itemList != null && itemList.size() > 0) {  
        	Dep dep = null;
        	Staff staff = null;
        	for (int i = 0; i < itemList.size(); i++) {
        		dep = itemList.get(i).getDep();
        		staff = itemList.get(i).getStaff();
        		if(staff==null){
        			continue;
        		}
        		//excel内容
        		sheet.addCell(new Label(0, i + 1, dep==null?"":dep.getName(),wcf));  
        		sheet.addCell(new Label(1, i + 1, staff.getEmployeeNum()==null?"":staff.getEmployeeNum(),wcf));
        		sheet.addCell(new Label(2, i + 1, staff.getLeAccount()==null?"":staff.getLeAccount(),wcf));
        		sheet.addCell(new Label(3, i + 1, staff.getName()==null?"":staff.getName(),wcf));
        		sheet.addCell(new Label(4, i + 1, staff.getIdNumber()==null?"":staff.getIdNumber(),wcf));
        		sheet.addCell(new Label(5, i + 1, staff.getWorkExperience()==null?"":staff.getWorkExperience(),wcf));
        		sheet.addCell(new Label(6, i + 1, staff.getCsExperience()==null?"":staff.getCsExperience(),wcf));
        		sheet.addCell(new Label(7, i + 1, staff.getEntryDate()==null?"":sdf.format(staff.getEntryDate()),wcf));
                sheet.addCell(new Label(8, i + 1, staff.getBirthdate()==null?"":sdf.format(staff.getBirthdate()),wcf));
                sheet.addCell(new Label(9, i + 1, staff.getSex()==null?"":getSex(staff.getSex()),wcf));
                sheet.addCell(new Label(10, i + 1, staff.getIsMarried()==null?"":getIsMarried(staff.getIsMarried()),wcf));
                sheet.addCell(new Label(11, i + 1, staff.getChildren()==null?"":map.get(1L).get(staff.getChildren()),wcf));
                sheet.addCell(new Label(12, i + 1, staff.getGraduateSchool()==null?"":staff.getGraduateSchool(),wcf));
                sheet.addCell(new Label(13, i + 1, staff.getEducation()==null?"":map.get(10L).get(staff.getEducation()),wcf));
                sheet.addCell(new Label(14, i + 1, staff.getMajor()==null?"":staff.getMajor(),wcf));
                sheet.addCell(new Label(15, i + 1, staff.getOnlineDate()==null?"":sdf.format(staff.getOnlineDate()),wcf));
                sheet.addCell(new Label(16, i + 1, staff.getTrainingOfficer()==null?"":staff.getTrainingOfficer(),wcf));
                sheet.addCell(new Label(17, i + 1, staff.getTraningSpeaker()==null?"":staff.getTraningSpeaker(),wcf));
                sheet.addCell(new Label(18, i + 1, staff.getAveScore()==null?"":staff.getAveScore().toString(),wcf));
                sheet.addCell(new Label(19, i + 1, staff.getScore()==null?"":staff.getScore().toString(),wcf));
                sheet.addCell(new Label(20, i + 1, staff.getResult()==null?"":map.get(61L).get(staff.getResult()),wcf));
                sheet.addCell(new Label(21, i + 1, staff.getJobTitle()==null?"":map.get(96L).get(staff.getJobTitle()),wcf));
                sheet.addCell(new Label(22, i + 1, staff.getService()==null?"":map.get(66L).get(staff.getService()),wcf));
                sheet.addCell(new Label(23, i + 1, dep==null?"":(dep.getPersonCharge()==null?"":dep.getPersonCharge()),wcf));
        	}
        }            
	}

    /**
     * 创建离职流水Excel
     * @param
     * @return
     */
    private void createDemissionFlowExcel(ModifyRecordQuery query,WritableWorkbook book, WritableCellFormat wf,List<ModifyRecord> itemList) throws RowsExceededException, WriteException {
    	 //sheet
        WritableSheet sheet = book.createSheet("离职流水", 0);
        //添加标题数据  
        sheet.addCell(new Label(0, 0, "职场", wf));
        sheet.addCell(new Label(1, 0, "工号", wf));
        sheet.addCell(new Label(2, 0, "姓名", wf));
        sheet.addCell(new Label(3, 0, "离职日期", wf));
        sheet.addCell(new Label(4, 0, "离职原因", wf));
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        
        WritableCellFormat wcf = new WritableCellFormat();
        wcf.setAlignment(Alignment.CENTRE);

        if (itemList != null && itemList.size() > 0) {  
        	Dep dep = null;
        	Staff staff = null;
        	for (int i = 0; i < itemList.size(); i++) {
        		dep = itemList.get(i).getDep();
        		staff = itemList.get(i).getStaff();
        		if(staff==null){
        			continue;
        		}
        		//excel内容
        		sheet.addCell(new Label(0, i + 1, dep==null?"":dep.getName(),wcf));
                sheet.addCell(new Label(1, i + 1, staff.getEmployeeNum()==null?"":staff.getEmployeeNum().split("\\|")[0],wcf));
                sheet.addCell(new Label(2, i + 1, staff.getName()==null?"":staff.getName(),wcf));
                sheet.addCell(new Label(3, i + 1, staff.getDimissionDate()==null?"":sdf.format(staff.getDimissionDate()),wcf));
                sheet.addCell(new Label(4, i + 1, staff.getDimissionReason()==null?"":staff.getDimissionReason(),wcf));
        	}
        }
	}
    
    /**
     * 构建入职流水字典
     * @param
     * @return
     */
    private Map<Long,Map<Integer,String>> getEntryFlowDicMap(){
    	Map<Long,Map<Integer,String>> map = new HashMap<Long, Map<Integer,String>>();
    	List<Dic> dics = null;
    	DicQuery query = new DicQuery();
    	//分别是代表：子女、学历、通过结果、员工岗位、业务
    	Long[] dicIds = {1L,10L,61L,96L,66L};
    	for(int i=0;i<dicIds.length;i++){
	    	query.setParentId(dicIds[i]);
	    	dics = dicService.queryDicList(query);
	    	if(CollectionUtils.isNotEmpty(dics)){
	    		Map<Integer,String> m = new HashMap<Integer,String>();
	    		for(Dic d: dics){
	    			m.put(d.getNum().intValue(), d.getName());
	    		}
	    		map.put(dicIds[i], m);
	    	}
    	}
    	return map;
    }
}
