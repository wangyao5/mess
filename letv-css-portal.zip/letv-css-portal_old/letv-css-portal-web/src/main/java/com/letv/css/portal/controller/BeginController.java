package com.letv.css.portal.controller;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.domain.query.UserQuery;
import com.letv.css.portal.service.CommonQueueService;
import com.letv.css.portal.service.DepService;
import com.letv.css.portal.service.UserService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequestMapping("begin")
public class BeginController extends BaseController {
    private static final Log LOG = LogFactory.getLog(BeginController.class);

    @Autowired
    private CommonQueueService commonQueueService;
    @Autowired
    private DepService depService;
    @Autowired
    private UserService userService;

    /**
     * 视图前缀
     */


    @RequestMapping(value = "index")
    public void index(HttpServletResponse response) {
        try {
            //查询所有的部门
            List<Dep> list = depService.queryDepList(new DepQuery());
            LOG.info("有" + list.size() + "个部门需要同步");
            for (Dep dep : list) {
                //插入commonqueue
                CommonQueue queue = new CommonQueue();
                queue.setOnlyId(dep.getId());
                queue.setOnlyType("dep id");
                queue.setEventId(EventConstants.EVENT_DEP_ADD);
                queue.setRequestRemake("初始化部门");
                queue.setCreatedBy("999");
                commonQueueService.insert(queue);
            }
            response.getWriter().write("成功！！");

        } catch (Exception e) {
            LOG.info("初始化部门失败" + e.getMessage());
        }


    }
    @RequestMapping(value = "portal")
    public void portal(HttpServletResponse response) {
        //查询所有的用户
        try {
            PageUtil page = new PageUtil();
            page.setCurPage(1);
            page.setPageSize(10000);
            List<User> list = userService.queryUserListWithPage(new UserQuery(), page);
            LOG.info("有" + list.size() + "个数据权限需要同步");
            for (User user : list) {
                CommonQueue queue = new CommonQueue();
                queue.setOnlyId(user.getId());
                queue.setOnlyType("user id");
                queue.setEventId(EventConstants.EVENT_USER_DEP);
                queue.setRequestRemake("用户组流程");
                queue.setCreatedBy("999");
                commonQueueService.insert(queue);
            }
            response.getWriter().write("成功！！");
        } catch (Exception e) {
            LOG.info("初始化数据权限失败" + e.getMessage());
        }

    }
}
