package com.letv.css.portal.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import net.sf.json.JSONObject;

public class DEMO_01 {
	
	private static String CORP_ID = "wx0db4a5d545906e49";
	
	private static String CORP_SECRET = "La-XpOgICNMVyj9BEBX_chMVtz02veQsBF3ynxXXhLE";
	
	private static String API_SECRET = "Xq_HoPp9x7uNibiAiD0h0_SCpj3N_4KbhvN_UQK5hl0";
	
	private static Integer AGENT_ID = 1000002;
	
	public static void main(String[] arg){
//		String url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"
//				+ "?corpid=" + CORP_ID
//				+ "&corpsecret=" + CORP_SECRET;
		
		String url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"
				+ "?corpid=" + CORP_ID
				+ "&corpsecret=" + API_SECRET;
		
		String param = "";
		
		String result = sendPost(url, param);
		System.out.println("获取授权："+result);
		
		Map<String, Object> oneJsonMap = JsonToMap(result);
		String oneAccessToken = oneJsonMap.get("access_token").toString();
		
		String url_3 = "https://qyapi.weixin.qq.com/cgi-bin/department/list?"
				+ "access_token="+oneAccessToken+"&id=";
		String result_3 = sendPost(url_3, "");
		System.out.println(result_3);
		
//		for(int i = 1; i < 6; i ++){
//			String url_4 = "https://qyapi.weixin.qq.com/cgi-bin/user/list?"
//					+ "access_token=" + oneAccessToken
//					+ "&department_id=" + i ;
//			String result_4 = sendPost(url_4, "");
//			System.out.println("["+i+"]"+result_4);
//		}
		
		
		
//		String url_2 = "https://qyapi.weixin.qq.com/cgi-bin/message/send"
//				+ "?access_token=" + oneAccessToken;
//		String param_2 = "{\"touser\" : \"ChenHuiTao\","
////				+ "\"toparty\" : \"\","
////				+ "\"totag\" : \"\","
//				+ "\"msgtype\" : \"text\","
//				+ "\"agentid\" :" + AGENT_ID + ","
//				+ "\"text\" : {"
//					+ "\"content\" : \"HeartBeat通知<br/>"
//						+ "异常事件: 2017-11-03 16:31:00<br/>"
//						+ "接口名称: 人脸考勤机16点同步<br/>"
//						+ "所属平台: 无<br/>"
//						+ "紧急程度: 中<br/>"
//						+ "责  任  人：  郭洪雷<br/>"
//						+ "详细信息请登录HB查询。"
//						+ "\""
//				+ "},"
//				+ "\"safe\":0}";
//		
//		String param_3 = "{\"touser\" : \"ChenHuiTao\","
//				+ "\"msgtype\" : \"textcard\","
//				+ "\"agentid\" :" + AGENT_ID + ","
//				+ "\"textcard\" : {"
//					+ "\"title\" : \"HeartBeat警告通知\","
//					+ "\"description\" : \""
//						+ "<div class=\\\"gray\\\">2017-11-03 16:31:00</div>"
//						+ "<div class=\\\"normal\\\">接口名称: 人脸考勤机16点同步</div>"
//						+ "<div class=\\\"normal\\\">所属平台: 无</div>"
//						+ "<div class=\\\"normal\\\">紧急程度: 中</div>"
//						+ "<div class=\\\"normal\\\">责  任  人：  郭洪雷</div>\","
//					+ "\"url\" : \"https://www.baidu.com\""
//				+ "}"
//				+ "}";
//		System.out.println(param_3);
//		String result_2 = sendPost(url_2, param_3);
//		System.out.println("发送消息："+result_2);
	}
	
	/**
     * 向指定 URL 发送POST方法的请求
     * 
     * @param url
     *            发送请求的 URL
     * @param param
     *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendPost(String url, String param) {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            URL realUrl = new URL(url);
            // 打开和URL之间的连接
            URLConnection conn = realUrl.openConnection();
            // 设置通用的请求属性
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            // 发送POST请求必须设置如下两行
            conn.setDoOutput(true);
            conn.setDoInput(true);
            // 获取URLConnection对象对应的输出流
            out = new PrintWriter(conn.getOutputStream());
            // 发送请求参数
            out.print(param);
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送 POST 请求出现异常！"+e);
            e.printStackTrace();
        }
        //使用finally块来关闭输出流、输入流
        finally{
            try{
                if(out!=null){
                    out.close();
                }
                if(in!=null){
                    in.close();
                }
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }
        return result;
    }    
	

	public static Map<String, Object> JsonToMap(String oneJson){
		Map<String, Object> result = new HashMap<String, Object>();
		if(oneJson!=null && !oneJson.trim().equals("")){
			JSONObject oneJsonObject = JSONObject.fromObject(oneJson);
			Iterator it = oneJsonObject.keys();
			// 遍历jsonObject数据，添加到Map对象
			while (it.hasNext()){
				String oneKey = String.valueOf(it.next());
				Object oneValue = oneJsonObject.get(oneKey);
				if(oneValue!=null && oneValue.toString().indexOf("{")!=-1){
					JSONObject oneValueJsonObject = JSONObject.fromObject(oneValue);
					Iterator oneValueIterator = oneValueJsonObject.keys();
					while(oneValueIterator.hasNext()){
						String twoKey = String.valueOf(oneValueIterator.next());
						Object twoValue = oneValueJsonObject.get(twoKey);
						result.put(oneKey+"_"+twoKey, twoValue);
					}
				}else{
					result.put(oneKey, oneValue);
				}
			}
		}
		return result;
	}
}
