package com.letv.css.portal.controller;

import java.util.*;

import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.constant.enums.*;
import com.letv.css.portal.domain.query.*;
import com.letv.css.portal.service.*;
import com.letv.css.portal.service.DepService;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letv.common.utils.DateHelper;
import com.letv.common.utils.exception.ExistedException;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.constant.CommonConstants;

/**
 * 员工类
 *
 * @Author menghan
 * @Version 2017-01-15 17:49:07
 */
@Controller
@RequestMapping("staff")
public class StaffController extends CommonController{
	
	private static final Log LOG = LogFactory.getLog(StaffController.class);
	
	@Autowired
	private StaffService staffService;
	@Autowired
	private DepService depService;
	@Autowired
	private UserService userService;
	@Autowired
	private ModifyRecordService modifyRecordService;
	@Autowired
	private UserDepService userDepService;
	@Autowired
    private SSOService ssoService;
	@Autowired
	private DicService dicService;
	@Autowired
	private MenuService menuService;
    @Autowired
    private CommonQueueService commonQueueService;
	@Autowired
	private DepBusinessService depBusinessService;
	
	/** 视图前缀 */
	private static final String VIEW_PREFIX = "staff";
	private static final String VIEW_INDEX = "index";
	private static final String VIEW_UPDATE = "update";
	
	
	@RequestMapping(value="")
	public String welcom(Model model, PageUtil page, StaffQuery query){
		return index(model,page,query);
	}

	@RequestMapping(value="index")
	public String index(Model model, PageUtil page, StaffQuery query){
		try {
			List<Staff> dataList = null;
			//数据权限控制
			User user = userService.getUserByUsername(getLoginUser().getUserName());
			String allowDepIds = getDepIds(user.getId());
			if(allowDepIds==null || "".equals(allowDepIds)){
				query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
			}else{
				query.setDepIds(allowDepIds);
			}
			
			if(StringUtils.isNotBlank(query.getCode())){
				if(query.getRange()!=null && query.getRange()==1){//查询条件为上级部门是的情况
					String tempCode = query.getCode();
					String parentCode = tempCode.substring(0, tempCode.length()-CommonConstants.DEP_CODE_BIT);//部门编号生成规则改变时，需要改DEP_CODE_BIT，现在默认以4个字符为一级
					//部门code为空的时候，其上级部门为空
					if("".equals(parentCode)){
						query.setCode("xxx");
					}else{
						query.setCode(parentCode);
					}
					dataList = this.staffService.queryStaffListWithPage(query, page);
					query.setCode(tempCode);//查询完，需要将部门编码重置
				}else{
					dataList = this.staffService.queryStaffListWithPage(query, page);
				}
			}else{
				dataList = this.staffService.queryStaffListWithPage(query, page);
			}
			model.addAttribute("dataList", dataList);//数据集合
			model.addAttribute("page", page);// 分页
			model.addAttribute("query", query);//查询条件
			addDepListToModel(model);//部门
			addEnumToModel(model);//各种字段的枚举值
			addButtonPortals(model,user);//添加按钮权限控制
		} catch (Exception e) {
			LOG.error("StaffController index has error.", e);
		} 
		return VIEW_PREFIX + "/" + VIEW_INDEX;
	}
	

	/**
	 * 查询员工详细信息
	 * @param
	 * @return
	 */
	@RequestMapping(value = "detail", method = RequestMethod.GET)
	@ResponseBody
	public Wrapper<?> detail(StaffQuery query){
		if(null==query||null==query.getId()){
			return illegalArgument();
		}
		try {
			Staff staff = staffService.getStaffById(query.getId());
			if(staff!=null){
				//该员工有没有上级部门，有上级部门的话，保存上级部门信息
				if(staff.getDep().getParentId()!=null && staff.getDep().getParentId()>0){
					staff.getDep().setParentDep(depService.getDepById(staff.getDep().getParentId()));
				}
				Map<String, Object> map = new HashedMap();
				map.put("staff", staff);

				//当前部门业务线
				List<Dic> business = getService(staff.getDep().getId());
				map.put("business", business);
				//岗位信息 如员工合同为BPO，岗位信息为BPO岗位信息
				List<Dic> inTitle = getTitle(staff);
				map.put("inTitle", inTitle);

				return new Wrapper<Map<String, Object>>().result(map);
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE,"查询员工详情失败！");
			}
		} catch (Exception e) {
			LOG.warn("detail staff has error.", e);
            return error();
		}
	}

	private List<Dic> getTitle(Staff staff) {
		int contract = staff.getStaffContract();
		DicQuery dicQuery = new DicQuery();
		dicQuery.setNum(contract);
		dicQuery.setParentName("合同性质");
		List<Dic> dicList = dicService.queryDicList(dicQuery);
		List<Dic> inTitle = new ArrayList<>();
		if(dicList.size() > 0){
            DicQuery dicQuery1 = new DicQuery();
            if(dicList.get(0).getName().equals("BPO类合同")){
                dicQuery1.setParentName("员工岗位");
            }else{
                dicQuery1.setParentName("内部岗位");
            }
            inTitle =  dicService.queryDicList(dicQuery1);

        }
        return inTitle;
	}

	@RequestMapping(value = "serviceNew", method = RequestMethod.GET)
	@ResponseBody
	public Wrapper<?> serviceNew(long depId){
		try {
				//当前部门业务线
			List<Dic> business = getService(depId);
			return new Wrapper<List<Dic>>().result(business);
		} catch (Exception e) {
			LOG.warn("detail staff has error.", e);
            return error();
		}
	}




	/**
     * 员工表----更新跳转
     * 
     * @param model
     * @return
     */
    @RequestMapping(value = "updateForward")
    public String updateForward(Model model, Staff staff) {
        try {
        	Staff staffResult = staffService.getStaffById(staff.getId());
            model.addAttribute("staff", staffResult);
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
            addEnumToModel(model);
            addDepListToModel(model);
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
        }
        return VIEW_PREFIX + "/"+ VIEW_UPDATE;
    }
	
    
    /**
     * 员工表----更新
     * 
     * @param model
     * @return
     */
    @RequestMapping(value = "update",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> update(Model model, Staff staff) {
        try {
			//判断上线权限
			Staff curStaff = staffService.getStaffById(staff.getId());
        	if(curStaff.getReviewedStatus() == 11 || curStaff.getReviewedStatus() == 13 || curStaff.getReviewedStatus() == 65) {
				staff.setUpdateUser(getLoginUserCnName());
				staff.setUpdateTime(new Date());
				staff.setLastModifyTime(new Date());
				//只有入职审核拒绝可以修改信息
				staff.setReviewedStatus(EventConstants.EXAMINE_ENTRY_FIRST);

				//更新前的员工信息
				if (staff.getResult() != null && curStaff.getResult() != staff.getResult()) {
					//修改了通关结果，改为通过，职位状态为在职
					if (staff.getResult() != null && (staff.getResult() == 1 || staff.getResult() == 2)) {
						staff.setPositionStatus("3");
					}
					//修改了通关结果，改为不通过，职位状态为考核未过
					if (staff.getResult() != null && (staff.getResult() == 3 || staff.getResult() == 4)) {
						staff.setPositionStatus("2");
					}
				}

				if (staff.getLeAccount() != null && !staff.getLeAccount().equals(curStaff.getLeAccount())) {
					//乐视账号(域账号)是唯一的，验证该账号是否已经存在
					if (staff.getLeAccount() != null && !"".equals(staff.getLeAccount())) {
						Staff s = staffService.getStaffByLeAccount(staff.getLeAccount());
						if (s != null) {
							return WrapMapper.wrap(3333, "修改失败，该乐视账号已经存在！");
						}
						User tempUser = userService.getUserByUsername(staff.getLeAccount());//该域账号已经被同步过
						if (tempUser != null && tempUser.getStaffId() != null) {
							return WrapMapper.wrap(3333, "修改失败，该乐视账号已经存在！");
						}
						//验证该域账号是否有效
						Map<String, Object> map = ssoService.queryUser(staff.getLeAccount());
						if (map == null) {
							return WrapMapper.wrap(4444, "修改失败，该乐视账号(域账号)不可用！");
						}
					}
				}

				if (staff.getCsId() != null && !staff.getCsId().equals(curStaff.getCsId())) {
					//客服工号是唯一的，验证该客服工号是否已经存在
					if (staff.getCsId() != null && !"".equals(staff.getCsId())) {
						Staff s = staffService.getStaffByCsId(staff.getCsId());
						if (s != null) {
							return WrapMapper.wrap(6666, "修改失败，该客服工号已经存在！");
						}
					}
				}
				if (staff.getEmployeeNum() != null && !staff.getEmployeeNum().equals(curStaff.getEmployeeNum())) {
					//员工编号是唯一的，验证该员工编号是否存在
					if("".equals(staff.getEmployeeNum())){//employeeNum在staff表有唯一索引，所以需要处理处理“”或者“ ”这样的情况
						staff.setEmployeeNum(null);
					}else{
						Staff s = staffService.getStaffByEmployeeNum(staff.getEmployeeNum());
						if (s != null) {
							return WrapMapper.wrap(7777, "该员工编号已经存在！");
						}
					}
				}

				if (staffService.update(staff)) {
					//判断该用户是否已经上线，如果上线，需要同步更改user表的数据
					Staff temp = staffService.getStaffById(staff.getId());//更新后的员工信息
					if (staff != null && !"".equals(temp.getLeAccount()) && "3".equals(temp.getPositionStatus())) {
						//User user = userService.getUserByUsername(temp.getLeAccount());
						User user = userService.getUserByStaffId(temp.getId());
						//员工已经上线过
						if (user != null && user.getStaffId() != null && !Objects.equals(user.getStaffId(),temp.getId())) {
							user.setName(temp.getName());
							user.setUsername(temp.getLeAccount());
							user.setUpdateUser(getLoginUserCnName());
							userService.update(user);
						} else {
							//该员工没有上线过
							if (staff.getResult() == 1 || staff.getResult() == 2) {//考核通过，需要将staff表的对应的员工信息同步到user表
								synStaffToUser(staff);
								//赋予该上线员工一条数据权限
								if (staff != null && !"".equals(staff.getLeAccount())) {
									synStaffPortal(staff);
								}
							}
						}
					}
					//如果是入职一审驳回或者二审驳回，重新创建工作流   ； 申请工号驳回也需要重新创建工作流
					if (curStaff.getReviewedStatus() == EventConstants.EXAMINE_ENTRY_SECOND_NO || curStaff.getReviewedStatus() == EventConstants.EXAMINE_ENTRY_FIRST_NO || curStaff.getReviewedStatus() == 65) {
						//插入commonQueue,同步工作流
						CommonQueue queue = new CommonQueue();
						queue.setOnlyId(staff.getId());
						queue.setOnlyType("staff id");
						queue.setEventId(EventConstants.EVENT_ENTRY);
						queue.setRequestRemake("入职流程");
						queue.setCreatedBy(getLoginUserId() + "");
						commonQueueService.insert(queue);
					}

					//该员工原来是上线的员工，后来在修改页面改为考核未过的员工了
					if (staff != null && !"".equals(temp.getLeAccount()) && "2".equals(temp.getPositionStatus())) {
						//如果该员工在对应的user表里有记录，将该记录的yn置为0
						User user = userService.getUserByUsername(temp.getLeAccount());
						if (user != null) {
							user.setYn(0);
							user.setUsername(user.getUsername() + "|" + new Date().getTime());//将用户名置为无效
							user.setStaffId(new Date().getTime());
							userService.update(user);
						}
						//如果该员工是部门负责人，将该部门的负责人置为空
						DepQuery query = new DepQuery();
						query.setPersonChargeId(staff.getId());
						List<Dep> deps = depService.queryDepList(query);
						if (deps != null && deps.size() != 0) {
							for (Dep dep : deps) {
								dep.setPersonCharge("");
								dep.setPersonChargeId(0L);
								depService.update(dep);
							}
						}
					}

					return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "更新成功！");
				} else {
					return WrapMapper.wrap(Wrapper.ERROR_CODE, "更新失败！");
				}
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE, "当前状态下不允许更新信息！");
			}
        } catch (Exception e) {
            LOG.error("user update has error.", e);
            return WrapMapper.error();
        }
    }
    
    /**
     * 员工表----上线
     * 			流程：1、需要更新staff表中对应的员工记录
     * 				2、需要将成功上线的员工（考核通过）信息同步到user表中
     * 				3、赋予该员工数据权限，仅包括其所在部门的数据权限
     * @param model
     * @return
     */
    @RequestMapping(value = "online",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> online(Model model, Staff staff) {
        try {
			//判断上线权限
			Staff s = staffService.getStaffById(staff.getId());
			if(s.getReviewedStatus() ==  15 || s.getReviewedStatus() == 21 || s.getReviewedStatus() == 23) {
				staff.setUpdateUser(getLoginUserCnName());
				staff.setUpdateTime(new Date());
				staff.setLastModifyTime(new Date());
				if (staff.getResult() == 3 || staff.getResult() == 4) {
					//result=3（不通过）对应着postionStatus=2（考核未过）
					staff.setPositionStatus("2");
					//离职一审
					staff.setReviewedStatus(EventConstants.EXAMINE_ENTRY_DIMISSION_FIRST);
					//离职原因 时间
					staff.setDimissionReason("被动离职:业务淘汰");
					staff.setDimissionDate(new Date());
				} else {
//        		staff.setPositionStatus("3");//上线二审通过后修改职位状态为在职
					//上线一审
					staff.setReviewedStatus(EventConstants.EXAMINE_ENTRY_ONLINE_FIRST);
				}
				//乐视账号(域账号)是唯一的，验证该账号是否已经存在
//        	if(staff.getLeAccount()!=null && !"".equals(staff.getLeAccount())){
//        		Staff s = staffService.getStaffByLeAccount(staff.getLeAccount());
//        		if(s!=null && !Objects.equals(s.getId(), staff.getId())){
//        			return WrapMapper.wrap(3333, "上线失败，该乐视账号已经存在！");
//        		}
//        		User tempUser = userService.getUserByUsername(staff.getLeAccount());//该域账号已经被同步过
//        		if(tempUser!=null && tempUser.getStaffId()!=null && !Objects.equals(s.getId(), staff.getId())){
//        			return WrapMapper.wrap(3333, "上线失败，该乐视账号已经存在！");
//        		}
//        		//验证该域账号是否有效
//        		Map<String,Object> map = ssoService.queryUser(staff.getLeAccount());
//        		if(map==null){
//        			return WrapMapper.wrap(4444, "上线失败，该乐视账号(域账号)不可用！");
//        		}
//        	}
//        	//客服工号是唯一的，验证该客服工号是否已经存在
//        	if(staff.getCsId()!=null && !"".equals(staff.getCsId())){
//        		Staff s = staffService.getStaffByCsId(staff.getCsId());
//        		if(s!=null){
//        			return WrapMapper.wrap(6666, "上线失败，该客服工号已经存在！");
//        		}
//        	}

				if (staffService.online(staff)) {
					if (staff.getResult() == 1 || staff.getResult() == 2) {//考核通过，需要将staff表的对应的员工信息同步到user表
						synStaffToUser(staff);
						//赋予该上线员工一条数据权限
						if (staff != null && !"".equals(staff.getLeAccount())) {
							synStaffPortal(staff);
							//插入commonQueue,同步工作流
							CommonQueue queue = new CommonQueue();
							queue.setOnlyId(staff.getId());
							queue.setOnlyType("staff id");
							queue.setEventId(EventConstants.EVENT_ONLINE);
							queue.setRequestRemake("上线流程");
							queue.setCreatedBy(getLoginUserId() + "");
							commonQueueService.insert(queue);
						}
					} else {
						//离职流程
						CommonQueue queue = new CommonQueue();
						queue.setOnlyId(staff.getId());
						queue.setOnlyType("staff id");
						queue.setEventId(EventConstants.EVENT_QUIT);
						queue.setRequestRemake("离职流程");
						queue.setCreatedBy(getLoginUserId() + "");
						commonQueueService.insert(queue);
					}
					return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "上线成功！");
				} else {
					return WrapMapper.wrap(Wrapper.ERROR_CODE, "上线失败！");
				}
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE, "当前状态不允许上线！");
			}
        } catch (Exception e) {
            LOG.error("user update has error.", e);
            return WrapMapper.error();
        }
    }
    
    
    
    /**
     * 员工表----删除
     * 
     * @return
     */
    @RequestMapping(value = "delete")
    @ResponseBody
    public Wrapper<?> delete(Staff staff) {
        try {
        	staff.setUpdateUser(getLoginUserCnName());
        	staff.setUpdateTime(new Date());
        	staff.setLastModifyTime(new Date());
        	Staff s = staffService.getStaffById(staff.getId());
            if (staffService.delete(staff.getId())) {
            	return new Wrapper<Staff>().result(s);
//                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "删除成功！");
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "删除失败！");
            }
        } catch (Exception e) {
            LOG.error("user delete has error.", e);
            return WrapMapper.error();
        }
    }
    
    /**
     * 员工表----添加
     * 
     * @return
     */
    @RequestMapping(value = "add",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> add(Staff staff) {
        try {
        	staff.setCreateUser(getLoginUserCnName());
        	staff.setCreateTime(new Date());
        	staff.setJobTitle(1);//新增员工的岗位为坐席培训期
			staff.setReviewedStatus(EventConstants.EXAMINE_ENTRY_FIRST);
        	//判断客服工号EmployeeNum是否为空，不为空的话，判断该工号是否已经被使用
        	if(StringUtils.isBlank(staff.getEmployeeNum())){
        		staff.setEmployeeNum(null);
        	}else{
        		Staff s = staffService.getStaffByEmployeeNum(staff.getEmployeeNum());
        		if(s!=null){
        			return WrapMapper.wrap(3333, "该员工编号已经存在！");
        		}
        	}
        	
        	//2017-12-07  班组长补齐，用户上级补齐 
    		Dep depInfo = depService.getDepById(staff.getDepId());
        	if(depInfo != null){
        		staff.setSuperior(depInfo.getPersonCharge());
        		staff.setSuperiorId(depInfo.getPersonChargeId());
        	}//2017-12-07 END
        	
            if (staffService.insert(staff)) {
            	//获得刚插入的员工的id，修改记录中需要该id
//            	Long id = staffService.getStaffId(staff.getName());
				//插入commonQueue,同步工作流
				CommonQueue queue = new CommonQueue();
				queue.setOnlyId(staff.getId());
				queue.setOnlyType("staff id");
				queue.setEventId(EventConstants.EVENT_ENTRY);
                queue.setRequestRemake("入职流程");
				queue.setCreatedBy(getLoginUserId() + "");
                commonQueueService.insert(queue);
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, staff.getId() + "");
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
            }
        } catch (ExistedException e) {
            LOG.warn("staff add fail, exist user.");
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败，已经存在");
        } catch (Exception e) {
            LOG.error("staff add has error.", e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
        }
    }
    
    /**
     * 员工表----离职
     * 			员工离职后，需要让其员工号csId无效，方法是在原来的基础上加一个时间戳
     * 			如果该员工在对应的user表里有记录，将该记录的yn置为0
	 *			如果该员工是某个部门的负责人，将该部门的负责人置为空
     * @param
     * @return
     */
    @RequestMapping(value = "dimission",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> dimission(Staff staff){
    	try {
			Staff s = staffService.getStaffById(staff.getId());
    		if(s.getReviewedStatus() == 51 || s.getReviewedStatus() == 53 || s.getReviewedStatus() == 64 || s.getReviewedStatus() == 31 ||
					s.getReviewedStatus() == 33 || s.getReviewedStatus() == 34  || s.getReviewedStatus() == 41 || s.getReviewedStatus() == 43 ||
					s.getReviewedStatus() == 44 || s.getReviewedStatus() == 24) {



				staff.setUpdateUser(getLoginUserCnName());
				staff.setUpdateTime(new Date());
				staff.setLastModifyTime(new Date());
				staff.setReviewedStatus(EventConstants.EXAMINE_ENTRY_DIMISSION_FIRST);
//    		//客服工号标记为无效
//    		if(s.getCsId()!=null && !"".equals(s.getCsId())){
//	    		staff.setCsId(s.getCsId()+"|" + new Date().getTime());
//    		}
//    		//员工编号标记为无效
//    		if(s.getEmployeeNum()!=null && !"".equals(s.getEmployeeNum())){
//    			staff.setEmployeeNum(s.getEmployeeNum() + "|" + new Date().getTime());
//    		}
//    		//乐视账号（域账号）标记为无效
//    		if(s.getLeAccount()!=null && !"".equals(s.getLeAccount())){
//    			staff.setLeAccount(s.getLeAccount() + "|" + new Date().getTime());
//    		}
//    		staff.setPositionStatus("4");
				if (staffService.update(staff)) {
					//如果该员工在对应的user表里有记录，将该记录的yn置为0
					User user = userService.getUserByUsername(s.getLeAccount());
					if (user != null) {
						user.setYn(0);
						user.setUsername(user.getUsername() + "|" + new Date().getTime());//将用户名置为无效
						user.setStaffId(new Date().getTime());
						userService.update(user);
					}
					//如果该员工是部门负责人，将该部门的负责人置为空
					DepQuery query = new DepQuery();
					query.setPersonChargeId(staff.getId());
					List<Dep> deps = depService.queryDepList(query);
					if (deps != null && deps.size() != 0) {
						for (Dep dep : deps) {
							dep.setPersonCharge("");
							dep.setPersonChargeId(0L);
							depService.update(dep);
						}
					}
					//插入commonQueue,同步工作流
					CommonQueue queue = new CommonQueue();
					queue.setOnlyId(staff.getId());
					queue.setOnlyType("staff id");
					queue.setEventId(EventConstants.EVENT_QUIT);
					queue.setRequestRemake("离职流程");
					queue.setCreatedBy(getLoginUserId() + "");
					commonQueueService.insert(queue);
					return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "离职成功！");
				} else {
					return WrapMapper.wrap(Wrapper.ERROR_CODE, "离职失败！");
				}
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE, "此状态下不允许离职操作！");
			}
        } catch (Exception e) {
            LOG.error("staff dimission has error.", e);
            return WrapMapper.error();
        }
    }
    
    /**
     * 员工表----岗位调整
     * @param
     * @return
     */
    @RequestMapping(value = "jobTitleAdjustment",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> jobTitleAdjustment(Staff staff,String jobTitleAdjustmentOtherReason){
    	try {
			Staff curStaff = staffService.getStaffById(staff.getId());
    		if(curStaff.getReviewedStatus() == 24 ||curStaff.getReviewedStatus() == 31 || curStaff.getReviewedStatus() == 33 || curStaff.getReviewedStatus() == 34 || curStaff.getReviewedStatus() == 41 ||
					curStaff.getReviewedStatus() == 43 || curStaff.getReviewedStatus() == 44 || curStaff.getReviewedStatus() == 51 || curStaff.getReviewedStatus() == 53) {
				staff.setUpdateUser(getLoginUserCnName());
				staff.setUpdateTime(new Date());
				staff.setLastModifyTime(new Date());
				staff.setReviewedStatus(EventConstants.EXAMINE_ENTRY_POST_FIRST);
				if ("其他".equals(staff.getJobTitleAdjustmentReason())) {
					staff.setJobTitleAdjustmentReason(jobTitleAdjustmentOtherReason);
				}
				boolean temp = staffService.jobChange(staff, getLoginUserId(), 1);
				if (temp) {
					return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "岗位调整成功！");
				} else {
					return WrapMapper.wrap(Wrapper.ERROR_CODE, "岗位调整失败！");
				}
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE, "此状态下不允许岗位调整");
			}
        } catch (Exception e) {
            LOG.error("staff jobTitleAdjustment has error.", e);
            return WrapMapper.error();
        }

    }
    
    /**
     * 员工表----结构调整
     * @param
     * @return
     */
    @RequestMapping(value = "structAdjust",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> structAdjust(Staff staff,String structAdjustOtherReason){
		try {
			Staff s = staffService.getStaffById(staff.getId());
			if(s.getReviewedStatus() == 24 ||s.getReviewedStatus() == 31 || s.getReviewedStatus() == 33 || s.getReviewedStatus() == 34 || s.getReviewedStatus() == 41 ||
					s.getReviewedStatus() == 43 || s.getReviewedStatus() == 44 || s.getReviewedStatus() == 51 || s.getReviewedStatus() == 53) {
				staff.setUpdateUser(getLoginUserCnName());
				staff.setUpdateTime(new Date());
				staff.setLastModifyTime(new Date());
				staff.setReviewedStatus(EventConstants.EXAMINE_ENTRY_DEPARTMENT_FIRST);
				if ("其他".equals(staff.getStructAdjustReason())) {
					staff.setStructAdjustReason(structAdjustOtherReason);
				}
				boolean temp = staffService.jobChange(staff, getLoginUserId(), 0);
				if (temp) {
					return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "结构调整成功！");
				} else {
					return WrapMapper.wrap(Wrapper.ERROR_CODE, "结构调整失败！");
				}
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE, "此状态下不允许岗位调整");
			}
		} catch (Exception e) {
			LOG.error("staff structAdjust has error.", e);
			return WrapMapper.error();
		}
	}
    
    /**
     * 将枚举值加入到model
     * @param
     * @return
     */
    private void addEnumToModel(Model model){
    	DicQuery query = new DicQuery();
    	query.setParentName("乐视复核人");
    	List<Dic> leReviewers = dicService.queryDicList(query);
    	model.addAttribute("leReviewers", leReviewers);//乐视复核人
    	query.setParentName("学历");
    	List<Dic> educations = dicService.queryDicList(query);
        model.addAttribute("educations", educations);//学历
        query.setParentName("子女");
    	List<Dic> childrens = dicService.queryDicList(query);
        model.addAttribute("childrens", childrens);//子女
        query.setParentName("员工状态");
    	List<Dic> staffStatus = dicService.queryDicList(query);
        model.addAttribute("staffStatus", staffStatus);//员工状态
        query.setParentName("部门范围");
    	List<Dic> depRange = dicService.queryDicList(query);
		model.addAttribute("depRange", depRange);//部门范围
		query.setParentName("员工岗位");
    	List<Dic> jobTitles = dicService.queryDicList(query);
		model.addAttribute("jobTitles", jobTitles);//员工岗位

		query.setParentName("内部岗位");
		List<Dic> inTitles = dicService.queryDicList(query);
		model.addAttribute("inTitles", inTitles);//员工岗位

		query.setParentName("通过结果");
    	List<Dic> results = dicService.queryDicList(query);
		model.addAttribute("results", results);//通过结果
		query.setParentName("岗位调整");
    	List<Dic> jobTitleAdjustments = dicService.queryDicList(query);
		model.addAttribute("jobTitleAdjustments", jobTitleAdjustments);//岗位调整
		query.setParentName("结构调整原因");
    	List<Dic> structuralAdjustments = dicService.queryDicList(query);
		model.addAttribute("structuralAdjustments", structuralAdjustments);//结构调整原因
		query.setParentName("修改记录类型");
    	List<Dic> modifyRecordTypes = dicService.queryDicList(query);
		model.addAttribute("modifyRecordTypes", modifyRecordTypes);//修改记录类型
		query.setParentName("业务");
    	List<Dic> services = dicService.queryDicList(query);
		model.addAttribute("services", services);//业务
		query.setParentName("职级");
    	List<Dic> ranks = dicService.queryDicList(query);
		model.addAttribute("ranks", ranks);//职级
		query.setParentName("合同性质");
    	List<Dic> staffContracts = dicService.queryDicList(query);
		model.addAttribute("staffContracts", staffContracts);//合同性质
		query.setParentName("工作性质");
    	List<Dic> workingPropertys = dicService.queryDicList(query);
		model.addAttribute("workingPropertys", workingPropertys);//工作性质
		query.setParentName("主动离职原因");
		List<Dic> dimissionReason = dicService.queryDicList(query);
		model.addAttribute("dimissionReason", dimissionReason);//主动离职原因
		query.setParentName("被动离职原因");
		List<Dic> beDimissionedReason = dicService.queryDicList(query);
		model.addAttribute("beDimissionedReason", beDimissionedReason);//被动离职原因
		query.setParentName("审批状态");
		List<Dic> reviewedStatus = dicService.queryDicList(query);
		model.addAttribute("reviewedStatus", reviewedStatus);//被动离职原因
		query.setParentName("请假类型");
		List<Dic> leaveType = dicService.queryDicList(query);
		model.addAttribute("leaveType", leaveType);//请假类型
    }
    
    /**
     * 将当前用户的可见部门信息加入model
     * @param
     * @return
     */
    private void addDepListToModel(Model model) {
    	//获得当前用户
		User user = userService.getUserByUsername(getLoginUser().getUserName());
		//当前用户的可见部门列表
		if(user!=null){
			String allowDeps = getDepIds(user.getId());
			List<Dep> depList = depService.getDepListByIds(allowDeps);
//			if(depList!=null && depList.size()!=0){
//				for(Dep dep:depList){
//					dep.setParentDep(depService.getDepById(dep.getParentId()));
//				}
//			}
			model.addAttribute("depList", depList);
		}
	}
    
    /***
     * 获得可见部门的id集合
     */
    private String getDepIds(Long userId){
    	List<UserDep> userDeps = userDepService.queryUserDepList(userId);
		StringBuilder sb = new StringBuilder();
		for(UserDep ud:userDeps){
			sb.append(ud.getDepId()+",");
		}
		String allowDeps = "";
		if(sb.length()>0){
			allowDeps = sb.substring(0, sb.length()-1);
		}
		return allowDeps;
    }
    
    /**
     * 同步staff表的信息到user
     * 			1.需要判断该用户是否存在于user表
     * 			2.存在的话更新该用户，不存在的话插入该用户
     * @param
     * @return
     */
    private boolean synStaffToUser(Staff staff){
    	try {
    		if(staff.getId()!=null && staff.getId()>0){
    			staff = staffService.getStaffById(staff.getId());
				User user = new User();
				user.setUsername(staff.getLeAccount());//乐视账号，即是登录的用户名
				user.setName(staff.getName());//姓名
				user.setStaffId(staff.getId());//对应的员工id
				user.setDepId(staff.getDep().getId());//对应的部门id
				user.setCreateUser(getLoginUserCnName());
				user.setCreateTime(new Date());
				user.setCode(staff.getEmployeeNum());
				
				User tempUser = userService.getUserByUsername(user.getUsername());
				if(tempUser==null){//不存在 ，直接插入
					userService.insert(user);
					//添加用户同步到工作流
					CommonQueue commonQueue=new CommonQueue();
					commonQueue.setEventId(EventConstants.EVENT_STAFF_ADD);
					commonQueue.setOnlyId(user.getId());
					commonQueue.setCreatedBy(String.valueOf(user.getId()));
					commonQueue.setOnlyType("staff online user id");
					commonQueue.setCreationDate(new Date());
					commonQueue.setStatus(0);
					commonQueue.setRequestRemake("上线用户加入queue表");
					this.commonQueueService.insert(commonQueue);
				}else if(tempUser.getStaffId()==null){//存在，且没有关联的staff，更新
					user.setId(tempUser.getId());
					userService.update(user);
				}else{//存在，且有已经关联的staff，不做操作
					return false;
				}
    		}
		} catch (Exception e) {
			LOG.error("staff synStaffToUser has error.", e);
		}
		return true;
    }
    
    /**
     * 员工上线成功时，赋予该员工当前部门的数据权限
     * @param
     * @return
     */
    private void synStaffPortal(Staff staff){
    	Long userId = userService.getUserByUsername(staff.getLeAccount()).getId();
    	Long depId = staffService.getStaffByLeAccount(staff.getLeAccount()).getDep().getId();
    	UserDep oldUserDep = new UserDep();
    	oldUserDep.setUserId(userId);
    	oldUserDep.setDepId(depId);
    	oldUserDep.setUpdateTime(new Date());
    	oldUserDep.setUpdateUser(getLoginUserCnName());
    	UserDep newUserDep = new UserDep();
    	newUserDep.setUserId(userId);
    	newUserDep.setDepId(depId);
    	newUserDep.setCreateTime(new Date());
    	newUserDep.setCreateUser(getLoginUserCnName());
    	List<UserDep> newUserDeps = new ArrayList<UserDep>(1);
    	newUserDeps.add(newUserDep);
    	userDepService.update(oldUserDep, newUserDeps, getLoginUserId());
    }
    
    
    /**
     * 添加按钮级别的权限
     * @param
     * @return
     */
    private void addButtonPortals(Model model,User user){
    	Set<String> set = new HashSet<String>();
    	List<Resource> resources = menuService.queryButtonResources(user);
    	for(Resource r:resources){
    		if(r.getParentId()!=null){
    			set.add(r.getUrl());
    		}
    	}
    	model.addAttribute("buttonPortals", set);
    }
    
}
