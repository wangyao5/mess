package com.letv.css.portal.controller.rest;

import com.letv.css.portal.domain.vo.ScheduleInfoWithType;
import com.letv.css.web.common.response.ResponseWrapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@RequestMapping("/schedule")
public class ScheduleRestController {

    @RequestMapping("/query")
    public ResponseWrapper<ScheduleInfoWithType> query(
            @RequestParam String key,
            @RequestParam Date beginDate,
            @RequestParam Date endDate,
            @RequestParam Integer type
    ) {
//todo
        return null;
    }
}
