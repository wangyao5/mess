package com.letv.css.portal.tools;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.Staff;

public class AutoSchedule {

	private final static Log LOG = LogFactory.getLog(AutoSchedule.class);
	
	public static void main (String[] arg){
		System.out.println("任雅静".compareTo("何改净"));
	}
	
	/**
	 * 获取排班计划明细信息集合
	 * @param schedulePlanDetailList
	 * @return Map<排班计划明细表ID, 排班计划信息>
	 */
	public Map<Long, SchedulePlanDetail> getPlanDetailInfoMap(List<SchedulePlanDetail> schedulePlanDetailList){
		Map<Long, SchedulePlanDetail> resultMap = new HashMap<Long, SchedulePlanDetail>();
		if(schedulePlanDetailList!=null && schedulePlanDetailList.size()>0){
			for(int i = 0; i < schedulePlanDetailList.size(); i ++){
				SchedulePlanDetail schedulePlanDetail = schedulePlanDetailList.get(i);
				resultMap.put(schedulePlanDetail.getId(), schedulePlanDetail);
			}
		}
		return resultMap;
	}
	
	/**
	 * 获取排班计划明细 编号 集合
	 * @param schedulePlanDetailList
	 * @return List< 排班计划明细表ID >
	 */
	public List<Long> getPlanDetailIdList(List<SchedulePlanDetail> schedulePlanDetailList){
		List<Long> resultList = new ArrayList<Long>();
		if(schedulePlanDetailList!=null && schedulePlanDetailList.size()>0){
			for(int i = 0; i < schedulePlanDetailList.size(); i ++){
				SchedulePlanDetail schedulePlanDetail = schedulePlanDetailList.get(i);
				resultList.add(schedulePlanDetail.getId());
			}
		}
		return resultList;
	}
	
	/**
	 * 获取坐席 编号 集合
	 * @param schedulePlanDetailList
	 * @return List< 坐席ID >
	 */
	public List<Long> getStaffIdList(List<Staff> staffList){
		List<Long> resultList = new ArrayList<Long>();
		if(staffList!=null && staffList.size()>0){
			for(int i = 0; i < staffList.size(); i ++){
				Staff staff = staffList.get(i);
				resultList.add(staff.getId());
			}
		}
		return resultList;
	}
	
	/**
	 * 获取 非空记录 - 班表计划明细表
	 * @param schedulePlanDetailList
	 * @return
	 */
	public List<Long> checkPlanDetailForNoNull (List<Long> planDetailIdList,
			Map<Long, SchedulePlanDetail> planDetailInfoMap){
		if(planDetailIdList != null && planDetailIdList.size() > 0){
			for(int i = planDetailIdList.size() - 1;i >= 0; i --){
				Long planDetailId = planDetailIdList.get(i);
				SchedulePlanDetail planDetailInfo = planDetailInfoMap.get(planDetailId);
				if(planDetailInfo == null || planDetailInfo.getNum()==null || planDetailInfo.getNum()<=0){
					planDetailIdList.remove(i);
				}
			}
		}
		return planDetailIdList;
	}
	

	/**
	 * 获取坐席列表的计划排班数
	 * @param staffInfoList
	 * @param scheduleDetailNum
	 * @return
	 */
	public Map<Long, Staff> getStaffInfoMapByPlanShiftNum(List<Staff> staffInfoList,int scheduleDetailNum){
		Map<Long, Staff> resultMap = new HashMap<Long, Staff>();
		if(staffInfoList!=null && staffInfoList.size()>0){
			int staffNum = staffInfoList.size();
			int preShiftNum = scheduleDetailNum / staffNum;
			int mostShiftNum = scheduleDetailNum - ( staffNum * preShiftNum );
			/** [随机打乱] . */
			Collections.shuffle(staffInfoList);
			for(int i = 0; i < staffInfoList.size(); i ++){
				Staff staff = staffInfoList.get(i);
				if(i < mostShiftNum){
					staff.setSchedulingPlanShiftNum(preShiftNum + 1);
				}else{
					staff.setSchedulingPlanShiftNum(preShiftNum);
				}
				resultMap.put(staff.getId(), staff);
			}
		}
		return resultMap;
	}
	
	/**
	 * 获取排班明细集合 通过 时间加班次编号
	 * @param List<SchedulePlanDetail>
	 * @return Map<"yyyy-MM-dd"+"-"+shiftsId, SchedulePlanDetail>
	 */
	public Map<String, Long> getPlanDetailIdMapByPlanDateShifts (Map<Long, SchedulePlanDetail> planDetailInfoMap){
		Map<String, Long> resultMap = new HashMap<String, Long>();
		if(planDetailInfoMap!=null && planDetailInfoMap.size()>0){
			for(Long planDetailId : planDetailInfoMap.keySet()){
				SchedulePlanDetail schedulePlanDetail = planDetailInfoMap.get(planDetailId);
				Date planDate = schedulePlanDetail.getPlanDate();
				Long shiftsId = schedulePlanDetail.getShiftsId();
				String planDateShiftsCode = formatDate(planDate) + "-" + shiftsId;
				resultMap.put(planDateShiftsCode, planDetailId);
			}
		}
		return resultMap;
	}
	
	/**
	 * 获取自动编号的员工集合
	 * @param staffInfoMap
	 * @param superiorCodeMap
	 * @return
	 */
    public List<Long> getStaffIdListByAutoCode(List<Long> staffIdList,
    		final Map<Long, Staff> staffInfoMap,
    		final Map<String, Integer> superiorCodeMap,
    		final boolean needPreShifts){
    	if(staffIdList!=null && staffIdList.size()>0){
    		Collections.shuffle(staffIdList);
    		Collections.sort(staffIdList,new Comparator<Long>() {  
                @Override  
                public int compare(Long staffId_1, Long staffId_2) {
                	Staff staffInfo_1 = staffInfoMap.get(staffId_1);
                	Staff staffInfo_2 = staffInfoMap.get(staffId_2);
                	
                	// 1. 获取 已排班次数
                	Integer dateSize_1 = 0;
                	List<Date> dateList_1 = staffInfo_1.getSchedulingDates();
                	if(dateList_1 != null){dateSize_1 = dateList_1.size();}
                	Integer dateSize_2 = 0;
                	List<Date> dateList_2 = staffInfo_2.getSchedulingDates();
                	if(dateList_2 != null){dateSize_2 = dateList_2.size();}
                	
                	Integer planShiftNum_1 = staffInfo_1.getSchedulingPlanShiftNum();
                	if(planShiftNum_1 == null){planShiftNum_1 = 0;}
                	Integer planShiftNum_2 = staffInfo_2.getSchedulingPlanShiftNum();
                	if(planShiftNum_2 == null){planShiftNum_2 = 0;}
                	// 2. 预置班次 是否计入判断
                	if(needPreShifts){ // 需要计入，则记为正常排班
                		List<Date> preShiftsList_1 = staffInfo_1.getPreShiftsDates();
                		if(preShiftsList_1 != null && preShiftsList_1.size() > 0){
                			dateSize_1 += preShiftsList_1.size();
                		}
                		List<Date> preShiftsList_2 = staffInfo_2.getPreShiftsDates();
                		if(preShiftsList_2 != null && preShiftsList_2.size() > 0){
                			dateSize_2 += preShiftsList_2.size();
                		}
                	}else{ // 无需计入，则从分配班次数中剔除预置班次
                		List<Date> preShiftsList_1 = staffInfo_1.getPreShiftsDates();
                		if(preShiftsList_1 != null && preShiftsList_1.size() > 0){
                			planShiftNum_1 -= preShiftsList_1.size();
                		}
                		List<Date> preShiftsList_2 = staffInfo_2.getPreShiftsDates();
                		if(preShiftsList_2 != null && preShiftsList_2.size() > 0){
                			planShiftNum_2 -= preShiftsList_2.size();
                		}
                	}
                	// 3. 比较空班数，有空班则为 0，没空班则为 1 ；
                	Integer nullShiftNum_1 = planShiftNum_1 - dateSize_1;
                	Integer nullShiftNum_2 = planShiftNum_2 - dateSize_2;
                	if(nullShiftNum_1 <= 0){nullShiftNum_1 = 1;}else{nullShiftNum_1 = 0;}
                	if(nullShiftNum_2 <= 0){nullShiftNum_2 = 1;}else{nullShiftNum_2 = 0;}
                	if(nullShiftNum_1 == nullShiftNum_2){
                		// 1. 已排班次不同时,直接返回比较结果,班次少的在前面
                        if(dateSize_1 == dateSize_2){
                        	// 2. 获取 员工上级的随机编号
                        	Integer superiorCode_1 = superiorCodeMap.get(staffInfo_1.getSuperior());
                        	if(superiorCode_1==null){superiorCode_1 = 999;}
                        	Integer superiorCode_2 = superiorCodeMap.get(staffInfo_2.getSuperior());
                            if(superiorCode_2==null){superiorCode_2 = 999;}
                            // 2. 员工上级随机编号不同时，直接返回结果，编号靠前的在前面
                            return superiorCode_1.compareTo(superiorCode_2);
                        }else{
                        	return dateSize_1.compareTo(dateSize_2);
                        }
                	}else{
                		return nullShiftNum_1.compareTo(nullShiftNum_2);
                	}
                }  
            });
    	}
    	return staffIdList;
    }
	
    /**
	 * 获取排班明细集合 通过 班次
	 * @param List<SchedulePlanDetail>
	 * @return Map<shiftsId, List<SchedulePlanDetail>>
	 */
	public Map<Long, List<Long>> getPlanDeTailIdListByShifts (Map<Long, SchedulePlanDetail> planDetailInfoMap){
		Map<Long, List<Long>> resultMap = new HashMap<Long, List<Long>>();
		if(planDetailInfoMap!=null && planDetailInfoMap.size()>0){
			for(Long planDetailId : planDetailInfoMap.keySet()){
				SchedulePlanDetail schedulePlanDetail = planDetailInfoMap.get(planDetailId);
				Long oneShiftsId = schedulePlanDetail.getShiftsId();
				List<Long> shiftsList = resultMap.get(oneShiftsId);
				if(shiftsList==null){shiftsList = new ArrayList<Long>();}
				shiftsList.add(schedulePlanDetail.getId());
				resultMap.put(oneShiftsId, shiftsList);
			}
		}
		return resultMap;
	}
	
	/**
	 * 
	 * @param planDetailIdList
	 * @param planDetailInfoMap
	 * @return
	 */
	public List<Long> getPlanDetailIdListByNoNull (List<Long> planDetailIdList,
			Map<Long, SchedulePlanDetail> planDetailInfoMap){
		if(planDetailIdList != null && planDetailIdList.size() > 0){
			for(int i = planDetailIdList.size()-1; i >= 0; i --){
				Long planDetailId = planDetailIdList.get(i);
				SchedulePlanDetail schedulePlanDetail = planDetailInfoMap.get(planDetailId);
				if(schedulePlanDetail != null){
					if(schedulePlanDetail.getNum() <= 0){planDetailIdList.remove(i);}
				}else{
					planDetailIdList.remove(i);
				}
			}
		}
		return planDetailIdList;
	}
	
	/**
	 * 获取排班明细集合 通过 班次
	 * @param oneScheduleDetailMap
	 * @return SCHEDULE_PLAN_DETAIL_LIST
	 */
	public List<Long> getPlanDetailIdListByNumDesc (List<Long> planDetailIdList,
			final Map<Long, SchedulePlanDetail> planDetailInfoMap){
		if(planDetailIdList!=null && planDetailIdList.size()>0){
			Collections.sort(planDetailIdList,new Comparator<Long>() {  
                @Override  
                public int compare(Long planDetailId_1, Long planDetailId_2) {
                	SchedulePlanDetail planDetailInfo_1 = planDetailInfoMap.get(planDetailId_1);
                	SchedulePlanDetail planDetailInfo_2 = planDetailInfoMap.get(planDetailId_2);
                	Integer planNum_1 = planDetailInfo_1.getNum();
                	Integer planNum_2 = planDetailInfo_2.getNum();
                	return planNum_2.compareTo(planNum_1);
                }  
            });
		}
		return planDetailIdList;
	}
	
	/**
	 * 获取排班明细集合 通过 时间
	 * @param List<SchedulePlanDetail>
	 * @return Map<planDate, List<SchedulePlanDetail>>
	 */
	public Map<Date, List<Long>> getPlanDetailIdListByPlanDate (Map<Long, SchedulePlanDetail> planDetailInfoMap){
		Map<Date, List<Long>> resultMap = new HashMap<Date, List<Long>>();
		if(planDetailInfoMap!=null && planDetailInfoMap.size()>0){
			for(Long planDetailId : planDetailInfoMap.keySet()){
				SchedulePlanDetail schedulePlanDetail = planDetailInfoMap.get(planDetailId);
				if(schedulePlanDetail == null){continue;}
				if(schedulePlanDetail.getNum() <= 0){continue;}
				Date planDate = schedulePlanDetail.getPlanDate();
				List<Long> planDetailIdList = resultMap.get(planDate);
				if(planDetailIdList==null){planDetailIdList = new ArrayList<Long>();}
				planDetailIdList.add(schedulePlanDetail.getId());
				resultMap.put(planDate, planDetailIdList);
			}
		}
		return resultMap;
	}
	
	/**
	 * 获取排班明细数量 通过时间 倒序排列
	 * @param schedulePlanDetailList
	 * @return
	 */
	public List<Date> getPlanDateListByNumDesc(Map<Long, SchedulePlanDetail> planDetailInfoMap){
		List<Date> resultList = new ArrayList<>();
		if(planDetailInfoMap!=null && planDetailInfoMap.size()>0){
			final Map<Date, Integer> planDateMap = new HashMap<Date, Integer>();
			for(Long planDetailId : planDetailInfoMap.keySet()){
				SchedulePlanDetail schedulePlanDetail = planDetailInfoMap.get(planDetailId);
				Date planDate = schedulePlanDetail.getPlanDate();
				Integer num = schedulePlanDetail.getNum(); 
				if(num == null || num <= 0){continue;}
				Integer mapNum = planDateMap.get(planDate);
				if(mapNum!=null){
					planDateMap.put(planDate, mapNum + num);
				}else{
					planDateMap.put(planDate, num);
				}
			}
			for(Date planDate : planDateMap.keySet()){
				System.out.println(planDate + "---" + planDateMap.get(planDate));
				resultList.add(planDate);
			}
			Collections.sort(resultList,new Comparator<Date>() {  
	            //升序排序  
	            public int compare(Date o1, Date o2) {
	            	Integer num_1 = planDateMap.get(o1);
	            	Integer num_2 = planDateMap.get(o2);
	            	// 倒序排列
	                return num_2.compareTo(num_1);
	            }  
	        });
		}
		return resultList;
	}
	
	
	public List<ScheduleDetail> getDetailListByStaffIdAsc(List<ScheduleDetail> scheduleDetailList){
		if(scheduleDetailList!=null && scheduleDetailList.size()>0){
			Collections.sort(scheduleDetailList,new Comparator<ScheduleDetail>() {  
                @Override  
                public int compare(ScheduleDetail detail_1, ScheduleDetail detail_2) {
                	String leaderName_1 = detail_1.getLeaderName();
                	String leaderName_2 = detail_2.getLeaderName();
                	if(leaderName_1.equals(leaderName_2) || leaderName_1 == leaderName_2){
                		Long staffId_1 = detail_1.getStaffId();
                    	Long staffId_2 = detail_2.getStaffId();
                    	if(staffId_1 == staffId_2){
                    		Long planDate_1 = detail_1.getPlanDate().getTime();
                    		Long planDate_2 = detail_2.getPlanDate().getTime();
                    		return planDate_1.compareTo(planDate_2);
                    	}else{
                    		return staffId_1.compareTo(staffId_2);
                    	}
                	}else{
                		return leaderName_1.compareTo(leaderName_2);
                	}
                }  
            });
		}
		return scheduleDetailList;
	}
	
	/**
	 * 
	 * @param scheduleDetailList
	 * @return
	 */
	public Map<Long, Map<Date, ScheduleDetail>> getDetailMapByStaffId(List<ScheduleDetail> scheduleDetailList){
		Map<Long, Map<Date, ScheduleDetail>> resultMap = new HashMap<Long, Map<Date,ScheduleDetail>>();
		if(scheduleDetailList!=null && scheduleDetailList.size() > 0){
			for(int i=0;i<scheduleDetailList.size();i++){
				ScheduleDetail scheduleDetail = scheduleDetailList.get(i);
				Long staffId = scheduleDetail.getStaffId();
				Date planDate = scheduleDetail.getPlanDate();
				Map<Date, ScheduleDetail> staffScheduleDetailMap = resultMap.get(staffId);
				if(staffScheduleDetailMap==null || staffScheduleDetailMap.size()<=0){
					staffScheduleDetailMap = new HashMap<Date, ScheduleDetail>();
				}
				staffScheduleDetailMap.put(planDate, scheduleDetail);
				resultMap.put(staffId, staffScheduleDetailMap);
			}
		}
		return resultMap;
	}
	
	public List<Long> getStaffListByNeedSchedule (Map<Long, Staff> staffInfoMap){
		List<Long> resultList = new ArrayList<Long>();
		if(staffInfoMap!=null && staffInfoMap.size()>0){
			for(Long staffId : staffInfoMap.keySet()){
				Staff staffInfo = staffInfoMap.get(staffId);
				Integer planShiftNum = staffInfo.getSchedulingPlanShiftNum();
				if(planShiftNum == null || planShiftNum <= 0){break;}
				List<Date> schedulingDates = staffInfo.getSchedulingDates();
				if(schedulingDates == null || schedulingDates.size() <= 0){schedulingDates = new ArrayList<Date>();}
				List<Date> preShiftsDates = staffInfo.getPreShiftsDates();
				if(preShiftsDates == null || preShiftsDates.size() <= 0){preShiftsDates = new ArrayList<Date>();}
				if(planShiftNum - schedulingDates.size() - preShiftsDates.size() > 0){
					resultList.add(staffId);
				}
			}
		}
		return resultList;
	}
	
	public List<Long> getStaffListByBreakSchedule (Map<Long, Staff> staffInfoMap){
		List<Long> resultList = new ArrayList<Long>();
		if(staffInfoMap!=null && staffInfoMap.size()>0){
			for(Long staffId : staffInfoMap.keySet()){
				Staff staffInfo = staffInfoMap.get(staffId);
				Integer planShiftNum = staffInfo.getSchedulingPlanShiftNum();
				if(planShiftNum == null || planShiftNum <= 0){break;}
				List<Date> schedulingDates = staffInfo.getSchedulingDates();
				if(schedulingDates == null || schedulingDates.size() <= 0){schedulingDates = new ArrayList<Date>();}
				List<Date> preShiftsDates = staffInfo.getPreShiftsDates();
				if(preShiftsDates == null || preShiftsDates.size() <= 0){preShiftsDates = new ArrayList<Date>();}
				if(planShiftNum - schedulingDates.size() - preShiftsDates.size() < 0){
					resultList.add(staffId);
				}
			}
		}
		return resultList;
	}
	
	public List<Date> getChangeDateListByStaff(Staff breakStaffInfo, Staff needStaffInfo){
		List<Date> changeShiftsList = new ArrayList<Date>();
		if(breakStaffInfo != null && needStaffInfo != null){
			/** [获取参数] 突破的坐席信息. */
			Integer breakPlanShiftNum = breakStaffInfo.getSchedulingPlanShiftNum();
			if(breakPlanShiftNum == null){breakPlanShiftNum = 0;}
			List<Date> breakSchedulingDates = breakStaffInfo.getSchedulingDates();
			if(breakSchedulingDates == null){breakSchedulingDates = new ArrayList<Date>();}
			List<Date> breakPreShiftsDates = breakStaffInfo.getPreShiftsDates();
			if(breakPreShiftsDates == null){breakPreShiftsDates = new ArrayList<Date>();}
			
			/** [] . */
			changeShiftsList.addAll(breakSchedulingDates);
			changeShiftsList.addAll(breakPreShiftsDates);
			if(changeShiftsList.size() <= 0){return null;}
			
			/** [获取参数] 需要排班的坐席信息. */
			Integer needPlanShiftNum = breakStaffInfo.getSchedulingPlanShiftNum();
			if(needPlanShiftNum == null){needPlanShiftNum = 0;}
			List<Date> needSchedulingDates = needStaffInfo.getSchedulingDates();
			if(needSchedulingDates == null){needSchedulingDates = new ArrayList<Date>();}
			List<Date> needPreShiftsDates = needStaffInfo.getPreShiftsDates();
			if(needPreShiftsDates == null){needPreShiftsDates = new ArrayList<Date>();}
			
			/** [] . */
			changeShiftsList.removeAll(needSchedulingDates);
			changeShiftsList.removeAll(needPreShiftsDates);
			
			for(int j = 0; j < changeShiftsList.size(); j ++){
				Date changeShiftsDate = changeShiftsList.get(j);
				if(breakPreShiftsDates.contains(changeShiftsDate)){
					changeShiftsList.remove(changeShiftsDate);
				}
			}
		}
		return changeShiftsList;
	}

    /**
     * 获取 员工上级的集合
     * @param staffInfoMap
     * @return
     */
    public List<String> getSuperiorList(Map<Long, Staff> STAFF_INFO_MAP){
    	List<String> resultList = new ArrayList<String>();
    	if(STAFF_INFO_MAP!=null && STAFF_INFO_MAP.size()>0){
    		for(Long staffId : STAFF_INFO_MAP.keySet()){
    			resultList.add(STAFF_INFO_MAP.get(staffId).getSuperior());
    		}
    	}
    	return resultList;
    }
	
    /**
     * 获取自动编号的上级集合
     * @param superiorList
     * @return
     */
    public Map<String, Integer> getSuperiorMapByAutoCode(List<String> superiorList){
    	Map<String, Integer> resultMap = new HashMap<String, Integer>();
    	if(superiorList!=null && superiorList.size()>0){
        	Collections.shuffle(superiorList);
    		for(int i = 0; i < superiorList.size(); i ++){
    			resultMap.put(superiorList.get(i), i);
    		}
    	}
    	return resultMap;
    }
	
    
	/**
	 * 校对明细数量
	 * @param detailNum
	 * @return
	 */
	public Integer checkDetailNum(Integer detailNum){
		Integer resultNum = null;
		if(detailNum != null){
			if(detailNum < 5){
				resultNum = detailNum;
			}else if(detailNum >= 5 && detailNum < 10){
				resultNum = 5;
			}else if(detailNum >= 10){
				resultNum = Math.round(detailNum / 2);
			}
		}
		return resultNum;
	}
	
	/**
	 * 获取排班周期的开始时间
	 * @param beginTime
	 * @return
	 */
    public Date getScheduleBeginTime(Date beginTime){
		if(beginTime != null){
			Date nowDate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
			try {
				nowDate = formatter.parse(formatter.format(nowDate));
				Calendar calendar = new GregorianCalendar();
				calendar.setTime(nowDate);
				calendar.add(calendar.DATE,1);
				nowDate = calendar.getTime(); 
			} catch (ParseException e) {
				e.printStackTrace();
			}
			if(beginTime.before(nowDate)){
				beginTime = nowDate;
			}
		}
		return beginTime;
    }
    
    public List<Date> getDateListByAutoCode(Date BeginTime,Date EndTime){
    	List<Date> resultList = new ArrayList<Date>();
    	if(BeginTime!=null && EndTime!=null){
        	Calendar cal = Calendar.getInstance();
        	cal.setTime(EndTime);
        	while (EndTime.after(BeginTime)){
        		EndTime = cal.getTime();
        		if(BeginTime.getTime() > EndTime.getTime()){break;}
        		resultList.add(EndTime);
        		cal.add(Calendar.DAY_OF_MONTH, -1);
        	}
        	Collections.shuffle(resultList);
    	}
    	return resultList;
    }
    

    /**
     * 时间格式化 yyyy-MM-dd
     * @param date
     * @return
     */
    public String formatDate(Date date){
    	SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");
    	return dateFormater.format(date);
    }
	/***************************************************************************************/
    
    /**
     * 获取计划班次人数 安装日期进行分组
     * @param planDetailList
     * @return Map<日期, 人数>
     */
    public Map<Date, Integer> getPlanDetailCountMapByPlanDate (List<SchedulePlanDetail> planDetailList){
    	Map<Date, Integer> planCountMap = new HashMap<Date, Integer>();
    	if(planDetailList != null && planDetailList.size() > 0 ){
    		for(int i = 0; i < planDetailList.size(); i ++){
    			SchedulePlanDetail planDetailInfo = planDetailList.get(i);
    			Date planDate = planDetailInfo.getPlanDate();
    			Integer planNum = planDetailInfo.getNum();
    			if(planNum == null){planNum = 0;}
    			Integer planCount = planCountMap.get(planDate);
    			if(planCount == null){planCount = 0;}
    			planCountMap.put(planDate, planCount + planNum);
    		}
    	}
    	return planCountMap;
    }
    
    
    /**
     * 获取班长下所属的坐席信息集合
     * @param staffInfoMap
     * @param leaderInfoList
     * @return Map<班长staffId, List<坐席信息>>
     */
    public Map<Long, List<Staff>> getLeaderStaffInfoMap (Map<Long, Staff> staffInfoMap, List<Staff> leaderInfoList){
    	Map<Long, List<Staff>> leaderStaffInfoMap = new HashMap<Long, List<Staff>>();
    	
    	Map<String, Long> LeaderNameMap = new HashMap<String, Long>();
    	if(leaderInfoList != null && leaderInfoList.size() > 0){
    		for(int i = 0; i < leaderInfoList.size(); i ++){
    			Staff leaderInfo = leaderInfoList.get(i);
    			LeaderNameMap.put(leaderInfo.getName(), leaderInfo.getId());
    		}
    	}
    	if(staffInfoMap != null && staffInfoMap.size() > 0){
    		for(Long staffId : staffInfoMap.keySet()){
    			Staff staffInfo = staffInfoMap.get(staffId);
    			String superior = staffInfo.getSuperior();
    			Long leaderStaffId = LeaderNameMap.get(superior);
    			if(leaderStaffId != null){
    				List<Staff> leaderStaffList = leaderStaffInfoMap.get(leaderStaffId);
    				if(leaderStaffList == null){leaderStaffList = new ArrayList<Staff>();}
    				leaderStaffList.add(staffInfo);
    				leaderStaffInfoMap.put(leaderStaffId, leaderStaffList);
    			}
    		}
    	}
    	return leaderStaffInfoMap;
    }
    
    
    public List<Long> getLeaderProportionByPlanDateDesc (Date planDate, Map<Long, List<Staff>> leaderStaffInfoMap){
    	List<Long> resultList = new ArrayList<Long>();
    	if(planDate != null && leaderStaffInfoMap != null){
    		final Map<Long, Double> staffProportionMap = new HashMap<Long, Double>();
    		for(Long leaderId : leaderStaffInfoMap.keySet()){
    			List<Staff> staffInfoList = leaderStaffInfoMap.get(leaderId);
    			int staffCount = 0;
    			for(int i = 0; i < staffInfoList.size(); i ++){
    				Staff staffInfo = staffInfoList.get(i);
    				if(staffInfo.getSchedulingDates()!= null && staffInfo.getSchedulingDates().contains(planDate)){ 
    					staffCount += 1;
    				}else if(staffInfo.getPreShiftsDates()!= null && staffInfo.getPreShiftsDates().contains(planDate)){
    					staffCount += 1;
    				}
    						
    			}
    			staffProportionMap.put(leaderId, (double)staffCount/staffInfoList.size());
    		}
    		resultList.addAll(leaderStaffInfoMap.keySet());
    		Collections.sort(resultList,new Comparator<Long>() {  
                @Override  
                public int compare(Long o1, Long o2) {
                	Double d1 = staffProportionMap.get(o1);
                	Double d2 = staffProportionMap.get(o2);
                	return d2.compareTo(d1);
                }
    		});
    	}
    	return resultList;
    }
    
    public Map<Date, Map<Long, Long>> getStaffShiftsProportionByLeader (List<ScheduleDetail> staffScheduleDetail, 
    		Map<Long, Staff> staffInfoMap, List<Staff> leaderInfoList){
    	Map<Date, Map<Long, Long>> resultMap = new HashMap<Date, Map<Long,Long>>();
    	if(staffScheduleDetail != null && staffScheduleDetail.size() > 0){
    		Map<Long, Staff> leaderInfoMap = new HashMap<Long, Staff>();
    		for(int i = 0; i < leaderInfoList.size(); i ++){
    			Staff leaderInfo = leaderInfoList.get(i);
    			leaderInfoMap.put(leaderInfo.getId(), leaderInfo);
    		}
    		
        	/** [排序] 时间正序，班长正序，班次正序，. */
        	Collections.sort(staffScheduleDetail,new Comparator<ScheduleDetail>() {  
                @Override  
                public int compare(ScheduleDetail detail_1, ScheduleDetail detail_2) {
                	Date planDate_1 = detail_1.getPlanDate();
                	Date planDate_2 = detail_2.getPlanDate();
                	if(planDate_1.getTime() != planDate_2.getTime()){
                		return planDate_1.compareTo(planDate_2);
                	}else{
                		String leaderName_1 = detail_1.getLeaderName();
                		String leaderName_2 = detail_2.getLeaderName();
                		if(leaderName_1!=null && !leaderName_1.trim().equals("") 
                				&& leaderName_2!=null && !leaderName_2.trim().equals("")){
                			if(leaderName_1.trim().equals(leaderName_2)){
                    			Long shiftsId_1 = detail_1.getShiftsId();
                    			Long shiftsId_2 = detail_2.getShiftsId();
                    			return shiftsId_1.compareTo(shiftsId_2);
                    		}else{
                    			return leaderName_1.compareTo(leaderName_2);
                    		}
                		}else if((leaderName_1==null || leaderName_1.trim().equals(""))
                				&& (leaderName_2==null || leaderName_2.trim().equals(""))){
                			return 0;
                		}else{
                			if(leaderName_1 != null && !leaderName_1.trim().equals("")){return 1;}else{return -1;}
                		}
                	}
                }
    		});
        	
    		/** [] Map<日期_班长编号, 班次编号>. */
    		int DETAIL_NUM = 0;
    		int MAX_DETAIL_NUM = 0;
        	for(int i = 0; i < staffScheduleDetail.size(); i ++){
        		ScheduleDetail scheduleDetail = staffScheduleDetail.get(i);
        		Long staffId = scheduleDetail.getStaffId();
        		Date planDate = scheduleDetail.getPlanDate();
        		Map<Long, Long> planDateShiftsMap = resultMap.get(planDate);
        		if(planDateShiftsMap == null || planDateShiftsMap.size() <= 0){
        			planDateShiftsMap = new HashMap<Long, Long>();
        		}
        		Staff staffInfo = staffInfoMap.get(staffId);
        		Long superiorId = staffInfo.getSuperiorId();
        		if(superiorId == null){continue;}
				Staff leaderInfo = leaderInfoMap.get(superiorId);
        		if(leaderInfo == null){continue;}
        		DETAIL_NUM += 1;
        		if(i >= staffScheduleDetail.size() - 1){
        			if(DETAIL_NUM > MAX_DETAIL_NUM){
        				planDateShiftsMap.put(leaderInfo.getId(), scheduleDetail.getShiftsId());
        				resultMap.put(planDate, planDateShiftsMap);
        			}
        		}else{
        			ScheduleDetail scheduleDetailNext = staffScheduleDetail.get(i + 1);
        			Long staffIdNext = scheduleDetailNext.getStaffId();
        			Date planDateNext = scheduleDetailNext.getPlanDate();
        			if(planDate.getTime() != planDateNext.getTime()){ // 不同一天
        				if(DETAIL_NUM > MAX_DETAIL_NUM){
        					MAX_DETAIL_NUM = DETAIL_NUM;
        					planDateShiftsMap.put(leaderInfo.getId(), scheduleDetail.getShiftsId());
        					resultMap.put(planDate, planDateShiftsMap);
        				}
        				DETAIL_NUM = 0;
        			}else{
        				Staff staffInfoNext = staffInfoMap.get(staffIdNext);
        				Long superiorIdNext = staffInfoNext.getSuperiorId();
        				if(superiorIdNext == null || superiorIdNext != superiorId){ // 不同一个组长
        					if(DETAIL_NUM > MAX_DETAIL_NUM){
        						MAX_DETAIL_NUM = 0;
        						planDateShiftsMap.put(leaderInfo.getId(), scheduleDetail.getShiftsId());
        						resultMap.put(planDate, planDateShiftsMap);
        					}
        				}
        			}
        		}
        	}
        	
    	}
    	return resultMap;
    }

    private Map<Date, List<Long>> getPlanDateShiftsList (List<SchedulePlanDetail> planDetailList,
    		Map<Long, Integer> shiftsOrderMap){
    	Map<Date, List<Long>> resultMap = new HashMap<Date, List<Long>>();
    	if(planDetailList != null && planDetailList.size() > 0){
    		/** [排序] 时间正序，班长正序，班次正序，. */
        	Collections.sort(planDetailList,new Comparator<SchedulePlanDetail>() {  
                @Override  
                public int compare(SchedulePlanDetail detail_1, SchedulePlanDetail detail_2) {
                	Date planDate_1 = detail_1.getPlanDate();
                	Date planDate_2 = detail_2.getPlanDate();
                	if(planDate_1 != planDate_2){
                		return planDate_1.compareTo(planDate_2);
                	}else{
                		Long shiftsId_1 = detail_1.getShiftsId();
                		Integer shiftsOrder_1 = shiftsOrderMap.get(shiftsId_1);
                		Long shiftsId_2 = detail_2.getShiftsId();
                		Integer shiftsOrder_2 = shiftsOrderMap.get(shiftsId_2);
                		
                		return shiftsOrder_1.compareTo(shiftsOrder_2);
                	}
                }
    		});
    		for(int i = 0; i < planDetailList.size(); i ++){
    			SchedulePlanDetail planDatail = planDetailList.get(i);
    			Date planDate = planDatail.getPlanDate();
    			if(planDatail.getNum() == null || planDatail.getNum() <= 0){continue;}
    			if(resultMap.get(planDate) == null){
    				resultMap.put(planDate, new ArrayList<Long>());
    			}
    			resultMap.get(planDate).add(planDatail.getShiftsId());
    		}
    	}
    	return resultMap;
    }
}
