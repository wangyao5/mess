package com.letv.css.portal.check.bean;

/**
 * Created by yangxinghe on 2017/6/30.
 * 记录excel的导入数据，数据不做校验，不做关联
 */
public class ImpScheduleMsg {
    /**
     * 职场名称
     */
    private String depName;

    /**
     * 客服工号
     */
    private String csId;
    /**
     * 用户名称
     */
    private String uName;
    /**
     * 岗位
     */
    private String jobTitleName;
    /**
     * 业务线
     */
    private String busName;
    /**
     * 组长
     */
    private String leaderName;
    /**
     * 周1班次名称
     */
    private String shiftsName1;
    /**
     * 周2班次名称
     */
    private String shiftsName2;
    /**
     * 周3班次名称
     */
    private String shiftsName3;
    /**
     * 周4班次名称
     */
    private String shiftsName4;
    /**
     * 周5班次名称
     */
    private String shiftsName5;
    /**
     * 周六班次名称
     */
    private String shiftsName6;
    /**
     * 周日班次名称
     */
    private String shiftsName7;

    public String getDepName() {
        return depName;
    }

    public void setDepName(String depName) {
        this.depName = depName;
    }

    public String getCsId() {
        return csId;
    }

    public void setCsId(String csId) {
        this.csId = csId;
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getJobTitleName() {
        return jobTitleName;
    }

    public void setJobTitleName(String jobTitleName) {
        this.jobTitleName = jobTitleName;
    }

    public String getBusName() {
        return busName;
    }

    public void setBusName(String busName) {
        this.busName = busName;
    }

    public String getLeaderName() {
        return leaderName;
    }

    public void setLeaderName(String leaderName) {
        this.leaderName = leaderName;
    }

    public String getShiftsName1() {
        return shiftsName1;
    }

    public void setShiftsName1(String shiftsName1) {
        this.shiftsName1 = shiftsName1;
    }

    public String getShiftsName2() {
        return shiftsName2;
    }

    public void setShiftsName2(String shiftsName2) {
        this.shiftsName2 = shiftsName2;
    }

    public String getShiftsName3() {
        return shiftsName3;
    }

    public void setShiftsName3(String shiftsName3) {
        this.shiftsName3 = shiftsName3;
    }

    public String getShiftsName4() {
        return shiftsName4;
    }

    public void setShiftsName4(String shiftsName4) {
        this.shiftsName4 = shiftsName4;
    }

    public String getShiftsName5() {
        return shiftsName5;
    }

    public void setShiftsName5(String shiftsName5) {
        this.shiftsName5 = shiftsName5;
    }

    public String getShiftsName6() {
        return shiftsName6;
    }

    public void setShiftsName6(String shiftsName6) {
        this.shiftsName6 = shiftsName6;
    }

    public String getShiftsName7() {
        return shiftsName7;
    }

    public void setShiftsName7(String shiftsName7) {
        this.shiftsName7 = shiftsName7;
    }
}
