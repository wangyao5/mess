package com.letv.css.portal.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.FunctionalStaffCalendar;
import com.letv.css.portal.domain.query.FunctionalStaffCalendarQuery;
import com.letv.css.portal.service.FunctionalStaffCalendarService;

@Controller
@RequestMapping("functionalStaffCalendar")
public class FunctionalStaffCalendarController extends BaseController{

	private static final Log LOG = LogFactory.getLog(FunctionalStaffCalendarController.class);
	
	@Autowired
	private FunctionalStaffCalendarService functionalStaffCalendarService;
	
	private static final String VIEW_PREFIX = "functionalStaffCalendar";
    private static final String VIEW_INDEX = "index";
	
	@RequestMapping("")
    public String welcome(Model model, FunctionalStaffCalendarQuery query) {
        return index(model, query);
    }
	
	@RequestMapping("index")
    public String index(Model model, FunctionalStaffCalendarQuery query) {
		if(query == null || query.getPlanYear() == null || query.getPlanMonth() == null){
			Date defaultPlanDate = new Date();
			query = new FunctionalStaffCalendarQuery();
			query.setPlanYear(defaultPlanDate.getYear() + 1900);
			query.setPlanMonth(defaultPlanDate.getMonth() + 1);
		}
		List<FunctionalStaffCalendar> calendarList = functionalStaffCalendarService.queryList(query);
		model.addAttribute("calendarList", calendarList);
        return VIEW_PREFIX + "/" + VIEW_INDEX;
    }
	
	/**
     * 获取工作日历
     *
     * @param model
     * @param schedule
     * @return
     */
	@RequestMapping("queryCalendar")
    @ResponseBody
    public Wrapper<?> queryCalendar(FunctionalStaffCalendarQuery query) throws Exception {
        if(query!=null){
        	return WrapMapper.wrap(Wrapper.SUCCESS_CODE, getCalendarJson(query));
        }else{
        	return WrapMapper.wrap(Wrapper.ERROR_CODE, "请求参数为空");
        }
    }
	
    /**
     * 保存工作日历
     *
     * @param model
     * @param schedule
     * @return
     */
    @RequestMapping("updateCalendar")
    @ResponseBody
    public Wrapper<?> updateCalendar(FunctionalStaffCalendarQuery query) throws Exception {
    	boolean result = updateMonthCalendar(query);
        if(result){
        	return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "保存成功");
        }else{
        	return WrapMapper.wrap(Wrapper.ERROR_CODE, "保存失败");
        }
    }
    
    private boolean updateMonthCalendar(FunctionalStaffCalendarQuery query){
    	boolean result = false;
    	if(query!=null){
    		Integer planYear = query.getPlanYear();
    		Integer planMonth = query.getPlanMonth();
    		String shiftsId = query.getShiftsId();
    		String workStatusJson = query.getWorkStatusJson();
    		String loginUserName = getLoginUserName();
    		JSONObject workStatus = JSONObject.parseObject(workStatusJson);
    		int dateOfMonth = getDateOfMonth(planYear, planMonth);
    		List<FunctionalStaffCalendar> calendarInfoList = new ArrayList<FunctionalStaffCalendar>();
    		for(int i=1;i<=dateOfMonth;i++){
    			FunctionalStaffCalendar calendarInfo = new FunctionalStaffCalendar();
    			Object oneWorkStatus = workStatus.get(i+"");
    			if(oneWorkStatus==null){break;}
    			/* 计划日期. */
    			Date planDate = packDate(planYear, planMonth, i);
    			calendarInfo.setPlanDate(planDate);
    			/* 工作状态. */
    			calendarInfo.setWorkStatus(Integer.valueOf(oneWorkStatus.toString()));
    			calendarInfo.setSchedulingStatus("0");
    			/* 班次编号. */
    			calendarInfo.setShiftsId(Long.valueOf(shiftsId));
    			calendarInfo.setCreateUser(loginUserName);
    			calendarInfo.setUpdateUser(loginUserName);
    			calendarInfoList.add(calendarInfo);
    		}
    		if(calendarInfoList.size() >= dateOfMonth){
    			result = functionalStaffCalendarService.inserts(calendarInfoList);
    		}
    	}
    	return result;
    }
    
    private int getDateOfMonth (int year,int month){
    	int dateOfMonth = -1;
    	if(year > 0 && month > 0){
    		Calendar cal = Calendar.getInstance();
    		cal.set(Calendar.YEAR, year);
    		cal.set(Calendar.MONTH, month - 1);
    		dateOfMonth = cal.getActualMaximum(Calendar.DATE);
    	}
    	return dateOfMonth;
    }
    
    private Date packDate (int year,int month,int day){
    	Date resultDate = null;
    	try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			resultDate = formatter.parse(year + "-" + month + "-" + day + " 00:00:00");
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	return resultDate;
    }
    
    /**
     * 获取工作日历的JSON
     * @param query
     * @return
     */
	private String getCalendarJson(FunctionalStaffCalendarQuery query){
		List<FunctionalStaffCalendar> calendarList = functionalStaffCalendarService.queryList(query);
		JSONObject jsonMap = new JSONObject();
		
		jsonMap.put("query", query);
		jsonMap.put("size", calendarList.size());
		jsonMap.put("list", calendarList);
		
		System.out.println("GREG:"+jsonMap);
		return jsonMap.toString();
	}
	
}
