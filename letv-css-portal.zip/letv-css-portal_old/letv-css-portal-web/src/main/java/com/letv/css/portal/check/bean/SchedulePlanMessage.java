package com.letv.css.portal.check.bean;

import java.io.Serializable;
import java.util.List;

import com.letv.css.portal.domain.SchedulePlanDetail;

/**
 * 总班表导入信息：验证通过总班表明细、未经过验证的总班表明细、验证错误信息
 *
 * @Author menghan
 * @Version 2017-06-13 18:28:31
 */
public class SchedulePlanMessage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6523365308491912396L;
	//总班表明细
	private List<SchedulePlanDetail> schedulePlanDetail;
	//未验证的数据信息
	private List<ImportsMessage> importsMessage;
	//验证错误信息
	private List<ImportsErrorMessage> importsErrorMessage;
	public List<SchedulePlanDetail> getSchedulePlanDetail() {
		return schedulePlanDetail;
	}
	public void setSchedulePlanDetail(List<SchedulePlanDetail> schedulePlanDetail) {
		this.schedulePlanDetail = schedulePlanDetail;
	}
	public List<ImportsMessage> getImportsMessage() {
		return importsMessage;
	}
	public void setImportsMessage(List<ImportsMessage> importsMessage) {
		this.importsMessage = importsMessage;
	}
	public List<ImportsErrorMessage> getImportsErrorMessage() {
		return importsErrorMessage;
	}
	public void setImportsErrorMessage(List<ImportsErrorMessage> importsErrorMessage) {
		this.importsErrorMessage = importsErrorMessage;
	}
	
}
