package com.letv.css.portal.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.constant.CommonConstants;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.service.CommonQueueService;
import com.letv.css.portal.service.SSOService;
import com.letv.css.portal.service.StaffService;
import com.letv.css.portal.service.UserService;
import com.letv.css.portal.domain.vo.workflow.bean.Instance;
import com.letv.css.portal.domain.vo.workflow.bean.QInstanceResult;
import com.letv.css.portal.domain.vo.workflow.bean.WfResponse;
import com.letv.css.portal.domain.vo.workflow.bean.WorkFlowIndexQuery;
import com.letv.css.web.common.utils.HttpUtil;
import com.letv.css.web.common.utils.JsonUtil;
import com.letv.css.web.common.utils.Md5Util;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.WebUtils;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("employee")
public class EmployeeController extends BaseController {
    private static final Log LOG = LogFactory.getLog(EmployeeController.class);

    @Value("${workflow.url.domain.host}")
    private  String URL_TEST;
    @Value("${workflow.url.domain.queryInstanceByMyOpen}")
    private  String URL_QUERYINSTANCEBYMYOPEN;
    @Value("${workflow.url.domain.processInstance}")
    private  String URL_PROCESSINSTANCE;
    @Autowired
    private SSOService ssoService;
    @Autowired
    private UserService userService;
    /**
     * 视图前缀
     */
    private static final String viewPrefix = "workflow";
    @Autowired
    private StaffService staffService;

    @Autowired
    private CommonQueueService commonQueueService;

    /**
     * 列表页
     */
    @RequestMapping("export")
    public void export(HttpServletResponse response, WorkFlowIndexQuery query, HttpServletRequest request) throws IOException {
        try {
            //excel数据

            String qparam = request.getParameter("qparam");
            qparam = java.net.URLDecoder.decode(qparam, "UTF-8");
            String url = URL_TEST + URL_QUERYINSTANCEBYMYOPEN;
            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put("operatorType", "css");
            param.put("operatorId", String.valueOf(getLoginUserId()));
            param.put("flowId", query.getFlowId());
            param.put("statusId", query.getStatusId());
            param.put("pageRows", "100");

            if (StringUtils.isNotEmpty(query.getQparam())) {
                param.put("keyword", query.getQparam());
            }
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info(str);

            WfResponse<QInstanceResult> wfs = JsonUtil.fromJsonObject(str,
                    new TypeReference<WfResponse<QInstanceResult>>() {
                    });
            if (wfs.getStatus().equals("0")) {
                QInstanceResult qir = wfs.getResult();
                List<Instance> itemList = qir.getInstance();
                //文件名 ，文件类型
                String fileName = getFlowDetailExcelName();

                response.setContentType("application/x-excel");
                response.setCharacterEncoding("UTF-8");
                response.addHeader("Content-Disposition", "attachment;filename="
                        + new String(fileName.getBytes(), "iso-8859-1"));// excel文件名
                String[] headers = new String[]{"流程ID", "人员ID", "姓名","姓名拼音", "部门", "创建人", "工号", "乐视账号","所属从属组ID","所属从属组名称"};
                String title = getFlowDetailExcelName();

                exportExcel(title, itemList, response.getOutputStream(), headers);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void exportExcel(String title, List<Instance> list, OutputStream out, String[] headers) {
        //声明一个工作簿
        HSSFWorkbook workbook = new HSSFWorkbook();
        //生成一个表格
        HSSFSheet sheet = workbook.createSheet(title);
        //设置表格默认列宽度为15个字符
        sheet.setDefaultColumnWidth(20);
        //生成一个样式，用来设置标题样式
        HSSFCellStyle style = workbook.createCellStyle();
        //产生表格标题行
        HSSFRow row = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            HSSFCell cell = row.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(style);
        }
        for (int i = 0; i < list.size(); i++) {
            Instance instance = list.get(i);
            row = sheet.createRow(i + 1);
            // 第四步，创建单元格，并设置值
            row.createCell(0).setCellValue(instance.getId());
            row.createCell(1).setCellValue(instance.getStaffId());
            row.createCell(2).setCellValue(instance.getName());
            row.createCell(3).setCellValue("");//姓名拼音
            row.createCell(4).setCellValue(instance.getDepName());
            row.createCell(5).setCellValue(instance.getCreaterName());
            row.createCell(6).setCellValue("");
            row.createCell(7).setCellValue("");
            row.createCell(8).setCellValue("");
            row.createCell(9).setCellValue("");
        }
        try {
            workbook.write(out);
            out.flush();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @RequestMapping("closeNo")
    @ResponseBody
    public Wrapper<?> disable(HttpServletRequest request) {
        try {
            String item = WebUtils.findParameterValue(request, "param");
            List<Staff> list = JsonUtil.fromJsonList(item, Staff.class);
            int temp = 0;
            for (Staff staff : list) {
                String result = updateFlow(staff.getInstanceId(), "closeSuccess", "closeJobNo");
                if ("0".equals(result)) {
                    Staff s = staffService.getStaffById(staff.getId());

                    s.setReviewedStatus(EventConstants.EXAMINE_ENTRY_DIMISSION_YES);
                    s.setPositionStatus(EventConstants.POSITION_STATUS_DIMISSION);
                    //客服工号标记为无效
                    if (s.getCsId() != null && !"".equals(s.getCsId())) {
                        s.setCsId(s.getCsId() + "|" + new Date().getTime());
                    }
                    //员工编号标记为无效
                    if (s.getEmployeeNum() != null && !"".equals(s.getEmployeeNum())) {
                        s.setEmployeeNum(s.getEmployeeNum() + "|" + new Date().getTime());
                    }
                    //乐视账号（域账号）标记为无效
                    if (s.getLeAccount() != null && !"".equals(s.getLeAccount())) {
                        s.setLeAccount(s.getLeAccount() + "|" + new Date().getTime());
                    }
                   if(staffService.update(s)) {
                       temp = 0;
                       //插入commonQueue,同步工作流
                       CommonQueue queue = new CommonQueue();
                       queue.setOnlyId(s.getId());
                       queue.setOnlyType("staff id");
                       queue.setEventId(EventConstants.EVENT_SEND_STAFF_LEAVE);
                       queue.setRequestRemake("工号关闭推送CC系统");
                       queue.setCreatedBy("STAFF LEAVE");
                       boolean flag=commonQueueService.insert(queue);
                       LOG.info("工号关闭后插入CommonQueue表：EmployeeController.disable 更新表的参数：" + JsonHelper.toJson(queue) + ",插入结果flag:" + flag);
                   }else{
                       temp = 1;
                   }
                }else{
                    temp = 1;
                }
            }
            if(temp == 1){
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "关闭工号失败！");
            }
            return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "关闭工号成功！");

        } catch (Exception e) {
            LOG.error("dep disable has error.", e);
            return WrapMapper.error();
        }
    }

    /**
     * 更新工作流
     */

    public String updateFlow(int id, String actionId, String statusId){
        try {
            String url = URL_TEST + URL_PROCESSINSTANCE;
            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);

            param.put("statusId", statusId);
            param.put("instanceId", id + "");
            param.put("operatorType", "css");
            param.put("actionId", actionId);
            param.put("operatorId", String.valueOf(getLoginUserId()));
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info(str);
            HashMap wfs =  JsonUtil.fromJsonObject(str,HashMap.class);
            return wfs.get("status") + "";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "-1";
    }
    /**
     * excel名称
     *
     * @param
     * @return
     */
    private String getFlowDetailExcelName() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return "工号导出" +
                "-" + sdf.format(new Date()) + ".xls";
    }

    @RequestMapping("imports")
    @ResponseBody
    public Wrapper<?> imports(@RequestParam("file") MultipartFile file, HttpServletRequest request) throws Exception {

        int temp = 0;
        // 判断文件是否为空
        if (!file.isEmpty()) {
            try {
                // 文件保存路径
                String uploadpath = request.getSession().getServletContext().getRealPath("/") + "upload/";
                File uploadfile = new File(uploadpath);
                if (!uploadfile.exists())
                    uploadfile.mkdirs();
                String filePath = uploadpath + System.currentTimeMillis()
                        + file.getOriginalFilename();
                // 转存文件
                file.transferTo(new File(filePath));
                List<Staff> excellist = readExcelFile(filePath);
                String str = "";
                for (Staff staff : excellist) {
                    if ("".equals(staff.getCsId().trim()) || "".equals(staff.getLeAccount().trim())) {
                        str += staff.getId() + "数据为空，失败;";
                        temp = -1;
                    } else {
                        //校验
                        int checkNum = checkAccountAndCsId(staff);
                        if(checkNum == -1){
                            str += staff.getId() + "账号重复;";
                            temp = -1;
                        }else if(checkNum == -2){
                            str += staff.getId() + "账号不可用;";
                            temp = -1;
                        }else if(checkNum == -3){
                            str += staff.getId() + "工号重复;";
                            temp = -1;
                        }else {
                            //流程状态流转
                            String num = updateFlow(staff.getInstanceId(), "allow", "waitForEmployeeNumCheck");
                            if ("0".equals(num)) {
                                //状态流转成功，修改数据库节点
                                Staff staffs = new Staff();
                                staffs.setId(staff.getId());
                                staffs.setReviewedStatus(EventConstants.EXAMINE_ENTRY_WORKNUM_YES);
                                staffs.setLeAccount(staff.getLeAccount());
                                staffs.setCsId(staff.getCsId());
                                if(staff.getNameSpell()!=null && !"".equals(staff.getNameSpell().trim())){//防止空覆盖
                                    staffs.setNameSpell(staff.getNameSpell());
                                }
                                staffs.setCcRoleGroupId(staff.getCcRoleGroupId());
                                staffs.setCcRoleGroupName(staff.getCcRoleGroupName());
                                LOG.info("工号导入更新数据库：EmployeeController.imports 更新表的参数：" + JsonHelper.toJson(staffs));
                                staffService.update(staffs);
                                //插入commonQueue,同步工作流
                                CommonQueue queue = new CommonQueue();
                                queue.setOnlyId(staffs.getId());
                                queue.setOnlyType("staff id");
                                queue.setEventId(EventConstants.EVENT_SEND_STAFF_NEW);
                                queue.setRequestRemake("工号导入推送CC系统");
                                queue.setCreatedBy("STAFF ADD");
                                boolean flag=commonQueueService.insert(queue);
                                LOG.info("工号导入后插入CommonQueue表：EmployeeController.imports 更新表的参数：" + JsonHelper.toJson(queue) + ",插入结果flag:" + flag);
                            } else {
                                temp = -1;
                                str += staff.getId() + "流转状态失败;";
                            }
                        }
                    }
                }
                LOG.info("导入：" + str);
                if(temp == 0) {
                    return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "导入成功！");
                }else{
                    return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "导入时部分失败！" + str);
                }
            } catch (Exception e) {
                logger.info("upload file:" + e.getMessage());
                return WrapMapper.error();
            }
        }
        return WrapMapper.error();
    }

    public int checkAccountAndCsId(Staff staff){
        int temp = 0;
        //乐视账号(域账号)是唯一的，验证该账号是否已经存在
        if(staff.getLeAccount()!=null && !"".equals(staff.getLeAccount())){
            Staff s = staffService.getStaffByLeAccount(staff.getLeAccount());
            if(s!=null && !Objects.equals(s.getId(), staff.getId())){
                temp = -1;
            }
//            User tempUser = userService.getUserByUsername(staff.getLeAccount());//该域账号已经被同步过
//            if(tempUser!=null && tempUser.getStaffId()!=null && !Objects.equals(s.getId(), staff.getId())){
//                temp = -1;
//            }
            //验证该域账号是否有效
            Map<String,Object> map = ssoService.queryUser(staff.getLeAccount());
            if(map==null){
                temp = -2;
            }
        }
        //客服工号是唯一的，验证该客服工号是否已经存在
        if(staff.getCsId()!=null && !"".equals(staff.getCsId())){
            Staff s = staffService.getStaffByCsId(staff.getCsId());
            if(s!=null && !Objects.equals(s.getId(), staff.getId())){
                temp = -3;
            }
        }
        return temp;

    }


    // 读取单元格的数据,把一行行的数据保存到list中，用map来过滤重复身份证的数据
    public static List<Staff> readExcelFile(String fileName) {
        // 创建对Excel工作薄文件的引用

        List<Staff> list = new ArrayList<Staff>();

        Workbook wb = null;
        FileInputStream in = null;
        try {
            in = new FileInputStream(fileName);
            if (fileName.endsWith(".xls")) {
                // Excel2003
                wb = new HSSFWorkbook(in);
            } else {
                // Excel 2007
                wb = new XSSFWorkbook(in);
            }

            // 创建对工作表的引用
            Sheet sheet = wb.getSheetAt(0);
            // 遍历所有单元格，读取单元格
            int row_num = sheet.getLastRowNum();
            // 项目名称
            for (int i = 1; i <= row_num; i++) {
                Row row = sheet.getRow(i);
                if (row == null)
                    continue;
//                name", "depName", "createUser", "work Num"
                String instanceId = readValue(row.getCell(0));
                String staffId = readValue(row.getCell(1));
                String nameSpell=readValue(row.getCell(3));//姓名拼音
                String csId = readValue(row.getCell(6));
                String leAccount = readValue(row.getCell(7));
                //CC系统从数组ID
                String ccRoleGroupId = readValue(row.getCell(8));
                //CC系统从数组名称
                String ccRoleGroupName = readValue(row.getCell(9));
                if(instanceId != null && staffId != null) {
                    //查找staff
                    Staff staff = new Staff();
                    staff.setId(Long.valueOf(staffId));
                    staff.setCsId(csId);
                    staff.setLeAccount(leAccount);
                    staff.setInstanceId(Integer.valueOf(instanceId));
                    staff.setNameSpell(nameSpell);//姓名拼音
                    staff.setCcRoleGroupId(ccRoleGroupId);
                    staff.setCcRoleGroupName(ccRoleGroupName);
                    list.add(staff);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            try {
                wb.close();
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        return list;
    }

    public static String readValue(Cell cell) {
        String value = "";
        if (cell == null) {
            return null;
        }
        int rowType = cell.getCellType();
        if (rowType == Cell.CELL_TYPE_STRING) {
            value = cell.getStringCellValue();
        } else if (rowType == Cell.CELL_TYPE_NUMERIC) {
                DecimalFormat df = new DecimalFormat("0");
                Number v = cell.getNumericCellValue();
                value = df.format(v);
        }
        return value;
    }

    /**
     * 我的代办-离职流程-关闭工号页面中，导出待关闭的工号
     * @param
     * @return
     */
    @RequestMapping("exportCloseNo")
    public void exportCloseNo(HttpServletRequest request,HttpServletResponse response){
    	try {
//    		String item = WebUtils.findParameterValue(request, "param");
    		String item = request.getParameter("exportJsonStr");
            List<Staff> list = JsonUtil.fromJsonList(item, Staff.class);
            LOG.info(JsonHelper.toJson(list));
            //文件名 ，文件类型
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fileName = "待关闭工号"+sdf.format(new Date())+".xls";
            response.setContentType("application/x-excel");
            response.setCharacterEncoding("UTF-8");
            response.addHeader("Content-Disposition", "attachment;filename="
                    + new String(fileName.getBytes(), "iso-8859-1"));// excel文件名
            String[] headers = new String[]{"姓名", "工号", "域账号" , "部门"};
            String title = "待关闭工号"+sdf.format(new Date())+".xls";

            exportCloseNoExcel(title, list, response.getOutputStream(), headers);
		} catch (Exception e) {
		}
    }
    
    //导出待关闭工号的excel列表
    private void exportCloseNoExcel(String title, List<Staff> list,
			ServletOutputStream out, String[] headers) {
    	//声明一个工作簿
        HSSFWorkbook workbook = new HSSFWorkbook();
        //生成一个表格
        HSSFSheet sheet = workbook.createSheet(title);
        //设置表格默认列宽度为15个字符
        sheet.setDefaultColumnWidth(20);
        //生成一个样式，用来设置标题样式
        HSSFCellStyle style = workbook.createCellStyle();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        //产生表格标题行
        HSSFRow row = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            HSSFCell cell = row.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(style);
        }
        for (int i = 0; i < list.size(); i++) {
            Staff staff = list.get(i);
            row = sheet.createRow(i + 1);
            // 第四步，创建单元格，并设置值
            HSSFCell cell1 = row.createCell(0);
            cell1.setCellValue(staff.getName());
            cell1.setCellStyle(style);
            HSSFCell cell2 = row.createCell(1);
            cell2.setCellValue(staff.getCsId());
            cell2.setCellStyle(style);
            HSSFCell cell3 = row.createCell(2);
            cell3.setCellValue(staff.getLeAccount());
            cell3.setCellStyle(style);
            HSSFCell cell4 = row.createCell(3);
            cell4.setCellValue(staff.getDep().getName());
            cell4.setCellStyle(style);
        }
        try {
            workbook.write(out);
            out.flush();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
    
}
