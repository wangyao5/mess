package com.letv.css.portal.controller;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.service.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 员工请假类
 */
@Controller
@RequestMapping("leave")
public class LeaveController extends BaseController{
	
	private static final Log LOG = LogFactory.getLog(LeaveController.class);
	
	@Autowired
	private LeaveService leaveService;
	@Autowired
	private StaffService staffService;

	/**
	 * 员工请假接口
	 * @param leave
	 * @return
	 */
	@RequestMapping(value = "addLeave",method=RequestMethod.POST)
	@ResponseBody
	public Wrapper<?> addLeave(Leave leave) {
		try {
			// 判断员工ID是否合法
			Long staffId = leave.getStaffId();
			Staff staff = staffService.getStaffById( staffId );
			if ( staff == null ) {
				return WrapMapper.wrap(500, "员工信息错误");
			}

			// 判断请假日期是否与历史数据重复
			List<Leave> repeatedLeaveList = leaveService.queryRepeatedLeave( staffId, leave.getLeaveStartTime(), leave.getLeaveEndTime() );
			if ( repeatedLeaveList.size() > 0 ) {
				return WrapMapper.wrap(500, "请假时间段内已有请假记录");
			}

			// 插入请假数据
			leave.setCreateUser( getLoginUserId().toString() );
			leave.setStatus(0);
			if ( leaveService.addLeave(leave) ) {
				return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "提交请假申请成功！");
			} else {
				return WrapMapper.wrap(Wrapper.ERROR_CODE, "提交请假申请失败！");
			}
		} catch (Exception e) {
			LOG.error("user addLeave has error.", e);
			return WrapMapper.error();
		}
	}

    
}
