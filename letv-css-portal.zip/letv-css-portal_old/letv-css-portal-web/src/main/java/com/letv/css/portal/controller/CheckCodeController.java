package com.letv.css.portal.controller;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.letv.common.utils.code.CheckCodeUtils;
import com.letv.css.portal.util.web.PortalWeb;

/**
 * 验证码 控制器
 * 
 * @author lijianzhong
 * @version 2015-01-23 下午1:54:30
 */
@Controller
@RequestMapping("/checkCode")
public class CheckCodeController {

	@Autowired
	private PortalWeb portalWeb;

	private static final Log LOG = LogFactory.getLog(CheckCodeController.class);

	/**
	 * 生成校验码图片
	 * 
	 * @param response
	 *            HttpServletResponse
	 */
	@RequestMapping("createImage")
	public void createImage(HttpServletResponse response) {
		try {
			CheckCodeUtils.createImage(response, portalWeb.getCookieDomain());
		} catch (Exception e) {
			LOG.warn("createImage has error,", e);
		}
	}

}
