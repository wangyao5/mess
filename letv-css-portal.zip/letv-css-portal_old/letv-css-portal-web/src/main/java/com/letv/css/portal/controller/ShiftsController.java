package com.letv.css.portal.controller;

import com.letv.common.utils.exception.ExistedException;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.query.*;
import com.letv.css.portal.service.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 客服组织架构
 *
 * @Author yxh
 * @Version 2017-5-15 11:50
 */
@Controller
@RequestMapping("shifts")
public class ShiftsController extends CommonController {

    private static final Log LOG = LogFactory.getLog(ShiftsController.class);
    @Autowired
    private UserService userService;
    @Autowired
    private MenuService menuService;

    @Autowired
    private ShiftsService shiftsService;

    @Autowired
    private ShiftsPeriodService shiftsPeriodService;

    @Autowired
    private DicService dicService;

    /**
     * 视图前缀
     */
    private static final String VIEW_PREFIX = "shifts";
    private static final String VIEW_INDEX = "index";
    private static final String VIEW_UPDATE = "update";
    private static final String VIEW_INDEX_PERIOD = "indexPeriod";
    private static final String VIEW_UPDATE_PERIOD = "updatePeriod";

    @RequestMapping("")
    public String welcome(Model model, PageUtil page, ShiftsQuery query) {
        return index(model, page, query);
    }

    @RequestMapping("index")
    public String index(Model model, PageUtil page, ShiftsQuery query) {
        try {
            List<Shifts> dataList = null;
            //数据权限控制
            User user = userService.getUserByUsername(getLoginUser().getUserName());

            dataList = shiftsService.queryShiftsListWithPage(query, page);
            List<Shifts> shiftsList = shiftsService.queryOptionShiftsList(query);//用于展示班次类型的下拉列表，不合理，需要查询数据库中的全部数据
            model.addAttribute("shiftsList", shiftsList);// 分页

            model.addAttribute("dataList", dataList);
            model.addAttribute("query", query);//查询条件
            model.addAttribute("page", page);// 分页

            addEnumToModel(model);
            addButtonPortals(model, user);//添加按钮权限控制
        } catch (Exception e) {
            LOG.error("ShiftsController index has error.", e);
        }
        return VIEW_PREFIX + "/" + VIEW_INDEX;
    }

    /**
     * 禁用本班次
     */
    @RequestMapping(value = "disable")
    @ResponseBody
    public Wrapper<?> disable(Shifts shifts) {
        LOG.info("shifts disable 入参：" + JsonHelper.toJson(shifts));
        try {
            shifts.setUpdateUser(getLoginUserCnName());
            shifts.setUpdateTime(new Date());
            shifts.setStatus(2);//设为禁用状态
            if (shiftsService.update(shifts)) {
                LOG.info("shifts disable 出参：" + Wrapper.SUCCESS_CODE + "，禁用成功！");
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "禁用成功！");
            } else {
                LOG.info("shifts disable 出参：" + Wrapper.ERROR_CODE + "，禁用失败！");
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "禁用失败！");
            }
        } catch (Exception e) {
            LOG.error("shifts disable has error.", e);
            return WrapMapper.error();
        }
    }

    /**
     * 班次----修改跳转
     *
     * @param model
     * @param shifts
     * @return
     */
    @RequestMapping(value = "updateForward")
    public String updateForward(Model model, Shifts shifts) {
        try {
            Shifts shiftsResult = shiftsService.getShiftsById(shifts.getId());
            //用于校验参数
            List<Shifts> shiftsList = shiftsService.queryShiftsList(new ShiftsQuery());
            model.addAttribute("shiftsList", shiftsList);
            model.addAttribute("shifts", shiftsResult);
            addEnumToModel(model);
        } catch (Exception e) {
            LOG.error("shifts updateForward has error.", e);
        }
        return VIEW_PREFIX + "/" + VIEW_UPDATE;
    }

    /**
     * 班段----修改跳转
     *
     * @param model
     * @param shiftsPeriod
     * @return
     */
    @RequestMapping(value = "updatePeriodForward")
    public String updatePeriodForward(Model model, ShiftsPeriod shiftsPeriod) {
        try {
            shiftsPeriod = shiftsPeriodService.getShiftsPeriodById(shiftsPeriod.getId());
            ShiftsPeriodQuery shiftsPeriodQuery = new ShiftsPeriodQuery();
            shiftsPeriodQuery.setShiftsId(shiftsPeriod.getShiftsId());
            //查询班次对应的班段，用于校验数据
            List<ShiftsPeriod> periodList = shiftsPeriodService.queryShiftsPeriodList(shiftsPeriodQuery);
            model.addAttribute("periodList", periodList);
            model.addAttribute("shiftsPeriod", shiftsPeriod);
            addEnumToModel(model);
        } catch (Exception e) {
            LOG.error("shifts updatePeriodForward has error.", e);
        }
        return VIEW_PREFIX + "/" + VIEW_UPDATE_PERIOD;
    }

    /**
     * 班段----展示班段信息
     *
     * @param model
     * @param shifts
     * @return
     */
    @RequestMapping(value = "indexPeriod")
    public String indexPeriod(Model model, Shifts shifts) {
        try {
            //数据权限控制
            User user = userService.getUserByUsername(getLoginUser().getUserName());

            Shifts shiftsResult = shiftsService.getShiftsById(shifts.getId());
            ShiftsPeriodQuery shiftsPeriodQuery = new ShiftsPeriodQuery();
            shiftsPeriodQuery.setShiftsId(shifts.getId());
            //查询班次对应的班段
            List<ShiftsPeriod> periodList = shiftsPeriodService.queryShiftsPeriodList(shiftsPeriodQuery);
            model.addAttribute("periodList", periodList);
            model.addAttribute("shifts", shiftsResult);
            addEnumToModel(model);

            addButtonPortals(model, user);//添加按钮权限控制
        } catch (Exception e) {
            LOG.error("shifts indexPeriod has error.", e);
        }
        return VIEW_PREFIX + "/" + VIEW_INDEX_PERIOD;
    }

    /**
<<<<<<< HEAD
=======
     * F
>>>>>>> dev
     * 班次----禁用/启用
     *
     * @param idBoxs
     * @param status
     * @return
     */
    @RequestMapping(value = "updateStatus")
    @ResponseBody
    public Wrapper<?> updateStatus(@RequestParam("idBoxs") String idBoxs, @RequestParam("status") String status) {
        Boolean flag = false;
        try {
            logger.info("shifts updateStatus 入参idBoxs=" + idBoxs + ",status=" + status);
            flag = shiftsService.updateStatus(idBoxs, status, getLoginUserCnName());
            logger.info("shifts updateStatus 出参idBoxs=" + idBoxs + ",status=" + status + ",flag=" + flag);
        } catch (Exception e) {
            LOG.error("shifts batch updateStatus has error.", e);
            flag = false;
        }
        if (flag) {
            return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "更新成功！");
        } else {
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "更新失败！");
        }

    }

    /**
     * 班段----删除
     *
     * @param idBoxs
     * @param status
     * @return
     */
    @RequestMapping(value = "deletePeriod")
    @ResponseBody
    public Wrapper<?> deletePeriod(@RequestParam("idBoxs") String idBoxs, @RequestParam("status") String status) {
        Boolean flag = false;
        try {
            logger.info("shifts deletePeriod入参idBoxs=" + idBoxs + ",status=" + status);
            flag = shiftsPeriodService.updateStatus(idBoxs, status, getLoginUserCnName());
            logger.info("shifts deletePeriod出参idBoxs=" + idBoxs + ",status=" + status + ",flag=" + flag);
        } catch (Exception e) {
            LOG.error("shifts batch deletePeriod has error.", e);
            flag = false;
        }
        if (flag) {
            return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "更新成功！");
        } else {
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "更新失败！");
        }

    }

    /**
     * 班次表----更新
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "update", method = RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> update(Model model, Shifts shifts) {
        LOG.info("shifts update 入参：" + JsonHelper.toJson(shifts));
        try {
            shifts.setUpdateUser(getLoginUserCnName());
            shifts.setUpdateTime(new Date());
            if (shiftsService.update(shifts)) {
                LOG.info("shifts update 出参：" + Wrapper.SUCCESS_CODE + ",更新成功");
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "更新成功！");
            } else {
                LOG.info("shifts update 出参：" + Wrapper.ERROR_CODE + ",更新失败");
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "更新失败！");
            }
        } catch (Exception e) {
            LOG.error("Shifts update has error.", e);
            return WrapMapper.error();
        }
    }

    /**
     * 班段表----更新
     *
     * @param id,String shiftsId,String periodName, String beginTime,String endTime,String mealStandard,String isNextDay
     * @return
     */
    @RequestMapping(value = "updatePeriod", method = RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> updatePeriod(String id, String shiftsId, String periodName,
                                   String beginTime, String endTime, String mealStandard, String isNextDay) {
        try {
            LOG.info("shifts updatePeriod 更新班段,入参：id: " + id + ",shiftsId:" + shiftsId + ",periodName:" + periodName + ",beginTime" + beginTime
                    + ",endTime:" + endTime + ",mealStandard:" + mealStandard + ",isNextDay:" + isNextDay);
            if (StringUtils.isEmpty(isNextDay)) {
                isNextDay = "2";
            }
            ShiftsPeriod shiftsPeriod = getShiftsPeriod(id, shiftsId, periodName, beginTime, endTime, mealStandard, Integer.parseInt(isNextDay));
            shiftsPeriod.setUpdateUser(getLoginUserCnName());
            shiftsPeriod.setUpdateTime(new Date());
            if (shiftsPeriodService.update(shiftsPeriod)) {
                LOG.info("shifts updatePeriod 更新班段,入参：id: " + id + ",更新成功");
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "更新成功！");
            } else {
                LOG.info("shifts updatePeriod 更新班段,入参：id: " + id + ",更新失败");
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "更新失败！");
            }
        } catch (Exception e) {
            LOG.error("ShiftsPeriod updatePeriod has error.", e);
            return WrapMapper.error();
        }
    }

    private ShiftsPeriod getShiftsPeriod(String id, String shiftsId, String periodName, String beginTime, String endTime, String mealStandard, Integer isNextDay) throws ParseException {
        ShiftsPeriod shiftsPeriod = new ShiftsPeriod();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        shiftsPeriod.setId(Long.parseLong(id));
        shiftsPeriod.setShiftsId(Long.parseLong(shiftsId));
        shiftsPeriod.setPeriodName(periodName);
        shiftsPeriod.setBeginTime(new Time(sdf.parse(beginTime).getTime()));
        shiftsPeriod.setEndTime(new Time(sdf.parse(endTime).getTime()));
        shiftsPeriod.setMealStandard(Integer.parseInt(mealStandard));
        shiftsPeriod.setCreateUser(getLoginUserCnName());
        shiftsPeriod.setCreateTime(new Date());
        shiftsPeriod.setIsNextDay(isNextDay);
        return shiftsPeriod;
    }

    /**
     * 班次表----添加
     *
     * @return
     */
    @RequestMapping(value = "add", method = RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> add(Shifts shifts) {
        LOG.info("shifts add 入参：" + JsonHelper.toJson(shifts));
        try {
            shifts.setCreateUser(getLoginUserCnName());
            shifts.setCreateTime(new Date());
            shifts.setUpdateUser(getLoginUserCnName());
            shifts.setUpdateTime(new Date());
            if (shiftsService.insert(shifts)) {
                LOG.info("shifts add 出参：" + Wrapper.SUCCESS_CODE + ",id:" + shifts.getId());
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, shifts.getId() + "");
            } else {
                LOG.info("shifts add 出参：" + Wrapper.ERROR_CODE + ",id:" + shifts.getId() + ",添加失败");
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
            }
        } catch (ExistedException e) {
            LOG.warn("shifts add fail, exist shifts.");
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败，已经存在");
        } catch (Exception e) {
            LOG.error("shifts add has error.", e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
        }
    }

    /**
     * 班段----添加
     *
     * @return
     */
    @RequestMapping(value = "addPeriod", method = RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> addPeriod(String shiftsId, String periodName,
                                String beginTime, String endTime, String mealStandard, String isNextDay) {
        try {
            LOG.info("shifts addPeriod增加班段,入参：shiftsId:" + shiftsId + ",periodName:" + periodName + ",beginTime" + beginTime
                    + ",endTime:" + endTime + ",mealStandard:" + mealStandard + ",isNextDay:" + isNextDay);
            if (StringUtils.isEmpty(isNextDay)) {
                isNextDay = "2";
            }
            ShiftsPeriod shiftsPeriod = putShiftsPeriod(shiftsId, periodName, beginTime, endTime, mealStandard, Integer.parseInt(isNextDay));
            if (shiftsPeriodService.insert(shiftsPeriod)) {
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, shiftsPeriod.getId() + "");
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
            }
        } catch (ExistedException e) {
            LOG.warn("shifts addPeriod fail, exist ShiftsPeriod.");
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败，已经存在");
        } catch (Exception e) {
            LOG.error("shifts addPeriod has error.", e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
        }
    }

    /**
     * 根据参数拼装实体
     *
     * @param shiftsId
     * @param periodName
     * @param beginTime
     * @param endTime
     * @param mealStandard
     * @return
     * @throws ParseException
     */
    private ShiftsPeriod putShiftsPeriod(String shiftsId, String periodName, String beginTime, String endTime, String mealStandard, Integer isNextDay) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        ShiftsPeriod shiftsPeriod = new ShiftsPeriod();
        shiftsPeriod.setShiftsId(Long.parseLong(shiftsId));
        shiftsPeriod.setPeriodName(periodName);
        shiftsPeriod.setBeginTime(new Time(sdf.parse(beginTime).getTime()));
        shiftsPeriod.setEndTime(new Time(sdf.parse(endTime).getTime()));
        shiftsPeriod.setMealStandard(Integer.parseInt(mealStandard));
        shiftsPeriod.setCreateUser(getLoginUserCnName());
        shiftsPeriod.setCreateTime(new Date());
        shiftsPeriod.setIsNextDay(isNextDay);
        return shiftsPeriod;
    }

    /**
     * 根据班次名称查询班次实体
     *
     * @return
     */
    @RequestMapping(value = "queryByName", method = RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> queryByName(@RequestParam("shiftsName") String shiftsName) {
        try {
            logger.info("shifts queryByName入参：" + shiftsName);
            Shifts shifts = shiftsService.getShiftsByName(shiftsName);
            logger.info("shifts queryByName出参：" + shiftsName + JsonHelper.toJson(shifts));

            if (shifts != null && (shifts.getId() != null || !"".equals(shifts.getId()))) {
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, shifts.getId() + "");
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "查询失败！");
            }
        } catch (Exception e) {
            LOG.error("shifts queryByName has error.", e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "查询失败！");
        }
    }


    /**
     * 将枚举值加入到model
     *
     * @param
     * @return
     */
    private void addEnumToModel(Model model) {
        DicQuery query = new DicQuery();
        query.setParentName("班次类型");
        List<Dic> shiftsTypes = dicService.queryDicList(query);
        model.addAttribute("shiftsTypes", shiftsTypes);//班次类型
        query.setParentName("班次状态");
        List<Dic> statuses = dicService.queryDicList(query);
        model.addAttribute("statuses", statuses);//班次状态
        query.setParentName("班别");
        List<Dic> shiftsClasses = dicService.queryDicList(query);
        model.addAttribute("shiftsClasses", shiftsClasses);//班别
    }

    /**
     * 添加按钮级别的权限
     *
     * @param
     * @return
     */
    private void addButtonPortals(Model model, User user) {
        Set<String> set = new HashSet<String>();
        List<Resource> resources = menuService.queryButtonResources(user);
        for (Resource r : resources) {
            if (r.getParentId() != null) {
                set.add(r.getUrl());
            }
        }
        model.addAttribute("buttonPortals", set);
    }
}
