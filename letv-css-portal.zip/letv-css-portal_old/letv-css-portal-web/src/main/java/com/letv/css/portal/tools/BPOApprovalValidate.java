package com.letv.css.portal.tools;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.letv.css.portal.domain.SchedulingInfo;
import com.letv.css.portal.service.SchedulingInfoService;

/**
 * bpo审批流校验
 * @author menghan
 *
 */
public class BPOApprovalValidate {
	
	private static final Log LOG = LogFactory.getLog(BPOApprovalValidate.class);
	
	/**
     * 根据schedulingInfo id，校验b_scheduling_info表中是否存在该记录
     * @param siIds
     */
    public static boolean validateSchedulingInfoIsExist(String siIds,SchedulingInfoService schedulingInfoService) {
    	if(siIds == null || "".equals(siIds)){
    		return false;
    	}
    	try {
    		String[] siId = siIds.split(",");
        	for(String id:siId){
        		SchedulingInfo info = schedulingInfoService.getSchedulingInfoById(Long.parseLong(id));
        		if(info==null) {
					return false;
				}
        	}
		} catch (Exception e) {
			LOG.error("延迟下班审批参数异常siIds："+siIds,e);
			return false;
		}
    	return true;
	}
	
}
