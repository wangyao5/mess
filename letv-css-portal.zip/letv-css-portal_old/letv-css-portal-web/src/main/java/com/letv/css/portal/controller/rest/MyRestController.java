package com.letv.css.portal.controller.rest;

import com.letv.css.portal.domain.vo.*;
import com.letv.css.web.common.response.ResponseWrapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/my")
public class MyRestController {
    /**
     * 读取当前用户信息
     *
     * @return
     */
    @RequestMapping("userinfo")
    public ResponseWrapper<UserInfo> userinfo() {
        //todo
        return null;
    }


    /**
     * 查询当前用户的通知和待办流程数量
     *
     * @return
     */
    @RequestMapping("menutip")
    public ResponseWrapper<Map<String, Integer>> menuTip() {
        //todo
//        HashMap<String, Integer> map = new HashMap<String, Integer>();
//        map.put("notice", 123);
//        map.put("workflow", 4);
        return null;
    }

    /**
     * 读取当前用户排班信息
     *
     * @return
     */
    @RequestMapping("schedule")
    public ResponseWrapper<ScheduleInfo[]> schedule() {
        //todo
        return null;
    }

    /**
     * 读取当前用户头像
     *
     * @return
     */
    @RequestMapping("photo")
    public ResponseWrapper<String> photo() {
        //todo
        return null;
    }

    /**
     * 读取当前用户的已排班周期，按总班表
     *
     * @return
     */
    @RequestMapping("scheduleplan")
    public ResponseWrapper<ScheduleSegment> schedulePlan() {
        //todo
        return null;
    }

    /**
     * 读取当前用户的已排班周期内换班次数，按总班表
     *
     * @return
     */
    @RequestMapping("swapTimes")
    public ResponseWrapper<ScheduleSwapTimes> swapTimes() {
        //todo
        return null;
    }

    /**
     * 获取系统通知列表
     *
     * @return
     */
    @RequestMapping("notices")
    public ResponseWrapper<SystemNotice[]> notices(
            @RequestParam int pageSize,
            @RequestParam int startIndex,
            @RequestParam String orderBy) {
        //todo
        return null;
    }
}
