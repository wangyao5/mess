package com.letv.css.portal.controller;


import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.css.portal.domain.MenuLogs;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.service.MenuLogsService;
import com.letv.css.portal.service.UserService;
import com.letv.css.web.common.utils.JsonResult;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-05-17 18:47:09
 */
@Controller
@RequestMapping("menuLogs")
public class MenuLogsController extends BaseController{

	private static final Log LOG = LogFactory.getLog(MenuLogsController.class);
	
	@Autowired
	private MenuLogsService menuLogsService;
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "addLog", method = RequestMethod.POST)
    @ResponseBody
	public JsonResult addRecord(MenuLogs menulogs){
		User user = userService.getUserByUsername(getLoginUser().getUserName());
		String str = menulogs.getMenuUrl();
		if(StringUtils.isNotBlank(str) && str.indexOf("?")>-1){
			str = str.substring(0, str.indexOf("?"));
		}
		menulogs.setMenuUrl(str);
		menulogs.setUserId(user.getId());
		menulogs.setUserName(user.getName());
		
		LOG.info("menuLogs->addLog->入参："+JsonHelper.toJson(menulogs));
		
		boolean result = menuLogsService.addLog(menulogs);
		
		LOG.info("menuLogs->addLog->出参："+result+","+JsonHelper.toJson(menulogs));
		
		if(result){
			return new JsonResult(result);
		}else{
			return new JsonResult(JsonResult.CODE_SERVER_ERROR, JsonResult.MESSAGE_SERVER_ERROR, result);
		}
	}
	
}
