package com.letv.css.portal.controller;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.letv.css.portal.domain.query.*;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.formula.functions.Even;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letv.common.utils.DateHelper;
import com.letv.common.utils.StringUtil;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.ApprovalManage;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.JsonData;
import com.letv.css.portal.domain.SchedulingInfo;
import com.letv.css.portal.domain.Shifts;
import com.letv.css.portal.domain.ShiftsPeriod;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.service.ApprovalManageService;
import com.letv.css.portal.service.CommonQueueService;
import com.letv.css.portal.service.DepService;
import com.letv.css.portal.service.DicService;
import com.letv.css.portal.service.JsonDataService;
import com.letv.css.portal.service.SchedulingInfoService;
import com.letv.css.portal.service.ShiftsPeriodService;
import com.letv.css.portal.service.ShiftsService;
import com.letv.css.portal.service.StaffService;
import com.letv.css.portal.service.UserDepService;
import com.letv.css.portal.service.UserService;

/**
 * BPO申请管理
 *
 * @Author menghan
 * @Version 2017-06-02 11:01:00
 */
@Controller
@RequestMapping("bpoApply")
public class BPOApplyController extends CommonController {

    private final static Log LOG = LogFactory.getLog(BPOApplyController.class);

    @Autowired
    private DepService depService;
    @Autowired
    private UserService userService;
    @Autowired
    private UserDepService userDepService;
    @Autowired
    private SchedulingInfoService schedulingInfoService;
    @Autowired
    private DicService dicService;
    @Autowired
    private ShiftsService shiftsService;
    @Autowired
    private ShiftsPeriodService shiftsPeriodService;
    @Autowired
    private JsonDataService jsonDataService;
    @Autowired
    private CommonQueueService commonQueueService;
    @Autowired
    private ApprovalManageService approvalManageService;
    @Autowired
    private StaffService staffService;

    /**
     * 视图前缀
     */
    private static final String VIEW_PREFIX = "bopApply";

    @RequestMapping(value = "")
    public String welcom(Model model, PageUtil page, SchedulingInfoQuery query) {
        return index(model, page, query);
    }

    @RequestMapping(value = "index")
    public String index(Model model, PageUtil page, SchedulingInfoQuery query) {
        //数据权限控制
        User user = userService.getUserByUsername(getLoginUser().getUserName());
        String allowDepIds = getDepIds(user.getId());
        if (allowDepIds == null || "".equals(allowDepIds)) {
            query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
        } else {
            query.setDepIds(allowDepIds);
        }
        //默认查询当天日期的数据
        if (StringUtils.isEmpty(query.getPlanDate())) {
            query.setPlanDate(DateHelper.format(new Date(), "yyyy-MM-dd"));
        }
        page.setPageSize(100);
        //查询条件是否含有班次信息
        if (query.getShiftsName() != null && !"".equals(query.getShiftsName())) {
            query.setShiftsId(getShiftsId(query.getShiftsName()));
        }
        List<SchedulingInfo> dataList = schedulingInfoService.querySchedulingInfoListWithPage(query, page);
        model.addAttribute("dataList", dataList);
        model.addAttribute("query", query);
        model.addAttribute("page", page);
        addDepListToModel(model, allowDepIds);//部门
        addBusinessToModel(model);//业务线
        return VIEW_PREFIX + "/" + "index";
    }

    /**
     * 新增支援调整
     *
     * @param
     * @return
     */
    @RequestMapping("support")
    public String support(Model model, String str) {
        List<SchedulingInfo> dataList = null;
        if (StringUtils.isNotEmpty(str)) {
            SchedulingInfoQuery queryBean = new SchedulingInfoQuery();
            queryBean.setIds(str);
            dataList = schedulingInfoService.querySchedulingInfoList(queryBean);
        }
        model.addAttribute("dataList", dataList);
        addBusinessToModel(model);
        return VIEW_PREFIX + "/" + "support";
    }

    /**
     * 提交支援调整审批
     *
     * @param
     * @return
     */
    @RequestMapping("addSupport")
    @ResponseBody
    public Wrapper<?> addSupport(String siIds, String busName, String supportStartTime, String supportEndTime, String supportReason) {
        try {
            //校验调整时间是否冲突
            if (!validateAdjustTime(siIds, busName, supportStartTime, supportEndTime)) {
                return WrapMapper.wrap(1100, "支援审批提交失败，调整时间存在重叠或者冲突！");
            }
            if (!validIsHavaFinishedFlow(siIds, 1)) {
                return WrapMapper.wrap(1200, "支援审批提交失败，已有任务在处理中！");
            }
            String[] siIdAttr = siIds.split(",");
            JsonData jsonData = new JsonData();
            jsonData.setType(1);
            Map<String, String> map = new HashMap<String, String>();
            map.put("busName", busName);
            map.put("supportStartTime", supportStartTime);
            map.put("supportEndTime", supportEndTime);
            map.put("supportReason", supportReason);
            map.put("num", siIdAttr.length + "");
            String data = JsonHelper.toJson(map);
            jsonData.setJsonData(data);
            jsonData.setCreateUser(getLoginUserName());
            LOG.info("入参：" + JsonHelper.toJson(jsonData));
            if (jsonDataService.insert(jsonData)) {
                CommonQueue queue = new CommonQueue();
                queue.setOnlyId(jsonData.getId());
                queue.setOnlyType("jsonData id");
                queue.setEventId(EventConstants.EVENT_SUPPORT);
                queue.setRequestRemake("支援审批申请");
                queue.setCreatedBy(String.valueOf(getLoginUserId()));
                commonQueueService.insert(queue);

                List<ApprovalManage> approvalManages = new ArrayList<ApprovalManage>();
                for (String siId : siIdAttr) {
                    ApprovalManage manage = new ApprovalManage();
                    manage.setSiId(Long.parseLong(siId));
                    manage.setJdId(jsonData.getId());
                    manage.setType(1);
                    manage.setConfirm(0);
                    manage.setCreateUser(getLoginUserName());
                    approvalManages.add(manage);
                }
                approvalManageService.inserts(approvalManages);
            }
        } catch (Exception e) {
            LOG.error("添加支援审批信息失败！" + e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "支援审批提交失败！");
        }
        return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "支援审批提交成功！");
    }

    /**
     * 新增用餐上报
     *
     * @param
     * @return
     */
    @RequestMapping("mealStandard")
    public String meal(Model model, String str) {
        List<SchedulingInfo> dataList = null;
        if (StringUtils.isNotEmpty(str)) {
            SchedulingInfoQuery queryBean = new SchedulingInfoQuery();
            queryBean.setIds(str);
            dataList = schedulingInfoService.querySchedulingInfoList(queryBean);
        }
        model.addAttribute("dataList", dataList);
        return VIEW_PREFIX + "/" + "mealStandard";
    }

    /**
     * 提交餐时审批
     *
     * @param
     * @return
     */
    @RequestMapping("addMealStandard")
    @ResponseBody
    public Wrapper<?> addMealStandard(String siIds, String adjustDate, String dinnerTime, String reportingReason) {
        try {
            if (!validateMealTime(siIds, dinnerTime)) {
                return WrapMapper.wrap(3100, "餐时审批提交失败，餐时时间过长！");
            }
            if (!validIsHavaFinishedFlow(siIds, 3)) {
                return WrapMapper.wrap(3200, "餐时审批提交失败，已有任务在处理中！");
            }

            String[] siIdAttr = siIds.split(",");
            JsonData jsonData = new JsonData();
            jsonData.setType(3);
            Map<String, String> map = new HashMap<String, String>();
            map.put("adjustDate", adjustDate);
            map.put("mealTime", dinnerTime);
            map.put("adjustReason", reportingReason);
            map.put("num", siIdAttr.length + "");
            String data = JsonHelper.toJson(map);
            jsonData.setJsonData(data);
            jsonData.setCreateUser(getLoginUserName());
            LOG.info("入参：" + JsonHelper.toJson(jsonData));
            if (jsonDataService.insert(jsonData)) {
                CommonQueue queue = new CommonQueue();
                queue.setOnlyId(jsonData.getId());
                queue.setOnlyType("jsonData id");
                queue.setEventId(EventConstants.EVENT_MEAL);
                queue.setRequestRemake("新增用餐上报");
                queue.setCreatedBy(String.valueOf(getLoginUserId()));
                commonQueueService.insert(queue);

                List<ApprovalManage> approvalManages = new ArrayList<ApprovalManage>();
                for (String siId : siIdAttr) {
                    ApprovalManage manage = new ApprovalManage();
                    manage.setSiId(Long.parseLong(siId));
                    manage.setJdId(jsonData.getId());
                    manage.setType(3);
                    manage.setConfirm(0);
                    manage.setCreateUser(getLoginUserName());
                    approvalManages.add(manage);
                }
                approvalManageService.inserts(approvalManages);
            }
        } catch (Exception e) {
            LOG.error("添加用餐上报审批信息失败！" + e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "餐时上报审批提交失败！");
        }
        return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "餐时上报审批提交成功！");
    }

    /**
     * 换班
     *
     * @param
     * @return
     */
    @RequestMapping("shift")
    public String shift(Model model, String str) {
        List<SchedulingInfo> dataList = null;
        if (StringUtils.isNotEmpty(str)) {
            SchedulingInfoQuery queryBean = new SchedulingInfoQuery();
            queryBean.setIds(str);
            dataList = schedulingInfoService.querySchedulingInfoList(queryBean);
        }
        User user = userService.getUserByUsername(getLoginUser().getUserName());
        String allowDepIds = getDepIds(user.getId());
        model.addAttribute("dataList", dataList);
        addDepListToModel(model, allowDepIds);//职场
        addShitfsToModel(model);//班次
        return VIEW_PREFIX + "/" + "shift";
    }

    /**
     * 提交换班审批
     *
     * @param
     * @return
     */
    @RequestMapping("addShift")
    @ResponseBody
    public Wrapper<?> addShift(String siIds, String depId, String shiftPeople, String shiftDate, String shifts, String shiftsPeriod, String shiftReason) {
        try {
        	if(!validateShift(siIds,depId,shiftPeople,shiftDate,shifts,shiftsPeriod)){
        		return WrapMapper.wrap(5200,"换班人与被换班人在换班后，上班时间出现冲突！");
        	}
        	
            String[] siIdAttr = siIds.split(",");
            String[] periodAndShiftSiId = shiftsPeriod.split(",");
            String valsiIds = siIds + "," + periodAndShiftSiId[1];
            if (!validIsHavaFinishedFlow(valsiIds, 5)) {
                return WrapMapper.wrap(5100, "支援审批提交失败，已有任务在处理中！");
            }
            JsonData jsonData = new JsonData();
            jsonData.setType(5);
            Map<String, String> map = new HashMap<String, String>();
            map.put("depId", depId);
            map.put("shiftBy", shiftPeople);
            map.put("shiftDate", shiftDate);
            map.put("shifts", shifts);
            map.put("shiftsPeriod", periodAndShiftSiId[0]);
            map.put("shiftSiId", periodAndShiftSiId[1]);
            map.put("shiftReason", shiftReason);
            map.put("num", siIdAttr.length + "");
            String data = JsonHelper.toJson(map);
            jsonData.setJsonData(data);
            jsonData.setCreateUser(getLoginUserName());
            LOG.info("入参：" + JsonHelper.toJson(jsonData));
            if (jsonDataService.insert(jsonData)) {
                CommonQueue queue = new CommonQueue();
                queue.setOnlyId(jsonData.getId());
                queue.setOnlyType("jsonData id");
                queue.setEventId(EventConstants.EVENT_SHIFT);
                queue.setRequestRemake("换班");
                queue.setCreatedBy(String.valueOf(getLoginUserId()));
                commonQueueService.insert(queue);


                List<ApprovalManage> approvalManages = new ArrayList<ApprovalManage>();
                for (String siId : siIdAttr) {
                    ApprovalManage manage = new ApprovalManage();
                    manage.setSiId(Long.parseLong(siId));
                    manage.setJdId(jsonData.getId());
                    manage.setType(5);
                    manage.setConfirm(0);
                    manage.setCreateUser(getLoginUserName());
                    approvalManages.add(manage);
                }
                approvalManageService.inserts(approvalManages);
            }
        } catch (Exception e) {
            LOG.error("新增换班审批信息失败！" + e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "换班审批提交失败！");
        }
        return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "换班审批提交成功！");
    }

	/**
     * 班次班段select联动
     *
     * @param
     * @return
     */
    @RequestMapping("getShiftsPeriod")
    @ResponseBody
    public Wrapper<?> getShiftsPeriod(ShiftsPeriodQuery query) {
        List<ShiftsPeriod> periods = null;
        try {
            periods = shiftsPeriodService.queryShiftsPeriodList(query);
            return new Wrapper<List<ShiftsPeriod>>().result(periods);
        } catch (Exception e) {
            return WrapMapper.error();
        }
    }

    /**
     * 部门、换班人员select联动
     *
     * @param
     * @return
     */
    @RequestMapping("getShiftPerson")
    @ResponseBody
    public Wrapper<?> getShiftPerson(StaffQuery query) {
        List<Staff> staffs = null;
        try {
            staffs = staffService.queryStaffList(query);
            return new Wrapper<List<Staff>>().result(staffs);
        } catch (Exception e) {
            return WrapMapper.error();
        }
    }

    /**
     * 部门、换班人员、排班日期 select联动
     *
     * @param
     * @return
     */
    @RequestMapping("getSchedulingInfo")
    @ResponseBody
    public Wrapper<?> getSchedulingInfo(SchedulingInfoQuery query) {
        List<SchedulingInfo> schedulingInfos = null;
        try {
            schedulingInfos = schedulingInfoService.querySchedulingInfoList(query);
            return new Wrapper<List<SchedulingInfo>>().result(schedulingInfos);
        } catch (Exception e) {
            return WrapMapper.error();
        }
    }

    /**
     * 班次调整
     *
     * @param
     * @return
     */
    @RequestMapping("adjust")
    public String adjust(Model model, String str) {
        List<SchedulingInfo> dataList = null;
        if (StringUtils.isNotEmpty(str)) {
            SchedulingInfoQuery queryBean = new SchedulingInfoQuery();
            queryBean.setIds(str);
            dataList = schedulingInfoService.querySchedulingInfoList(queryBean);
        }
        model.addAttribute("dataList", dataList);
        return VIEW_PREFIX + "/" + "adjust";
    }

    /**
     * 提交班次调整审批
     *
     * @param
     * @return
     */
    @RequestMapping("addAdjust")
    @ResponseBody
    public Wrapper<?> addAdjust(String siIds, String adjustType, String adjustTime, String adjustReason) {
        try {
            //校验调整后的班次是否出现跨天的情况
            if (!adjustValidate(siIds, adjustType, adjustTime)) {
                return WrapMapper.wrap(2100, "班次调整提交失败，调整后的时间出现跨天的情况或者调整后的开始时间大于了结束时间！");
            }
            if (!validIsHavaFinishedFlow(siIds, 2)) {
                return WrapMapper.wrap(2200, "班次调整提交失败，已有任务在处理中！");
            }
            String[] siIdAttr = siIds.split(",");
            JsonData jsonData = new JsonData();
            jsonData.setType(2);
            Map<String, String> map = new HashMap<String, String>();
            map.put("adjustType", adjustType);
            map.put("adjustTime", adjustTime);
            map.put("adjustReason", adjustReason);
            map.put("num", siIdAttr.length + "");
            String data = JsonHelper.toJson(map);
            jsonData.setJsonData(data);
            jsonData.setCreateUser(getLoginUserName());
            LOG.info("入参：" + JsonHelper.toJson(jsonData));
            if (jsonDataService.insert(jsonData)) {
                CommonQueue queue = new CommonQueue();
                queue.setOnlyId(jsonData.getId());
                queue.setOnlyType("jsonData id");
                queue.setEventId(EventConstants.EVENT_ADJSUT);
                queue.setRequestRemake("班次调整审批申请");
                queue.setCreatedBy(String.valueOf(getLoginUserId()));
                commonQueueService.insert(queue);

                List<ApprovalManage> approvalManages = new ArrayList<>();
                for (String siId : siIdAttr) {
                    ApprovalManage manage = new ApprovalManage();
                    manage.setSiId(Long.parseLong(siId));
                    manage.setJdId(jsonData.getId());
                    manage.setType(2);
                    manage.setConfirm(0);
                    manage.setCreateUser(getLoginUserName());
                    approvalManages.add(manage);
                }
                approvalManageService.inserts(approvalManages);
            }
        } catch (Exception e) {
            LOG.error("添加班次调整审批信息失败！" + e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "班次调整审批提交失败！");
        }
        return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "班次调整审批提交成功！");
    }

    /**
     * 加班
     *
     * @param
     * @return
     */
    @RequestMapping("overtime")
    public String overtime(Model model) {
        //数据权限控制
        User user = userService.getUserByUsername(getLoginUser().getUserName());
        String allowDepIds = getDepIds(user.getId());
        addDepListToModel(model, allowDepIds);//职场
        addBusinessToModel(model);//业务线
        addShitfsToModel(model);//班次
        return VIEW_PREFIX + "/" + "overtime";
    }

    /**
     * 提交加班审批
     *
     * @param
     * @return
     */
    @RequestMapping("addOvertime")
    @ResponseBody
    public Wrapper<?> addOvertime(String depId, String business, String shifts, String shiftsPeriod, String num, String overtimeReason) {
        try {
            JsonData jsonData = new JsonData();
            jsonData.setType(4);
            Map<String, String> map = new HashMap<String, String>();
            map.put("depId", depId);
            map.put("business", business);
            map.put("shifts", shifts);
            map.put("shiftsPeriod", shiftsPeriod);
            map.put("adjustTime", DateHelper.now());
            map.put("num", num);
            map.put("overtimeReason", overtimeReason);
            String data = JsonHelper.toJson(map);
            jsonData.setJsonData(data);
            jsonData.setCreateUser(getLoginUserName());
            LOG.info("入参：" + JsonHelper.toJson(jsonData));
            if (jsonDataService.insert(jsonData)) {
                CommonQueue queue = new CommonQueue();
                queue.setOnlyId(jsonData.getId());
                queue.setOnlyType("jsonData id");
                queue.setEventId(EventConstants.EVENT_OVERTIME);
                queue.setRequestRemake("加班审批申请");
                queue.setCreatedBy(String.valueOf(getLoginUserId()));
                commonQueueService.insert(queue);
            }
        } catch (Exception e) {
            LOG.error("添加加班审批信息失败！" + e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "加班审批提交失败！");
        }
        return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "加班审批提交成功！");
    }

    /**
     * 职场、业务线select联动
     *
     * @param
     * @return
     */
    @RequestMapping("getBusiness")
    @ResponseBody
    public Wrapper<?> getBusiness(Long depId) {
        try {
            //业务线
            List<Dic> list = getService(depId);
            return new Wrapper<List<Dic>>().result(list);
        } catch (Exception e) {
            return WrapMapper.error();
        }
    }

    /**
     * 请假
     *
     * @param
     * @return
     */
    @RequestMapping("leave")
    public String leave(Model model, String str) {
        List<SchedulingInfo> dataList = null;
        if (StringUtils.isNotEmpty(str)) {
            SchedulingInfoQuery queryBean = new SchedulingInfoQuery();
            queryBean.setIds(str);
            dataList = schedulingInfoService.querySchedulingInfoList(queryBean);
        }
        model.addAttribute("dataList", dataList);
        return VIEW_PREFIX + "/" + "leave";
    }

    /**
     * 提交请假审批
     *
     * @param
     * @return
     */
    @RequestMapping("addLeave")
    @ResponseBody
    public Wrapper<?> addLeave(String siIds, String leaveType, String leaveTime, String leaveReason, String timeType) {
        try {
            if (!validateLeave(siIds, timeType, leaveTime)) {
                return WrapMapper.wrap(4100, "请假申请提交失败，请假时间跨天！");
            }
            if (!validIsHavaFinishedFlow(siIds, 6)) {
                return WrapMapper.wrap(4200, "班次调整提交失败，已有任务在处理中！");
            }
            String[] siIdAttr = siIds.split(",");
            JsonData jsonData = new JsonData();
            jsonData.setType(6);
            Map<String, String> map = new HashMap<String, String>();
            map.put("tempLeaveType", leaveType);
            map.put("tempLeaveTime", leaveTime);
            map.put("tempLeaveReason", leaveReason);
            map.put("tempLeaveReason", leaveReason);
            map.put("timeType", timeType);
            map.put("num", siIdAttr.length + "");
            String data = JsonHelper.toJson(map);
            jsonData.setJsonData(data);
            jsonData.setCreateUser(getLoginUserName());
            LOG.info("入参：" + JsonHelper.toJson(jsonData));
            if (jsonDataService.insert(jsonData)) {
                CommonQueue queue = new CommonQueue();
                queue.setOnlyId(jsonData.getId());
                queue.setOnlyType("jsonData id");
                queue.setEventId(EventConstants.EVENT_TEMP_LEAVE);//注意，原来的系统中存在EVENT_LEAVE枚举值，注意区分
                queue.setRequestRemake("请假审批申请");
                queue.setCreatedBy(String.valueOf(getLoginUserId()));
                commonQueueService.insert(queue);

                List<ApprovalManage> approvalManages = new ArrayList<ApprovalManage>();
                for (String siId : siIdAttr) {
                    ApprovalManage manage = new ApprovalManage();
                    manage.setSiId(Long.parseLong(siId));
                    manage.setJdId(jsonData.getId());
                    manage.setType(6);
                    manage.setConfirm(0);
                    manage.setCreateUser(getLoginUserName());
                    approvalManages.add(manage);
                }
                approvalManageService.inserts(approvalManages);
            }
        } catch (Exception e) {
            LOG.error("添加请假审批信息失败！" + e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "请假审批提交成功！");
        }
        return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "请假审批提交成功！");
    }

    /***
     * 获得可见部门的id集合
     */
    private String getDepIds(Long userId) {
        List<UserDep> userDeps = userDepService.queryUserDepList(userId);
        StringBuilder sb = new StringBuilder();
        for (UserDep ud : userDeps) {
            sb.append(ud.getDepId() + ",");
        }
        String allowDeps = "";
        if (sb.length() > 0) {
            allowDeps = sb.substring(0, sb.length() - 1);
        }
        return allowDeps;
    }

    /**
     * 将当前用户的可见部门信息加入model
     *
     * @param
     * @return
     */
    private void addDepListToModel(Model model, String allowDepIds) {
        //当前用户的可见部门列表
        if (StringUtils.isNotEmpty(allowDepIds)) {
            List<Dep> depList = depService.getDepListByIds(allowDepIds);
            model.addAttribute("depList", depList);
        }
    }

    /**
     * 将业务线加到model
     *
     * @param
     * @return
     */
    private void addBusinessToModel(Model model) {
        List<Dic> business = getBusiness();
        model.addAttribute("business", business);
    }

    /**
     * 将班次加入到model
     *
     * @param
     * @return
     */
    private void addShitfsToModel(Model model) {
        ShiftsQuery shiftsQuery = new ShiftsQuery();
        shiftsQuery.setStatus(1);//启用状态
        List<Shifts> shiftsList = shiftsService.queryShiftsList(shiftsQuery);//一次读取所有班次信息
        model.addAttribute("shiftsList", shiftsList);
    }

    /**
     * 申请时不能与现有系统中的排班冲突。如：调整之后的排班，不能与此人的其他班次上班时间出现重叠。
     *
     * @return
     */
    private boolean validateAdjustTime(String siIds, String busName, String supportStartTime, String supportEndTime) {
        List<SchedulingInfo> list = null;
        try {
            String[] siIdAttr = siIds.split(",");
            for (String siId : siIdAttr) {
                SchedulingInfo info = schedulingInfoService.getSchedulingInfoById(Long.parseLong(siId));
                if (info == null) {
                    continue;
                }
                SchedulingInfo schedulingInfo = new SchedulingInfo();
                schedulingInfo.setBeginTime(Time.valueOf(supportStartTime + ":00"));//加上“00”，保证Time格式解析正确
                schedulingInfo.setEndTime(Time.valueOf(supportEndTime + ":00"));
                schedulingInfo.setPlanDate(info.getPlanDate());
                schedulingInfo.setBusName(busName);
                list = schedulingInfoService.querySchedulingInfoByTime(schedulingInfo);
                //返回结果不为空，证明调整后的时间会出现重叠
                if (CollectionUtils.isNotEmpty(list)) {
                    return false;
                }
            }
        } catch (Exception e) {
            LOG.error("校验数据信息与规定参数不符！", e);
        }
        return true;
    }

    /**
     * 班次调整时间校验
     * 不能跨天，例如：向前调整不能超过00：00：00，向后调整不能超过24：00：00.
     *
     * @return
     */
    private boolean adjustValidate(String siIds, String adjustType, String adjustTime) {
        String[] siIdAttr = siIds.split(",");
        Time time = null;
        for (String siId : siIdAttr) {
            SchedulingInfo info = schedulingInfoService.getSchedulingInfoById(Long.parseLong(siId));
            if (info == null) {
                continue;
            }
            if ("提前上班".equals(adjustType)) {
                //计算新的上班开始时间
                time = new Time(info.getBeginTime().getTime() - 1000 * 60 * Integer.parseInt(adjustTime));
                //提前后计算出的新上班开始时间如果大于原来的上班时间，说明调整后出现了跨天
                //比较方式不能用compareTo和before，该方式在跨天的情况下不能获得正确结果
                if (compareTime(time, info.getBeginTime()) > 0) {
                    return false;
                }
            } else if ("提前下班".equals(adjustType)) {
                //计算新的下班时间
                time = new Time(info.getEndTime().getTime() - 1000 * 60 * Integer.parseInt(adjustTime));
                //提前后的下班时间如果大于原来的下班时间，说明调整后出现了跨天
                if (compareTime(time, info.getEndTime()) > 0 || compareTime(info.getBeginTime(), time) > 0) {
                    return false;
                }
            } else if ("延迟上班".equals(adjustType)) {
                //计算新的上班开始时间
                time = new Time(info.getBeginTime().getTime() + 1000 * 60 * Integer.parseInt(adjustTime));
                //延迟后的上班时间如果小于原来的上班时间，说明调整后出现了跨天
                if (compareTime(time, info.getBeginTime()) < 0 || compareTime(info.getEndTime(), time) < 0) {
                    return false;
                }
            } else if ("延迟下班".equals(adjustType)) {
                //计算新的下班时间
                time = new Time(info.getEndTime().getTime() + 1000 * 60 * Integer.parseInt(adjustTime));
                //加班后的下班时间如果小于原来的下班时间，说明调整后出现了跨天
                if (compareTime(time, info.getEndTime()) < 0) {
                    return false;
                }
            } else {
                return false;
            }
        }
        return true;
    }

    /**
     * 比较java.sql.Time时间大小，能够处理跨天的情况；
     * time在正常情况下比较：今天的12:00:00T1，比较昨天的18:00:00T2，结果会显示T1>T2。
     * 先将time类型转成string，然后在转成time，这样可以有效解决跨天比较的问题，结果会显示T1<T2。
     *
     * @param time
     * @param beginTime
     */
    private Integer compareTime(Time time, Time beginTime) {
        try {
            String str1 = time.toString();
            String str2 = beginTime.toString();
            Time t1 = Time.valueOf(str1);
            Time t2 = Time.valueOf(str2);
            return t1.compareTo(t2);
        } catch (Exception e) {
            LOG.error("参数：" + time + "与" + beginTime + "比较出现异常！", e);
        }
        return 0;
    }

    /**
     * 校验餐时
     *
     * @param siIds
     * @param dinnerTime
     * @return
     */
    private boolean validateMealTime(String siIds, String dinnerTime) {
        try {
            String[] ids = siIds.split(",");
            for (String i : ids) {
                Long id = Long.parseLong(i);
                SchedulingInfo info = schedulingInfoService.getSchedulingInfoById(id);
                if (info == null) {
                    continue;
                }
                Long diff = info.getEndTime().getTime() - info.getBeginTime().getTime();
                Long dTime = Long.parseLong(dinnerTime) * 60 * 1000;
                if (dTime - diff > 0) {
                    return false;
                }
            }
        } catch (Exception e) {
            LOG.error("餐时调整出现异常，参数dinnerTime：" + dinnerTime, e);
            return false;
        }
        return true;
    }

    /**
     * 校验是否存在处理中的任务
     *
     * @param siIds
     * @param type
     * @return
     */
    private boolean validIsHavaFinishedFlow(String siIds, Integer type) {
        try {

            ApprovalManageQuery approvalManageQuery = new ApprovalManageQuery();
            approvalManageQuery.setSiIds(siIds);
            approvalManageQuery.setType(type);
            int count = approvalManageService.queryAppManageCount(approvalManageQuery);
            if (count > 0) {
                return false;
            }
        } catch (Exception e) {
            LOG.error("申请出现异常，参数siIds：" + siIds, e);
            return false;
        }
        return true;
    }

    /**
     * 校验请假时间
     *
     * @param siIds
     * @param timeType
     * @param leaveTime
     * @return
     */
    private boolean validateLeave(String siIds, String timeType,
                                  String leaveTime) {
        try {
            String[] ids = siIds.split(",");
            for (String i : ids) {
                Long id = Long.parseLong(i);
                SchedulingInfo info = schedulingInfoService.getSchedulingInfoById(id);
                if (info == null) {
                    continue;
                }
                if ("早走".equals(timeType)) {
                    Long newEndTime = info.getEndTime().getTime() - 1000 * 60 * Long.parseLong(leaveTime);
                    if (compareTime(new Time(newEndTime), info.getEndTime()) > 0 || compareTime(new Time(newEndTime), info.getBeginTime()) < 0) {
                        return false;
                    }
                } else if ("晚到".equals(timeType)) {
                    Long newBeginTime = info.getBeginTime().getTime() + 1000 * 60 * Long.parseLong(leaveTime);
                    if (compareTime(new Time(newBeginTime), info.getBeginTime()) < 0 || compareTime(new Time(newBeginTime), info.getEndTime()) > 0) {
                        return false;
                    }
                } else {
                    return false;
                }
            }
        } catch (Exception e) {
            LOG.error("请假申请出现异常，参数timeType：" + timeType + "，leaveTime：" + leaveTime, e);
        }
        return true;
    }

    /**
     * 根据班次名称获得班次id
     *
     * @param shiftsName
     * @return
     */
    private Long getShiftsId(String shiftsName) {
        if (shiftsName != null && !"".equals(shiftsName)) {
            Shifts shifts = shiftsService.getShiftsByName(shiftsName);
            if (shifts != null)
                return shifts.getId();
            return -1L;
        }
        return null;
    }
    
    /***
     * 获得所有业务线
     * @return
     */
    private List<Dic> getBusiness(){
    	DicQuery query = new DicQuery();
        query.setParentName("业务");
        List<Dic> business = dicService.queryDicList(query);
        return business;
    }
    
    /**
     * 被换班人校验
     * @param depId
     * @param shiftPeople
     * @param shiftDate
     * @param shifts
     * @param shiftsPeriod
     * @return
     */
    private boolean validateShift(String siIds,String depId, String shiftPeople,
			String shiftDate, String shifts, String shiftsPeriod){
    	try {
			SchedulingInfo info = schedulingInfoService.getSchedulingInfoById(Long.parseLong(siIds));
			//校验换班人，换班人如果在被换班那天的指定班段班次下有班，说明换班冲突
			SchedulingInfoQuery query1 = new SchedulingInfoQuery();
			query1.setStaffId(info.getStaffId());
			query1.setDepId(Long.parseLong(depId));
			query1.setPlanDate(shiftDate);
			query1.setShiftsId(Long.parseLong(shifts));
			String shiftsPeriodId = shiftsPeriod.split(",")[0];
			query1.setShiftPeriodId(Long.parseLong(shiftsPeriodId));
			List<SchedulingInfo> list1 = schedulingInfoService.querySchedulingInfoList(query1);
			if(CollectionUtils.isNotEmpty(list1)){//如果查询结果不为空，证明换班人在那天有班，换班后会有时间冲突
				return false;
			}
			
			//校验被换班人，被换班人如果在换班那天的指定班段班次下有班，说明换班冲突
			SchedulingInfoQuery query2 = new SchedulingInfoQuery();
			query2.setStaffId(Long.parseLong(shiftPeople));
			query2.setDepId(info.getDepId());
			query2.setPlanDate(DateHelper.format(info.getPlanDate(), "yyyy-MM-dd"));
			query2.setShiftsId(info.getShiftsId());
			query2.setShiftPeriodId(info.getShiftsPeriod().getId());
			List<SchedulingInfo> list2 = schedulingInfoService.querySchedulingInfoList(query2);
			if(CollectionUtils.isNotEmpty(list2)){//如果查询结果不为空，证明被换班人在那天有班，换班后会有时间冲突
				return false;
			}
		} catch (Exception e) {
			LOG.error("换班申请失败，参数为siIds:"+siIds+",depId:"+depId+",shiftPeople:"+shiftPeople+",shiftDate:"+shiftDate+",shifts"+",shiftsPeriod:"+shiftsPeriod, e);
			return false;
		}
    	return true;
    }
}