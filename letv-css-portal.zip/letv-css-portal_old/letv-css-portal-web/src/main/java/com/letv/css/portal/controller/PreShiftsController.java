package com.letv.css.portal.controller;

import com.letv.common.utils.DateHelper;
import com.letv.common.utils.exception.ExistedException;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.*;
import com.letv.css.portal.service.*;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

/**
 * BPO预置班次
 *
 * @Author yxh
 */
@Controller
@RequestMapping("preShifts")
public class PreShiftsController extends CommonController {
    private final static Log LOG = LogFactory.getLog(PreShiftsController.class);
    @Autowired
    private DepService depService;
    @Autowired
    private UserService userService;
    @Autowired
    private UserDepService userDepService;
    @Autowired
    private PreShiftsService preShiftsService;
    @Autowired
    private DicService dicService;
    @Autowired
    private ShiftsService shiftsService;
    @Autowired
    private StaffService staffService;
    @Autowired
    private JsonDataService jsonDataService;
    @Autowired
    private CommonQueueService commonQueueService;
    @Autowired
    private ApprovalManageService approvalManageService;
    /**
     * 视图前缀
     */
    private static final String VIEW_PREFIX = "preShifts";
    private static final String VIEW_INDEX = "index";
    private static final String VIEW_ADD = "preShifts";


    @RequestMapping("")
    public String welcom(Model model, PageUtil page, PreShiftsQuery query) {
        return index(model, page, query);
    }

    ;

    @RequestMapping(value = "index")
    public String index(Model model, PageUtil page, PreShiftsQuery query) {
        //数据权限控制
        User user = userService.getUserByUsername(getLoginUser().getUserName());
        String allowDepIds = userDepService.getDepIds(user.getId());
        if (allowDepIds == null || "".equals(allowDepIds)) {
            query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
        } else {
            query.setDepIds(allowDepIds);
        }
        page.setPageSize(100);
        //查询条件是否含有班次信息
        if (query.getShiftsName() != null && !"".equals(query.getShiftsName())) {
            query.setShiftsId(shiftsService.getShiftsId(query.getShiftsName()));
        }
        List<PreShifts> dataList = preShiftsService.queryPreShiftsListWithPage(query, page);
        model.addAttribute("dataList", dataList);
        model.addAttribute("query", query);
        model.addAttribute("page", page);
        addDepListToModel(model, allowDepIds);//部门
        addBusinessToModel(model);//业务线
        addShitfsToModel(model);
        return VIEW_PREFIX + "/" + VIEW_INDEX;
    }

    /**
     * 查询 可用加班的人员
     */
    @RequestMapping(value = "getPreShiftsStaff")
    @ResponseBody
    public Wrapper getPreShiftsStaff(StaffQuery queryBean) {
        List<Staff> staffList;
        try {
            queryBean.setPositionStatus("3");//只查询可以排班的人
            staffList = staffService.getPreShiftsStaff(queryBean, getLoginUserId());
        } catch (Exception e) {
            LOG.error(" getPreShiftsStaff has error.", e);
            return error();
        }
        return new Wrapper<List<Staff>>().result(staffList);
    }

    /**
     * 预置班次-跳转
     *
     * @return
     */
    @RequestMapping("addForward")
    public String addForward(Model model) {
        //数据权限控制
        User user = userService.getUserByUsername(getLoginUser().getUserName());
        String allowDepIds = userDepService.getDepIds(user.getId());
        addDepListToModel(model, allowDepIds);//职场
        addShitfsToModel(model);//班次
        return VIEW_PREFIX + "/" + VIEW_ADD;
    }

    /**
     * 预置班次-新增
     *
     * @return
     */
    @RequestMapping(value = "add", method = RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> add(PreShifts preShifts) {
        try {
            //一个人一天只能有一个预置一个班次
            PreShiftsQuery queryBean = new PreShiftsQuery();
            queryBean.setStaffId(preShifts.getStaffId());
            queryBean.setPlanDate(DateHelper.formatDate(preShifts.getPlanDate()));
            List<PreShifts> preShiftsList = preShiftsService.queryPreShiftsList(queryBean);
            if (preShiftsList != null && preShiftsList.size() > 0) {
                StringBuilder idsStrBuilder = new StringBuilder();
                for (int i = 0; i < preShiftsList.size(); i++) {
                    if (i == 0) {
                        idsStrBuilder.append(preShiftsList.get(i).getId());
                    } else {
                        idsStrBuilder.append(",").append(preShiftsList.get(i).getId());
                    }
                }
                if (!validIsHavaFinishedFlow(idsStrBuilder.toString(), 7)) {
                    return WrapMapper.wrap(4200, "预置班次提交失败，只能预置一次！");
                }
            }
            preShifts.setCreateUser(getLoginUserCnName());
            preShifts.setCreateTime(new Date());
            //用于记录审核人
            preShifts.setUpdateUser(getLoginUserCnName());
            preShifts.setUpdateTime(new Date());
            preShifts.setStatus(1);
            //人员信息
            Staff staff = staffService.getStaffById(preShifts.getStaffId());
            preShifts.setStaffName(staff.getName());
            preShifts.setCsId(staff.getCsId());
            //业务线名称
            String busName = dicService.getDicByNum(10L, preShifts.getBusId()).getName();
            preShifts.setBusName(busName);
            if (preShiftsService.insert(preShifts)) {
                //commQ表中新增记录
                JsonData jsonData = new JsonData();
                jsonData.setType(7);
                Map<String, String> map = new HashMap<>();
                map.put("depId", preShifts.getDepId().toString());
                map.put("name", preShifts.getStaffName());
                map.put("business", preShifts.getBusName());
                map.put("shifts", busName);
                map.put("preShiftsDate", DateHelper.formatDate(preShifts.getPlanDate()));
                map.put("preShiftsReason", preShifts.getRemark());
                String data = JsonHelper.toJson(map);
                jsonData.setJsonData(data);
                jsonData.setCreateUser(getLoginUserName());
                LOG.info("入参：" + JsonHelper.toJson(jsonData));
                if (jsonDataService.insert(jsonData)) {
                    CommonQueue queue = new CommonQueue();
                    queue.setOnlyId(jsonData.getId());
                    queue.setOnlyType("jsonData id");
                    queue.setEventId(EventConstants.EVENT_PRE_SHIFTS);
                    queue.setRequestRemake("新增预置班次");
                    queue.setCreatedBy(String.valueOf(getLoginUserId()));
                    commonQueueService.insert(queue);

                    List<ApprovalManage> approvalManages = new ArrayList<ApprovalManage>();
                    ApprovalManage manage = new ApprovalManage();
                    manage.setSiId(preShifts.getId());
                    manage.setJdId(jsonData.getId());
                    manage.setType(7);
                    manage.setConfirm(0);
                    manage.setCreateUser(getLoginUserName());
                    approvalManages.add(manage);
                    approvalManageService.inserts(approvalManages);
                }
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, preShifts.getId() + "");
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
            }
        } catch (ExistedException e) {
            LOG.warn("preShifts add fail, exist preShifts.");
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败，已经存在");
        } catch (Exception e) {
            LOG.error("preShifts add has error.", e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
        }
    }

    @RequestMapping("getDepBusiness")
    @ResponseBody
    public Wrapper<?> getDepBusiness(String depId) {
        List<Dic> business = null;
        try {
            business = getService(Long.parseLong(depId));
        } catch (Exception e) {
            LOG.error(" getPreShiftsStaff has error.", e);
            return error();
        }
        return new Wrapper<List<Dic>>().result(business);

    }

    private void addStaffListToModel(Model model, String allowDepIds) {
        StaffQuery queryBean = new StaffQuery();
        queryBean.setDepIds(allowDepIds);
        List<Staff> staffList = staffService.getPreShiftsStaff(queryBean, getLoginUserId());
        model.addAttribute("staffList", staffList);//可用人
    }

    /**
     * 校验是否存在处理中的任务
     *
     * @param siIds
     * @param type
     * @return
     */
    private boolean validIsHavaFinishedFlow(String siIds, Integer type) {
        try {

            ApprovalManageQuery approvalManageQuery = new ApprovalManageQuery();
            approvalManageQuery.setSiIds(siIds);
            approvalManageQuery.setType(type);
            int count = approvalManageService.queryValidCount(approvalManageQuery);
            if (count > 0) {
                return false;
            }
        } catch (Exception e) {
            LOG.error("申请出现异常，参数siIds：" + siIds, e);
            return false;
        }
        return true;
    }

    /**
     * 将当前用户的可见部门信息加入model
     *
     * @param
     * @return
     */
    private void addDepListToModel(Model model, String allowDepIds) {
        //当前用户的可见部门列表
        if (StringUtils.isNotEmpty(allowDepIds)) {
            List<Dep> depList = depService.getDepListByIds(allowDepIds);
            model.addAttribute("depList", depList);
        }
    }

    /**
     * 将业务线加到model
     *
     * @param
     * @return
     */
    private void addBusinessToModel(Model model) {
        List<Dic> business = getBusiness();
        model.addAttribute("business", business);
    }

    /**
     * 将班次加入到model
     *
     * @param
     * @return
     */
    private void addShitfsToModel(Model model) {
        ShiftsQuery shiftsQuery = new ShiftsQuery();
        shiftsQuery.setStatus(1);//启用状态
        List<Shifts> shiftsList = shiftsService.queryShiftsList(shiftsQuery);//一次读取所有班次信息
        model.addAttribute("shiftsList", shiftsList);
    }

    /***
     * 获得所有业务线
     * @return
     */
    private List<Dic> getBusiness() {
        DicQuery query = new DicQuery();
        query.setParentName("业务");
        List<Dic> business = dicService.queryDicList(query);
        return business;
    }
}
