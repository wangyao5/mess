package com.letv.css.portal.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.common.web.context.LanguageContext;
import com.letv.css.portal.domain.Role;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.UserRole;
import com.letv.css.portal.domain.query.RoleQuery;
import com.letv.css.portal.service.RoleService;
import com.letv.css.portal.service.UserRoleService;
import com.letv.css.portal.service.UserService;
import com.letv.css.web.common.utils.JsonReader;
import com.letv.css.web.common.utils.JsonResult;

/**
 * User: cailong Date: 14-4-14 Time: 下午2:15
 */
@Controller
@RequestMapping("/role")
public class RoleController extends BaseController {
	private final Log logger = LogFactory.getLog(this.getClass());

	@Autowired
	private RoleService roleService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired UserService userService;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String index(Model model) {
		this.logger.debug("role --> role");
		model.addAttribute("language", LanguageContext.get().getLanguage());
		return "role/role";
	}

	@RequestMapping(value = "/queryRoles", method = RequestMethod.POST)
	@ResponseBody
	public JsonReader queryRoleList(@RequestParam Map<String, Object> paramMap, RoleQuery query, Model model) {
		JsonReader result = new JsonReader();
		try {
			model.addAttribute("language", LanguageContext.get().getLanguage());
			List<Role> list = roleService.queryRoles(query);
			result.setResult(list);
		} catch (Exception e) {
			this.logger.error("system --> queryRoles 查询数据异常:", e);
			result.setCode(JsonResult.CODE_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * 查询角色列表
	 * 
	 * @param paramMap
	 * @return
	 */
	@RequestMapping(value = "/queryRoleList", method = RequestMethod.POST)
	@ResponseBody
	public JsonReader queryBusinessList(@RequestParam Map<String, Object> paramMap, RoleQuery query, Model model) {
		this.logger.info("RoleController --> queryRoleList 按条件查询角色信息");
		JsonReader result = new JsonReader();
		try {
			PageUtil pageUtil = new PageUtil(query.getPage(), query.getRows());
			List<Role> roles = this.roleService.queryRoleListWithPage(query, pageUtil);
			result.setPaginatedData(roles, pageUtil);
		} catch (Exception e) {
			this.logger.error("roles --> queryRoleList 查询数据异常:", e);
			result.setCode(JsonResult.CODE_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * 角色新增，修改，删除
	 * 
	 * @param role
	 * @param oper
	 * @return
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	@ResponseBody
	public JsonResult save(Role role, String oper, String ids) {
		this.logger.info("RoleController -->save,oper=" + oper);
		if ("add".equals(oper)) {
			this.logger.info("Role -->save 新增角色开始，角色名称【" + role.getName() + "】");
			role.setCreateUser(getLoginUserName());
			boolean result = roleService.insert(role);
			this.logger.info("Role -->save 新增角色结束，角色名称【" + role.getName() + "】,结果 【" + result + "】");
		} else {
			if ((role != null && role.getId() != null && role.getId() > 0) || StringUtils.isNotBlank(ids)) {
				if ("edit".equals(oper)) {
					this.logger.info("Role -->save 修改角色开始，角色名称【" + role.getName() + "】");
					role.setUpdateUser(getLoginUserName());
					boolean result = roleService.update(role);
					this.logger.info("Role -->save 修改角色结束，角色名称【" + role.getName() + "】， 结果 【" + result + "】");
				} else if ("del".equals(oper)) {
					this.logger.info("Role -->save 删除角色开始");
					String[] roleIds = ids.split(",");
					boolean result = roleService.delete(roleIds);
					this.logger.info("Role -->save 删除角色结束，结果 【" + result + "】");
				}
			} else {
				this.logger.error("Role-->" + oper + ",传入参数不正确！");
				return new JsonResult(JsonResult.CODE_PARAM_ERROR, JsonResult.MESSAGE_PARAM_ERROR);
			}
		}
		return new JsonResult(JsonResult.CODE_SUCCESS, JsonResult.MESSAGE_SUCCESS);
	}
	
	/**
	 * 根据角色id查询用户信息列表
	 * @param
	 * @return
	 */
	@RequestMapping(value="queryUserByRoleId",method=RequestMethod.POST)
	@ResponseBody
	public Wrapper<?> queryUserByRoleId(Long roleId){
		try {
			this.logger.info("入参，roleId："+roleId);
			List<UserRole> userRoles = userRoleService.queryUsersByRoleId(roleId);
			this.logger.info("出参："+JsonHelper.toJson(userRoles));
			String[] ids = new String[userRoles.size()];
			for(int i=0,length=userRoles.size();i<length;i++){
				ids[i] = userRoles.get(i).getUserId().toString();
			}
			this.logger.info("入参："+JsonHelper.toJson(ids));
			List<User> users = userService.queryUsersByIds(ids);
			return WrapMapper.wrap(Wrapper.SUCCESS_CODE, Wrapper.SUCCESS_MESSAGE,users);
		} catch (Exception e) {
			 this.logger.error("queryUserByRoleId has error.", e);
	         return WrapMapper.error();
		}
	}
}
