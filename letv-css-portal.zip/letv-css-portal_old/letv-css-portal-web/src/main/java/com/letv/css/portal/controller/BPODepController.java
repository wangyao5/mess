package com.letv.css.portal.controller;

import java.util.*;

import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.service.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.exception.ExistedException;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.constant.CommonConstants;
import com.letv.css.portal.domain.constant.enums.DepRangeEnum;
import com.letv.css.portal.domain.constant.enums.HierarchyEnum;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.domain.query.DicQuery;

/**
 * BPO客服组织架构
 * 		与客服组织架构的区别在于，该页面不显示部门人数信息
 *
 * @Author menghan
 * @Version 2017-01-15 14:05:45
 */
@Controller
@RequestMapping("bpoDep")
public class BPODepController extends CommonController{
	
	private static final Log LOG = LogFactory.getLog(BPODepController.class);
	@Autowired
	private DepService depService;
	@Autowired
	private UserService userService;
	@Autowired
	private UserDepService userDepService;
	@Autowired
	private StaffService staffService;
	@Autowired
	private DicService dicService;
	@Autowired
	private MenuService menuService;
	@Autowired
	private CommonQueueService commonQueueService;
	
	/**视图前缀*/
	private static final String VIEW_PREFIX = "bpoDep";
	private static final String VIEW_INDEX = "index";
	private static final String VIEW_UPDATE = "update";
	
	@RequestMapping("")
	public String welcome(Model model, PageUtil page, DepQuery query){
		return index(model,page,query);
	}
	
	@RequestMapping("index")
	public String index(Model model, PageUtil page, DepQuery query){
		try {
			List<Dep> dataList = null;
			//数据权限控制
			User user = userService.getUserByUsername(getLoginUser().getUserName());
			String allowDepIds = getDepIds(user.getId());
			if(allowDepIds==null || "".equals(allowDepIds)){
				query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
			}else{
				query.setDepIds(allowDepIds);
			}
			
			dataList = depService.queryDepList(query);
			//找到可见部门的根部门code
			List<String> depCode = computeDepLevel(dataList);
			//补全部门
			dataList = complementedDep(depCode,allowDepIds);
			//补全人员数量
			//complementedDepQuantity(dataList);
			model.addAttribute("dataList", dataList);
			model.addAttribute("query", query);//查询条件
			addDepListToModel(model);
			addEnumToModel(model);
			addButtonPortals(model,user);//添加按钮权限
		} catch (Exception e) {
			LOG.error("DepController index has error.", e);
		}
		return VIEW_PREFIX + "/" + VIEW_INDEX;
	}
	
	/**
	 * 查询部门详细信息
	 * @param
	 * @return
	 */
	@RequestMapping(value="detail", method = RequestMethod.GET)
	@ResponseBody
	public Wrapper<?> detail(DepQuery query){
		if(null==query||null==query.getId()){
			return illegalArgument();
		}
		try {
			Dep dep = depService.getDepById(query.getId());
			if(dep!=null && dep.getParentId()!=null && dep.getParentId()>0){
				Dep parentDep = depService.getDepById(dep.getParentId());
				dep.setParentDep(parentDep);
			}
			if(dep!=null){
				return new Wrapper<Dep>().result(dep);
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE,"查询部门详情失败！");
			}
		} catch (Exception e) {
			LOG.warn("dep staff has error.", e);
            return error();
		}
	}
	
	/**
     * 部门----添加
     * 			添加部门时要注意该部门是否存在上级部门
     * 			部门添加完成后，需要更新其父部门（如果存在）的信息
     * 						需要更新当前用户的数据权限（可见部门）信息
     * @return
     */
    @RequestMapping(value = "add",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> add(Dep dep) {
        try {
        	//存在上级部门的情况
        	if(dep.getParentId()!=0L){
	        	Long parentId = dep.getParentId();//父ID
	        	Dep parentDep = depService.getDepById(parentId);
	        	int level = parentDep.getLevel()+1;//层级
	        	String code = computeCode(parentDep.getId(),parentDep.getCode());//计算编码
	        	dep.setCode(code);
	        	dep.setNum(code);//num已经被废弃，使其与code内容一致
	        	dep.setLevel(level);
        	}else{
        		String code = computeCode(0L,"0");//计算编码
        		dep.setCode(code);
        		dep.setNum(code);//num已经被废弃，使其与code内容一致
        		dep.setLevel(1);
        	}
        	dep.setHasChild(0);
        	dep.setCreateUser(getLoginUserCnName());
        	dep.setCreateTime(new Date());
            if (depService.insert(dep)) {
            	updateUserDepIds(dep.getCode());//更新当前用户的可见部门列表
            	updateParentDep(dep.getCode());//更新 新的父部门信息

				//插入commonQueue,同步工作流
				CommonQueue queue = new CommonQueue();
				queue.setOnlyId(dep.getId());
				queue.setOnlyType("dep id");
				queue.setEventId(EventConstants.EVENT_DEP_ADD);
				queue.setRequestRemake("新增部门流程");
				queue.setCreatedBy("BPODep add");
				commonQueueService.insert(queue);

                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "添加成功！");
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
            }
        } catch (ExistedException e) {
            LOG.warn("dep add fail, exist user.");
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败，已经存在");
        } catch (Exception e) {
            LOG.error("dep add has error.", e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
        }
    }
    
    /**
     * 部门----修改跳转
     * 
     * @param model
     * @param dep
     * @return
     */
    @RequestMapping(value = "updateForward")
    public String updateForward(Model model, Dep dep){
    	try {
    		Dep depResult = depService.getDepById(dep.getId());
    		model.addAttribute("dep", depResult);
            addEnumToModel(model);
            addFilterDepListToModel(model,depResult);
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
        }
        return VIEW_PREFIX + "/"+ VIEW_UPDATE;
    }
    
	/**
     * 部门----修改
     * 		检查该部门的上级部门是否发生了变化，
     * 		上级变化了需要重新计算当前部门的code、level，
     * 		需要检查原来的上级是否还有子部门，如果没有子部门的话需要将hasChild置为0,
     * 		检查当前部门的层级是否发生变化，层级变化了，需要修改子部门的层级和编号
     * @param user
     * @return
     */
    @RequestMapping(value = "update",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> update(Dep dep){
    	try{
    		//需要修改的部门
    		Dep curDep = depService.getDepById(dep.getId());
    		//int curLevel = curDep.getLevel();
	    	Long parentId = dep.getParentId();//父编码
	    	//父部门Id改变的时候，需要重新计算当前部门的编码
	    	if(parentId != null && !Objects.equals(parentId,curDep.getParentId())){
	    		Dep parentDep = depService.getDepById(parentId);
	    		if(parentDep!=null){
		    		int level = parentDep.getLevel()+1;//层级
		    		String code = computeCode(parentDep.getId(),parentDep.getCode());//计算编码
		    		dep.setCode(code);
		    		dep.setNum(code);//num已经被废弃，使其与code内容一致
		    		dep.setLevel(level);
	    		}else{
	    			//部门变为一级部门的情况
	    			String code = computeCode(0L,"0");
	    			dep.setCode(code);
	    			dep.setNum(code);
	    			dep.setLevel(1);
	    		}
	    	}
	    	dep.setUpdateUser(getLoginUserCnName());
	    	dep.setUpdateTime(new Date());
	    	if (depService.update(dep)) {
	    		updateParentDep(dep.getCode());//更新新的父部门
	    		if(parentId != curDep.getParentId()){//更新原来的父部门
	    			updatePastParentDep(curDep.getParentId());
	    		}
	    		if(parentId != curDep.getParentId()){//更新当前部门的子部门
	    			curDep = depService.getDepById(dep.getId());
	    			updateChildDep(curDep.getId(),curDep.getCode());
	    		}
				//插入commonQueue,同步工作流
				CommonQueue queue = new CommonQueue();
				queue.setOnlyId(dep.getId());
				queue.setOnlyType("dep id");
				queue.setEventId(EventConstants.EVENT_DEP_ADD);
				queue.setRequestRemake("修改部门流程");
				queue.setCreatedBy("DEP ADD");
				commonQueueService.insert(queue);
	            return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "修改成功！");
	        } else {
	            return WrapMapper.wrap(Wrapper.ERROR_CODE, "修改失败！");
	        }
	    } catch (ExistedException e) {
	        LOG.warn("dep update fail, exist user.");
	        return WrapMapper.wrap(Wrapper.ERROR_CODE, "修改失败，已经存在");
	    } catch (Exception e) {
	        LOG.error("dep update has error.", e);
	        return WrapMapper.wrap(Wrapper.ERROR_CODE, "修改失败！");
	    }
    }
    
	/**
     * 部门表----禁用
     * 
     * @param user
     * @return
     */
    @RequestMapping(value = "disable")
    @ResponseBody
    public Wrapper<?> disable(Dep dep) {
        try {
        	dep.setUpdateUser(getLoginUserCnName());
        	dep.setUpdateTime(new Date());
        	dep.setDepState(1);//设为禁用状态
            if (depService.update(dep)) {
				//插入commonQueue,同步工作流
				CommonQueue queue = new CommonQueue();
				queue.setOnlyId(dep.getId());
				queue.setOnlyType("dep id");
				queue.setEventId(EventConstants.EVENT_DEP_DISABLE);
				queue.setRequestRemake("禁用部门流程");
				queue.setCreatedBy("BPODep disable");
				commonQueueService.insert(queue);

                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "禁用成功！");
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "禁用失败！");
            }
        } catch (Exception e) {
            LOG.error("dep disable has error.", e);
            return WrapMapper.error();
        }
    }
    
    /**
     * 查询子部门
     * 
     * @param query
     * @return
     */
    @RequestMapping(value = "treeChild")
    @ResponseBody
    public Wrapper<?> treeChild(DepQuery query) {
    	if (null==query||null==query.getParentId()) {
			return illegalArgument();
		}
        try {
        	User user = userService.getUserByUsername(getLoginUser().getUserName());
			String allowDepIds = getDepIds(user.getId());
			query.setDepIds(allowDepIds);
            List<Dep> list = depService.queryTreeDepList(query);
            if (!CollectionUtils.isEmpty(list)) {
            	//complementedDepQuantity(list);//补齐人员数量
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, Wrapper.SUCCESS_MESSAGE, list);
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "查询配置信息失败！");
            }
        } catch (Exception e) {
            LOG.error("dep query has error.", e);
            return WrapMapper.error();
        }
    }
	
	/**
	 * 添加枚举类信息到model
	 * @param
	 * @return
	 */
	private void addEnumToModel(Model model){
		DicQuery query = new DicQuery();
//		query.setParentName("部门范围");
//		List<Dic> depRanges = dicService.queryDicList(query);
//		model.addAttribute("depRanges", depRanges);//部门范围
		query.setParentName("部门层级");
		List<Dic> hierarchys = dicService.queryDicList(query);
		model.addAttribute("hierarchys",hierarchys);//部门层级
		model.addAttribute("depCharges", getDepCharges());//部门负责人
	}
	
	/**
     * 将当前用户的可见部门信息加入model
     * @param
     * @return
     */
    private void addDepListToModel(Model model) {
    	//获得当前用户
		User user = userService.getUserByUsername(getLoginUser().getUserName());
		//当前用户的可见部门列表
		if(user!=null){
			String allowDeps = getDepIds(user.getId());
			List<Dep> depList = depService.getDepListByIds(allowDeps);
			if(depList!=null && depList.size()!=0){
				for(Dep dep:depList){
					dep.setParentDep(depService.getDepById(dep.getParentId()));
				}
			}
			model.addAttribute("depList", depList);
		}
	}
    
    /***
     * 获得可见部门的id集合
     */
    private String getDepIds(Long userId){
    	List<UserDep> userDeps = userDepService.queryUserDepList(userId);
		StringBuilder sb = new StringBuilder();
		for(UserDep ud:userDeps){
			sb.append(ud.getDepId()+",");
		}
		String allowDeps = "";
		if(sb.length()>0){
			allowDeps = sb.substring(0, sb.length()-1);
		}
		return allowDeps;
    }
	
    /***
     * 计算部门编码，该编码不是指用户输入的num，而是code用来判断部门之间的父子关系
     * @param
     * @return
     */
    private String computeCode(Long parentId,String parentCode){
    	//父编号为0的情况
    	if(parentId == null || parentId == 0L){
    		List<String> list = depService.getChildrenCodByParentId(parentId);
    		StringBuffer sb = new StringBuffer("");
    		if(list!=null && list.size()!=0){
        		String tempCode = list.get(0);
        		int val = Integer.valueOf(tempCode);
        		val++;
        		sb.append(String.valueOf(val));
        		while(sb.length()<CommonConstants.DEP_CODE_BIT){
        			sb.insert(0, "0");
        		}
    		}else{
    			int val = 1;
    			sb.append(String.valueOf(val));
        		while(sb.length()<CommonConstants.DEP_CODE_BIT){
        			sb.insert(0, "0");
        		}
    		}
    		return sb.toString();
    	}
    	//父编号不为0的情况
    	List<String> list = depService.getChildrenCodByParentId(parentId);
    	int length = parentCode.length();
    	StringBuffer sb = new StringBuffer("");
    	if(list!=null && list.size()!=0){
    		String tempCode = list.get(0);
    		int val = Integer.valueOf(tempCode.substring(length, tempCode.length()));
    		val++;
    		sb.append(String.valueOf(val));
    		while(sb.length()<CommonConstants.DEP_CODE_BIT){
    			sb.insert(0, "0");
    		}
    	}else{
    		sb.append("0001");
    	}
    	sb.insert(0, parentCode);
    	return sb.toString();
    }
    
    /***
     * 更新当前用户的可见部门列表
     * 	   旧的逻辑(不在使用)：根据传入的部门编码num，获得当前部门信息；获得当前用户信息，将当前部门的ID加入到当前用户的allowDepIds。
     * 	   新的逻辑：根据传入的部门编码code，获得当前部门信息；更新user-dep表，添加一条该用户和部门的关联
     * @param
     * @return
     */
    private void updateUserDepIds(String code){
    	DepQuery query = new DepQuery();
    	query.setCode(code);
    	List<Dep> tempDeps = depService.queryDepListWithPage(query, null);
    	//更新用户的可见部门
    	if(tempDeps!=null && tempDeps.size()!=0){
    		Dep dep = tempDeps.get(0);
    		User tempUser = userService.getUserByUsername(getLoginUser().getUserName());
//	    	User user = new User();
//	    	if(tempUser!=null){
//		    	user.setAllowDepIds(tempUser.getAllowDepIds()+","+dep.getId());
//		    	user.setId(tempUser.getId());
//		    	userService.update(user);
//	    	}
    		if(tempUser!=null){
		    	UserDep userDep = new UserDep();
		    	userDep.setUserId(tempUser.getId());
		    	userDep.setDepId(dep.getId());
		    	userDep.setCreateTime(new Date());
		    	userDep.setCreateUser(tempUser.getName());
		    	userDepService.insert(userDep);
    		}
    	}
    }
    
    /**
     * 更新 新的父部门信息，将其父部门中的hasChild更新为1
     * 		根据传入的部门编码code，获得当前部门信息；通过当前的部门的parentId，获得其父部门信息，将父部门的hasChild置为1，update。
     * @param
     * @return
     */
    private void updateParentDep(String code) {
    	DepQuery query = new DepQuery();
    	query.setCode(code);
    	//子部门信息
    	List<Dep> tempDeps = depService.queryDepListWithPage(query, null);
    	if(tempDeps!=null && tempDeps.size()!=0){
    		Dep dep = tempDeps.get(0);
    		//父部门信息
    		Dep parentDep = depService.getDepById(dep.getParentId());
    		if(parentDep!=null){
    			parentDep.setHasChild(1);
	    		depService.update(parentDep);
    		}
    	}
	}
    
    /**
     * 更新过去的父部门信息，判断其是否还有子部门，没有的话，将其hasChild置为0
     */
    private void updatePastParentDep(Long parentId) {
    	Dep dep = depService.getDepById(parentId);
		DepQuery query = new DepQuery();
		query.setParentId(parentId);
		//子部门信息
    	List<Dep> tempDeps = depService.queryDepList(query);
    	if(tempDeps == null || tempDeps.size() == 0){
    		dep.setHasChild(0);
    		depService.update(dep);
    	}
	}
    
    /**
     * 递归修改子部门的层级和code
     */
	private void updateChildDep(Long parentId,String parentCode) {
		DepQuery query = new DepQuery();
		query.setParentId(parentId);
		//子部门信息
    	List<Dep> deps = depService.queryDepList(query);
    	int index = 1;
    	StringBuilder sb= null;
		for(Dep dep:deps){
			sb = new StringBuilder();
			sb.append(String.valueOf(index));
			while(sb.length()<CommonConstants.DEP_CODE_BIT){
    			sb.insert(0, "0");
    		}
			sb.insert(0, parentCode);
			dep.setCode(sb.toString());
			dep.setNum(sb.toString());
			dep.setLevel(sb.length()/CommonConstants.DEP_CODE_BIT);
			depService.update(dep);
			index++;
			updateChildDep(dep.getId(),dep.getCode());
		}
	}
	
	/**
	 * 补全该部门的人员数量
	 * @param
	 * @return
	 */
//	private void complementedDepQuantity(List<Dep> dataList) {
//		if(dataList!=null && dataList.size()>0){
//			int count = 0;
//			for(Dep dep:dataList){
//				count = depService.queryDepPersonQuantityByCode(dep.getCode());
//				dep.setPersonQuantity(count);
//			}
//		}
//	}
	
	/**
	 * 获得部门负责人
	 * 			目前没有规则，获得所有员工，后期需要改进
	 * @param
	 * @return
	 */
	private List<Staff> getDepCharges(){
		return staffService.queryStaffList(null);
	}
	
	/**
	 * 添加部门信息到model，过滤掉自己和自己的下级部门
	 * @param
	 * @return
	 */
	private void addFilterDepListToModel(Model model,Dep dep) {
		//获得当前用户
		User user = userService.getUserByUsername(getLoginUser().getUserName());
		//当前用户的可见部门列表
		if(user!=null){
			String allowDeps = getDepIds(user.getId());
			List<Dep> depList = depService.getDepListByIds(allowDeps);
			List<Dep> temp = new ArrayList<Dep>(depList.size());
			if(depList!=null && depList.size()!=0){
				for(Dep d:depList){
					if(Objects.equals(d.getId() , dep.getId()) || d.getCode().indexOf(dep.getCode())==0){
						//无操作，不添加自己和自己的下级部门
					}else{
						d.setParentDep(depService.getDepById(d.getParentId()));
						temp.add(d);
					}
				}
			}
			depList = temp;
			//检查当前部门的父部门是否在depList中，不在话加入depList
			Dep parentDep = depService.getDepById(dep.getParentId());
			if(parentDep!=null){
				boolean flag = false;
				for(Dep dd:depList){
					if(dd.getId()==parentDep.getId()){
						flag = true;
						break;
					}
				}
				if(!flag){
					depList.add(parentDep);
				}
			}
			model.addAttribute("depList", depList);
		}
	}
	
	/**
	 * 找到不同部门的根部门code
	 * @param
	 * @return
	 */
	private List<String> computeDepLevel(List<Dep> dataList) {
		if(dataList!=null && dataList.size()>0){
			List<String> strs = new ArrayList<String>(dataList.size());
			for(Dep d:dataList){
				strs.add(d.getCode());
			}
			List<String> result = new ArrayList<String>(dataList.size());
			if(strs!=null && strs.size()>0){
				String str = strs.get(0);
				result.add(str);
				for(int i=1;i<strs.size();i++){
					if(strs.get(i).indexOf(str)!=0){
						str = strs.get(i);
						result.add(str);
					}
				}
			}
			return result;
		}else{
			return null;
		}
	}

	/**
	 * 根据部门code集合，找到所有部门
	 * @param
	 * @return
	 */
	private List<Dep> complementedDep(List<String> depCode,String allowDepIds) {
		List<Dep> dataList = null;
		DepQuery query = new DepQuery();
		if(depCode!=null && depCode.size()>0){
			dataList = new ArrayList<Dep>(depCode.size());
			for(int i=0;i<depCode.size();i++){
				query.setCode(depCode.get(i));
				dataList.addAll(depService.queryDepList(query));
			}
		}
		query = new DepQuery();
		query.setDepIds(allowDepIds);
		List<Dep> deps = depService.queryDepList(query);
		if(dataList!=null && dataList.size()>0){
			for(Dep dep:dataList){
				Long id = dep.getId();
				boolean flag = false;
				for(Dep d:deps){
					if(d.getParentId()!=0 && Objects.equals(id,d.getParentId())){
						dep.setHasChild(1);
						flag = true;
					}
				}
				if(!flag){
					dep.setHasChild(0);
				}
			}
		}
		return dataList;
	}
	
	/**
     * 添加按钮级别的权限
     * @param
     * @return
     */
    private void addButtonPortals(Model model,User user){
    	Set<String> set = new HashSet<String>();
    	List<Resource> resources = menuService.queryButtonResources(user);
    	for(Resource r:resources){
    		if(r.getParentId()!=null){
    			set.add(r.getUrl());
    		}
    	}
    	model.addAttribute("buttonPortals", set);
    }
}
