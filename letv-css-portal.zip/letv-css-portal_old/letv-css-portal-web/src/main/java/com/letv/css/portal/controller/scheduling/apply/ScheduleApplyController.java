package com.letv.css.portal.controller.scheduling.apply;

import com.fasterxml.jackson.core.type.TypeReference;
import com.letv.common.controller.base.BaseController;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.constant.CommonConstants;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;
import com.letv.css.portal.service.ApprovalManageService;
import com.letv.css.portal.service.DepService;
import com.letv.css.portal.service.SchedulingInfoService;
import com.letv.css.portal.service.UserDepService;
import com.letv.css.portal.domain.vo.workflow.bean.ProcessLog;
import com.letv.css.portal.domain.vo.workflow.bean.NewInstanceParam;
import com.letv.css.portal.domain.vo.workflow.bean.WfResponse;
import com.letv.css.portal.domain.vo.workflow.bean.WorkFlowIndexQuery;
import com.letv.css.web.common.utils.HttpUtil;
import com.letv.css.web.common.utils.JsonUtil;
import com.letv.css.web.common.utils.Md5Util;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
* @author yxh
* @date  2017-06-28 16:06:38.
* @version V1.0
*/
@Controller
public class ScheduleApplyController extends BaseController {
    private static final Log LOG = LogFactory.getLog(ScheduleApplyController.class);

    @Value("${workflow.url.domain.host}")
    private String URL_TEST;
    @Value("${workflow.url.domain.queryInstanceSumByMyOpen}")
    private String URL_QUERYINSTANCESUMBYMYOPEN;
    @Value("${workflow.url.domain.queryInstanceByMyOpen}")
    private String URL_QUERYINSTANCEBYMYOPEN;
    @Value("${workflow.url.domain.processInstance}")
    private String URL_PROCESSINSTANCE;
    @Value("${workflow.url.domain.queryInstanceLog}")
    private String URL_QUERYINSTANCELOG;

    @Autowired
    private SchedulingInfoService schedulingInfoService;

    @Autowired
    private ApprovalManageService approvalManageService;
    @Autowired
    private UserDepService userDepService;
    @Autowired
    private DepService depService;

    public  void setFlowHistoryInModel(Model model, NewInstanceParam p) throws IOException {
        WorkFlowIndexQuery query = new WorkFlowIndexQuery();
        query.setFlowId(p.getFlowId());
        query.setInstanceId(p.getInstanceId());
        String str1 = getWFInstanceLog(null, query);
        WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str1,
                new TypeReference<WfResponse<List<ProcessLog>>>() {
                });
        if ("0".equals(wfs.getStatus()))
            model.addAttribute("result", wfs.getResult());
    }

    /**
     * 根据排班ID获取选择的排班班段信息
     * @param p
     * @return
     */
    public List<SchedulingInfo> getApplySchedulingInfos(NewInstanceParam p, boolean isSetAppManage,Integer yn) {
        String str = null;
        List<SchedulingInfo> dataList = null;
        //根据排班ID获取选择的排班班段信息
        List<ApprovalManage> appManages = approvalManageService.queryAppManageList(Long.parseLong(p.getOutId()));
        if (CollectionUtils.isNotEmpty(appManages)) {
            for (ApprovalManage appManage : appManages) {
                if (str == null) {
                    str = appManage.getSiId().toString();
                } else {
                    str += "," + appManage.getSiId();
                }
            }
        } else {
            if(!"bpoOvertime".equals(p.getFlowId())){//加班后维护人员，可能未维护
                throw new NullPointerException("人员班段明细为空！");
            }
        }
        if (org.apache.commons.lang.StringUtils.isNotEmpty(str)) {
            SchedulingInfoQuery queryBean = new SchedulingInfoQuery();
            queryBean.setIds(str);
            if(yn !=null){
                queryBean.setYn(yn);
            }
            dataList = schedulingInfoService.querySchedulingInfoList(queryBean);
        }
        //审核不需要设置值，确认时需要
        if (isSetAppManage) {
            if (CollectionUtils.isNotEmpty(dataList)) {
                for (SchedulingInfo schedulingInfo : dataList) {
                    for (ApprovalManage appManage : appManages) {
                        if (schedulingInfo.getId().equals(appManage.getSiId())) {
                            schedulingInfo.setApprovalManage(appManage);
                            continue;
                        }
                    }
                }
            }
        }
        return dataList;
    }
    /**
     * 执行下一步操作
     * @param p
     * @param wfs
     * @return
     * @throws IOException
     */
    public HashMap workFlowStepNext(NewInstanceParam p, HashMap wfs) throws IOException {
        String url = URL_TEST + URL_PROCESSINSTANCE;
        Map<String, String> param = new HashMap<String, String>();
        String timestamp = String.valueOf(System.currentTimeMillis());
        param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
        param.put("operatorType", "css");
        param.put("operatorId", String.valueOf(getLoginUserId()));
        param.put("instanceId", p.getInstanceId());
        param.put("statusId", p.getStatusId());
        param.put("actionId", p.getActionId());
        param.put("remark", p.getRemark());
        param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
        param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
        LOG.info("start applySupport call workflow url:" + url + ": " + param.toString());
        String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
        LOG.info("end applySupport to call workflow resul is:" + str);
        wfs = JsonUtil.fromJsonObject(str, HashMap.class);
        return wfs;
    }
    //为工作流设置基本实例参数
    public void addWorkflowParam(Model model, NewInstanceParam p) {
        model.addAttribute("flowId", p.getFlowId());
        model.addAttribute("instanceId", p.getInstanceId());
        model.addAttribute("statusId", p.getStatusId());
        model.addAttribute("actionId", p.getActionId());
        model.addAttribute("outId", p.getOutId());
    }
    //获取工作操作日志
    private String getWFInstanceLog(Staff staff, WorkFlowIndexQuery query) throws IOException {
        String url = URL_TEST + URL_QUERYINSTANCELOG;
        Map<String, String> param = new HashMap<String, String>();
        String timestamp = String.valueOf(System.currentTimeMillis());
        param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
        param.put("operatorType", "css");
        param.put("operatorId", String.valueOf(getLoginUserId()));
        param.put("instanceId", query.getInstanceId());
        param.put("flowId", query.getFlowId());
        param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
        param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));

        LOG.info("start getWFInstanceLog url:" + url + ": " + param.toString());
        String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
        LOG.info("end  getWFInstanceLog result:" + str);
        return str;
    }
    
    /***
     * 获得可见部门的id集合
     */
    public String getDepIds(Long userId) {
        List<UserDep> userDeps = userDepService.queryUserDepList(userId);
        StringBuilder sb = new StringBuilder();
        for(UserDep ud:userDeps){
            sb.append(ud.getDepId()+",");
        }
        String allowDeps = "";
        if(sb.length()>0){
            allowDeps = sb.substring(0, sb.length()-1);
        }
        return allowDeps;
    }
    /**
     * 将当前用户的可见部门信息加入model
     * @param
     * @return
     */
    public void addDepListToModel(Model model,String allowDepIds) {
        //当前用户的可见部门列表
        if(org.apache.commons.lang.StringUtils.isNotEmpty(allowDepIds)){
            List<Dep> depList = depService.getDepListByIds(allowDepIds);
            model.addAttribute("depList", depList);
        }
    }
}
