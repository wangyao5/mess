package com.letv.css.portal.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.letv.common.utils.serialize.JsonHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.PreShifts;
import com.letv.css.portal.domain.Schedule;
import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.SchedulePlan;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.Shifts;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.ThresholdValue;
import com.letv.css.portal.domain.query.*;
import com.letv.css.portal.service.*;
import com.letv.css.portal.tools.AutoSchedule;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * BPO自动排班
 *
 * @Author greg
 * @Version 2017-09-04
 */
@Controller
@RequestMapping("scheduleAuto")
public class ScheduleAutoController extends CommonController {

    private final static Log LOG = LogFactory.getLog(ScheduleAutoController.class);
    
    
    @Autowired
    private ScheduleService scheduleService;
    @Autowired
    private ScheduleDetailService scheduleDetailService;
    @Autowired
    private SchedulePlanService schedulePlanService;
    @Autowired
    private SchedulePlanDetailService schedulePlanDetailService;
    @Autowired
    private UserDepService userDepService;
    @Autowired
    private DepService depService;
    @Autowired
    private ShiftsService shiftsService;
    @Autowired
    private StaffService staffService;
    @Autowired
    private DicService dicService;
    @Autowired
    private PreShiftsService preShiftsService;
    @Autowired
    private ThresholdValueService thresholdValueService;
    
    
    private static final String JOB_TITLE_STAFF = "坐席";
    
    private static final String JOB_TITLE_LEADER = "坐席组长";
    
    private static final String SHIFTS_NAME_HOLIDAY = "休息";
    /** [字典表类型] 职工岗位. */
    private static final Long SERVER_JOB_CODE = 12L;
    /** [字典表类型] 业务线. */
    private static final Long SERVER_DIC_CODE = 10L;
    
    private static final String STAFF_POSITION_STATUS_NORMAL = "3";
    /** 预置班次完成状态编号. */
    private static final Integer FINISH_STATUS_PRE_SHIFTS = 3;
    /** 报错提示话术. */
    private static final String SUCCESS_MESSAGE = "系统排班已完成。";
    private static final String ERROR_MESSAGE_9999 = "发生未知错误，请及时反馈管理员。";
    
    private static final String ERROR_MESSAGE_0001 = "提交的班表编号为空。";
    private static final String ERROR_MESSAGE_0002 = "班表不存在或已删除，请核对后重新提交。";
    private static final String ERROR_MESSAGE_0003 = "班表流水号有误，请核对后重新提交。";
    private static final String ERROR_MESSAGE_0004 = "当前职场和业务线无坐席可进行排班。";
    private static final String ERROR_MESSAGE_0005 = "班表所需坐席为零，无需排班。";
    private static final String ERROR_MESSAGE_0006 = "班表已过期，无法进行排班。";
    private static final String ERROR_MESSAGE_0007 = "人均班次超出排班周期，无法正常排班。";
    
    private static final String ERROR_MESSAGE_0008 = "当前班表的职场参数异常，请联系管理员。";
    private static final String ERROR_MESSAGE_0009 = "当前班表的业务线参数异常，请联系管理员。";
    
    /**
     * 自动排班页面展示
     *
     * @param model
     * @param schedule
     * @return
     */
    @RequestMapping("submit")
    @ResponseBody
    public Wrapper<?> submit(ScheduleDetailQuery query) throws Exception {
        if(query!=null){
        	Long S_ID = query.getsId();
        	Long SP_ID = query.getSpId();
        	String resultJson = AutoSchedule(S_ID, SP_ID);
        	LOG.info(S_ID + "[排班结果]"+resultJson);
        	return WrapMapper.wrap(Wrapper.SUCCESS_CODE, resultJson);
        }else{
        	return WrapMapper.wrap(Wrapper.ERROR_CODE, ERROR_MESSAGE_0001);
        }
    }
    
    
    /**
     * 自动排班 - 操作流程
     * @param SP_ID
     * @return
     */
    private String AutoSchedule(Long S_ID,Long SP_ID){
    	AutoSchedule autoSchedule = new AutoSchedule();
    	/** [校验] 参数非空判断. */
    	if(S_ID==null || SP_ID==null){return getResultJson(false, ERROR_MESSAGE_0001, null);}
    	/** [数据库] 班表信息. */
    	Schedule SCHEDULE_INFO = scheduleService.getScheduleById(S_ID);
    	/** [校验] 班表编号是否存在. */
    	if(SCHEDULE_INFO == null){return getResultJson(false, ERROR_MESSAGE_0002, null);}
    	/** [校验] 班表计划编号是否一致. */
    	Long OneSpId = SCHEDULE_INFO.getSpId();
    	if(SP_ID != OneSpId){return getResultJson(false, ERROR_MESSAGE_0003, null);}
    	/** [数据库] 班表计划信息. */
    	SchedulePlan SCHEDULE_PLAN_INFO = schedulePlanService.getSchedulePlanById(SP_ID);
    	/** [获取参数] 职场编号. */
    	if(SCHEDULE_INFO.getDepId() == null || SCHEDULE_PLAN_INFO.getDepId() == null){
    		return getResultJson(false, ERROR_MESSAGE_0008, null);
    	}
    	/** [获取参数] 业务线编号. */
    	if(SCHEDULE_INFO.getBusId() == null || SCHEDULE_PLAN_INFO.getBusId() == null){
    		return getResultJson(false, ERROR_MESSAGE_0009, null);
    	}
    	/** [数据库] 下属部门信息集合. */
    	List<Dep> TREE_DEP_LIST = queryTreeDepListByDepId(SCHEDULE_PLAN_INFO.getDepId());
    	Map<Long, Dep> DEP_INFO_MAP = queryTreeDepInfoMap(SCHEDULE_INFO,TREE_DEP_LIST);
    	/** [获取参数] 名为"坐席"的业务字典信息集合. */
    	List<Dic> SERVER_TYPE_LIST = queryServerTypeList(JOB_TITLE_STAFF);
    	/** [数据库] 参与排班坐席明细. */
    	List<Staff> staffInfoList = QueryStaffList(JOB_TITLE_STAFF,SCHEDULE_INFO, SCHEDULE_PLAN_INFO, TREE_DEP_LIST, SERVER_TYPE_LIST);
    	/** [校验] 参与排班坐席不能为空. */
    	if(staffInfoList==null || staffInfoList.size()<=0){return getResultJson(false, ERROR_MESSAGE_0004, null);}
    	
    	/** [数据库] 班表计划明细信息. */
    	List<SchedulePlanDetail> planDetailList = querySchedulePlanDetailList(SCHEDULE_PLAN_INFO);
    	/** [获取参数] 获取班表计划明细信息集合. */
    	Map<Long, SchedulePlanDetail> PLAN_DETAIL_INFO_MAP = autoSchedule.getPlanDetailInfoMap(planDetailList);
    	/** [获取参数] 需排班班次总数. */
    	int SCHEDULE_DETAIL_COUNT = queryScheduleDetailCount(PLAN_DETAIL_INFO_MAP);
    	if(SCHEDULE_DETAIL_COUNT <= 0){return getResultJson(false, ERROR_MESSAGE_0005, null);}
    	/** [获取参数] 需排班班次总数 按照日期统计. */
    	Map<Date, Integer> PLAN_DETAIL_COUNT_MAP = autoSchedule.getPlanDetailCountMapByPlanDate(planDetailList);
    	
    	/** [获取参数] 获取班表计划明细编号集合. */
    	List<Long> PLAN_DETAIL_ID_LIST = autoSchedule.getPlanDetailIdList(planDetailList);
    	/** [获取参数] 非空且人力不为零的班表计划明细. */
    	PLAN_DETAIL_ID_LIST = autoSchedule.checkPlanDetailForNoNull(PLAN_DETAIL_ID_LIST, PLAN_DETAIL_INFO_MAP);
    	
    	/** [获取参数] 参与排班坐席数量. */
    	int STAFF_COUNT = staffInfoList.size();
    	/** [获取参数] 坐席人均班次. */
    	int STAFF_PER_SHIFTS_NUM = getPreShiftsNum(JOB_TITLE_STAFF, SCHEDULE_DETAIL_COUNT, STAFF_COUNT);
    	/** [获取参数] 班长人均班次. */
    	int LEADER_PER_SHIFTS_NUM = getPreShiftsNum(JOB_TITLE_LEADER, SCHEDULE_DETAIL_COUNT, STAFF_COUNT);
    	
    	/** [获取参数] 获取用户信息集合,坐席班务分配. */
    	Map<Long, Staff> STAFF_INFO_MAP = autoSchedule.getStaffInfoMapByPlanShiftNum(staffInfoList,SCHEDULE_DETAIL_COUNT);
    	/** [获取参数] 获取用户编号集合. */
    	List<Long> STAFF_ID_LIST = autoSchedule.getStaffIdList(staffInfoList);
    	
    	/** [获取参数] 组长信息集合. */
    	List<String> SUPERIOR_LIST = autoSchedule.getSuperiorList(STAFF_INFO_MAP);
    	/** [获取参数] 排班计划开始时间. */
    	Date SCHEDULE_BEGINTIME = SCHEDULE_PLAN_INFO.getBeginTime();
    	/** [校验] 排班计划开始时间不得在当前系统时间之前. */
    	SCHEDULE_BEGINTIME = autoSchedule.getScheduleBeginTime(SCHEDULE_BEGINTIME);
    	/** [获取参数] 排班计划结束时间. */
    	Date SCHEDULE_ENDTIME = SCHEDULE_PLAN_INFO.getEndTime();
    	if(SCHEDULE_ENDTIME.before(SCHEDULE_BEGINTIME)){return getResultJson(false, ERROR_MESSAGE_0006, null);}
    	if( (SCHEDULE_ENDTIME.getTime() - SCHEDULE_BEGINTIME.getTime())/(1000*3600*24) < STAFF_PER_SHIFTS_NUM ){
    		return getResultJson(false, ERROR_MESSAGE_0007, null);
    	}
    	
    	/** [获取参数] 班制信息集合. */
    	ShiftsQuery shiftsQuery = new ShiftsQuery();
    	shiftsQuery.setStatus(1);
    	List<Shifts> SHIFTS_LIST = shiftsService.queryShiftsList(shiftsQuery);
    	System.out.println("GREG:"+SHIFTS_LIST.size());
    	Map<Long, Shifts> SHIFT_INFO_MAP = queryShiftsInfoMap(SHIFTS_LIST);
    	/** [获取参数] 业务线名称. */
		String BUS_NAME = dicService.getDicByNum(SERVER_DIC_CODE, SCHEDULE_PLAN_INFO.getBusId()).getName();
		SCHEDULE_INFO.setBusName(BUS_NAME);
    	/***********************************************************/
    	/** [申明变量] 创建班表明细集合,用于已分配的班次进行数据存储. */
    	List<ScheduleDetail> STAFF_SCHEDULE_DETAIL_LIST = new ArrayList<ScheduleDetail>();
    	
    	Integer ALL_SCHEDULE_DETAIL_COUNT = queryScheduleDetailCount(PLAN_DETAIL_INFO_MAP);
    	
    	/****[预置班次处理]********************************BEGIN********/
    	List<PreShifts> PRE_SHIFTS_INFO_LIST = queryPreShiftList(JOB_TITLE_STAFF,SCHEDULE_INFO, SCHEDULE_PLAN_INFO, TREE_DEP_LIST, SERVER_TYPE_LIST);
    	LOG.info("[预制班次]待处理记录："+PRE_SHIFTS_INFO_LIST.size());
    	if(PRE_SHIFTS_INFO_LIST!=null && PRE_SHIFTS_INFO_LIST.size()>0){
    		Map<String, Long> planDetailIdMap = autoSchedule.getPlanDetailIdMapByPlanDateShifts(PLAN_DETAIL_INFO_MAP);
    		for(int i=0;i<PRE_SHIFTS_INFO_LIST.size();i++){
    			PreShifts preShifts = PRE_SHIFTS_INFO_LIST.get(i);
    			Date planDate = preShifts.getPlanDate();
    			Long shiftsId = preShifts.getShiftsId();
    			String planDateShiftsIdCode = autoSchedule.formatDate(planDate) + "-" + shiftsId;
    			Long planDetailId = planDetailIdMap.get(planDateShiftsIdCode);
    			SchedulePlanDetail schedulePlanDetail = PLAN_DETAIL_INFO_MAP.get(planDetailId);
    			if(schedulePlanDetail!=null){
    				Long staffId = preShifts.getStaffId();
    				Staff staff = STAFF_INFO_MAP.get(staffId);
    				List<Date> preShiftsDates = staff.getPreShiftsDates();
    				ScheduleDetail scheduleDetail = packScheduleDetailForStaff(SCHEDULE_INFO, schedulePlanDetail, staff, DEP_INFO_MAP, SHIFT_INFO_MAP);
    				scheduleDetail.setRemark("[预]");
    				STAFF_SCHEDULE_DETAIL_LIST.add(scheduleDetail);
    				/** [逻辑操作] 更新员工排班日期信息. */
    				if(preShiftsDates == null){preShiftsDates = new ArrayList<Date>();}
    				preShiftsDates.add(planDate);
    				staff.setPreShiftsDates(preShiftsDates);
    				STAFF_INFO_MAP.put(staff.getId(), staff);
    				/** [逻辑操作] 更新排班计划明细的人力需求信息. */
    				schedulePlanDetail.setNum(schedulePlanDetail.getNum() - 1);
    				PLAN_DETAIL_INFO_MAP.put(schedulePlanDetail.getId(), schedulePlanDetail);
    			}
    		}
    	}
    	/****[预置班次处理]******************************** END ********/
    	
    	/****[算法    阶段一]********************************BEGIN********/
    	if(SCHEDULE_DETAIL_COUNT > 0){
    		/** [获取参数] 随机排序后的组长编号集合. */
        	Map<String, Integer> superiorCodeMap = autoSchedule.getSuperiorMapByAutoCode(SUPERIOR_LIST);
        	/** [获取参数] 结合组长编号进行可分配坐席排序，得到组内随机打乱的坐席排序表. */
        	List<Long> staffIdList = autoSchedule.getStaffIdListByAutoCode(STAFF_ID_LIST, STAFF_INFO_MAP, superiorCodeMap,false);
    		/** [获取参数] 按照班次分组的班次明细表. */
        	Map<Long, List<Long>> planDetailIdListMap = autoSchedule.getPlanDeTailIdListByShifts(PLAN_DETAIL_INFO_MAP);
        	
        	Double PER_SHIFTS_PROPORTION = queryPreShiftProportion();
        	int scheduleEndNum = (int) Math.rint(STAFF_PER_SHIFTS_NUM * PER_SHIFTS_PROPORTION);
        	
        	int staffNum = 0;
        	/** [遍历集合] 遍历班次信息. */
        	for(Shifts shifts : SHIFTS_LIST){
        		/** [获取参数] 班制编号. */
        		Long shiftsId = shifts.getId();
        		/** [获取参数] 通过班制编号获取对应班次计划明细. */
        		List<Long> planDetailIdList = planDetailIdListMap.get(shiftsId);
        		/** [校验] 班制对应的班次为空，则跳过该班制. */
        		if(planDetailIdList==null || planDetailIdList.size()<=0){continue;}
        		/** [校验] 当坐席顺位编号超过坐席人数上限时，结束当前循环. */
        		if(staffNum >= STAFF_COUNT){break;}
        		/** [集合遍历] 起始位置为累加计算，此处坐席顺位只取一次. */
        		for(int i = staffNum; i < STAFF_COUNT; i ++){
        			boolean staffOrderPoint = false;
        			/** [获取参数] 坐席信息. */
        			Long staffId = staffIdList.get(i);
        			Staff staff = STAFF_INFO_MAP.get(staffId);
        			Integer planShiftNum = staff.getSchedulingPlanShiftNum();
        			List<Date> schedulingDates = staff.getSchedulingDates();
        			if(schedulingDates == null){schedulingDates = new ArrayList<Date>();}
        			List<Date> preShiftDates = staff.getPreShiftsDates();
        			if(preShiftDates == null){preShiftDates = new ArrayList<Date>();}
        			/** [校验] 当该坐席的空班数小于等于零时，跳过该坐席. */
        			if( ( schedulingDates.size() + preShiftDates.size() ) >= planShiftNum ){continue;}
        			/** [获取参数] 人力预估不为零的班表计划明细信息. */
        			planDetailIdList = autoSchedule.getPlanDetailIdListByNoNull(planDetailIdList,PLAN_DETAIL_INFO_MAP);
        			/** [排序] 按照人力数倒序排序. */
        			planDetailIdList = autoSchedule.getPlanDetailIdListByNumDesc(planDetailIdList,PLAN_DETAIL_INFO_MAP);
        			/** [校验] 可排班的班次计划明细为空，则结束当前循环. */
        			if(planDetailIdList==null){break;}
        			/** [校验] 可排班的班次计划明细数量 少于 人均班次 时，结束当前循环. */
        			if(planDetailIdList.size() < scheduleEndNum){break;}
        			/** [遍历集合] 可排班的班次计划明细. */
        			for(int j = 0; j < planDetailIdList.size(); j ++){
        				/** [校验] 当循环序号等于人均班次时，结束当前循环. */
        				if(j == planShiftNum){break;}
        				/** [获取参数] 班表计划信息. */
        				Long planDetailId = planDetailIdList.get(j);
        				/** [] . */
        				SchedulePlanDetail schedulePlanDetail = PLAN_DETAIL_INFO_MAP.get(planDetailId);
        				/** [获取参数] 班次时间. */
        				Date planDate = schedulePlanDetail.getPlanDate();
        				/** [校验] 预置排班和日期冲突则跳过. */
        				if(schedulingDates.contains(planDate)){continue;}
        				if(preShiftDates.contains(planDate)){continue;}
        				/** [获取参数] 班表计划安排的人数. */
        				Integer schedulePlanDetail_Num = schedulePlanDetail.getNum();
        				/** [校验] 可安排人数小于等于0时跳过该日期.*/
        				if(schedulePlanDetail_Num <= 0){continue;}
        				/** [封装对象] 班表明细记录. */
        				ScheduleDetail scheduleDetail = packScheduleDetailForStaff(SCHEDULE_INFO, schedulePlanDetail, staff, DEP_INFO_MAP, SHIFT_INFO_MAP);
        				scheduleDetail.setRemark("[1]"+staff.getSchedulingPlanShiftNum());
        				/** [逻辑操作] 将封装好的对象写入List集合. */
        				STAFF_SCHEDULE_DETAIL_LIST.add(scheduleDetail);
        				/** [逻辑操作] 更新坐席的已排班日期参数. */
        				schedulingDates.add(schedulePlanDetail.getPlanDate());
        				staff.setSchedulingDates(schedulingDates);
        				STAFF_INFO_MAP.put(staff.getId(), staff);
        				/** [逻辑操作] 更新排班计划的剩余人力参数. */
        				schedulePlanDetail.setNum(schedulePlanDetail_Num-1);
        				PLAN_DETAIL_INFO_MAP.put(schedulePlanDetail.getId(), schedulePlanDetail);
        				
        				if(planShiftNum - schedulingDates.size() - preShiftDates.size() <= 0){break;}
        			}
        			/** [断点] 顺序断点未开启，且第一次有人有空班则开启断点. **/
        			if(!staffOrderPoint && (planShiftNum - schedulingDates.size() - preShiftDates.size()) > 0 ){
        				staffOrderPoint = true;
        			}
        			/** [逻辑操作] 执行结束后坐席顺位加一. */
        			if(!staffOrderPoint){
        				staffNum += 1;
        			}
        		}
        	}
    	}
    	/****[算法    阶段一]******************************** END ********/
    	SCHEDULE_DETAIL_COUNT = queryScheduleDetailCount(PLAN_DETAIL_INFO_MAP);
    	LOG.info("[算法阶一]剩余班次："+SCHEDULE_DETAIL_COUNT);
    	/****[算法    阶段二]********************************BEGIN********/
    	if(SCHEDULE_DETAIL_COUNT > 0){
    		/** [获取参数] 日期分组的班表计划明细. */
        	Map<Date, List<Long>> schedulePlanDetailMap = autoSchedule.getPlanDetailIdListByPlanDate(PLAN_DETAIL_INFO_MAP);
        	/** [获取参数] 随机排序后的组长编号集合. */
        	Map<String, Integer> superiorCodeMap = autoSchedule.getSuperiorMapByAutoCode(SUPERIOR_LIST);
        	for(int i = 0; i < SCHEDULE_DETAIL_COUNT; i ++){
            	/** [获取参数] 结合组长编号进行可分配坐席排序，得到组内随机打乱的坐席排序表. */
            	List<Long> staffIdList = autoSchedule.getStaffIdListByAutoCode(STAFF_ID_LIST, STAFF_INFO_MAP, superiorCodeMap,false);
            	
            	List<Date> planDateDetailNumList = autoSchedule.getPlanDateListByNumDesc(PLAN_DETAIL_INFO_MAP);
            	if(planDateDetailNumList == null || planDateDetailNumList.size() <= 0){break;}
            	LOG.info("[算法阶二]可分配天数："+planDateDetailNumList.size());
            	Date planDate = null;
            	for(int j = 0; j < planDateDetailNumList.size(); j ++){
            		Date planDateDemo = planDateDetailNumList.get(j);
            		if(schedulePlanDetailMap.get(planDateDemo)==null || schedulePlanDetailMap.get(planDateDemo).size()<=0){continue;}
            		planDate = planDateDemo;
            		break;
            	}
            	if(planDate == null){break;}
        		List<Long> planDetailIdList = schedulePlanDetailMap.get(planDate);
        		Integer detailNum = queryScheduleDetailCountByIds(PLAN_DETAIL_INFO_MAP, planDetailIdList);
            	if(detailNum == null){continue;}
            	LOG.info("[算法阶二]["+planDate+"]空班数:"+detailNum);
        		Integer scheduleNum = autoSchedule.checkDetailNum(detailNum);
        		if(scheduleNum == null || scheduleNum <= 0){break;}
        		LOG.info("[算法阶二]["+planDate+"]本轮可排班数："+scheduleNum);
        		int staffOrder = 0;
        		for(int j = 0; j < scheduleNum; j ++){
        			Long planDetailId = planDetailIdList.get(0);
        			SchedulePlanDetail schedulePlanDetail = PLAN_DETAIL_INFO_MAP.get(planDetailId);
        			if(schedulePlanDetail.getNum()==null || schedulePlanDetail.getNum()<=0){break;}
        			Staff staff = null;
        			for(int k = staffOrder; k < staffIdList.size(); k ++){
        				Long staffId = staffIdList.get(k);
        				Staff staffInfo = STAFF_INFO_MAP.get(staffId);
        				if(staffInfo.getSchedulingDates() == null){staffInfo.setSchedulingDates(new ArrayList<Date>());}
        				if(staffInfo.getSchedulingDates().contains(planDate)){continue;}
        				if(staffInfo.getPreShiftsDates() == null){staffInfo.setPreShiftsDates(new ArrayList<Date>());}
        				if(staffInfo.getPreShiftsDates().contains(planDate)){continue;}
        				if( ( staffInfo.getSchedulingDates().size() + staffInfo.getPreShiftsDates().size() ) 
        						>= staffInfo.getSchedulingPlanShiftNum()){continue;}
        				staff = staffInfo;
        				staffOrder = k;
    					break;
        			}
        			if(staff == null){schedulePlanDetailMap.remove(planDate);break;}
        			
        			/** [封装对象] 封装班表明细参数. */
    				ScheduleDetail scheduleDetail = packScheduleDetailForStaff(SCHEDULE_INFO, schedulePlanDetail, staff, DEP_INFO_MAP, SHIFT_INFO_MAP);
    				scheduleDetail.setRemark("[2]"+staff.getSchedulingPlanShiftNum()+"-"+i);
    				STAFF_SCHEDULE_DETAIL_LIST.add(scheduleDetail);
    				/** [逻辑操作] 更新员工排班日期信息. */
    				staff.getSchedulingDates().add(planDate);
    				STAFF_INFO_MAP.put(staff.getId(), staff);
    				staffOrder += 1;
    				/** [逻辑操作] 更新排班计划明细的人力需求信息. */
    				schedulePlanDetail.setNum(schedulePlanDetail.getNum() - 1);
    				PLAN_DETAIL_INFO_MAP.put(schedulePlanDetail.getId(), schedulePlanDetail);
    				if(schedulePlanDetail.getNum() <= 0){
    					planDetailIdList.remove(0);
    				}
        		}
        		LOG.info("[算法阶二]["+STAFF_SCHEDULE_DETAIL_LIST.size()+"]"+planDate);
        	}
    	}
    	/****[算法    阶段二]******************************** END ********/
    	SCHEDULE_DETAIL_COUNT = queryScheduleDetailCount(PLAN_DETAIL_INFO_MAP);
    	LOG.info("[算法阶二]剩余班次："+SCHEDULE_DETAIL_COUNT);
    	/****[算法    突破一]********************************BEGIN********/
    	if(SCHEDULE_DETAIL_COUNT > 0){
    		/** [获取参数] 班表计划明细. */
    		List<Long> planDetailIdList = autoSchedule.getPlanDetailIdListByNoNull(PLAN_DETAIL_ID_LIST,PLAN_DETAIL_INFO_MAP);
    		/** [校验] 非空判断. */
    		if(planDetailIdList!=null && planDetailIdList.size()>0){
    			/** [遍历集合] 遍历班表计划明细，补足所有剩余未分配班次. */
            	for(int i = 0; i < planDetailIdList.size(); i ++){
            		Long planDetailId = planDetailIdList.get(i);
            		SchedulePlanDetail schedulePlanDetail = PLAN_DETAIL_INFO_MAP.get(planDetailId);
            		/** [获取参数] 获取排班日期以及剩余待分配班次数. */
            		Date planDate = schedulePlanDetail.getPlanDate();
            		Integer schedulePlanDetail_Num = schedulePlanDetail.getNum();
            		LOG.info("[算法突破]["+planDate+"]空班数:"+schedulePlanDetail_Num);
            		/** [获取参数] 重置坐席推荐码排序. */
            		Map<String, Integer> superiorCodeMap = autoSchedule.getSuperiorMapByAutoCode(SUPERIOR_LIST);
                	List<Long> staffIdList = autoSchedule.getStaffIdListByAutoCode(STAFF_ID_LIST, STAFF_INFO_MAP, superiorCodeMap, true);
                	/** [遍历集合] 遍历空班数，补足对应量的坐席. */
                	int staffNum = 0;
            		for(int j = 0; j < schedulePlanDetail_Num; j ++){
                    	Staff staff = new Staff();
                    	/** [遍历集合] 遍历坐席列表，筛选当前日期没有上班的人员. */
                		for(int k = staffNum; k < staffIdList.size(); k ++){
                			Long staffId = staffIdList.get(k);
                			Staff staffInfo = STAFF_INFO_MAP.get(staffId);
                			/** [获取参数] 已排班日期集合. */
                			List<Date> schedulingList = staffInfo.getSchedulingDates();
                			if(schedulingList == null){schedulingList = new ArrayList<Date>();}
                			/** [校验] 当日已排班则跳过. */
                			if(schedulingList.contains(planDate)){continue;}
                			/** [获取参数] 预置排班日期集合. */
                			List<Date> preShiftsList = staffInfo.getPreShiftsDates();
                			if(preShiftsList == null){preShiftsList = new ArrayList<Date>();}
                			/** [校验] 当日已排班则跳过. */
                			if(preShiftsList.contains(planDate)){continue;}
                			if( ( staffInfo.getSchedulingDates().size() + staffInfo.getPreShiftsDates().size() ) 
            						>= ( staffInfo.getSchedulingPlanShiftNum() + 1 )){continue;}
                			staff = staffInfo;
                			staffNum = k;
                			break;
                		}
                		/** [校验] 未获取到坐席则结束当前循环. */
                		if(staff == null || staff.getId() == null){break;}
                		LOG.info("[算法突破]["+j+"]:"+staff.getName()+"["+staffNum+"]");
                		/** [封装对象] 排班明细对象. */
                		ScheduleDetail scheduleDetail = packScheduleDetailForStaff(SCHEDULE_INFO, schedulePlanDetail, staff, DEP_INFO_MAP, SHIFT_INFO_MAP);
            			scheduleDetail.setRemark("[4]"+staff.getSchedulingPlanShiftNum());
            			STAFF_SCHEDULE_DETAIL_LIST.add(scheduleDetail);
                		/** [逻辑操作] 更新员工排班日期信息. */
        				if(staff.getSchedulingDates()==null){staff.setSchedulingDates(new ArrayList<Date>());}
        				staff.getSchedulingDates().add(schedulePlanDetail.getPlanDate());
        				STAFF_INFO_MAP.put(staff.getId(), staff);
        				/** [逻辑操作] 更新排班计划明细的人力需求信息. */
        				schedulePlanDetail.setNum(schedulePlanDetail.getNum() - 1);
        				PLAN_DETAIL_INFO_MAP.put(schedulePlanDetail.getId(), schedulePlanDetail);
        				staffNum += 1; 
            		}
            	}
    		}
    	}
    	/****[算法    突破一]******************************** END ********/
    	SCHEDULE_DETAIL_COUNT = queryScheduleDetailCount(PLAN_DETAIL_INFO_MAP);
    	LOG.info("[算法突破]剩余班次："+SCHEDULE_DETAIL_COUNT);
    	
    	/****[算法    休息阶段]********************************BEGIN********/
    	if(STAFF_SCHEDULE_DETAIL_LIST != null && STAFF_SCHEDULE_DETAIL_LIST.size() > 0){
    		List<Date> planDateList = autoSchedule.getDateListByAutoCode(SCHEDULE_BEGINTIME, SCHEDULE_ENDTIME);
        	List<ScheduleDetail> scheduleDetailInfo_Rest = AutoScheduleRestForStaff( SCHEDULE_INFO, SCHEDULE_PLAN_INFO, STAFF_INFO_MAP, planDateList,DEP_INFO_MAP);
        	STAFF_SCHEDULE_DETAIL_LIST.addAll(scheduleDetailInfo_Rest);
    	}
    	/****[算法    休息阶段]******************************** END ********/

    	/****[算法    换班阶段]********************************BEGIN********/
    	/** [获取参数] 需要排班的坐席列表. */
    	List<Long> needStaffList = autoSchedule.getStaffListByNeedSchedule(STAFF_INFO_MAP);
    	if(needStaffList != null && needStaffList.size() > 0){
    		Map<Long, Map<Date, ScheduleDetail>> staffDetailMap = autoSchedule.getDetailMapByStaffId(STAFF_SCHEDULE_DETAIL_LIST);
        	/** [获取参数] 打破排班计划的坐席列表. */
        	List<Long> breakStaffList = autoSchedule.getStaffListByBreakSchedule(STAFF_INFO_MAP);
        	if(breakStaffList != null && breakStaffList.size() > 0){
        		for(int i = 0; i < breakStaffList.size(); i ++){
        			/** [获取参数] 突破的坐席信息. */
        			Long breakStaffId = breakStaffList.get(i);
        			Staff breakStaffInfo = STAFF_INFO_MAP.get(breakStaffId);
        			Map<Date, ScheduleDetail> breakStaffDetailMap = staffDetailMap.get(breakStaffId);
        			
        			Staff needStaffInfo = null;
        			List<Date> changeDateList = null;
        			if(needStaffList == null || needStaffList.size() <= 0){break;}
        			for(int j = 0; j < needStaffList.size(); j ++){
        				/** [获取参数] 需要排班的坐席信息. */
            			Long needStaffId = needStaffList.get(j);
            			needStaffInfo = STAFF_INFO_MAP.get(needStaffId);
            			/** [比对参数] 获取可进行换班的日期. */
            			changeDateList = autoSchedule.getChangeDateListByStaff(breakStaffInfo, needStaffInfo);
            			if(changeDateList != null && changeDateList.size() > 0){
            				break;
            			}else{
            				needStaffInfo = null;
            				changeDateList = null;
            			}
        			}
        			if(needStaffInfo == null || changeDateList == null || changeDateList.size() <= 0){continue;}
        			Long needStaffId = needStaffInfo.getId();
        			Map<Date, ScheduleDetail> needStaffDetailMap = staffDetailMap.get(needStaffId);
        			
        			Date changeDate = changeDateList.get(0);
        			ScheduleDetail breakScheduleDetail = breakStaffDetailMap.get(changeDate);
        			ScheduleDetail needScheduleDetail = needStaffDetailMap.get(changeDate);
        			 
        			breakScheduleDetail = packScheduleStaffInfo(breakScheduleDetail, needStaffInfo);
        			needScheduleDetail = packScheduleStaffInfo(needScheduleDetail, breakStaffInfo);
        			
        			breakScheduleDetail.setRemark("[换]"+breakStaffInfo.getName());
        			needScheduleDetail.setRemark("[换]"+needStaffInfo.getName());
        			
        			breakStaffDetailMap.put(changeDate, breakScheduleDetail);
        			needStaffDetailMap.put(changeDate, needScheduleDetail);
        			
        			breakStaffInfo.getSchedulingDates().remove(changeDate);
        			needStaffInfo.getSchedulingDates().add(changeDate);
        			
        			STAFF_INFO_MAP.put(breakStaffId, breakStaffInfo);
        			STAFF_INFO_MAP.put(needStaffId, needStaffInfo);
        			
        			if( ( needStaffInfo.getSchedulingDates().size() + needStaffInfo.getPreShiftsDates().size() )
        					>= needStaffInfo.getSchedulingPlanShiftNum() ){
        				needStaffList.remove(needStaffId);
        			}
        		}
        	}
        	if(needStaffList.size() <= 0){
        		STAFF_SCHEDULE_DETAIL_LIST = new ArrayList<ScheduleDetail>();
        		for(Long staffId : staffDetailMap.keySet()){
        			Map<Date, ScheduleDetail> scheduleDetailMap = staffDetailMap.get(staffId);
        			for(Date planDate : scheduleDetailMap.keySet()){
        				ScheduleDetail scheduleDetail = scheduleDetailMap.get(planDate);
        				STAFF_SCHEDULE_DETAIL_LIST.add(scheduleDetail);
        			}
        		}
        	}
    	}
    	/****[算法    换班阶段]******************************** END ********/
    	
    	/****[班长    初排]********************************BEGIN********/
    	if(STAFF_SCHEDULE_DETAIL_LIST.size() > 0){
    		List<ScheduleDetail> LEADER_SCHEDULE_DETAIL_LIST = new ArrayList<ScheduleDetail>();
    		/** [获取参数] 班次排序表. */
    		Map<Long, Integer> SHIFTS_ORDER_MAP = queryShiftsOrderMap();
    		/** [数据库] 获取组长信息列表. */
    		List<Staff> leaderInfoList = QueryStaffList(JOB_TITLE_LEADER,SCHEDULE_INFO, SCHEDULE_PLAN_INFO, TREE_DEP_LIST, SERVER_TYPE_LIST);
    		if(leaderInfoList != null && leaderInfoList.size() > 0){
    			
    			
    			int leaderShiftsCount = leaderInfoList.size() * LEADER_PER_SHIFTS_NUM ;
    			/** [获取参数] 获取用户信息集合,坐席班务分配. */
    	    	Map<Long, Staff> LEADER_INFO_MAP = autoSchedule.getStaffInfoMapByPlanShiftNum(leaderInfoList,leaderShiftsCount);
    	    	
    			
    			/** [] 每日班长人数. */
    			Map<Date, Integer> planLeaderCountMap = new HashMap<Date, Integer>();
    			for(Date planDate : PLAN_DETAIL_COUNT_MAP.keySet()){
    				Integer planDetailCount = PLAN_DETAIL_COUNT_MAP.get(planDate);
    				int planLeaderNum = Math.round( ((float) planDetailCount / ALL_SCHEDULE_DETAIL_COUNT) * leaderShiftsCount );
    				planLeaderCountMap.put(planDate, planLeaderNum);
    			}
    			Map<Long, List<Staff>> leaderStaffInfoMap = autoSchedule.getLeaderStaffInfoMap(STAFF_INFO_MAP, leaderInfoList);
    			
    			/** [] . */
    			for(Date planDate : planLeaderCountMap.keySet()){
    				/** [获取参数] 当日上班坐席组内占比，倒序排列. */
    				List<Long> leaderProportionList = autoSchedule.getLeaderProportionByPlanDateDesc(planDate, leaderStaffInfoMap);
    				for(int i = 0; i < leaderInfoList.size(); i ++){
    					Staff oneStaff = leaderInfoList.get(i);
    					if(!leaderProportionList.contains(oneStaff.getId())){
    						leaderProportionList.add(oneStaff.getId());
    					}
    				}
    				Integer planLeaderCount = planLeaderCountMap.get(planDate);
    				for(int i = 0; i < planLeaderCount; i ++){
    					Long leaderId = leaderProportionList.get(i);
    					Staff leaderInfo = LEADER_INFO_MAP.get(leaderId);
    					
    					List<Date> leaderSchedulingDate = leaderInfo.getSchedulingDates();
    					if(leaderSchedulingDate == null ){leaderSchedulingDate = new ArrayList<Date>();}
    					
    					if(leaderSchedulingDate.size() >= leaderInfo.getSchedulingPlanShiftNum()){continue;}
    					
    					leaderSchedulingDate.add(planDate);
    					leaderInfo.setSchedulingDates(leaderSchedulingDate);
    					LEADER_INFO_MAP.put(leaderId, leaderInfo);
    					
    				}
    			}
    			
    			Map<Date, Map<Long, Long>> staffShiftsProporMap = autoSchedule.getStaffShiftsProportionByLeader(STAFF_SCHEDULE_DETAIL_LIST, STAFF_INFO_MAP, leaderInfoList);
    			if(staffShiftsProporMap!=null && staffShiftsProporMap.size()>0){
    				for(Long staffId : LEADER_INFO_MAP.keySet()){
    					Staff leaderInfo = LEADER_INFO_MAP.get(staffId);
    					List<Date> leaderPlanDateList = leaderInfo.getSchedulingDates();
    					for(int i = 0; i < leaderPlanDateList.size(); i ++){
    						Date planDate = leaderPlanDateList.get(i);
    						Long leaderShiftsId = staffShiftsProporMap.get(planDate).get(leaderInfo.getId());
    						Shifts shiftsInfo = SHIFT_INFO_MAP.get(leaderShiftsId);
    						ScheduleDetail scheduleDetailForLeader = packScheduleDetailForLeader(SCHEDULE_INFO, leaderInfo, planDate, shiftsInfo, DEP_INFO_MAP);
    						scheduleDetailForLeader.setRemark("[班]");
    						LEADER_SCHEDULE_DETAIL_LIST.add(scheduleDetailForLeader);
    					}
    					
    				}
    			}else{
    				for(Long staffId : LEADER_INFO_MAP.keySet()){
    					Staff leaderInfo = LEADER_INFO_MAP.get(staffId);
    					List<Date> leaderPlanDateList = leaderInfo.getSchedulingDates();
    					for(int i = 0; i < leaderPlanDateList.size(); i ++){
    						Date planDate = leaderPlanDateList.get(i);
    						Long leaderShiftsId = staffShiftsProporMap.get(planDate).get(leaderInfo.getId());
    						Shifts shiftsInfo = SHIFT_INFO_MAP.get(leaderShiftsId);
    						ScheduleDetail scheduleDetailForLeader = packScheduleDetailForLeader(SCHEDULE_INFO, leaderInfo, planDate, shiftsInfo, DEP_INFO_MAP);
    						scheduleDetailForLeader.setRemark("[班]");
    						LEADER_SCHEDULE_DETAIL_LIST.add(scheduleDetailForLeader);
    					}
    					
    				}
    			}
    			
    			System.out.println("GREG[班]"+LEADER_SCHEDULE_DETAIL_LIST.size());
    			STAFF_SCHEDULE_DETAIL_LIST = new ArrayList<ScheduleDetail>();
    			STAFF_SCHEDULE_DETAIL_LIST.addAll(LEADER_SCHEDULE_DETAIL_LIST);
    		}
    	}
    	/****[班长   初排]******************************** END ********/
    	
    	if(STAFF_SCHEDULE_DETAIL_LIST.size() > 0){
    		/** [数据库] 删除历史数据. */
        	boolean result = scheduleDetailService.deleteBySid(S_ID);
        	LOG.info("[自动排班]清空历史："+result);
        	/** [数据库] 写入数据. */
        	result = scheduleDetailService.inserts(STAFF_SCHEDULE_DETAIL_LIST);
        	LOG.info("[自动排班]写入数据：["+STAFF_SCHEDULE_DETAIL_LIST.size()+"]"+result);
        	return getResultJson(true, SUCCESS_MESSAGE, STAFF_SCHEDULE_DETAIL_LIST);
    	}else{
    		return getResultJson(false, ERROR_MESSAGE_9999, null);
    	}
    }
    
    /**
     * 分配休息天数
     * @param scheduleInfo
     * @param schedulePlanInfo
     * @param staffList
     * @param planDateList
     * @param depInfoMap
     * @return
     */
    private List<ScheduleDetail> AutoScheduleRestForStaff(Schedule scheduleInfo,SchedulePlan schedulePlanInfo,
    		Map<Long, Staff> staffInfoMap, List<Date> planDateList, Map<Long, Dep> depInfoMap){
    	List<ScheduleDetail> HolidayScheduleDetailList = new ArrayList<ScheduleDetail>();
    	/** [获取参数] 登陆用户名、总班表编号、部门编号、部门名称、业务线编号、业务线名称、当前系统时间. */
    	String loginUserName = getLoginUserName();
    	Long sId = scheduleInfo.getId();
    	Long depId = schedulePlanInfo.getDepId();
    	Dep depInfo = depInfoMap.get(depId);
    	String depName = depInfo.getName();
    	Long busId = schedulePlanInfo.getBusId();
    	String busName = scheduleInfo.getBusName();
    	Date NowDate = new Date();
    	/** [获取参数] 获取名为休息的班次信息. */
    	Shifts shiftsInfo = shiftsService.getShiftsByName(SHIFTS_NAME_HOLIDAY);
    	Long shiftsId = shiftsInfo.getId();
    	String shiftsName = shiftsInfo.getShiftsName();
    	/** [遍历集合] 遍历坐席，获取已排班周期，根据班表开始结束日期去重后，全部补为休息. */
    	for(Long staffId : staffInfoMap.keySet()){
    		Staff staff = staffInfoMap.get(staffId);
    		List<Date> schedulingDateList = staff.getSchedulingDates();
    		List<Date> preShiftsDateList = staff.getPreShiftsDates();
    		
    		List<Date> staffNoScheduleDates = new ArrayList<Date>();
    		staffNoScheduleDates.addAll(planDateList);
    		if(schedulingDateList!=null && schedulingDateList.size()>0){
    			staffNoScheduleDates.removeAll(schedulingDateList);
    		}
    		if(preShiftsDateList!=null && preShiftsDateList.size()>0){
    			staffNoScheduleDates.removeAll(preShiftsDateList);
    		}
    		if(staffNoScheduleDates.size()>0){
    			for(int i=0; i<staffNoScheduleDates.size(); i++){
        			ScheduleDetail scheduleDetail = new ScheduleDetail();
        			scheduleDetail.setCreateUser(loginUserName); // 创建人
        			scheduleDetail.setCreateTime(NowDate); // 创建时间
        			scheduleDetail.setsId(sId); // 班表编号
        			scheduleDetail.setDep(depInfo);
        			scheduleDetail.setDepId(depId); // 部门编号
        			scheduleDetail.setDepName(depName); // 部门名称
        			scheduleDetail.setBusId(busId); // 业务编号
        			scheduleDetail.setBusName(busName); // 业务名称
        			scheduleDetail.setShifts(shiftsInfo);
        			scheduleDetail.setShiftsId(shiftsId); // 班档编号
        			scheduleDetail.setShiftsName(shiftsName); // 班档名称
        			scheduleDetail.setJobTitleName(JOB_TITLE_STAFF);
        			scheduleDetail.setPlanDate(staffNoScheduleDates.get(i));
        			scheduleDetail.setYn(1);
                	scheduleDetail.setStaffId(staff.getId());
                	scheduleDetail.setuName(staff.getName());
                	String OneCsId = staff.getCsId();
                	if(OneCsId == null){OneCsId = "";}
                	scheduleDetail.setCsId(OneCsId);
                	String OneSuperior = staff.getSuperior();
                	if(OneSuperior==null){OneSuperior = "";}
                	scheduleDetail.setLeaderName(OneSuperior);
                	
                	HolidayScheduleDetailList.add(scheduleDetail);
        		}
    		}
    	}
    	return HolidayScheduleDetailList;
    }
    
    /**
     * 分配休息天数
     * @param scheduleInfo
     * @param schedulePlanInfo
     * @param staffList
     * @param planDateList
     * @param depInfoMap
     * @return
     */
    private List<ScheduleDetail> AutoScheduleRestForLeader(Schedule scheduleInfo,SchedulePlan schedulePlanInfo,
    		Map<Long, Staff> staffInfoMap, List<Date> planDateList, Map<Long, Dep> depInfoMap){
    	List<ScheduleDetail> HolidayScheduleDetailList = new ArrayList<ScheduleDetail>();
    	/** [获取参数] 登陆用户名、总班表编号、部门编号、部门名称、业务线编号、业务线名称、当前系统时间. */
    	String loginUserName = getLoginUserName();
    	Long sId = scheduleInfo.getId();
    	Long depId = schedulePlanInfo.getDepId();
    	Dep depInfo = depInfoMap.get(depId);
    	String depName = depInfo.getName();
    	Long busId = schedulePlanInfo.getBusId();
    	String busName = scheduleInfo.getBusName();
    	Date NowDate = new Date();
    	/** [获取参数] 获取名为休息的班次信息. */
    	Shifts shiftsInfo = shiftsService.getShiftsByName(SHIFTS_NAME_HOLIDAY);
    	Long shiftsId = shiftsInfo.getId();
    	String shiftsName = shiftsInfo.getShiftsName();
    	/** [遍历集合] 遍历坐席，获取已排班周期，根据班表开始结束日期去重后，全部补为休息. */
    	for(Long staffId : staffInfoMap.keySet()){
    		Staff staff = staffInfoMap.get(staffId);
    		List<Date> schedulingDateList = staff.getSchedulingDates();
    		List<Date> preShiftsDateList = staff.getPreShiftsDates();
    		
    		List<Date> staffNoScheduleDates = new ArrayList<Date>();
    		staffNoScheduleDates.addAll(planDateList);
    		if(schedulingDateList!=null && schedulingDateList.size()>0){
    			staffNoScheduleDates.removeAll(schedulingDateList);
    		}
    		if(preShiftsDateList!=null && preShiftsDateList.size()>0){
    			staffNoScheduleDates.removeAll(preShiftsDateList);
    		}
    		if(staffNoScheduleDates.size()>0){
    			for(int i=0; i<staffNoScheduleDates.size(); i++){
        			ScheduleDetail scheduleDetail = new ScheduleDetail();
        			scheduleDetail.setCreateUser(loginUserName); // 创建人
        			scheduleDetail.setCreateTime(NowDate); // 创建时间
        			scheduleDetail.setsId(sId); // 班表编号
        			scheduleDetail.setDep(depInfo);
        			scheduleDetail.setDepId(depId); // 部门编号
        			scheduleDetail.setDepName(depName); // 部门名称
        			scheduleDetail.setBusId(busId); // 业务编号
        			scheduleDetail.setBusName(busName); // 业务名称
        			scheduleDetail.setShifts(shiftsInfo);
        			scheduleDetail.setShiftsId(shiftsId); // 班档编号
        			scheduleDetail.setShiftsName(shiftsName); // 班档名称
        			scheduleDetail.setJobTitleName(JOB_TITLE_LEADER);
        			scheduleDetail.setPlanDate(staffNoScheduleDates.get(i));
        			scheduleDetail.setYn(1);
                	scheduleDetail.setStaffId(staff.getId());
                	scheduleDetail.setuName(staff.getName());
                	String OneCsId = staff.getCsId();
                	if(OneCsId == null){OneCsId = "";}
                	scheduleDetail.setCsId(OneCsId);
                	String OneSuperior = staff.getSuperior();
                	if(OneSuperior==null){OneSuperior = "";}
                	scheduleDetail.setLeaderName(OneSuperior);
                	
                	HolidayScheduleDetailList.add(scheduleDetail);
        		}
    		}
    	}
    	return HolidayScheduleDetailList;
    }
    
    /**
     * 封装班表明细信息-坐席的
     * @param schedule
     * @param schedulePlanDetail
     * @param staff
     * @param depInfoMap
     * @param shiftsInfoMap
     * @return
     */
    private ScheduleDetail packScheduleDetailForStaff (Schedule schedule,SchedulePlanDetail schedulePlanDetail,
    		Staff staff,Map<Long, Dep> depInfoMap,Map<Long, Shifts> shiftsInfoMap){
    	ScheduleDetail scheduleDetail = new ScheduleDetail();
    	if(schedule != null && schedulePlanDetail != null){
    		scheduleDetail.setCreateUser(getLoginUserName()); // 创建人
    		scheduleDetail.setCreateTime(new Date()); // 创建时间
    		scheduleDetail.setsId(schedule.getId()); // 班表编号
    		Long depId = staff.getDep().getId();
    		scheduleDetail.setDepId(depId); // 部门编号
    		Dep depInfo = depInfoMap.get(depId);
    		String depName = depInfo.getName();
    		scheduleDetail.setDep(depInfo);
    		scheduleDetail.setDepName(depName); // 部门名称
    		scheduleDetail.setBusId(schedulePlanDetail.getBusId().longValue()); // 业务编号
    		scheduleDetail.setBusName(schedule.getBusName()); // 业务名称
    		Long shiftsId = schedulePlanDetail.getShifts().getId();
    		scheduleDetail.setShiftsId(shiftsId); // 班制编号
    		Shifts shiftsInfo = shiftsInfoMap.get(shiftsId);
    		String shiftsName = shiftsInfo.getShiftsName();
    		scheduleDetail.setShifts(shiftsInfo);
    		scheduleDetail.setShiftsName(shiftsName);// 班制名称
    		scheduleDetail.setJobTitleName(JOB_TITLE_STAFF);
    		scheduleDetail.setPlanDate(schedulePlanDetail.getPlanDate());
    		scheduleDetail.setYn(1);
    	}
    	if(staff != null){ 
    		scheduleDetail.setStaffId(staff.getId());
        	scheduleDetail.setuName(staff.getName());
        	String OneCsId = staff.getCsId();
        	if(OneCsId == null){OneCsId = "";}
        	scheduleDetail.setCsId(OneCsId);
        	String OneSuperior = staff.getSuperior();
        	if(OneSuperior==null){OneSuperior = "";}
        	scheduleDetail.setLeaderName(OneSuperior);
    	}
		return scheduleDetail;
    }
    
    /**
     * 封装班表明细信息-班长的
     * @param schedule
     * @param schedulePlanDetail
     * @param staff
     * @param depInfoMap
     * @param shiftsInfoMap
     * @return
     */
    private ScheduleDetail packScheduleDetailForLeader (Schedule schedule,
    		Staff leader, Date planDate ,Shifts shiftsInfo,Map<Long, Dep> depInfoMap){
    	ScheduleDetail scheduleDetail = new ScheduleDetail();
    	if(schedule != null){
    		scheduleDetail.setCreateUser(getLoginUserName()); // 创建人
    		scheduleDetail.setCreateTime(new Date()); // 创建时间
    		scheduleDetail.setsId(schedule.getId()); // 班表编号
    		Long depId = leader.getDep().getId();
    		scheduleDetail.setDepId(depId); // 部门编号
    		Dep depInfo = depInfoMap.get(depId);
    		String depName = depInfo.getName();
    		scheduleDetail.setDep(depInfo);
    		scheduleDetail.setDepName(depName); // 部门名称
    		scheduleDetail.setBusId(schedule.getBusId()); // 业务编号
    		scheduleDetail.setBusName(schedule.getBusName()); // 业务名称
    		scheduleDetail.setShiftsId(shiftsInfo.getId()); // 班制编号
    		String shiftsName = shiftsInfo.getShiftsName();
    		scheduleDetail.setShifts(shiftsInfo);
    		scheduleDetail.setShiftsName(shiftsName);// 班制名称
    		scheduleDetail.setJobTitleName(JOB_TITLE_LEADER);
    		scheduleDetail.setPlanDate(planDate);
    		scheduleDetail.setYn(1);
    	}
    	if(leader != null){ 
    		scheduleDetail.setStaffId(leader.getId());
        	scheduleDetail.setuName(leader.getName());
        	String OneCsId = leader.getCsId();
        	if(OneCsId == null){OneCsId = "";}
        	scheduleDetail.setCsId(OneCsId);
        	String OneSuperior = leader.getSuperior();
        	if(OneSuperior==null){OneSuperior = "";}
        	scheduleDetail.setLeaderName(OneSuperior);
    	}
		return scheduleDetail;
    }
    
    /**
     * 封装班表明细信息
     * @param schedule
     * @param schedulePlanDetail
     * @param staff
     * @param depInfoMap
     * @param shiftsInfoMap
     * @return
     */
    private ScheduleDetail packScheduleStaffInfo (ScheduleDetail scheduleDetail,Staff staff){
    	if(scheduleDetail != null && staff != null){ 
    		scheduleDetail.setStaffId(staff.getId());
        	scheduleDetail.setuName(staff.getName());
        	String OneCsId = staff.getCsId();
        	if(OneCsId == null){OneCsId = "";}
        	scheduleDetail.setCsId(OneCsId);
        	String OneSuperior = staff.getSuperior();
        	if(OneSuperior==null){OneSuperior = "";}
        	scheduleDetail.setLeaderName(OneSuperior);
    	}
		return scheduleDetail;
    }
    
    /**
     * 查询可分配坐席明细，带随机码的
     * @param OneSchedule
     * @param OneSchedulePlan
     * @param DepChildList
     * @param JobTypeList
     * @return
     */
    private List<Staff> QueryStaffList(String jobTitleName,
    		Schedule OneSchedule,SchedulePlan OneSchedulePlan,
    		List<Dep> DepChildList,List<Dic> JobTypeList){
    	StaffQuery queryInfo = new StaffQuery();
    	queryInfo.setPositionStatus(STAFF_POSITION_STATUS_NORMAL);
    	queryInfo.setService(OneSchedulePlan.getBusId().intValue());
    	
    	Long OneDepId = OneSchedulePlan.getDepId();
    	if(DepChildList!=null && DepChildList.size()>0){
    		String OneDepIds = "'"+OneDepId+"'";
    		for(int i=0;i<DepChildList.size();i++){
        		OneDepIds += ",'" + DepChildList.get(i).getId() + "'";
    		}
    		queryInfo.setDepIds(OneDepIds);
    	}else{
    		queryInfo.setDepId(OneDepId.intValue());
    	}
    	if(JobTypeList!=null && JobTypeList.size()>0){
    	    String OneJobTitles = "";
    	    String OneJobTitle = "";
    		for(int i=0;i<JobTypeList.size();i++){
        		Dic OneJobTypeInfo = JobTypeList.get(i);
        		if(OneJobTypeInfo.getName().trim().equals(jobTitleName)){
        			OneJobTitles += "'" + JobTypeList.get(i).getNum() + "',";
        			if(OneJobTitle.trim().equals("")){
        				OneJobTitle = JobTypeList.get(i).getNum().toString();
        			}
        		}
        	}
        	OneJobTitles = OneJobTitles.substring(0,OneJobTitles.length()-1);
        	if(OneJobTitles.indexOf(",")!=-1){
        		queryInfo.setJobTitles(OneJobTitles);
        	}else{
        		queryInfo.setJobTitle(OneJobTitle);
        	}
    	}
		List<Staff> staffList = staffService.queryStaffList(queryInfo);
		return staffList;
	}
    
    /**
     * 查询预置班次列表
     * @param schedule
     * @param schedulePlan
     * @param DepChildList
     * @param JobTypeList
     * @return
     */
    private List<PreShifts> queryPreShiftList (String jobTitleName,
    		Schedule schedule,SchedulePlan schedulePlan,
    		List<Dep> DepChildList,List<Dic> JobTypeList){
    	PreShiftsQuery queryInfo = new PreShiftsQuery();
    	queryInfo.setBusId(schedulePlan.getBusId());
    	queryInfo.setStatus(FINISH_STATUS_PRE_SHIFTS);
    	Long OneDepId = schedulePlan.getDepId();
    	if(DepChildList!=null && DepChildList.size()>0){
    		String OneDepIds = "'"+OneDepId+"'";
    		for(int i=0;i<DepChildList.size();i++){
        		OneDepIds += ",'" + DepChildList.get(i).getId() + "'";
    		}
    		queryInfo.setDepIds(OneDepIds);
    	}else{
    		queryInfo.setDepId(OneDepId);
    	}
    	if(JobTypeList!=null && JobTypeList.size()>0){
    	    String OneJobTitles = "";
    	    String OneJobTitle = "";
    		for(int i=0;i<JobTypeList.size();i++){
        		Dic OneJobTypeInfo = JobTypeList.get(i);
        		if(OneJobTypeInfo.getName().trim().equals(jobTitleName)){
        			OneJobTitles += "'" + JobTypeList.get(i).getNum() + "',";
        			if(OneJobTitle.trim().equals("")){
        				OneJobTitle = JobTypeList.get(i).getNum().toString();
        			}
        		}
        	}
        	OneJobTitles = OneJobTitles.substring(0,OneJobTitles.length()-1);
        	if(OneJobTitles.indexOf(",")!=-1){
        		queryInfo.setJobTitles(OneJobTitles);
        	}else{
        		queryInfo.setJobTitle(OneJobTitle);
        	}
    	}
    	/** [获取参数] 排班计划开始时间. */
    	Date SCHEDULE_BEGINTIME = schedulePlan.getBeginTime();
    	/** [校验] 排班计划开始时间不得在当前系统时间之前. */
    	AutoSchedule autoSchedule = new AutoSchedule();
    	SCHEDULE_BEGINTIME = autoSchedule.getScheduleBeginTime(SCHEDULE_BEGINTIME);
    	/** [获取参数] 排班计划结束时间. */
    	Date SCHEDULE_ENDTIME = schedulePlan.getEndTime();
    	queryInfo.setStartPlanDate(autoSchedule.formatDate(SCHEDULE_BEGINTIME));
    	queryInfo.setEndPlanDate(autoSchedule.formatDate(SCHEDULE_ENDTIME));
    	
    	List<PreShifts> queryPreShiftList = preShiftsService.queryPreShiftsList(queryInfo);
    	return queryPreShiftList;
    }

    /**
     * 通过部门ID获取该部门所有子部门的集合
     * @param depId
     * @return
     */
    private List<Dep> queryTreeDepListByDepId(Long depId){
    	List<Dep> OneDepChildList = new ArrayList<>();
        if(depId!=null){
            Dep dep=depService.getDepById(depId);
            if(dep !=null){
                DepQuery OneQuery_Dep = new DepQuery();
                OneQuery_Dep.setUpperCode(dep.getCode());
                OneDepChildList = depService.queryDepList(OneQuery_Dep);
            }
        }
    	return OneDepChildList;
    }
    
    /**
     * 获取岗位为“坐席”的字典表编号
     * @return
     */
    private List<Dic> queryServerTypeList (String jobTitleName){
    	List<Dic> OneJobTypeList = new ArrayList<Dic>();
    		DicQuery OneQuery_Dic = new DicQuery();
        	OneQuery_Dic.setParentNum(SERVER_JOB_CODE);
        	OneQuery_Dic.setName(jobTitleName);
        	OneJobTypeList = dicService.queryDicList(OneQuery_Dic);
    	return OneJobTypeList;
    }
    
    /**
     * 获取班次计划明细表信息
     * @param schedulePlan
     * @return
     */
    private List<SchedulePlanDetail> querySchedulePlanDetailList(SchedulePlan schedulePlan){
    	List<SchedulePlanDetail> schedulePlanDetailList = new ArrayList<SchedulePlanDetail>();
    	if(schedulePlan!=null){
    		SchedulePlanDetailQuery queryWhere = new SchedulePlanDetailQuery();
    		queryWhere.setSpId(schedulePlan.getId());
    		queryWhere.setDepId(schedulePlan.getDepId());
    		queryWhere.setBusId(schedulePlan.getBusId().intValue());
        	schedulePlanDetailList = schedulePlanDetailService.querySchedulePlanDetailList(queryWhere);
    	}
    	return schedulePlanDetailList;
    }
    
    /**
     * 获取班制计划未排班的班次总数
     * @param schedulePlanDetailList
     * @return
     */
    private Integer queryScheduleDetailCount(Map<Long, SchedulePlanDetail> planDetailInfoMap){
    	Integer resultCount = 0;
    	if(planDetailInfoMap!=null && planDetailInfoMap.size()>0){
    		for(Long planDetailId : planDetailInfoMap.keySet()){
    			resultCount += planDetailInfoMap.get(planDetailId).getNum();
    		}
    	}
    	return resultCount;
    }
    
    /**
     * 获取班制计划未排班的班次总数
     * @param schedulePlanDetailList
     * @return
     */
    private Integer queryScheduleDetailCountByIds(Map<Long, SchedulePlanDetail> planDetailInfoMap,List<Long> planDetailIdList){
    	Integer resultCount = 0;
    	if(planDetailIdList!=null && planDetailIdList.size()>0){
    		for(int i=0;i<planDetailIdList.size();i++){
    			Long planDetailId = planDetailIdList.get(i);
    			SchedulePlanDetail schedulePlanDetail = planDetailInfoMap.get(planDetailId);
    			if(schedulePlanDetail!=null && schedulePlanDetail.getNum()!=null){
    				resultCount += schedulePlanDetail.getNum();
    			}
    		}
    	}
    	return resultCount;
    }
    
    /**
     * 获取班制字典信息
     * @param shiftsList
     * @return
     */
    private Map<Long, Shifts> queryShiftsInfoMap(List<Shifts> shiftsList){
    	Map<Long, Shifts> resultMap = new HashMap<Long, Shifts>();
    	if(shiftsList!=null && shiftsList.size()>0){
    		for(Shifts shifts : shiftsList){
    			resultMap.put(shifts.getId(), shifts);
    		}
    	}
    	return resultMap;
    }
    /**
     * 获取所属部门信息的集合
     * @param TREE_DEP_LIST
     * @return
     */
    private Map<Long, Dep> queryTreeDepInfoMap(Schedule scheduleInfo,List<Dep> TREE_DEP_LIST){
    	Map<Long, Dep> resultMap = new HashMap<Long, Dep>();
    	if(TREE_DEP_LIST!=null && TREE_DEP_LIST.size()>0){
    		for(Dep dep : TREE_DEP_LIST){
    			resultMap.put(dep.getId(), dep);
    		}
    	}
    	if(scheduleInfo!=null){
    		Dep dep = depService.getDepById(scheduleInfo.getDepId());
    		resultMap.put(dep.getId(), dep);
    	}
    	return resultMap;
    }
    
    private static final double MORE_SHITFS_PROPORTION = 0.5;
    
    private Integer getPreShiftsNum(String jobTitleName, Integer scheduleDetailCount, Integer staffCount){
    	Integer result = null;
    	if(scheduleDetailCount != null && staffCount != null){
    		if(JOB_TITLE_STAFF.equals(jobTitleName)){
        		result = (scheduleDetailCount / staffCount) + 1;
        	}else if(JOB_TITLE_LEADER.equals(jobTitleName)){
        		result = scheduleDetailCount / staffCount ;
        		if( (scheduleDetailCount % staffCount) >= (staffCount * MORE_SHITFS_PROPORTION)){result += 1;}
        	}
    	}
    	return result;
    }
    
    private Map<Long, Integer> queryShiftsOrderMap(){
    	Map<Long, Integer> resultMap = new HashMap<Long, Integer>();
    	ShiftsQuery query = new ShiftsQuery();
    	query.setStatus(1);
    	List<Shifts> shiftsList = shiftsService.queryShiftsListByMinBeginTime(query);
    	if(shiftsList != null && shiftsList.size() > 0){
    		for(int i = 0;i< shiftsList.size(); i ++){
    			Shifts shiftsInfo = shiftsList.get(i);
    			Long shiftsId = shiftsInfo.getId();
    			resultMap.put(shiftsId, i);
    		}
    	}
    	return resultMap;
    }
    
    private double queryPreShiftProportion(){
    	double result = 1.0;
    	ThresholdValue thresholdValue = new ThresholdValue();
    	thresholdValue = thresholdValueService.getInfoByCode(ThresholdValue.SCHEDULING_FIRST_PRE_SHIFTS_PROPORTION);
    	if(thresholdValue!=null){
    		result = Double.valueOf(thresholdValue.getValue());
    	}
    	return result;
    }
    
    /**
     * 获取响应JSON字符串
     * @param result
     * @param message
     * @param detailList
     * @return
     */
    private String getResultJson (boolean result, String message, List<ScheduleDetail> detailList){
    	Map<String, Object> resultMap = new HashMap<String, Object>();
    	if(result){
    		resultMap.put("code", Wrapper.SUCCESS_CODE);
    	}else{
    		resultMap.put("code", Wrapper.ERROR_CODE);
    	}
    	resultMap.put("message", message);
    	if(detailList != null && detailList.size() > 0){
    		AutoSchedule autoSchedule = new AutoSchedule();
    		detailList = autoSchedule.getDetailListByStaffIdAsc(detailList);
    	}
    	resultMap.put("result", detailList);
    	return JsonHelper.toJson(resultMap);
    }
    
}
