package com.letv.css.portal.controller.scheduling.apply;

import com.alibaba.fastjson.JSONObject;
import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.service.*;
import com.letv.css.portal.domain.vo.workflow.bean.NewInstanceParam;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
* @author yxh
* @date  2017/10/23  11:32
* @version V1.0
*/
@Controller
@RequestMapping("workflow")
public class PreShiftsApplyController extends BaseController {
    private static final Log LOG = LogFactory.getLog(PreShiftsApplyController.class);

    /**
     * 视图前缀
     */
    private static final String viewPrefix = "workflow";

    @Autowired
    private ApprovalManageService approvalManageService;

    @Autowired
    private JsonDataService jsonDataService;

    @Autowired
    private ScheduleApplyController scheduleApplyController;
    @Autowired
    private DepService depService;
    @Autowired
    private PreShiftsService preShiftsService;

    /**
     * 預置班次审批展示
     * url:preShifts?id=&flowId=bpoPreShifts&statusId=requested&instanceId=298&outId=208&adjustId=&isDetail=1
     *
     * @param
     * @return
     */
    @RequestMapping("preShifts")
    public String preShiftsDetail(Model model, String isDetail, Staff staff, NewInstanceParam p) {
        try {
            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isDetail", isDetail);
            if (isDetail != null && "2".equals(isDetail)) {
                model.addAttribute("isCanSelect", "1");//可以修改
            }
            //查询审批信息
            bpoPreShiftsJsonModel(model, p);
            //历史信息
            scheduleApplyController.setFlowHistoryInModel(model, p);
        } catch (Exception e) {
            LOG.error("preShiftsDetail has error.", e);
        }
        if (org.apache.commons.lang3.StringUtils.isNotEmpty(isDetail) && "2".equals(isDetail)) {
            return viewPrefix + "/" + "preShiftsDetail";
        } else {
            return viewPrefix + "/" + "preShifts";
        }
    }


    /**
     * 預置班次审批
     */
    private void bpoPreShiftsJsonModel(Model model, NewInstanceParam p) {
        JsonData jsonData = jsonDataService.getById(Long.parseLong(p.getOutId()));
        JSONObject jsonObj = JSONObject.parseObject(jsonData.getJsonData());

        String depId = jsonObj.get("depId").toString();
        Dep dep = null;
        if (org.apache.commons.lang3.StringUtils.isNotEmpty(depId.trim())) {
            dep = depService.getDepById(Long.parseLong(depId));
        }
        model.addAttribute("depId", depId);
        model.addAttribute("depName", dep == null ? "" : dep.getName());
        model.addAttribute("name", jsonObj.get("name").toString());
        model.addAttribute("business", jsonObj.get("business").toString());
        model.addAttribute("shifts", jsonObj.get("shifts").toString());
        model.addAttribute("preShiftsDate", jsonObj.get("preShiftsDate").toString());
        model.addAttribute("preShiftsReason", jsonObj.get("preShiftsReason").toString());
    }

    /**
     * BPo支援工单BPO审核
     *
     * @param model
     * @param p
     * @return
     */
    @RequestMapping(value = "applyPreShifts")
    @ResponseBody
    public Wrapper applyPreShifts(Model model, NewInstanceParam p) {
        HashMap wfs = null;
        try {
            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isCanSelect", "0");//可以修改
            //工作流向下走一步
            wfs = scheduleApplyController.workFlowStepNext(p, wfs);
            String responseStatus = (String) wfs.get("status");

            PreShifts preShifts = null;
            List<ApprovalManage> list = approvalManageService.queryAppManageList(Long.parseLong(p.getOutId()));
            if (list != null && list.size() > 0) {
                preShifts = preShiftsService.getPreShiftsById(list.get(0).getSiId());
            }
            Integer status = 0;

            if ("0".equals(responseStatus)) {
                //首次同意时确认同意的数据
                if ("requested".equals(p.getStatusId()) && "allow".equals(p.getActionId())) {
                    //更新是否已经确认，更新完成
                    if (StringUtils.isNotBlank(p.getOutId())) {//JD_ID
                        approvalManageService.updateByJdId(p.getOutId());
                    }
                    status = 3;
                } else {
                    //更新完成
                    if (StringUtils.isNotBlank(p.getOutId())) {//JD_ID
                        approvalManageService.updateFinishByJdId(p.getOutId());
                    }
                    status = 2;
                }
                if (preShifts != null) {
                    //用于记录审核人
                    preShifts.setUpdateUser(p.getOperator());
                    preShifts.setUpdateTime(new Date());
                    preShifts.setStatus(status);
                    //更改pre_shifts信息
                    preShiftsService.update(preShifts);
                }

            } else {
                return error();
            }
        } catch (Exception e) {
            LOG.error(" applyPreShifts has error.", e);
            return error();
        }
        return new Wrapper<HashMap>().result((HashMap) wfs.get("result"));
    }

}
