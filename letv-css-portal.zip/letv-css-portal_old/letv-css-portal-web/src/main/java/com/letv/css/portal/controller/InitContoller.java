package com.letv.css.portal.controller;

import java.util.Date;
import java.util.List;

import com.letv.css.portal.domain.constant.enums.EventConstants;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.domain.query.UserQuery;
import com.letv.css.portal.service.CommonQueueService;
import com.letv.css.portal.service.UserService;

@Controller
@RequestMapping("init")
public class InitContoller extends  BaseController{

	@Autowired
	UserService userService;
	@Autowired
	CommonQueueService commonQueueService;
	@RequestMapping(value = "")
	@ResponseBody
	public Wrapper<?> index(){
		Wrapper<String> w=new Wrapper<String>();
		List<User> ulist=userService.queryUserList(new UserQuery());
		if(CollectionUtils.isEmpty(ulist)){
			return error();
		}
		for(User u:ulist){
			CommonQueue commonQueue=new CommonQueue();
			commonQueue.setEventId(EventConstants.EVENT_STAFF_ADD);
			commonQueue.setOnlyId(u.getId());
			commonQueue.setCreatedBy(String.valueOf(u.getId()));
			commonQueue.setOnlyType("init add user id");
			commonQueue.setCreationDate(new Date());
			commonQueue.setStatus(0);
			commonQueue.setRequestRemake("初始化添加");
			commonQueueService.insert(commonQueue);
		}
		w.setResult("ok");
		return w;
	}
	
	@RequestMapping(value = "initUserRole")
	@ResponseBody
	public Wrapper<?> initUserRole(){
		Wrapper<String> w=new Wrapper<String>();
		List<User> ulist=userService.queryUserList(new UserQuery());
		if(CollectionUtils.isEmpty(ulist)){
			return error();
		}
		for (User u : ulist) { 
			CommonQueue commonQueue = new CommonQueue();
			commonQueue.setOnlyId(u.getId());
			commonQueue.setCreatedBy(String.valueOf(u.getId()));
			commonQueue.setEventId(EventConstants.EVENT_ROLE);
			commonQueue.setChangeDate(new Date());
			commonQueue.setOnlyType("initUserRole uesr id add");
			commonQueue.setStatus(0);
			commonQueue.setRequestRemake("init add");
			commonQueueService.insert(commonQueue);
		}
	w.setResult("ok");
	return w;
	}
}
