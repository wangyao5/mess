package com.letv.css.portal.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.Resource;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.domain.query.UserQuery;
import com.letv.css.portal.service.DepService;
import com.letv.css.portal.service.DicService;
import com.letv.css.portal.service.MenuService;
import com.letv.css.portal.service.UserDepService;
import com.letv.css.portal.service.UserService;
import com.letv.css.web.common.utils.JsonResult;

/**
 * 人员数据权限（指的是员工有哪些可见的部门）
 *
 * @Author menghan
 * @Version 2017-01-15 17:45:22
 */
@Controller
@RequestMapping("portal")
public class PortalController extends BaseController{

	private static final Log LOG = LogFactory.getLog(PortalController.class);
	
	@Autowired
	private UserService userService;
	@Autowired
	private DepService depService;
	@Autowired
	private UserDepService userDepService;
	@Autowired
	private DicService dicService;
	@Autowired
	private MenuService menuService;
	
	/** 视图前缀 */
	private static final String VIEW_PREFIX = "portal";
	private static final String VIEW_INDEX = "index";
	private static final String VIEW_UPDATE = "update";
	
	
	@RequestMapping(value="")
	public String welcom(Model model, PageUtil page, UserQuery query){
		return index(model,page,query);
	}

	@RequestMapping(value="index")
	public String index(Model model, PageUtil page, UserQuery query){
		try {
			//数据权限控制
			User user = userService.getUserByUsername(getLoginUser().getUserName());
			//管理员不受到权限控制
			if(user.getDepId()!=null){
				String allowDepIds = getDepIds(user.getId());
				if(allowDepIds==null || "".equals(allowDepIds)){
					query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
				}else{
					query.setDepIds(allowDepIds);
				}
			}
			
			List<User> dataList = userService.queryUserDepStaffListWhere(query, page);
			model.addAttribute("dataList", dataList);
			model.addAttribute("query", query);
			model.addAttribute("page", page);
			addEnumToModel(model);
			addDepListToModel(model);
			addButtonPortals(model,user);
		} catch (Exception e) {
			LOG.error("PortalController index has error.", e);
		}
		return VIEW_PREFIX + "/" + VIEW_INDEX;
	}
	
	/**
     * 给用户分配部门时，依据用户ID查询部门信息
     * 
     * @return
     */
    @RequestMapping(value = "queryDepTree")
    @ResponseBody
    public Wrapper<?> queryDepTree(Long userId) {
        try {
            List<Dep> list = depService.queryDepTree(userId);
            //数据权限控制，人员数据权限页面，加上了数据权限控制，这样就导致了修改自己的权限会让自己的权限越来越小
			User user = userService.getUserByUsername(getLoginUser().getUserName());
			if(user.getDepId()!=null){//管理员不用受到数据权限的控制
				//当前登录用户的权限
				String allowDepIds = getDepIds(user.getId());
				DepQuery query = new DepQuery();
				if(allowDepIds==null || "".equals(allowDepIds)){
					query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
				}else{
					query.setDepIds(allowDepIds);
				}
				List<Dep> allowDeps = depService.queryDepList(query);
				for(Dep dd:allowDeps){
					dd.setYn(0);
					for(Dep d:list){
						if(dd.getId().equals(d.getId())){
							dd.setYn(d.getYn());
							break;
						}
					}
				}
				list = allowDeps;
			}
			//end
			
            if (!CollectionUtils.isEmpty(list)) {
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, Wrapper.SUCCESS_MESSAGE, list);
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "查询部门信息失败！");
            }
        } catch (Exception e) {
            LOG.error("queryDepTree userId has error.", e);
            return WrapMapper.error();
        }
    }
	
    
    /**
     * 给角色分配资源
     * 
     * @return
     */
    @RequestMapping(value = "/saveUserDeps", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult saveUserDeps(UserDep oldUserDep, @RequestParam("depIds") String[] depIds) {
        JsonResult jsonResult = new JsonResult();
        try {
            this.logger.info("userDep --> saveUserDeps，userId = " + oldUserDep.getUserId() + ",depIds="
                    + Arrays.toString(depIds));
            oldUserDep.setUpdateUser(getLoginUserCnName());

            List<UserDep> newUserDeps = null;
			if (null != depIds && depIds.length > 0) {
                newUserDeps = new ArrayList<UserDep>(depIds.length);
                for (String depId : depIds) {
                	UserDep userDep = new UserDep();
                	userDep.setUserId(oldUserDep.getUserId());
                	userDep.setDepId(Long.valueOf(depId));
                	userDep.setCreateUser(getLoginUserCnName());
                    newUserDeps.add(userDep);
                }
            }
            boolean result = userDepService.update(oldUserDep, newUserDeps, getLoginUserId());
            jsonResult.setResult(result);
        } catch (Exception e) {
            this.logger.error("UserDep --> saveUserDeps 保存数据异常:", e);
            jsonResult.setCode(JsonResult.CODE_SERVER_ERROR);
        }
        return jsonResult;
    }
    
	
    /**
     * 将当前用户的可见部门信息加入model
     * @param
     * @return
     */
    private void addDepListToModel(Model model) {
    	//获得当前用户
		User user = userService.getUserByUsername(getLoginUser().getUserName());
		//当前用户的可见部门列表
		if(user!=null){
			String allowDeps = getDepIds(user.getId());
			List<Dep> depList = depService.getDepListByIds(allowDeps);
			if(depList!=null && depList.size()!=0){
				for(Dep dep:depList){
					dep.setParentDep(depService.getDepById(dep.getParentId()));
				}
			}
			model.addAttribute("depList", depList);
		}
	}
    
    /***
     * 获得可见部门的id集合
     */
    private String getDepIds(Long userId){
    	List<UserDep> userDeps = userDepService.queryUserDepList(userId);
		StringBuilder sb = new StringBuilder();
		for(UserDep ud:userDeps){
			sb.append(ud.getDepId()+",");
		}
		String allowDeps = "";
		if(sb.length()>0){
			allowDeps = sb.substring(0, sb.length()-1);
		}
		return allowDeps;
    }
    
    /**
	 * 添加枚举类信息到model
	 * @param
	 * @return
	 */
	private void addEnumToModel(Model model){
		DicQuery query = new DicQuery();
		query.setParentName("合同性质");
		List<Dic> staffContracts = dicService.queryDicList(query);
		model.addAttribute("staffContracts", staffContracts);//员工合同性质
	}
	
	/**
     * 添加按钮级别的权限
     * @param
     * @return
     */
    private void addButtonPortals(Model model,User user){
    	Set<String> set = new HashSet<String>();
    	List<Resource> resources = menuService.queryButtonResources(user);
    	for(Resource r:resources){
    		if(r.getParentId()!=null){
    			set.add(r.getUrl());
    		}
    	}
    	model.addAttribute("buttonPortals", set);
    }
    
}
