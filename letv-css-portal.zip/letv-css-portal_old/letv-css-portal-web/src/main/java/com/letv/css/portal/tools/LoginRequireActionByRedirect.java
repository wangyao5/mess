package com.letv.css.portal.tools;

import com.letv.css.web.common.authen.BaseTokenManager;
import com.letv.css.web.common.interceptor.AuthenticationInterceptor;
import com.letv.css.web.common.url.UrlBuilder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.MalformedURLException;

public class LoginRequireActionByRedirect implements AuthenticationInterceptor.LoginRequireAction {


    private BaseTokenManager tokenManager;

    public void setTokenManager(BaseTokenManager tokenManager) {
        this.tokenManager = tokenManager;
    }

    public BaseTokenManager getTokenManager() {
        return tokenManager;
    }

    /**
     * 读取登录页面url
     *
     * @param request
     * @return
     * @throws MalformedURLException
     */
    private String getLoginUrl(HttpServletRequest request) throws MalformedURLException {
        UrlBuilder urlBuilder = new UrlBuilder(getTokenManager().getLoginUrl());
        UrlBuilder.Builder loginUrlBuilder = urlBuilder.forPath(null);
        loginUrlBuilder.put("ReturnUrl", request.getRequestURI());
        return loginUrlBuilder.build();
    }
    @Override
    public void action(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(getLoginUrl(request));
    }
}
