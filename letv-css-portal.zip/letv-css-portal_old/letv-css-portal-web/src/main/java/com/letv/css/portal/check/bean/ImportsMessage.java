package com.letv.css.portal.check.bean;

/**
 * 记录excel的导入数据，数据不做校验，不做关联
 *
 * @Author menghan
 * @Version 2017-06-13 18:05:30
 */
public class ImportsMessage {
	/**
	 * 职场名称
	 */
	private String depName;
	/**
	 * 班次名称
	 */
	private String shiftsName;
	/**
	 * 餐时标准
	 */
	private String mealStandard;
	/**
	 * 业务线名称
	 */
	private String busName;
	/**
	 * 周1人数
	 */
	private String num1;
	/**
	 * 周2人数
	 */
	private String num2;
	/**
	 * 周3人数
	 */
	private String num3;
	/**
	 * 周4人数
	 */
	private String num4;
	/**
	 * 周5人数
	 */
	private String num5;
	/**
	 * 周六人数
	 */
	private String num6;
	/**
	 * 周日人数
	 */
	private String num7;
	public String getDepName() {
		return depName;
	}
	public void setDepName(String depName) {
		this.depName = depName;
	}
	public String getShiftsName() {
		return shiftsName;
	}
	public void setShiftsName(String shiftsName) {
		this.shiftsName = shiftsName;
	}
	public String getMealStandard() {
		return mealStandard;
	}
	public void setMealStandard(String mealStandard) {
		this.mealStandard = mealStandard;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getNum1() {
		return num1;
	}
	public void setNum1(String num1) {
		this.num1 = num1;
	}
	public String getNum2() {
		return num2;
	}
	public void setNum2(String num2) {
		this.num2 = num2;
	}
	public String getNum3() {
		return num3;
	}
	public void setNum3(String num3) {
		this.num3 = num3;
	}
	public String getNum4() {
		return num4;
	}
	public void setNum4(String num4) {
		this.num4 = num4;
	}
	public String getNum5() {
		return num5;
	}
	public void setNum5(String num5) {
		this.num5 = num5;
	}
	public String getNum6() {
		return num6;
	}
	public void setNum6(String num6) {
		this.num6 = num6;
	}
	public String getNum7() {
		return num7;
	}
	public void setNum7(String num7) {
		this.num7 = num7;
	}
	
}
