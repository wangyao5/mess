package com.letv.css.portal.controller;

import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.letv.common.web.context.LanguageContext;
import com.letv.common.web.context.UserContext;
import com.letv.css.portal.domain.constant.enums.EventConstants;

import com.letv.css.web.common.authen.BaseTokenManager;
import com.letv.css.web.common.utils.DesUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.DateHelper;
import com.letv.common.utils.code.CheckCodeUtils;
import com.letv.common.utils.security.MD5Util;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.common.web.context.LoginUser;
import com.letv.common.web.url.UrlUtils;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.constant.CommonConstants;
import com.letv.css.portal.domain.dto.MenuDto;
import com.letv.css.portal.domain.dto.SubMenuDto;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.service.CommonQueueService;
import com.letv.css.portal.service.MenuService;
import com.letv.css.portal.service.SSOService;
import com.letv.css.portal.service.SyncDataService;
import com.letv.css.portal.service.UserService;

/**
 * 主界面控制器：首页、登录等
 *
 * @author lijianzhong
 */
@Controller
@RequestMapping("")
public class IndexController extends BaseController {

    private static final String LOGIN_MSG_KEY = "login_msg";
    private static final String LOGIN_MSG_VALUE_ILLEGAL = "1";// "用户名和密码不能空";
    private static final String LOGIN_MSG_CHECK_CODE_ERROR = "2";// "验证码输入错误";
    private static final String LOGIN_MSG_VALUE_ERROR = "3";// "用户名密码错误";
    private static final String REDIRECT = "redirect:";
    private static final String VIEW_LOGIN = "login";
    private static final String VIEW_INDEX = "index";
    private static final String FORWARD_URL = "forwardUrl";
    private static final String LOGIN_FORWARD = "loginForward";
    @Autowired
    private SSOService ssoService;
    @Autowired
    private UserService userService;
    @Autowired
    private SyncDataService syncDataService;
    //    @Autowired
//    private PortalWeb portalWeb;
    @Autowired
    private MenuService menuService;
    @Autowired
    private CommonQueueService commonQueueService;
    @Value("${desBpo.username.key}")
    private String key;

    @Value("${open.checkCode}")
    private Boolean isOpenCheckCode;

    @Autowired
    private BaseTokenManager tokenManager;

    private final Log logger = LogFactory.getLog(this.getClass());

    @RequestMapping(value = "", method = RequestMethod.GET)
    public String welcome(Model model) {
        return index(model);
    }

    /**
     * 首页
     *
     * @param model
     * @return
     * @since 2015-03-26
     */
    @RequestMapping(value = "index", method = RequestMethod.GET)
    public String index(Model model) {
        User loginUser = getCurrentUser();
        if (loginUser == null) {
            return login(model, VIEW_INDEX);
        } else {
            //防止cookie中有记录而数据库中没有记录，空读数据
            User user = userService.getUserByUsername(loginUser.getUsername());
            if (user == null) {
                return login(model, VIEW_INDEX);
            }
            model.addAttribute("name", loginUser.getName());
            initMenu(model, loginUser);
            return VIEW_INDEX;
        }
    }

    /**
     * 获取当前登录用户：从上下文获取，（cookie解析而得）
     *
     * @return
     */
    private User getCurrentUser() {
        LoginUser loginUser = getLoginUser();
        User user = new User();
        user.setId(loginUser.getUserId());
        user.setName(loginUser.getCnName());
        user.setUsername(loginUser.getUserName());
        return user;

    }

    /**
     * 原首页-默认空白页
     *
     * @return
     * @since 2015-03-26
     */
    @RequestMapping(value = "empty", method = RequestMethod.GET)
    public String empty() {
        return "empty";
    }


    /**
     * 新版首页
     *
     * @return
     * @since 2015-03-26
     */
    @RequestMapping(value = "home", method = RequestMethod.GET)
    public String home() {
        return "home";
    }

    /**
     * 初始化菜单
     *
     * @param model
     * @author gaohongjing 20140514
     */
    private void initMenu(Model model, User user) {
        String language = LanguageContext.get().getLanguage();
        List<MenuDto> menus = menuService.getMenus(user);
        menuFilter(user, language, menus);
        model.addAttribute(CommonConstants.LOGIN_MENUS_KEY, menus);
    }

    /**
     * 批量补全用户菜单中 用户UID，站点标志f，当前语种locale
     *
     * @param user
     * @param language
     * @param sysMenus
     */
    private void menuFilter(User user, String language, List<MenuDto> sysMenus) {
        for (MenuDto menuDto : sysMenus) {
            if (null != menuDto && !CollectionUtils.isEmpty(menuDto.getSubMenus())) {
                for (SubMenuDto subMenuDto : menuDto.getSubMenus()) {
                    menuFilter(user.getId(), subMenuDto, language, user.getUsername());
                }
            }
        }
    }

    /**
     * 补全用户菜单中 用户UID，当前语种locale
     *
     * @param userId
     * @param subMenuDto
     * @param language
     */
    private void menuFilter(Long userId, SubMenuDto subMenuDto, String language, String username) {
        if (null != subMenuDto && StringUtils.isNotBlank(subMenuDto.getSubMenuUrl())) {
            String param = "?";
            if (subMenuDto.getSubMenuUrl().contains("?")) {
                param = "&";
            }
            StringBuilder builder = new StringBuilder(subMenuDto.getSubMenuUrl()).append(param);
            builder.append("UID=").append(userId);
            builder.append("&locale=").append(language);
            try {
                String encStr = URLEncoder.encode(DesUtils.encrypt(username, key), "UTF-8");
                builder.append("&bpousername=").append(encStr);
            } catch (Exception e) {
                logger.info("bpousername Des encrypt:{}" + e.getMessage());
            }
            subMenuDto.setSubMenuUrl(builder.toString());
        }
    }

    @RequestMapping(value = "login", method = RequestMethod.GET)
    public String login(Model model, @RequestParam(value = "ReturnUrl", required = false) String forwardUrl) {
        model.addAttribute(FORWARD_URL, UrlUtils.encodeUrl(forwardUrl));
        model.addAttribute("isOpenCheckCode", isOpenCheckCode);
        model.addAttribute("formAction", "loginSys");
        return VIEW_LOGIN;
    }

    @RequestMapping(value = "loginByJos", method = RequestMethod.GET)
    public String loginByJos(Model model, @RequestParam(value = "ReturnUrl", required = false) String forwardUrl) {
        model.addAttribute(FORWARD_URL, UrlUtils.encodeUrl(forwardUrl));
        model.addAttribute("isOpenCheckCode", isOpenCheckCode);
        model.addAttribute("formAction", "loginSysByJos");
        return "loginByJos";
    }


    /**
     * 登录事件，处理流程:<br />
     * 1.依据用户账号查询用户信息；<br />
     * 2.如果用户信息不存在，补全用户信息，如果补全失败，返回；否则，重新查询用户信息。<br />
     * 3.如果用户信息不存在，返回并提示；如果存在，继续下一步判断用户类型。<br />
     * 4.如果用户类型为乐视用户，则调用乐视单点登录系统验证；<br />
     * 如果不是，则直接判断数据库的用户密码和输入的密码是否相等。
     *
     * @param user
     * @param model
     * @param checkCode  验证码
     * @param forwardUrl 跳转url
     * @return
     */
    @RequestMapping(value = "loginSys", method = RequestMethod.POST)
    public String loginSys(User user, Model model, HttpServletRequest request, HttpServletResponse response,
                           String checkCode, String forwardUrl) {
        if (user == null || StringUtils.isEmpty(user.getUsername()) || StringUtils.isEmpty(user.getPassword())) { // 缺少参数
            model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_VALUE_ILLEGAL);
            model.addAttribute(FORWARD_URL, forwardUrl);
            return VIEW_LOGIN;
        }

        if (isOpenCheckCode && !CheckCodeUtils.validateCheckCode(checkCode, request)) {// 验证码
            model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_CHECK_CODE_ERROR);
            model.addAttribute(FORWARD_URL, forwardUrl);
            return VIEW_LOGIN;
        }

        String name = user.getUsername().split("@")[0];
        String password = user.getPassword();
        this.logger.info("loginSys: user name=" + name);

        try {
            User loginUser = userService.getUserByUsername(name);
            if (loginUser == null) {
                model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_VALUE_ERROR);
                model.addAttribute(FORWARD_URL, forwardUrl);
                return VIEW_LOGIN;
            }
            boolean checkResult = MD5Util.md5Hex(password + tokenManager.getPasswordSalt()).equals(loginUser.getPassword());
            if (!checkResult) {
                model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_VALUE_ERROR);
                model.addAttribute(FORWARD_URL, forwardUrl);
                return VIEW_LOGIN;
            }
            setCookie(response, loginUser);
            if (StringUtils.isBlank(forwardUrl)) {
                forwardUrl = VIEW_INDEX;
            } else { // 解码后 删除html标签，防止xss
                forwardUrl = UrlUtils.decodeUrl(forwardUrl);
            }
            return "redirect:" + forwardUrl;
        } catch (Exception e) {
            logger.error("对用户[" + name + "]进行登录验证未通过,异常信息如下:", e);
            model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_VALUE_ERROR);
            model.addAttribute(FORWARD_URL, forwardUrl);
            return VIEW_LOGIN;
        }
    }

    /**
     * 登录事件，处理流程:<br />
     * 1.依据用户账号查询用户信息；<br />
     * 2.如果用户信息不存在，补全用户信息，如果补全失败，返回；否则，重新查询用户信息。<br />
     * 3.如果用户信息不存在，返回并提示；如果存在，继续下一步判断用户类型。<br />
     * 4.如果用户类型为乐视用户，则调用乐视单点登录系统验证；<br />
     * 如果不是，则直接判断数据库的用户密码和输入的密码是否相等。
     *
     * @param user
     * @param model
     * @param checkCode  验证码
     * @param forwardUrl 跳转url
     * @return
     */
    @RequestMapping(value = "loginSysByJos", method = RequestMethod.POST)
    public String loginSysByJos(User user, Model model, HttpServletRequest request, HttpServletResponse response,
                                String checkCode, String forwardUrl) {
        if (user == null || StringUtils.isEmpty(user.getUsername()) || StringUtils.isEmpty(user.getPassword())) { // 缺少参数
            model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_VALUE_ILLEGAL);
            model.addAttribute(FORWARD_URL, forwardUrl);
            return "loginByJos";
        }

        if (isOpenCheckCode && !CheckCodeUtils.validateCheckCode(checkCode, request)) {// 验证码
            model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_CHECK_CODE_ERROR);
            model.addAttribute(FORWARD_URL, forwardUrl);
            return "loginByJos";
        }

        String name = user.getUsername().split("@")[0];
        String password = user.getPassword();
        this.logger.info("loginSys: user name=" + name);

        try {
            User loginUser = userService.getUserByUsername(name);
            if (loginUser == null) {
                if (!syncUser(name)) {// 补全用户
                    this.logger.warn("补全用户[" + name + "]信息不成功");
                    model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_VALUE_ERROR);
                    model.addAttribute(FORWARD_URL, forwardUrl);
                    return "loginByJos";
                }
                loginUser = userService.getUserByUsername(name);
                //添加用户同步到工作流
                CommonQueue commonQueue = new CommonQueue();
                commonQueue.setEventId(EventConstants.EVENT_STAFF_ADD);
                commonQueue.setOnlyId(loginUser.getId());
                commonQueue.setCreatedBy(String.valueOf(loginUser.getId()));
                commonQueue.setOnlyType("user login add user id");
                commonQueue.setCreationDate(new Date());
                commonQueue.setStatus(0);
                commonQueue.setRequestRemake("用户登陆添加");
                this.commonQueueService.insert(commonQueue);
            }

            // 使用LDAP进行账号认证，则使用sso接口验证账号
            boolean checkResult = ssoService.checkUser(name, password);

            if (!checkResult) {
                model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_VALUE_ERROR);
                model.addAttribute(FORWARD_URL, forwardUrl);
                return "loginByJos";
            }
            setCookie(response, loginUser);
            if (StringUtils.isBlank(forwardUrl)) {
                forwardUrl = VIEW_INDEX;
            } else { // 解码后 删除html标签，防止xss
                forwardUrl = UrlUtils.decodeUrl(forwardUrl);
            }
            return "redirect:" + forwardUrl;
        } catch (Exception e) {
            logger.error("对用户[" + name + "]进行登录验证未通过,异常信息如下:", e);
            model.addAttribute(LOGIN_MSG_KEY, LOGIN_MSG_VALUE_ERROR);
            model.addAttribute(FORWARD_URL, forwardUrl);
            return "loginByJos";
        }
    }

    /**
     * 补全用户
     *
     * @param name
     * @return
     */
    private boolean syncUser(String name) {
        boolean result = false;
        String tempUserName = name;
        if (!tempUserName.toLowerCase().endsWith("@letv.com")) {
            tempUserName += "@letv.com";
        }

        User user = this.syncDataService.syncUser(tempUserName);
        if (null != user) {
            this.logger.info("补全用户[" + tempUserName + "]信息成功");
            result = true;
        }
        return result;
    }

    /**
     * 用户退出:失效所有的cookie
     *
     * @param response
     * @return
     */
    @RequestMapping("quit")
    public String quit(HttpServletRequest request, HttpServletResponse response) {
        LoginUser loginUser = UserContext.get().getUser();
        if (loginUser != null) {
            tokenManager.invalidateToken(request, response, loginUser.getUserName());
        } else {
            tokenManager.invalidateToken(request, response, null);
        }
        return REDIRECT + VIEW_INDEX;
    }

    /**
     * 写入Cookie
     *
     * @param response
     * @param user
     */
    private void setCookie(HttpServletResponse response, User user) throws NoSuchAlgorithmException, InvalidKeyException {
        if (null == user) {
            return;
        }
        LoginUser loginUser = new LoginUser();
        loginUser.setUserId(user.getId());
        loginUser.setUserName(user.getUsername());
        loginUser.setCnName(user.getName());
        if (null != user.getDep()) {
            loginUser.setDepId(user.getDep().getId());
            loginUser.setDepName(user.getDep().getName());
        }
        String userJson = loginUser.toString();// 用户信息的json值
        tokenManager.conferToken(response, loginUser.getUserName(), userJson);
    }

    /**
     * 依据账号密码进行认证，认证成功后写cookie；以便接入宙斯的子系统的菜单嵌入客服CC系统使用。
     *
     * @param response
     * @param username
     * @param password
     * @param site
     * @param sign
     * @param callback
     * @return
     */
    @RequestMapping(value = "services/user/authen", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public JSONPObject userAuthen(HttpServletResponse response, String username,
                                  String password, String site, String sign, String callback) {
        logger.info("用户认证请求参数：username= " + username);
        logger.info("调用方标志 site= " + site);
        logger.info("签名 sign= " + sign);
        logger.info("回调函数名称 callback= " + callback);
        Wrapper<Object> value = WrapMapper.ok();
        try {
            if (StringUtils.isBlank(username) || StringUtils.isBlank(password) || StringUtils.isBlank(site)
                    || StringUtils.isBlank(sign) || StringUtils.isBlank(callback)) {
                value = WrapMapper.illegalArgument().message("参数非法：缺少参数");
            } else {
                String today = DateHelper.format(new Date(), DateHelper.DATE_FORMAT_NO_SPLIT);
                String mySign = MD5Util.md5Hex(username + password + today);
                logger.info("mySign= " + mySign);
                if (!sign.equals(mySign)) {
                    value = WrapMapper.illegalArgument().message("参数非法：sign校验失败");
                } else {
                    User loginUser = userService.getUserByUsername(username);
                    if (loginUser != null) {
                        setCookie(response, loginUser);
                    } else {
                        value = WrapMapper.illegalArgument().message("校验失败，不存在的账号" + username);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("userAuthen has error.", e);
            value = WrapMapper.error();
        }

        logger.info("response value json: " + JsonHelper.toJson(value));
        return new JSONPObject(callback, value);
    }
}
