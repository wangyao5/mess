package com.letv.css.portal.controller.scheduling.apply;

import com.alibaba.fastjson.JSONObject;
import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.DateHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.query.ApprovalManageQuery;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;
import com.letv.css.portal.domain.query.StaffQuery;
import com.letv.css.portal.service.*;
import com.letv.css.portal.domain.vo.workflow.bean.NewInstanceParam;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author yxh
 * @date  2017-06-28 16:06:38.
 * @version V1.0
 */
@Controller
@RequestMapping("workflow")
public class OvertimeApplyController extends BaseController {
    private static final Log LOG = LogFactory.getLog(OvertimeApplyController.class);


    /**
     * 视图前缀
     */
    private static final String viewPrefix = "workflow";

    @Autowired
    private SchedulingInfoService schedulingInfoService;

    @Autowired
    private ApprovalManageService approvalManageService;

    @Autowired
    private JsonDataService jsonDataService;
    @Autowired
    private DepService depService;

    @Autowired
    private StaffService staffService;
    @Autowired
    private ShiftsService shiftsService;
    @Autowired
    private ShiftsPeriodService shiftsPeriodService;
    @Autowired
    private UserService userService;
    @Autowired
    private ScheduleApplyController scheduleApplyController;
    @Autowired
    private DicService dicService;
    

    /**
     * BPO加班申请
     * @param
     * @return
     */
    @RequestMapping("overtime")
    public String bpoOvertimeDetail(Model model, String isDetail, Staff staff, NewInstanceParam p) {
        try {
            //数据权限控制
            User user = userService.getUserByUsername(getLoginUser().getUserName());
            String allowDepIds = scheduleApplyController.getDepIds(user.getId());
            scheduleApplyController.addDepListToModel(model,allowDepIds);//部门

            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isDetail", isDetail);
            boolean flag=false;
            if(isDetail!=null && "2".equals(isDetail)){
                flag=true;
                model.addAttribute("isCanSelect", "1");//不可以修改
            }
            List<SchedulingInfo> dataList = scheduleApplyController.getApplySchedulingInfos(p, flag,3);

            model.addAttribute("dataList", dataList);
            //查询审批信息
            addOverTimeJsonModel(model, p);

            //历史信息
            scheduleApplyController.setFlowHistoryInModel(model, p);
        } catch (Exception e) {
            LOG.error(" bpoOvertimeDetail has error.", e);
        }
        if (StringUtils.isNotEmpty(isDetail) && "2".equals(isDetail)) {
            return viewPrefix + "/" + "bpoOvertimeDetail";
        } else {
            return viewPrefix + "/" + "bpoOvertime";
        }
    }

    /**
     * 查询 可用加班的人员
     */
    @RequestMapping(value = "getOvertimeStaff")
    @ResponseBody
    public Wrapper getOvertimeStaff(String depCode, String shifts,String shiftsPeriod,String adjustTime) {
        List<Staff> staffList;
        try {
            StaffQuery queryBean=new StaffQuery();
            if(depCode !=null && !"".equals(depCode)){
                queryBean.setCode(depCode);
            }
            queryBean.setShiftsId(Long.parseLong(shifts));
            queryBean.setPeriodId(Long.parseLong(shiftsPeriod));
            queryBean.setAdjustTime(DateHelper.parseDate(adjustTime.substring(0,adjustTime.indexOf(" ")) + " 00:00:00"));

            staffList=staffService.getOvertimeStaff(queryBean,getLoginUserId());
        } catch (Exception e) {
            LOG.error(" getOvertimeStaff has error.", e);
            return error();
        }
        return new Wrapper<List<Staff>>().result(staffList);
    }

    /**
     *BPO加班申请审核
     *
     * @param siIds
     * @param model
     * @param p
     * @return
     */
    @RequestMapping(value = "applyOvertime")
    @ResponseBody
    public Wrapper applyOvertime(String siIds,String depId,String business,String shifts,String shiftsPeriod,
                                 String adjustTime,String num,String remark, Model model, NewInstanceParam p) {
        HashMap wfs = null;
        try {
        	//注意：加班与其他的工作流审批不一样，不需要验证b_scheduling_info表中的信息
//        	//校验排班记录是否还存在与b_scheduling_info表中
//        	if("allow".equals(p.getActionId()) && !validateSchedulingInfoIsExist(siIds,schedulingInfoService)){
//        		return WrapMapper.wrap(10100, "排班明细中不存在这些记录或者这些记录已经被删除，请进行驳回操作！");
//        	}
        	
        	//校验加班时间与在岗时间是否有冲突
        	if("requested".equals(p.getStatusId())){
	        	if(!validateOverTime(siIds,depId,business,shifts,shiftsPeriod,adjustTime)){
	        		return WrapMapper.wrap(6100, "加班审批提交失败，加班时间段与员工上班时间重叠！");
	        	}
        	}
        	//校验员工的加班申请是否重复提交
        	if("requested".equals(p.getStatusId()) && StringUtils.isNotBlank(siIds)){
                if(!validateOvertimeIsRepeat(siIds,depId,business,shifts,shiftsPeriod,adjustTime)){
                    return WrapMapper.wrap(6200, "加班审批提交失败，已有员工在加班申请中未处理完！");
                }
        	}

            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isCanSelect", "0");//可以修改
            //工作流向下走一步
            wfs = scheduleApplyController.workFlowStepNext(p, wfs);
            String responseStatus = (String) wfs.get("status");
            if ("0".equals(responseStatus)) {
                //首次同意时确认同意的数据
                if ("requested".equals(p.getStatusId()) && "allow".equals(p.getActionId()) && StringUtils.isNotBlank(siIds)) {
                    //1.生成排班信息 排班info表记录，同时设置记录为未生效状态。
                    Map<String,String> paramMap=new HashMap();
                    paramMap.put("siIds",siIds);
                    paramMap.put("business",business);
                    paramMap.put("businessName",getBusiness(business));
                    paramMap.put("shifts",shifts);
                    paramMap.put("shiftsPeriod",shiftsPeriod);
                    paramMap.put("adjustTime",adjustTime);
                    paramMap.put("remark",remark);
                    paramMap.put("outId",p.getOutId());
                    paramMap.put("userName",getLoginUserName());
                    approvalManageService.initSchedulAndApproval(paramMap);
                }
                //确认同意，更新明细表记录
                if ("confirm".equals(p.getStatusId()) && "allow".equals(p.getActionId())) {
                    //更新是否已经确认
                    if (StringUtils.isNotBlank(siIds)) {
                        //生效推送记录数据
                        approvalManageService.updateConfirmBySiId(siIds);
                        //生效排班数据
                        SchedulingInfoQuery queryBean = new SchedulingInfoQuery();
                        queryBean.setJdId(Long.parseLong(p.getOutId()));
                        queryBean.setYn(1);//设置数据生效
                        queryBean.setRemark("增加班次确认");
                        queryBean.setUpdateUser(getLoginUserCnName());
                        schedulingInfoService.updateByApplyFlow(queryBean);
                    }
                }
                //工作流流程走完 记录状态
                //更新是否已经确认
                if("confirm".equals(p.getStatusId())){
                    if (StringUtils.isNotBlank(p.getOutId())) {//JD_ID
                        approvalManageService.updateFinishByJdId(p.getOutId());
                    }
                }
            } else {
                return error();
            }
        } catch (Exception e) {
            LOG.error(" applyOvertime has error.", e);
            return error();
        }
        return new Wrapper<HashMap>().result((HashMap) wfs.get("result"));
    }

	/**
     * BPO加班申请确认
     * @param
     * @return
     */
    @RequestMapping("overtimeConfirm")
    public String overtimeConfirmDetail(Model model, Staff staff, NewInstanceParam p) {
        try {
            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isCanSelect", "0");//不可以修改
            //根据排班ID获取选择的排班班段信息
            List<SchedulingInfo> dataList = scheduleApplyController.getApplySchedulingInfos(p, true,0);

            model.addAttribute("dataList", dataList);
            //查询审批信息
            addOverTimeJsonModel(model, p);

            //历史信息
            scheduleApplyController.setFlowHistoryInModel(model, p);
        } catch (Exception e) {
            LOG.error(" overtimeConfirmDetail has error.", e);
        }
        return viewPrefix + "/" + "bpoOvertimeDeal";
    }

    //4加班
    private void addOverTimeJsonModel(Model model, NewInstanceParam p) {
        Dep dep=null;
        Shifts shiftsEntity=null;
        ShiftsPeriod shiftsPeriodEntity=null;

        JsonData jsonData = jsonDataService.getById(Long.parseLong(p.getOutId()));
        JSONObject jsonObj = JSONObject.parseObject(jsonData.getJsonData());
        String depId=jsonObj.get("depId").toString();
        String shifts=jsonObj.get("shifts").toString();
        String shiftsPeriod=jsonObj.get("shiftsPeriod").toString();

        if(StringUtils.isNotEmpty(depId.trim())){
            dep =depService.getDepById(Long.parseLong(depId));
        }
        if(StringUtils.isNotEmpty(shifts.trim())){
            shiftsEntity =shiftsService.getShiftsById(Long.parseLong(shifts));
        }
        if(StringUtils.isNotEmpty(shiftsPeriod.trim())){
            shiftsPeriodEntity =shiftsPeriodService.getShiftsPeriodById(Long.parseLong(shiftsPeriod));
        }
        model.addAttribute("depId", depId);
        model.addAttribute("depName", dep==null?"":dep.getName());
        model.addAttribute("business", jsonObj.get("business").toString());
        model.addAttribute("shifts", shifts);
        model.addAttribute("shiftsName",shiftsEntity==null?"":shiftsEntity.getShiftsName());
        model.addAttribute("shiftsPeriod",shiftsPeriod);
        model.addAttribute("periodName",shiftsPeriodEntity==null?"":shiftsPeriodEntity.getPeriodName());
        model.addAttribute("overtimeReason", jsonObj.get("overtimeReason").toString());
        model.addAttribute("adjustTime", jsonObj.get("adjustTime").toString());
        model.addAttribute("num", jsonObj.get("num").toString());
    }
    
    /**
     * 校验加班时间。校验依据：如果该员工在该部门该业务线该班次班段下面有班，则判断为加班时间重叠。
     * @param siIds
     * @param depId
     * @param business
     * @param shifts
     * @param shiftsPeriod
     * @param adjustTime
     * @return
     */
    private boolean validateOverTime(String siIds, String depId,
			String business, String shifts, String shiftsPeriod,String adjustTime) {
    	try {
    		SchedulingInfoQuery query = new SchedulingInfoQuery();
    		String[] siId = siIds.split(",");
    		for(String sId:siId){
    			if("".equals(sId)){
    				continue;
    			}
    			String[] id = sId.split("\\$");
    			Long staffId = Long.parseLong(id[0]);//获得员工id
    			query.setStaffId(staffId);
                query.setPlanDate(adjustTime.split(" ")[0] + " 00:00:00");
    			ShiftsPeriod sp = shiftsPeriodService.getShiftsPeriodById(Long.parseLong(shiftsPeriod));
    			List<SchedulingInfo> list = schedulingInfoService.querySchedulingInfoList(query);
    			for(SchedulingInfo si:list){
    				if(sp.getBeginTime().compareTo(si.getBeginTime())>=0 || sp.getEndTime().compareTo(si.getBeginTime())<=0){
    					continue;
    				}else{
    					return false;
    				}
    			}
    			
    			if(!CollectionUtils.isEmpty(list)){
    				return false;
    			}
    		}
		} catch (Exception e) {
			LOG.error("加班审批参数异常siIds:"+siIds+",depId:"+depId+",business:"+business+",shifts:"+shifts+",shiftsPeriod:"+shiftsPeriod+",adjustTime:"+adjustTime, e);
			return false;
		}
		return true;
	}
    
    /***
     * 获得所有业务线
     * @return
     */
    private String getBusiness(String businessId){
    	DicQuery query = new DicQuery();
        query.setParentName("业务");
        query.setNum(Integer.parseInt(businessId));
        List<Dic> business = dicService.queryDicList(query);
        if(CollectionUtils.isNotEmpty(business)){
        	return business.get(0).getName();
        }
        return "";
    }
    
    /**
     * 校验是否存在处理中的任务
     *
     * @param siIds
     * @param type
     * @return
     */
    private boolean validIsHavaFinishedFlow(String siIds, Integer type) {
        try {

            ApprovalManageQuery approvalManageQuery = new ApprovalManageQuery();
            approvalManageQuery.setSiIds(siIds);
            approvalManageQuery.setType(type);
            int count = approvalManageService.queryAppManageCount(approvalManageQuery);
            if (count > 0) {
                return false;
            }
        } catch (Exception e) {
            LOG.error("申请出现异常，参数siIds：" + siIds, e);
            return false;
        }
        return true;
    }
    
    /**
     * 校验加班申请是否重复 当天只能有一个未完成的加班申请
     *
     * @param
     * @return
     */
    private boolean validateOvertimeIsRepeat(String siIds, String depId,
			String business, String shifts, String shiftsPeriod,
			String adjustTime) {
    	try {
    		SchedulingInfoQuery query = new SchedulingInfoQuery();
//        	query.setDepId(Long.parseLong(depId));
//        	query.setShiftsId(Long.parseLong(shifts));
//        	query.setShiftPeriodId(Long.parseLong(shiftsPeriod));
//        	query.setBusName(getBusiness(business));
            query.setPlanDate(adjustTime.split(" ")[0] + " 00:00:00");
        	query.setYn(0);
        	String[] siId = siIds.split(",");
        	for(String id : siId){
        		Long staff = Long.parseLong(id.split("\\$")[0]);
        		query.setStaffId(staff);
        		List<SchedulingInfo> list = schedulingInfoService.querySchedulingInfoList(query);
        		if(CollectionUtils.isNotEmpty(list)){
                    //关联查询数据是否已经办结
                    String ids = null;
                    for (int i = 0; i < list.size(); i++) {
                        if (ids == null) {
                            ids = list.get(i).getId().toString();
                        } else {
                            ids = ids + "," + list.get(i).getId();
                        }
                    }
                    ApprovalManageQuery approvalManageQuery = new ApprovalManageQuery();
                    approvalManageQuery.setSiIds(ids);
                    approvalManageQuery.setType(4);
                    int count = approvalManageService.queryAppManageCount(approvalManageQuery);
                    if (count > 0) {
        			return false;
        		}
        	}
            }
        	return true;
		} catch (Exception e) {
			LOG.error("参数有误！", e);
			return false;
		}
	}

}
