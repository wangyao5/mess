package com.letv.css.portal.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.constant.CommonConstants;
import com.letv.css.portal.service.StaffService;
import com.letv.css.portal.domain.vo.workflow.bean.QInstanceResult;
import com.letv.css.portal.domain.vo.workflow.bean.WfResponse;
import com.letv.css.web.common.utils.HttpUtil;
import com.letv.css.web.common.utils.JsonUtil;
import com.letv.css.web.common.utils.Md5Util;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.nio.charset.Charset;
import java.util.*;
/**
* @author yxh
* @date  2017/10/23  14:41
* @version V1.0
*/
@Controller
@RequestMapping("already")
public class AlreadyController extends BaseController {
    private static final Log LOG = LogFactory.getLog(AlreadyController.class);
    @Value("${workflow.url.domain.host}")
    private  String URL_TEST;
    @Value("${workflow.url.domain.queryInstanceByModifier}")
    private  String URL_QUERYINSTANCEBYMODIFIER;

    /**
     * 视图前缀
     */
    private static final String VIEW_PREFIX = "workflow";


    @RequestMapping(value = "")
    public String welcom(Model model, PageUtil page, String query) {
        return index(model, page, query);
    }

    @RequestMapping(value = "index")
    public String index(Model model, PageUtil page, String query) {
        try {
            String url = URL_TEST + URL_QUERYINSTANCEBYMODIFIER;

            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);

            param.put("operatorType", "css");
            param.put("operatorId", getLoginUserId() + "");
            param.put("page", page.getCurPage() + "");
            param.put("pageRows", page.getPageSize() + "");
            //查询条件
            if(query != null && !"".equals(query)){
                param.put("keyword", query);
            }
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            LOG.info("入参" + JsonUtil.toJsonObject(param));
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info(str);
            WfResponse<QInstanceResult> wfs = JsonUtil.fromJsonObject(str,
                    new TypeReference<WfResponse<QInstanceResult>>() {});
            if ("0".equals(wfs.getStatus())) {
                QInstanceResult qir = (QInstanceResult)wfs.getResult();
                Integer totalRow = Integer.valueOf(qir.getTotal());
                page.setTotalRow(totalRow);
                page.init();
                model.addAttribute("dataList", qir.getInstance());
            }

            LOG.info("返回结果：" + str);
            model.addAttribute("page", page);// 分页
            model.addAttribute("query", query);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return VIEW_PREFIX + "/myAlready";
    }

}
