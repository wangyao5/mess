package com.letv.css.portal.controller.rest;

import com.letv.css.portal.domain.vo.ScheduleInfoWithType;
import com.letv.css.portal.domain.vo.ScheduleSwapTimes;
import com.letv.css.web.common.response.ResponseWrapper;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@RequestMapping("/user")
public class UserRestController {
    /**
     * 模糊查询用户或部门
     *
     * @param key
     * @return
     */
    @RequestMapping("/queryName")
    public ResponseWrapper<String[]> queryName(String key) {
        //todo
        return null;
    }

    /**
     * 按条件查询用户信息
     *
     * @param key
     * @return
     */
    @RequestMapping("/query/{key}")
    public ResponseWrapper<String[]> query(@PathVariable String key) {
        //todo
        return null;
    }

    @RequestMapping("/swapTimes")
    public ResponseWrapper<ScheduleSwapTimes> swapTimes(@RequestParam String userName) {
        //todo
        return null;
    }

    /**
     * 按条件查询用户排班信息
     *
     * @param key
     * @param beginDate
     * @param endDate
     * @param type
     * @return
     */
    @RequestMapping("schedule")
    public ResponseWrapper<ScheduleInfoWithType> schedule(
            @RequestParam String key,
            @RequestParam Date beginDate, @RequestParam Date endDate,
            @RequestParam Integer type
    ) {
//todo
        return null;
    }
}
