package com.letv.css.portal.controller.rest;

import com.letv.css.portal.domain.vo.DicItem;
import com.letv.css.web.common.response.ResponseWrapper;
import com.letv.css.portal.domain.Shifts;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/sys")
public class SysRestController {
    /**
     * 读取系统数据字典信息
     * @param dicID
     * @return
     */
    @RequestMapping("/dic/{dicID}")
    public ResponseWrapper<List<DicItem>> items(@PathVariable String dicID) {
        //todo
        return null;
    }
    /**
     * 读取系统班次设置信息
     *
     * @return
     */
    @RequestMapping("/shifts/list")
    public ResponseWrapper<Shifts[]> list() {
        //todo
        return null;
    }
}
