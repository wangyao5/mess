package com.letv.css.portal.check.bean;

import com.letv.css.portal.domain.Schedule;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by yangxinghe on 2017/6/2.
 */
//记录导入错误详细信息，并且可以存储到数据库中
public class ScheduleMessage implements Serializable{
    private static final long serialVersionUID = -7682441148629677152L;
    //导入记录ID 用于写入数据库
    private Long id;
    //导入结果，成功 0/失败1
    private Integer code;
    //导入结果信息 成功/失败
    private String msg;
    //导入时间
    private Date impDate;
    //导入人Name
    private String uName;

    //导出Excel地址
    private String excelExpURL;
    //导入错误明细
    private List<ImportsErrorMessage> errList = new ArrayList<ImportsErrorMessage>();

    //EXCEL导入信息
    private List<ImpScheduleMsg> impScheduleMsgList = new ArrayList<ImpScheduleMsg>();

    //抽取EXCEL导入数据的日期
    private List<Date> impPlanDates = new ArrayList<Date>();

    //排班任务实体
    private Schedule schedule;

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public List<ImpScheduleMsg> getImpScheduleMsgList() {
        return impScheduleMsgList;
    }

    public void setImpScheduleMsgList(List<ImpScheduleMsg> impScheduleMsgList) {
        this.impScheduleMsgList = impScheduleMsgList;
    }

    public List<Date> getImpPlanDates() {
        return impPlanDates;
    }

    public void setImpPlanDates(List<Date> impPlanDates) {
        this.impPlanDates = impPlanDates;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<ImportsErrorMessage> getErrList() {
        return errList;
    }

    public void setErrList(List<ImportsErrorMessage> errList) {
        this.errList = errList;
    }

    public Date getImpDate() {
        return impDate;
    }

    public void setImpDate(Date impDate) {
        this.impDate = impDate;
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getExcelExpURL() {
        return excelExpURL;
    }

    public void setExcelExpURL(String excelExpURL) {
        this.excelExpURL = excelExpURL;
    }
}
