package com.letv.css.portal.controller.rest;

import com.letv.common.utils.security.MD5Util;
import com.letv.common.web.context.LoginUser;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.service.UserService;
import com.letv.css.web.common.authen.BaseTokenManager;
import com.letv.css.web.common.response.ResponseStatusEnum;
import com.letv.css.web.common.response.ResponseWrapper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/")
public class IndexRestController {

    private final UserService userService;
    private final BaseTokenManager tokenManager;

    private final Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    public IndexRestController(UserService userService, BaseTokenManager tokenManager) {
        this.userService = userService;
        this.tokenManager = tokenManager;
    }

    @RequestMapping("/")
    ResponseWrapper<String> welcome() {
        return new ResponseWrapper<String>("Hello css-gateway!");
    }

    /**
     * 需要登录系统
     *
     * @return
     */
    @RequestMapping(value = "/loginRequire")
    ResponseWrapper loginRequire() {
        return new ResponseWrapper(ResponseStatusEnum.UNAUTHORIZED);
    }

    /**
     * 系统登录
     *
     * @return
     */
    @RequestMapping(value = "/login")
    ResponseWrapper<String> login(HttpServletResponse response, @RequestBody User userParam) {
        //todo
        String name = userParam.getUsername().split("@")[0];
        String password = userParam.getPassword();
        this.logger.info("loginSys: user name=" + name);

        try {
            User user = userService.getUserByUsername(name);
            if (user == null) {
                return new ResponseWrapper<>(ResponseStatusEnum.ILLEGAL_ERROR_ARGUMENT.getCode(), "您请求的用户名或密码错误");
            }
            boolean checkResult = MD5Util.md5Hex(password + tokenManager.getPasswordSalt()).equals(user.getPassword());
            if (!checkResult) {
                return new ResponseWrapper<>(ResponseStatusEnum.ILLEGAL_ERROR_ARGUMENT.getCode(), "您请求的用户名或密码错误");
            }
            LoginUser loginUser = new LoginUser();
            loginUser.setUserId(user.getId());
            loginUser.setUserName(user.getUsername());
            loginUser.setCnName(user.getName());
            if (null != user.getDep()) {
                loginUser.setDepId(user.getDep().getId());
                loginUser.setDepName(user.getDep().getName());
            }
            String userJson = loginUser.toString();// 用户信息的json值
            return new ResponseWrapper<>(tokenManager.conferToken(response, loginUser.getUserName(), userJson));
        } catch (Exception e) {
            return new ResponseWrapper<>(ResponseStatusEnum.ILLEGAL_ERROR_ARGUMENT.getCode(), "您请求的用户名或密码错误");
        }
    }

    /**
     * 系统退出
     *
     * @return
     */
    @RequestMapping(value = "/logout")
    ResponseWrapper<String> logout() {
        //todo
        return new ResponseWrapper<>("logout");
    }

    /**
     * 申请新token
     *
     * @return
     */
    @RequestMapping("/refreshtoken")
    ResponseWrapper<String> refreshToken() {
        //todo
        return new ResponseWrapper<>("new token");
    }
}