package com.letv.css.portal.controller.scheduling.apply;

import com.alibaba.fastjson.JSONObject;
import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.domain.query.ShiftsQuery;
import com.letv.css.portal.service.*;
import com.letv.css.portal.domain.vo.workflow.bean.NewInstanceParam;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @author yxh
 * @date  2017/10/23  14:40
 * @version V1.0
 */
@Controller
@RequestMapping("workflow")
public class AutoScheduleApplyController extends BaseController {
    private static final Log LOG = LogFactory.getLog(AutoScheduleApplyController.class);

    /**
     * 视图前缀
     */
    private static final String viewPrefix = "workflow";


    @Autowired
    private ApprovalManageService approvalManageService;

    @Autowired
    private JsonDataService jsonDataService;

    @Autowired
    private ScheduleApplyController scheduleApplyController;
    @Autowired
    private ScheduleService scheduleService;
    @Autowired
    private ShiftsService shiftsService;

    @Autowired
    private DicService dicService;
    @Autowired
    private CommonQueueService commonQueueService;

    /**
     * 預置班次审批展示
     * url:autoScheduling?id=&flowId=bpoAutoScheduling&statusId=requested&instanceId=316&outId=227&adjustId=&isDetail=1
     *
     * @param
     * @return
     */
    @RequestMapping("autoScheduling")
    public String autoSchedulingDetail(Model model, String isDetail, Staff staff, NewInstanceParam p) {
        try {
            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isDetail", isDetail);
            if (isDetail != null && "2".equals(isDetail)) {
                model.addAttribute("isCanSelect", "1");//可以修改
            }
            //查询审批信息
            bpoAutoSchedulingJsonModel(model, p);
            addBusinessToModel(model);//业务线
            addShitfsToModel(model);//班次
            //历史信息
            scheduleApplyController.setFlowHistoryInModel(model, p);
        } catch (Exception e) {
            LOG.error("autoSchedulingDetail has error.", e);
        }
        if (StringUtils.isNotEmpty(isDetail) && "2".equals(isDetail)) {
            return viewPrefix + "/" + "autoSchedulingDetail";
        } else {
            return viewPrefix + "/" + "autoScheduling";
        }
    }


    //預置班次审批
    private void bpoAutoSchedulingJsonModel(Model model, NewInstanceParam p) {
        JsonData jsonData = jsonDataService.getById(Long.parseLong(p.getOutId()));
        JSONObject jsonObj = JSONObject.parseObject(jsonData.getJsonData());

        model.addAttribute("spId", jsonObj.get("spId").toString());
        model.addAttribute("sId", jsonObj.get("sId").toString());
    }

    /**
     * BPo支援工单BPO审核
     *
     * @param model
     * @param p
     * @return
     */
    @RequestMapping(value = "applyAutoScheduling")
    @ResponseBody
    public Wrapper applyAutoScheduling(Model model, NewInstanceParam p) {
        HashMap wfs = null;
        try {
            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isCanSelect", "0");//可以修改
            //工作流向下走一步
            wfs = scheduleApplyController.workFlowStepNext(p, wfs);
            String responseStatus = (String) wfs.get("status");
            JsonData jsonData = jsonDataService.getById(Long.parseLong(p.getOutId()));
            JSONObject jsonObj = JSONObject.parseObject(jsonData.getJsonData());

            Schedule schedule =  scheduleService.getScheduleById(Long.parseLong(jsonObj.get("sId").toString()));
            Integer status = 0;
            if ("0".equals(responseStatus)) {
                //首次同意时确认同意的数据
                if ("requested".equals(p.getStatusId()) && "allow".equals(p.getActionId())) {
                    status = 3;
                    //更新是否已经确认，更新完成
                    if (StringUtils.isNotBlank(p.getOutId())) {//JD_ID
                        approvalManageService.updateByJdId(p.getOutId());
                    }
                    //插入commonQueue,标记已经删除班次信息
                    addDisSchedulePeriodJob(schedule);

                    addSchedulePeriodJob(schedule);

                } else {
                    status = 2;
                }
                if (schedule != null) {
                    //用于记录审核人
                    schedule.setUpdateUser(p.getOperator());
                    schedule.setUpdateTime(new Date());
                    schedule.setStatus(status);
                    scheduleService.update(schedule);
                }
            } else {
                return error();
            }
        } catch (Exception e) {
            LOG.error(" applyAutoScheduling has error.", e);
            return error();
        }
        return new Wrapper<HashMap>().result((HashMap) wfs.get("result"));
    }
    /**
     * 将业务线加到model
     *
     * @param
     * @return
     */
    private void addBusinessToModel(Model model) {
        List<Dic> business = getBusiness();
        model.addAttribute("businessList", business);
    }

    /**
     * 将班次加入到model
     *
     * @param
     * @return
     */
    private void addShitfsToModel(Model model) {
        ShiftsQuery shiftsQuery = new ShiftsQuery();
        shiftsQuery.setStatus(1);//启用状态
        List<Shifts> shiftsList = shiftsService.queryShiftsList(shiftsQuery);//一次读取所有班次信息
        model.addAttribute("shiftsList", shiftsList);
    }
    /***
     * 获得所有业务线
     * @return
     */
    private List<Dic> getBusiness(){
        DicQuery query = new DicQuery();
        query.setParentName("业务");
        List<Dic> business = dicService.queryDicList(query);
        return business;
    }
    /**
     * 向CommcnQueue增加删除班段信息，用于JOB轮询
     *
     * @param schedule
     */
    private void addDisSchedulePeriodJob(Schedule schedule) {
        CommonQueue queue = new CommonQueue();
        queue.setOnlyId(schedule.getId());
        queue.setOnlyType("scheduleDetail sId disable");
        queue.setEventId(EventConstants.EVENT_SCHEDULE_INFO_DISABLE);
        queue.setRequestRemake("更新删除排班班段信息");
        queue.setCreatedBy("SCHEDULE ADD");
        commonQueueService.insert(queue);
    }

    /**
     * 向CommcnQueue增加班段信息，用于JOB轮询
     *
     * @param schedule
     */
    private void addSchedulePeriodJob(Schedule schedule) {
        CommonQueue queue = new CommonQueue();
        queue.setOnlyId(schedule.getId());
        queue.setOnlyType("scheduleDetail sId");
        queue.setEventId(EventConstants.EVENT_SCHEDULE_INFO_ADD);
        queue.setRequestRemake("生成排班班段信息 ");
        queue.setCreatedBy("SCHEDULE ADD");
        commonQueueService.insert(queue);
    }

}
