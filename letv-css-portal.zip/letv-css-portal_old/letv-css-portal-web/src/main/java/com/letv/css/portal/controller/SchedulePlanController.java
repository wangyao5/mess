package com.letv.css.portal.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.letv.common.utils.DateHelper;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.check.bean.ImportsErrorMessage;
import com.letv.css.portal.check.bean.ImportsMessage;
import com.letv.css.portal.check.bean.SchedulePlanMessage;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.SchedulePlan;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.Shifts;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.domain.query.SchedulePlanDetailQuery;
import com.letv.css.portal.domain.query.SchedulePlanQuery;
import com.letv.css.portal.domain.query.ShiftsQuery;
import com.letv.css.portal.service.DepService;
import com.letv.css.portal.service.DicService;
import com.letv.css.portal.service.SchedulePlanDetailService;
import com.letv.css.portal.service.SchedulePlanService;
import com.letv.css.portal.service.ShiftsService;
import com.letv.css.portal.service.UserDepService;
import com.letv.css.portal.service.UserService;

/**
 * 总班表导入页面
 *
 * @Author menghan
 * @Version 2017-05-24 14:39:04
 */
@Controller
@RequestMapping("schedulePlan")
public class SchedulePlanController extends CommonController{

	private final static Log LOG = LogFactory.getLog(SchedulePlanController.class);
	
	@Autowired
	private SchedulePlanService schedulePlanService;

	@Autowired
	private SchedulePlanDetailService schedulePlanDetailService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDepService userDepService;
	
	@Autowired
	private DepService depService;
	
	@Autowired
	private ShiftsService shiftsService;
	
	@Autowired
	private DicService dicService;
	
    /**
     * 视图前缀
     */
	private static final String VIEW_PREFIX = "schedulePlan";
	private static final String VIEW_INDEX = "index";
	
	@RequestMapping("")
	public String welcome(Model model, PageUtil page, SchedulePlanQuery query){
		return index(model,page,query);
	}
	
	@RequestMapping("index")
	public String index(Model model, PageUtil page, SchedulePlanQuery query){
		try {
			LOG.info("入参："+JsonHelper.toJson(query));
			//数据权限控制
			String allowDepIds = getDepIds(getLoginUser().getUserId());
			if(allowDepIds==null || "".equals(allowDepIds)){
				query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
			}else{
				query.setDepIds(allowDepIds);
			}
			List<SchedulePlan> dataList = schedulePlanService.querySchedulePlanListWithPage(query, page);
			LOG.info("出参："+JsonHelper.toJson(dataList));
            ShiftsQuery shiftsQuery = new ShiftsQuery();
            shiftsQuery.setStatus(1);//启用状态
            List<Shifts> shiftsList = shiftsService.queryShiftsList(shiftsQuery);//一次读取所有班次信息
            DicQuery dicQuery = new DicQuery();
            dicQuery.setParentId(66L);//业务线在字典表的主键id
            List<Dic> businessList = dicService.queryDicList(dicQuery); //一次读取所有业务线信息
			model.addAttribute("dataList", dataList);
			model.addAttribute("shiftsList", shiftsList);
			model.addAttribute("businessList", businessList);
			model.addAttribute("page", page);// 分页
			model.addAttribute("query", query);
			addDepListToModel(model);
		} catch (Exception e) {
			LOG.error("SchedulePlanController index has error.", e);
		}
		return VIEW_PREFIX + "/" + VIEW_INDEX;
	}
	
	/**
	 * 导入总班表excel
     *
	 * @param
	 * @return
	 */
	@RequestMapping("imports")
    @ResponseBody
    public Wrapper<?> imports(@RequestParam("file") MultipartFile file, HttpServletRequest request) throws Exception {
		if(file!=null && !file.isEmpty()){
			SchedulePlanMessage schedulePlanMessage = new SchedulePlanMessage();
			try {
				// 文件保存路径
                String uploadpath = request.getSession().getServletContext().getRealPath("/") + "upload" + File.separator;
                File uploadfile = new File(uploadpath);
                if (!uploadfile.exists())
                    uploadfile.mkdirs();
                String filePath = uploadpath + System.currentTimeMillis()
                        + file.getOriginalFilename();
                // 转存文件
                file.transferTo(new File(filePath));
                LOG.info("转存的文件路径："+filePath);
                List<ImportsErrorMessage> errorMessages = new ArrayList<ImportsErrorMessage>();
                List<ImportsMessage> importsMessages = new ArrayList<ImportsMessage>();
                List<SchedulePlanDetail> schedulePlanDetailList = readExcelFile(filePath,errorMessages,importsMessages);
                schedulePlanMessage.setImportsErrorMessage(errorMessages);
                schedulePlanMessage.setImportsMessage(importsMessages);
                schedulePlanMessage.setSchedulePlanDetail(schedulePlanDetailList);
                
                //排班日期需要小于等于7天
                if(schedulePlanDetailList == null){
                	return WrapMapper.wrap(Wrapper.ERROR_CODE,errorMessages.get(0).getMessage());
                }
                
                //验证总班表导入是否符合要求，要求排班时间必须大于当前日期
                if(!validateSchedulePlanDate(importsMessages)){
                	return WrapMapper.wrap(Wrapper.ERROR_CODE, "导入失败，排班日期必须大于当前日期！");
                }
                
                validateSchedulePlanDetail(errorMessages,importsMessages);
                
                if(errorMessages.size()>0){
                	return WrapMapper.wrap(400, "数据校验错误！",schedulePlanMessage);
                }
                
                LOG.info("导入的总班表详细信息："+JsonHelper.toJson(schedulePlanDetailList));
                List<SchedulePlan> schedulePlanList = readExcelList(schedulePlanDetailList);
                LOG.info("班表导入记录："+JsonHelper.toJson(schedulePlanList));
                //将从excel读取的数据存入数据库
                if(schedulePlanService.inserts(schedulePlanList, schedulePlanDetailList))
                	return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "导入成功！");
                else
                	return  WrapMapper.wrap(Wrapper.ERROR_CODE, "导入失败！");
			}catch(NumberFormatException nfe){
                nfe.printStackTrace();
                LOG.error(nfe.getMessage());
				return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！",schedulePlanMessage);
			}catch (IllegalStateException ise) {
                ise.printStackTrace();
                LOG.error(ise.getMessage());
				return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！",schedulePlanMessage);
			}catch (Exception e) {
                e.printStackTrace();
                LOG.error(e.getMessage());
				return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！",schedulePlanMessage);
			}
		}
		return WrapMapper.wrap(Wrapper.ILLEGAL_ARGUMENT_CODE_, "导入失败，导入文件为空！");
	 }
	
	/**
	 * 提交table数据：先根据table的内容生成excel，并将excel文件保存到服务器，解析excel数据。
     *
	 * @param
	 * @return
	 */
	@RequestMapping("submitTableInfo")
	@ResponseBody
	public Wrapper<?> submitTableInfo(String param){
		if(StringUtils.isNotEmpty(param)){
			SchedulePlanMessage schedulePlanMessage = new SchedulePlanMessage();
			try{
				//将table内容转换成ImportsMessage
				List<ImportsMessage> importsMessages = Arrays.asList(JsonHelper.toBean(param, ImportsMessage[].class));
				LOG.info(JsonHelper.toJson(importsMessages));
				
				List<ImportsErrorMessage> errorMessages = new ArrayList<ImportsErrorMessage>();
				//解析table
	            List<SchedulePlanDetail> schedulePlanDetailList = readTableContent(importsMessages,errorMessages);
	            schedulePlanMessage.setImportsErrorMessage(errorMessages);
	            schedulePlanMessage.setImportsMessage(importsMessages);
	            schedulePlanMessage.setSchedulePlanDetail(schedulePlanDetailList);
	            
	            //排班日期需要小于等于7天
	            if(schedulePlanDetailList == null){
	            	return WrapMapper.wrap(Wrapper.ERROR_CODE,errorMessages.get(0).getMessage());
	            }
	            
	            //验证总班表导入是否符合要求，要求排班时间必须大于当前日期
	            if(!validateSchedulePlanDate(importsMessages)){
	            	return WrapMapper.wrap(Wrapper.ERROR_CODE, "导入失败，排班日期必须大于当前日期！");
	            }
	            
	            validateSchedulePlanDetail(errorMessages,importsMessages);
	            
	            if(errorMessages.size()>0){
	            	return WrapMapper.wrap(400, "数据校验错误！",schedulePlanMessage);
	            }
	            
	            LOG.info("导入的总班表详细信息："+JsonHelper.toJson(schedulePlanDetailList));
	            List<SchedulePlan> schedulePlanList = readExcelList(schedulePlanDetailList);
	            LOG.info("班表导入记录："+JsonHelper.toJson(schedulePlanList));
	            //将从excel读取的数据存入数据库
	            schedulePlanService.inserts(schedulePlanList, schedulePlanDetailList);
	            return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "导入成功！");
			}catch(NumberFormatException nfe){
				return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！",schedulePlanMessage);
			}catch (IllegalStateException ise) {
				return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！",schedulePlanMessage);
			}catch (Exception e) {
				return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！",schedulePlanMessage);
			}
		}
		return WrapMapper.wrap(101,"提交数据失败，提交的数据为空！");
	}

	/**
	 * 导出修改后的excel数据
     *
	 * @param
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("exportExcelInfo")
	public void exportExcelInfo(HttpServletResponse response,HttpServletRequest request) throws IOException{
		String param = request.getParameter("exportJsonStr");
		LOG.info(param);
		String fileName = "修改后的总班表明细"+new SimpleDateFormat("yyyy-MM-dd").format(new Date())+".xls";
		response.setContentType("application/x-excel");
        response.setCharacterEncoding("UTF-8");
        response.addHeader("Content-Disposition", "attachment;filename="
                + new String(fileName.getBytes(), "iso-8859-1"));// excel文件名
        List<ImportsMessage> messages = Arrays.asList(JsonHelper.toBean(param, ImportsMessage[].class));
        LOG.info(messages);
        exportExcel(fileName,messages,response.getOutputStream());
        
	}

	/**
	 * 将修改后的总班表信息导出到excel
     *
	 * @param
	 * @return
	 */
	private void exportExcel(String fileName, List<ImportsMessage> messages,
			ServletOutputStream outputStream) {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet();
		sheet.setDefaultColumnWidth(20);
		HSSFCellStyle style = workbook.createCellStyle();
		HSSFCellStyle dateStyle = workbook.createCellStyle();
		HSSFDataFormat dataFormat = workbook.createDataFormat();
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFRow row = sheet.createRow(0);
		ImportsMessage header = messages.get(0);
		//excel表头
		for(int i=0;i<11;i++){
			HSSFCell cell = row.createCell(i);
			style.setFillBackgroundColor(HSSFColor.CORAL.index);
			cell.setCellStyle(style);
			if(i>=4){
				dateStyle.setDataFormat(dataFormat.getFormat("yyyy/MM/dd"));
            	cell.setCellStyle(dateStyle);
			}
            if(i==0){cell.setCellValue(header.getDepName());}
            else if(i==1){cell.setCellValue(header.getShiftsName());}
            else if(i==2){cell.setCellValue(header.getMealStandard());}
            else if(i==3){cell.setCellValue(header.getBusName());}
            else if(i==4){cell.setCellValue(header.getNum1());}
            else if(i==5){cell.setCellValue(header.getNum2());}
            else if(i==6){cell.setCellValue(header.getNum3());}
            else if(i==7){cell.setCellValue(header.getNum4());}
            else if(i==8){cell.setCellValue(header.getNum5());}
            else if(i==9){cell.setCellValue(header.getNum6());}
            else if(i==10){cell.setCellValue(header.getNum7());}
		}
		int len = messages.size();
		for(int i=1;i<len;i++){
			row = sheet.createRow(i);
			ImportsMessage message = messages.get(i);
			row.createCell(0).setCellValue(message.getDepName());
			row.createCell(1).setCellValue(message.getShiftsName());
			row.createCell(2).setCellValue(message.getMealStandard());
			row.createCell(3).setCellValue(message.getBusName());
			row.createCell(4).setCellValue(message.getNum1());
			row.createCell(5).setCellValue(message.getNum2());
			row.createCell(6).setCellValue(message.getNum3());
			row.createCell(7).setCellValue(message.getNum4());
			row.createCell(8).setCellValue(message.getNum5());
			row.createCell(9).setCellValue(message.getNum6());
			row.createCell(10).setCellValue(message.getNum7());
		}
		try {
			workbook.write(outputStream);
			outputStream.flush();
			outputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//验证总班表中的排班日期是否合理
	private boolean validateSchedulePlanDate(List<ImportsMessage> importsMessages) {
		//importsMessages地0行记录了excel的表头信息，其中包括排班日期
		if(importsMessages==null || importsMessages.size() == 0){
			return true;
		}
		ImportsMessage message = importsMessages.get(0);
        Long now = new Date().getTime();
        if (message == null) {
			return true;
		}
        if (message.getNum1() != null) {
            if (!compareDateLargeNow(now, message.getNum1())) {
                return false;
            }
        }
        if (message.getNum2() != null) {
            if (!compareDateLargeNow(now, message.getNum1())) {
                return false;
            }
        }
        if (message.getNum3() != null) {
            if (!compareDateLargeNow(now, message.getNum1())) {
                return false;
            }
        }
        if (message.getNum4() != null) {
            if (!compareDateLargeNow(now, message.getNum1())) {
                return false;
            }
        }
        if (message.getNum5() != null) {
            if (!compareDateLargeNow(now, message.getNum1())) {
                return false;
            }
        }
        if (message.getNum6() != null) {
            if (!compareDateLargeNow(now, message.getNum1())) {
                return false;
            }
        }
        if (message.getNum7() != null) {
            if (!compareDateLargeNow(now, message.getNum1())) {
                return false;
            }
        }
        return true;
    }

    public boolean compareDateLargeNow(Long now, String date) {
        Long date1 = DateHelper.parseDate(date, "yyyy/MM/dd").getTime();
        if (now < date1) {
            return true;
        }
        return false;
	}
	
	//验证总班表明细中是否有重复信息，判断依据：同一个职场，同一个班次，同一个业务线只能有一行数据
	private void validateSchedulePlanDetail(List<ImportsErrorMessage> errorMessages,List<ImportsMessage> importsMessages) {
		String validate = "";
		List<String> list = new ArrayList<String>();
		int len = importsMessages.size();
		for(int i=1; i<len; i++){
			ImportsMessage message = importsMessages.get(i);
			validate = message.getDepName()+message.getShiftsName()+message.getBusName();
			int pos = list.indexOf(validate);
			if(pos>-1){
				ImportsErrorMessage errorMessage = new ImportsErrorMessage();
				errorMessage.setRow(i);
				errorMessage.setCode("900001");
				errorMessage.setMessage("第"+i+"行数据信息与第"+(pos+1)+"行重复！");
				errorMessages.add(errorMessage);
				list.add(validate);
			}else{
				list.add(validate);
			}
			validate = "";
		}
	}

	/**
	 * 总班表明细
     *
	 * @param
	 * @return
	 */
	@RequestMapping(value = "detail", method = RequestMethod.GET)
	@ResponseBody
	public Wrapper<?> detail(SchedulePlanDetailQuery query){
		if(query == null ){
			return illegalArgument();
		}
		try {
			LOG.info("入参："+query);
			List<SchedulePlanDetail> schedulePlanDetails = schedulePlanDetailService.querySchedulePlanDetailList(query);
			LOG.info("出参："+JsonHelper.toJson(schedulePlanDetails));
			if(CollectionUtils.isNotEmpty(schedulePlanDetails)){
				return WrapMapper.wrap(Wrapper.SUCCESS_CODE,"查询成功",schedulePlanDetails);
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE,"总班表详情为空！");
			}
		} catch (Exception e) {
			LOG.warn("detail staff has error.", e);
			return WrapMapper.wrap(Wrapper.ERROR_CODE,"查询总班表详情失败！");
		}
	}
	
	
	/**
     * 将当前用户的可见部门信息加入model
     *
     * @param
     * @return
     */
    private void addDepListToModel(Model model) {
    	//获得当前用户
		Long userId = getLoginUser().getUserId();
		//当前用户的可见部门列表
		if(userId!=null && userId.intValue()>0){
			String allowDeps = getDepIds(userId);
			List<Dep> depList = depService.getDepListByIds(allowDeps);
//			if(depList!=null && depList.size()!=0){
//				for(Dep dep:depList){
//					dep.setParentDep(depService.getDepById(dep.getParentId()));
//				}
//			}
			model.addAttribute("depList", depList);
		}
	}
    
    /***
     * 获得可见部门的id集合
     */
    private String getDepIds(Long userId){
    	List<UserDep> userDeps = userDepService.queryUserDepList(userId);
		StringBuilder sb = new StringBuilder();
		for(UserDep ud:userDeps){
			sb.append(ud.getDepId()+",");
		}
		String allowDeps = "";
		if(sb.length()>0){
			allowDeps = sb.substring(0, sb.length()-1);
		}
		return allowDeps;
    }
    
    
    /**
     * 读取单元格的数据,把数据保存到importsMessages中，并把通过校验的数据保存到list中，
     *  把错误信息保存到errorMessages。
     */
    private List<SchedulePlanDetail> readExcelFile(String fileName,List<ImportsErrorMessage> errorMessages,List<ImportsMessage> importsMessages) {
        // 创建对Excel工作薄文件的引用
        List<SchedulePlanDetail> list = new ArrayList<SchedulePlanDetail>();
        Workbook wb = null;
        FileInputStream in = null;
        try {
            in = new FileInputStream(fileName);
            if (fileName.endsWith(".xls")) {
                // Excel2003
                wb = new HSSFWorkbook(in);
            } else {
                // Excel 2007
                wb = new XSSFWorkbook(in);
            }

            // 创建对工作表的引用
            Sheet sheet = wb.getSheetAt(0);
            // 遍历所有单元格，读取单元格
            int rowNum = sheet.getLastRowNum();
            
            //excel表格拆分，行转列，例：
            //		     职场名称	班次名称	餐时标准	业务线	2月13日	2月14日	2月15日	2月16日	2月17日	2月18日	2月19日
            //	转换成：职场名称	班次名称	餐时标准	业务线	2月13日，班次名称	餐时标准	业务线	2月14日，...等等
            //获得需要转换的列的行数，也就是日期个数
            Row firstRow = sheet.getRow(0);//excel第一行，标题
            List<Date> planDates = new ArrayList<Date>();
            int dayCount = 0;//计算导入的总班表数据有几天，存在不足7天的情况
            for(int i=4;firstRow.getCell(i)!=null;i++){//从第四行开始，是2月13日的日期。
            	Date date = null;
            	try {
            		date = readDateValue(firstRow.getCell(i));
            	} catch (Exception e) {
            		e.printStackTrace();
            	}
            	planDates.add(date);
            	dayCount++;
            }
            //将标题信息存到importMessage中
            ImportsMessage titleMessage = new ImportsMessage();
            titleMessage.setDepName(readValue(firstRow.getCell(0)));
            titleMessage.setShiftsName(readValue(firstRow.getCell(1)));
            titleMessage.setMealStandard(readValue(firstRow.getCell(2)));
            titleMessage.setBusName(readValue(firstRow.getCell(3)));
            if(dayCount>=1){titleMessage.setNum1(DateHelper.format(readDateValue(firstRow.getCell(4)), "yyyy/MM/dd"));}
            if(dayCount>=2){titleMessage.setNum2(DateHelper.format(readDateValue(firstRow.getCell(5)), "yyyy/MM/dd"));}
            if(dayCount>=3){titleMessage.setNum3(DateHelper.format(readDateValue(firstRow.getCell(6)), "yyyy/MM/dd"));}
            if(dayCount>=4){titleMessage.setNum4(DateHelper.format(readDateValue(firstRow.getCell(7)), "yyyy/MM/dd"));}
            if(dayCount>=5){titleMessage.setNum5(DateHelper.format(readDateValue(firstRow.getCell(8)), "yyyy/MM/dd"));}
            if(dayCount>=6){titleMessage.setNum6(DateHelper.format(readDateValue(firstRow.getCell(9)), "yyyy/MM/dd"));}
            if(dayCount>=7){titleMessage.setNum7(DateHelper.format(readDateValue(firstRow.getCell(10)), "yyyy/MM/dd"));}
            importsMessages.add(titleMessage);
            //排班日期需要小于等于7天
            if(planDates.size()<=0||planDates.size()>7){
            	ImportsErrorMessage errorMessage = new ImportsErrorMessage();
            	errorMessage.setCode("100001");
            	errorMessage.setMessage("排班日期需要小于等于7天");
            	errorMessages.add(errorMessage);
            	return null;
            }
            String depName = "";//职场名称，也就是部门
            Dep dep = null;
            String shiftsName = "";//班次名称
            Shifts shifts = new Shifts();
            ShiftsQuery shiftsQuery = new ShiftsQuery();
            shiftsQuery.setStatus(1);
            List<Shifts> shiftsList = shiftsService.queryShiftsList(shiftsQuery);//一次读取所有班次信息
            String mealStandard = "";//餐时标准
            String busName = "";//业务线名称
            Dic business = null;
            DicQuery dicQuery = new DicQuery();
            dicQuery.setParentId(66L);//业务线在字典表的主键id
            List<Dic> businessList = dicService.queryDicList(dicQuery); //一次读取所有业务线信息
            String num = "";//排班人数
            int counter;//设置一个计数器，当counter大于0的时候，表示导入的数据有问题
            //读取excel中的数据，从第二行开始
            for (int i = 1; i <= rowNum; i++) {
            	counter = 0;
                Row row = sheet.getRow(i);
                if (row == null)
                    continue;
                //部门--职场名
                depName = readValue(row.getCell(0));
                if(dep==null || !depName.equals(dep.getName())){
                	dep = depService.getDepByName(depName);
                }
                //部门不存在
                if(dep == null){
                	ImportsErrorMessage errorMessage = new ImportsErrorMessage();
                	errorMessage.setCode("200001");
                	errorMessage.setMessage("职场："+depName+"不存在");
                	errorMessage.setRow(i);
                	errorMessage.setColumn(0);//excel第1行为职场名称
                	errorMessages.add(errorMessage);
                	counter++;
                }
                //班次名称
                shiftsName = readValue(row.getCell(1));
                if(shifts==null || !shiftsName.equals(shifts.getShiftsName())){
					shifts=new Shifts();
                	shifts.setShiftsName(shiftsName);
                	int pos = shiftsList.indexOf(shifts);
                	if(pos<0){
                		shifts = null;
                	}else{
                		shifts = shiftsList.get(pos);
                	}
                }
                //班次名称不存在
                if(shifts==null){
                	ImportsErrorMessage errorMessage = new ImportsErrorMessage();
                	errorMessage.setCode("300001");
                	errorMessage.setMessage("班次："+shiftsName+"不存在");
                	errorMessage.setRow(i);
                	errorMessage.setColumn(1);//excel第2行为职场名称
                	errorMessages.add(errorMessage);
                	counter++;
                }
                //餐时
                mealStandard = readValue(row.getCell(2));
                mealStandard = mealStandard.replace("m", ""); //有些excel单元格中，餐时时间带有m，replace掉
                //业务线
                busName = readValue(row.getCell(3));
                if(business == null || !busName.equals(business.getName())){
                	for(Dic b : businessList){
                		if(busName.equals(b.getName())){
                			business = b;
                		}
                	}
                }
                //业务线不存在
                if(business == null){
                	ImportsErrorMessage errorMessage = new ImportsErrorMessage();
                	errorMessage.setCode("400001");
                	errorMessage.setMessage("业务线："+busName+"不存在");
                	errorMessage.setRow(i);
                	errorMessage.setColumn(3);//excel第4行为职场名称
                	errorMessages.add(errorMessage);
                	counter++;
                }
                //计数器为0，说明excel的这行数据验证通过
                if(counter==0){
	                //excel行转列的地方，将一行七天的数据转换成七行一天的数据
	                int colNum = 4;//从第四行开始
	                for(Date planDate:planDates){
	                	num = readValue(row.getCell(colNum));
	                	SchedulePlanDetail detail = new SchedulePlanDetail();
	                	detail.setDepId(dep.getId());//职场
	                	detail.setShiftsId(shifts.getId());//班次
	                	detail.setMealStandard(Integer.parseInt(mealStandard));//餐时
	                	detail.setBusId(business.getNum().intValue());//业务线
	                	detail.setNum(Integer.parseInt(num));//人数
	                	detail.setPlanDate(planDate);//排班日期
	                	detail.setCreateUser(getLoginUserName());
	                	list.add(detail);
	                	colNum++;
	                }
                }
                business = null;
                //保存excel的数据，不做验证
                ImportsMessage importsMessage = new ImportsMessage();
                importsMessage.setDepName(depName);
                importsMessage.setShiftsName(shiftsName);
                importsMessage.setMealStandard(mealStandard);
                importsMessage.setBusName(busName);
                importsMessage.setNum1(readValue(row.getCell(4)));
                importsMessage.setNum2(readValue(row.getCell(5)));
                importsMessage.setNum3(readValue(row.getCell(6)));
                importsMessage.setNum4(readValue(row.getCell(7)));
                importsMessage.setNum5(readValue(row.getCell(8)));
                importsMessage.setNum6(readValue(row.getCell(9)));
                importsMessage.setNum7(readValue(row.getCell(10)));
                importsMessages.add(importsMessage);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                wb.close();
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    //读取excel单元格中的数值
    private String readValue(Cell cell) {
        String value = "";
        if (cell == null) {
            return null;
        }
        int rowType = cell.getCellType();
        if (rowType == Cell.CELL_TYPE_STRING) {
            value = cell.getStringCellValue();
        }else if (rowType == Cell.CELL_TYPE_NUMERIC) {
            DecimalFormat df = new DecimalFormat("0");
            Number v = cell.getNumericCellValue();
            value = df.format(v);
        }
        return value;
    }
    
    //读取excel中的日期
    private Date readDateValue(Cell cell){
    	int cellType = cell.getCellType();
    	if(cellType == Cell.CELL_TYPE_STRING){
    		return DateHelper.parseDate(cell.getStringCellValue(), "yyyy/MM/dd");
    	}else{
    		return cell.getDateCellValue();
    	}
    }
    
    /**
	 * 从总班表详细信息中，抽取出总班表导入记录，抽取规则：按照部门与业务线抽取
	 * 										例：三个部门、每个部门有两个业务线，最后会抽取六条记录
	 * 										        三个部门、有一个部门有两个业务线、剩下的部门有一个业务线，最后会抽取四条记录
	 * @param
	 * @return
	 */
	private List<SchedulePlan> readExcelList(List<SchedulePlanDetail> excellist) {
		Date startDate = null;//起始日期
		Date endDate = null;//结束日期
//		Set<Long> depIds = new LinkedHashSet<Long>();//部门--职场，导入的职场可能有多个
		Set<String> depAndBus = new LinkedHashSet<String>();//存储部门和该部门对应的业务线，一定会要保证有序
		List<Date> dates = new ArrayList<Date>();//排班日期列表，排序完成后，第一个为起始日期，最后一个为结束日期
		String username = getLoginUserName();
		List<SchedulePlan> schedulePlans = new ArrayList<SchedulePlan>();
		for(SchedulePlanDetail detail:excellist){
//			depIds.add(detail.getDepId());//部门--职场列表去重
			depAndBus.add(detail.getDepId() + "-" + detail.getBusId());
			dates.add(detail.getPlanDate());//加入排班日期
		}
		try {
			Collections.sort(dates,dateComparator);//排班日期排序
		} catch (Exception e) {
			e.printStackTrace();
		}
		startDate = dates.get(0);
		endDate = dates.get(dates.size()-1);
//		for(Long depId:depIds){//按部门（职场）加入到集合中
//			SchedulePlan plan = new SchedulePlan();
//			plan.setDepId(depId);
//			plan.setBeginTime(startDate);
//			plan.setEndTime(endDate);
//			plan.setCreateUser(username);
//			schedulePlans.add(plan);
//		}
		for(String dab:depAndBus){//按部门(职场)-业务线加入到集合中
			String[] ids = dab.split("-");//数组0为depId，数组1为busId
			if(ids == null || ids.length<2){
				continue;
			}
			SchedulePlan plan = new SchedulePlan();
			plan.setDepId(Long.parseLong(ids[0]));//部门id
			plan.setBusId(Long.parseLong(ids[1]));//业务id
			plan.setBeginTime(startDate);
			plan.setEndTime(endDate);
			plan.setCreateUser(username);
			schedulePlans.add(plan);
		}
		return schedulePlans;
	}
    
    //日期排序，升序
    private Comparator<Date> dateComparator = new Comparator<Date>() {
		@Override
		public int compare(Date o1, Date o2) {
			return o1.compareTo(o2);
		}
	};
	
	/**
	 * 解析提交的table数据
     *
	 * @param
	 * @return
	 */
	private List<SchedulePlanDetail> readTableContent(List<ImportsMessage> importsMessages,List<ImportsErrorMessage> errorMessages) {
		// 创建对Excel工作薄文件的引用
        List<SchedulePlanDetail> list = new ArrayList<SchedulePlanDetail>();
        try {
            
            //table数据拆分，行转列，例：
            //		     职场名称	班次名称	餐时标准	业务线	2月13日	2月14日	2月15日	2月16日	2月17日	2月18日	2月19日
            //	转换成：职场名称	班次名称	餐时标准	业务线	2月13日，班次名称	餐时标准	业务线	2月14日，...等等
            //获得需要转换的列的行数，也就是日期个数
        	ImportsMessage firstImportsMessage = importsMessages.get(0);//table第一行，标题
            List<Date> planDates = new ArrayList<Date>();
            if (StringUtils.isNotEmpty(firstImportsMessage.getNum1())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getNum1(), "yyyy/MM/dd"));
            }//从第四行开始，是2月13日的日期。
            if (StringUtils.isNotEmpty(firstImportsMessage.getNum2())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getNum2(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getNum3())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getNum3(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getNum4())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getNum4(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getNum5())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getNum5(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getNum6())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getNum6(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getNum7())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getNum7(), "yyyy/MM/dd"));
            }
            //排班日期需要小于等于7天
            if(planDates.size()<=0||planDates.size()>7){
            	ImportsErrorMessage errorMessage = new ImportsErrorMessage();
            	errorMessage.setCode("100001");
            	errorMessage.setMessage("排班日期需要小于等于7天");
            	errorMessages.add(errorMessage);
            	return null;
            }
            String depName = "";//职场名称，也就是部门
            Dep dep = null;
            String shiftsName = "";//班次名称
            Shifts shifts = new Shifts();
            ShiftsQuery shiftsQuery = new ShiftsQuery();
            shiftsQuery.setStatus(1);
            List<Shifts> shiftsList = shiftsService.queryShiftsList(shiftsQuery);//一次读取所有班次信息
            String mealStandard = "";//餐时标准
            String busName = "";//业务线名称
            Dic business = null;
            DicQuery dicQuery = new DicQuery();
            dicQuery.setParentId(66L);//业务线在字典表的主键id
            List<Dic> businessList = dicService.queryDicList(dicQuery); //一次读取所有业务线信息
            String num = "";//排班人数
            int counter;//设置一个计数器，当counter大于0的时候，表示导入的数据有问题
            //读取excel中的数据，从第二行开始
            int n = importsMessages.size();
            for (int i = 1; i < n; i++) {
            	counter = 0;
                ImportsMessage importsMessage = importsMessages.get(i);
                if (importsMessage == null)
                    continue;
                //部门--职场名
                depName = importsMessage.getDepName();
                if(dep==null || !depName.equals(dep.getName())){
                	dep = depService.getDepByName(depName);
                }
                //部门不存在
                if(dep == null){
                	ImportsErrorMessage errorMessage = new ImportsErrorMessage();
                	errorMessage.setCode("200001");
                	errorMessage.setMessage("职场："+depName+"不存在");
                	errorMessage.setRow(i);
                	errorMessage.setColumn(0);//excel第1行为职场名称
                	errorMessages.add(errorMessage);
                	counter++;
                }
                //班次名称
                shiftsName = importsMessage.getShiftsName();
                if(shifts==null || !shiftsName.equals(shifts.getShiftsName())){
					shifts=new Shifts();
                	shifts.setShiftsName(shiftsName);
                	int pos = shiftsList.indexOf(shifts);
                	if(pos<0){
                		shifts = null;
                	}else{
                		shifts = shiftsList.get(pos);
                	}
                }
                //班次名称不存在
                if(shifts==null){
                	ImportsErrorMessage errorMessage = new ImportsErrorMessage();
                	errorMessage.setCode("300001");
                	errorMessage.setMessage("班次："+shiftsName+"不存在");
                	errorMessage.setRow(i);
                	errorMessage.setColumn(1);//excel第2行为职场名称
                	errorMessages.add(errorMessage);
                	counter++;
                }
                //餐时
                mealStandard = importsMessage.getMealStandard();
                mealStandard = mealStandard.replace("m", ""); //有些excel单元格中，餐时时间带有m，replace掉
                //业务线
                busName = importsMessage.getBusName();
                if(business == null || !busName.equals(business.getName())){
                	for(Dic b : businessList){
                		if(busName.equals(b.getName())){
                			business = b;
                		}
                	}
                }
                //业务线不存在
                if(business == null){
                	ImportsErrorMessage errorMessage = new ImportsErrorMessage();
                	errorMessage.setCode("400001");
                	errorMessage.setMessage("业务线："+busName+"不存在");
                	errorMessage.setRow(i);
                	errorMessage.setColumn(3);//excel第4行为职场名称
                	errorMessages.add(errorMessage);
                	counter++;
                }
                //计数器为0，说明excel的这行数据验证通过
                if(counter==0){
	                //excel行转列的地方，将一行七天的数据转换成七行一天的数据
	                int colNum = 0;//从第四行开始
	                int pz = planDates.size();
	                List<String> nums = new ArrayList<String>(pz);
	                if(pz>=1){nums.add(importsMessage.getNum1());}
	                if(pz>=2){nums.add(importsMessage.getNum2());}
	                if(pz>=3){nums.add(importsMessage.getNum3());}
	                if(pz>=4){nums.add(importsMessage.getNum4());}
	                if(pz>=5){nums.add(importsMessage.getNum5());}
	                if(pz>=6){nums.add(importsMessage.getNum6());}
	                if(pz>=7){nums.add(importsMessage.getNum7());}
	                for(Date planDate:planDates){
	                	num = nums.get(colNum);
	                	SchedulePlanDetail detail = new SchedulePlanDetail();
	            		detail.setDepId(dep.getId());//职场
	                	detail.setShiftsId(shifts.getId());//班次
	                	detail.setMealStandard(Integer.parseInt(mealStandard));//餐时
	                	detail.setBusId(business.getNum().intValue());//业务线
	                	detail.setNum(Integer.parseInt(num));//人数
	                	detail.setPlanDate(planDate);//排班日期
	                	detail.setCreateUser(getLoginUserName());
	                	list.add(detail);
	                	colNum++;
	                }
                }
                business = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return list;
	}

}
