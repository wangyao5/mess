package com.letv.css.portal.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.DateHelper;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.constant.CommonConstants;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.service.*;
import com.letv.css.portal.util.mail.MailSender;
import com.letv.css.portal.domain.vo.workflow.bean.ProcessLog;
import com.letv.css.portal.domain.vo.workflow.bean.NewInstanceParam;
import com.letv.css.portal.domain.vo.workflow.bean.QInstanceResult;
import com.letv.css.portal.domain.vo.workflow.bean.WfResponse;
import com.letv.css.portal.domain.vo.workflow.bean.WorkFlowIndexQuery;

import com.letv.css.web.common.utils.HttpUtil;
import com.letv.css.web.common.utils.JsonUtil;
import com.letv.css.web.common.utils.Md5Util;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jianghongwei on 2016/11/30.
 */
@Controller
@RequestMapping("workflow")
public class MainController extends BaseController {
    private static final Log LOG = LogFactory.getLog(MainController.class);


    @Value("${workflow.url.domain.host}")
    private String URL_TEST;
    @Value("${workflow.url.domain.queryInstanceSumByMyOpen}")
    private String URL_QUERYINSTANCESUMBYMYOPEN;
    @Value("${workflow.url.domain.queryInstanceByMyOpen}")
    private String URL_QUERYINSTANCEBYMYOPEN;
    @Value("${workflow.url.domain.processInstance}")
    private String URL_PROCESSINSTANCE;
    @Value("${workflow.url.domain.queryInstanceLog}")
    private String URL_QUERYINSTANCELOG;


    /**
     * 视图前缀
     */
    private static final String viewPrefix = "workflow";
    private static final String viewPrefix1 = "closeNo";
    @Autowired
    private StaffService staffService;
    @Autowired
    private UserService userService;

    @Autowired
    private DicService dicService;

    @Autowired
    private UserDepService userDepService;

    @Autowired
    private DepService depService;
    @Autowired
    private AdjustChangeService adjustChangeService;
    @Autowired
    private LeaveService leaveService;
    //收件人列表
    @Value("#{'${email.to}'.split(',')}")
    private String[] to;

    /**
     * @param model 我的待办、
     *              我的已办理、
     * @param query
     * @return
     */
    @RequestMapping(value = "")
    public String index(Model model, WorkFlowIndexQuery query) {
        try {
            String url = URL_TEST + URL_QUERYINSTANCESUMBYMYOPEN;
            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put("operatorType", "css");
            param.put("operatorId", String.valueOf(getLoginUserId()));
            param.put("keyword", query.getQparam());
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            LOG.info("start call workflow url:" + url + ": " + param.toString());
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info("end to call workflow resul is:" + str);
            HashMap wfs = JsonUtil.fromJsonObject(str, HashMap.class);
            LOG.info(wfs.get("result"));
            if ("0".equals(wfs.get("status")))
                model.addAttribute("paramValues", wfs.get("result"));
            model.addAttribute("query", query);
        } catch (Exception e) {
            LOG.info("error:", e);
        }
        return viewPrefix + "/index";
    }

    @RequestMapping(value = "/create")
    public String create() {
        return viewPrefix + "/create";
    }

    /**
     * 审核列表页
     *
     * @param model
     * @param page
     * @param query
     * @param request
     * @return
     */
    @RequestMapping(value = "status")
    public String toStatus(Model model, PageUtil page, WorkFlowIndexQuery query, HttpServletRequest request) {
        try {
            String qparam = "";
            if (request.getParameter("qparam") != null) {
                qparam = URLDecoder.decode(request.getParameter("qparam"), "UTF-8");
            }
            String url = URL_TEST + URL_QUERYINSTANCEBYMYOPEN;
            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put("operatorType", "css");
            param.put("operatorId", String.valueOf(getLoginUserId()));
            param.put("flowId", query.getFlowId());
            param.put("statusId", query.getStatusId());
            if (StringUtils.isNotEmpty(query.getQparam())) {
                param.put("keyword", query.getQparam());
            }
            if (StringUtils.isNotEmpty(qparam)) param.put("keyword", qparam);
            param.put("page", String.valueOf(page.getCurPage()));
            param.put("pageRows", String.valueOf(page.getPageSize()));
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info(str);
            WfResponse<QInstanceResult> wfs = JsonUtil.fromJsonObject(str,
                    new TypeReference<WfResponse<QInstanceResult>>() {
                    });
            if (wfs.getStatus().equals("0")) {
                QInstanceResult qir = (QInstanceResult) wfs.getResult();
                Integer totalRow = Integer.valueOf(qir.getTotal());
                page.setTotalRow(totalRow);
                page.init();
                model.addAttribute("dataList", qir.getInstance());
            }
            if (StringUtils.isNotEmpty(query.getFlowId())) model.addAttribute("flowId", query.getFlowId());
            if (StringUtils.isNotEmpty(query.getStatusId())) model.addAttribute("statusId", query.getStatusId());
            model.addAttribute("query", query);
            model.addAttribute("qparam", URLDecoder.decode(qparam, "UTF-8"));
            model.addAttribute("page", page);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if ("closeJobNo".equals(query.getStatusId())) {
            return viewPrefix1 + "/status";
        }
        return viewPrefix + "/status";
    }

    /**
     * @param model 入职审核页面
     * @param staff
     * @param p
     * @return
     */
    @RequestMapping(value = "bpoAdd")
    public String bpoAdd(Model model, Staff staff, NewInstanceParam p) {
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            model.addAttribute("staff", staffResult);
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
            addEnumToModel(model, staffResult);
            WorkFlowIndexQuery query = new WorkFlowIndexQuery();
            query.setFlowId(p.getFlowId());
            query.setInstanceId(p.getInstanceId());
            String str = getWFInstanceLog(staff, query);
            WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str,
                    new TypeReference<WfResponse<List<ProcessLog>>>() {
                    });
            if ("0".equals(wfs.getStatus()))
                model.addAttribute("result", wfs.getResult());
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
        }
        return viewPrefix + "/bpoAdd";
    }

    /**
     * @param model
     * @param staff 入职审核
     * @param p
     * @return
     */
    @RequestMapping(value = "bpoAddCheck")
    @ResponseBody
    public Wrapper<?> bpoAddCheck(Model model, Staff staff, NewInstanceParam p) {
        HashMap wfs = null;
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());
            String url = URL_TEST + URL_PROCESSINSTANCE;
            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put("operatorType", "css");
            param.put("operatorId", String.valueOf(getLoginUserId()));
            param.put("instanceId", p.getInstanceId());
            param.put("statusId", p.getStatusId());
            param.put("actionId", p.getActionId());
            param.put("remark", p.getRemark());
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            LOG.info("start bpoAddCheck call workflow url:" + url + ": " + param.toString());
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info("end bpoAddCheck to call workflow resul is:" + str);
            wfs = JsonUtil.fromJsonObject(str, HashMap.class);
            Staff staffbean = new Staff();
            staffbean.setId(staff.getId());
            staffbean.setUpdateUser(getLoginUserCnName());
            if ("waitForFirstCheck".equals(p.getStatusId())) {
                //一审
                if ("0".equals(wfs.get("status"))) {
                    //审核通过
                    if ("allow".equals(p.getActionId())) staffbean.setReviewedStatus(10);
                    else staffbean.setReviewedStatus(11);
                    staffService.update(staffbean);
                } else {
                    return error();
                }

            } else if ("waitForSecondCheck".equals(p.getStatusId())) {
                //2审
                if ("0".equals(wfs.get("status"))) {
                    //审核通过
                    if ("allow".equals(p.getActionId())) {
                        staffbean.setPositionStatus("1");//培训
                        staffbean.setReviewedStatus(14);//14工号申请
                        MailSender.sendEmail(to, staffResult.getName() + "工号申请", "您好:<br> &emsp;&emsp;" + staffResult.getDep().getName() + "," + staffResult.getName() + "入职二审通过，需要进行工号申请。");
                    } else {
                        staffbean.setReviewedStatus(13);
                    }
                    staffService.update(staffbean);
                } else {
                    return error();
                }
            } else if ("waitForEmployeeNumCheck".equals(p.getStatusId())) {
                //工号申请被驳回
                if ("0".equals(wfs.get("status"))) {
                    if ("reject".equals(p.getActionId())) {
                        staffbean.setReviewedStatus(11);
                        staffService.update(staffbean);
                    }
                } else {
                    return error();
                }
            } else {
                return error();
            }
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
            return error();
        }
        return new Wrapper<HashMap>().result((HashMap) wfs.get("result"));
    }


    @RequestMapping(value = "bpoAddDetail")
    public String bpoAddDetail(Model model, Staff staff, WorkFlowIndexQuery query) {
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            String str = getWFInstanceLog(staff, query);
            model.addAttribute("staff", staffResult);
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
            LOG.info("end to bpoAddDetail resul is:" + str);
            WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str,
                    new TypeReference<WfResponse<List<ProcessLog>>>() {
                    });
//            HashMap wfs =  JsonUtil.fromJsonObject(str,HashMap.class);
            //LOG.info(wfs.getResult());
            if ("0".equals(wfs.getStatus()))
                model.addAttribute("result", wfs.getResult());
            addEnumToModel(model, staffResult);
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
        }
        return viewPrefix + "/bpoAddDetail";
    }

    private String getWFInstanceLog(Staff staff, WorkFlowIndexQuery query) throws IOException {
        String url = URL_TEST + URL_QUERYINSTANCELOG;
        Map<String, String> param = new HashMap<String, String>();
        String timestamp = String.valueOf(System.currentTimeMillis());
        param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
        param.put("operatorType", "css");
        param.put("operatorId", String.valueOf(getLoginUserId()));
        param.put("instanceId", query.getInstanceId());
        param.put("flowId", query.getFlowId());
        param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
        param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
        // param.put(CommonConstants.s, value)
//        if (StringUtils.isNotBlank(query.getQparam())){
//            param.put("q", query.getQparam());
//        }

        LOG.info("start getWFInstanceLog url:" + url + ": " + param.toString());
        String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
        LOG.info("end  getWFInstanceLog result:" + str);
        return str;
    }

    @RequestMapping(value = "bpoOnLineSecondUpdate")
    public String bpoOnLineSecondUpdate(Model model, Staff staff) {
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            model.addAttribute("staff", staffResult);
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
            addEnumToModel(model, staffResult);
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
        }
        return viewPrefix + "/bpoOnLineSecondUpdate";
    }

    @RequestMapping(value = "bpoOnLineUpdate")
    public String bpoOnLineUpdate(Model model, Staff staff, NewInstanceParam p) {
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            if (staffResult != null) {
                Long pid = staffResult.getDep().getParentId();
                if (pid != null && pid > 0) {
                    staffResult.getDep().setParentDep(depService.getDepById(pid));
                }
                model.addAttribute("staff", staffResult);
            }
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
            addEnumToModel(model, staffResult);
            WorkFlowIndexQuery query = new WorkFlowIndexQuery();
            query.setFlowId(p.getFlowId());
            query.setInstanceId(p.getInstanceId());
            String str = getWFInstanceLog(staff, query);
            WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str,
                    new TypeReference<WfResponse<List<ProcessLog>>>() {
                    });
            if ("0".equals(wfs.getStatus()))
                model.addAttribute("result", wfs.getResult());
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
        }
        return viewPrefix + "/bpoOnLineUpdate";
    }

    /**
     * @param model
     * @param staff 上线审核详情
     * @return
     */
    @RequestMapping(value = "bpoOnLineDetail")
    public String bpoOnLineDetail(Model model, Staff staff, WorkFlowIndexQuery query) {
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            if (staffResult != null) {
                Long pid = staffResult.getDep().getParentId();
                if (pid != null && pid > 0) {
                    staffResult.getDep().setParentDep(depService.getDepById(pid));
                }
                model.addAttribute("staff", staffResult);
                String str = getWFInstanceLog(staff, query);
                LOG.info("end to bpoOnLineDetail resul is:" + str);
                WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str,
                        new TypeReference<WfResponse<List<ProcessLog>>>() {
                        });
//	            HashMap wfs =  JsonUtil.fromJsonObject(str,HashMap.class);
                //LOG.info(wfs.getResult());
                if ("0".equals(wfs.getStatus()))
                    model.addAttribute("result", wfs.getResult());
            }
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
            addEnumToModel(model, staffResult);

        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
        }
        return viewPrefix + "/bpoOnLineDetail";
    }

    /**
     * @param model
     * @param staff 岗位调整和结构调整审核
     * @return
     */
    @RequestMapping(value = "jobTitleAdjustment")
    public String jobTitleAdjustment(Model model, Staff staff, NewInstanceParam p) {
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            AdjustChange adjustChange = adjustChangeService.selectById(p.getAdjustId());
            if (staffResult == null || adjustChange == null) {
                LOG.error("jobTitleAdjustment has error.");
                return null;
            }
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());
            model.addAttribute("type", p.getType());
            model.addAttribute("isDetail", p.getIsDetail());
            model.addAttribute("adjustId", p.getAdjustId());
            if (staffResult != null) {
                Long pid = staffResult.getDep().getParentId();
                if (pid != null && pid > 0) {
                    staffResult.getDep().setParentDep(depService.getDepById(pid));
                }
                model.addAttribute("staff", staffResult);
                model.addAttribute("adjustChange", adjustChange);
            }
            model.addAttribute("changeDate", DateHelper.format(adjustChange.getChangeDate(), "yyyy-MM-dd"));
            addEnumToModel(model, staffResult, adjustChange);
            WorkFlowIndexQuery query = new WorkFlowIndexQuery();
            query.setFlowId(p.getFlowId());
            query.setInstanceId(p.getInstanceId());
            String str = getWFInstanceLog(staff, query);
            WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str,
                    new TypeReference<WfResponse<List<ProcessLog>>>() {
                    });
            if ("0".equals(wfs.getStatus()))
                model.addAttribute("result", wfs.getResult());

        } catch (Exception e) {
            LOG.error("jobTitleAdjustment has error.", e);
        }
        return viewPrefix + "/jobTitleAdjustment";
    }


    /**
     * @param model
     * @param staff 岗位调整和结构调整审核
     * @param p
     * @return
     */
    @RequestMapping(value = "jobTitleAdjustmentCheck")
    @ResponseBody
    public Wrapper<?> jobTitleAdjustmentCheck(Model model, Staff staff, NewInstanceParam p) {
        HashMap wfs = null;
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            AdjustChange adjustChange = adjustChangeService.selectById(p.getAdjustId());
            if (staffResult == null || adjustChange == null) {
                LOG.error("jobTitleAdjustment has error.");
                return null;
            }
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());
            String url = URL_TEST + URL_PROCESSINSTANCE;
            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put("operatorType", "css");
            param.put("operatorId", String.valueOf(getLoginUserId()));
            param.put("instanceId", p.getInstanceId());
            param.put("statusId", p.getStatusId());
            param.put("actionId", p.getActionId());
            param.put("remark", p.getRemark());
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            LOG.info("start bpoAddCheck call workflow url:" + url + ": " + param.toString());
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info("end bpoAddCheck to call workflow resul is:" + str);
            wfs = JsonUtil.fromJsonObject(str, HashMap.class);
            if ("0".equals(wfs.get("status"))) {
                //获取为最终状态修改部门和岗位
                HashMap resultmap = (HashMap) wfs.get("result");
                if (resultmap != null && "finishedNormally".equals(resultmap.get("statusTo"))) {
                    Staff staffResultUpdate = new Staff();
                    staffResultUpdate.setDepId(adjustChange.getNewDepartment());
                    staffResultUpdate.setJobTitle(adjustChange.getNewPost());
                    staffResultUpdate.setId(staff.getId());
                    staffResultUpdate.setUpdateUser(getLoginUserCnName());
                    staffResultUpdate.setUpdateTime(new Date());
                    staffResultUpdate.setService(adjustChange.getNewService());
                    staffService.update(staffResultUpdate);
                }
                if ("waitForFirstCheck".equals(p.getStatusId())) {
                    //一审
                    /*10:入职一审 11: 入职一审驳回 12:入职二审 13:入职二审驳回 14:工号申请 15:入职成功
20:上线一审 21: 上线一审驳回 22:上线二审 23:上线二审驳回 24:二审通过 
30:岗位调整一审 31: 岗位调整一审驳回 32:岗位调整二审 33:岗位调整二审驳回 34:二审通过 
40:部门调整一审 41: 部门调整一审驳回 42:部门调整二审 43:部门调整二审驳回 44:二审通过 

50:离职一审 51: 离职一审驳回 52:离职二审 53:离职二审驳回 54:工号关闭 55:离职成功*/
                    if ("0".equals(wfs.get("status"))) {
                        //审核通过
                        Staff staffResultUpdate = new Staff();
                        staffResultUpdate.setId(staff.getId());
                        if ("allow".equals(p.getActionId())) {
                            if (0 == adjustChange.getChangeType()) staffResultUpdate.setReviewedStatus(42);
                            if (1 == adjustChange.getChangeType()) staffResultUpdate.setReviewedStatus(32);
                        } else {
                            if (0 == adjustChange.getChangeType()) staffResultUpdate.setReviewedStatus(41);
                            if (1 == adjustChange.getChangeType()) staffResultUpdate.setReviewedStatus(31);
                        }
                        staffResultUpdate.setUpdateUser(getLoginUserCnName());
                        staffResultUpdate.setUpdateTime(new Date());
                        staffService.update(staffResultUpdate);
                    } else {
                        return error();
                    }

                } else {
                    //2审
                    if ("0".equals(wfs.get("status"))) {
                        Staff staffResultUpdate = new Staff();
                        staffResultUpdate.setId(staff.getId());
                        //审核通过
                        if ("allow".equals(p.getActionId())) {
                            if (0 == adjustChange.getChangeType()) staffResultUpdate.setReviewedStatus(44);
                            if (1 == adjustChange.getChangeType()) staffResultUpdate.setReviewedStatus(34);
                        } else {
                            if (0 == adjustChange.getChangeType()) staffResultUpdate.setReviewedStatus(43);
                            if (1 == adjustChange.getChangeType()) staffResultUpdate.setReviewedStatus(33);
                        }
                        staffResultUpdate.setUpdateUser(getLoginUserCnName());
                        staffResultUpdate.setUpdateTime(new Date());
                        staffService.update(staffResultUpdate);
                    } else {
                        return error();
                    }
                }

            } else
                return error();
//            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
//            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
            return error();
        }
        return new Wrapper<HashMap>().result((HashMap) wfs.get("result"));
    }


    @RequestMapping(value = "dimission")
    public String dimission(Model model, Staff staff, NewInstanceParam p) {
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());
            if (staffResult != null) {
                model.addAttribute("staff", staffResult);
                WorkFlowIndexQuery query = new WorkFlowIndexQuery();
                query.setFlowId(p.getFlowId());
                query.setInstanceId(p.getInstanceId());
                String str = getWFInstanceLog(staff, query);
                LOG.info("end to bpoOnLineDetail resul is:" + str);
                WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str,
                        new TypeReference<WfResponse<List<ProcessLog>>>() {
                        });
                if ("0".equals(wfs.getStatus()))
                    model.addAttribute("result", wfs.getResult());
            }
            model.addAttribute("dimissionDate", DateHelper.format(staffResult.getDimissionDate(), "yyyy-MM-dd"));
            addEnumToModel(model, staffResult);
        } catch (Exception e) {
            LOG.error(" dimission has error.", e);
        }
        return viewPrefix + "/dimission";
    }


    @RequestMapping(value = "dimissionDetail")
    public String dimissionDetail(Model model, Staff staff, WorkFlowIndexQuery query) {
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            if (staffResult != null) {
                model.addAttribute("staff", staffResult);
                String str = getWFInstanceLog(staff, query);
                LOG.info("end to bpoOnLineDetail resul is:" + str);
                WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str,
                        new TypeReference<WfResponse<List<ProcessLog>>>() {
                        });
                if ("0".equals(wfs.getStatus()))
                    model.addAttribute("result", wfs.getResult());
            }
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
            addEnumToModel(model, staffResult);
        } catch (Exception e) {
            LOG.error(" dimission has error.", e);
        }
        return viewPrefix + "/dimissionDetail";
    }

    /**
     * @param model
     * @param staff 入职审核
     * @param p
     * @return
     */
    @RequestMapping(value = "bpoOnLineUpdateCheck")
    @ResponseBody
    public Wrapper<?> bpoOnLineUpdateCheck(Model model, Staff staff, NewInstanceParam p) {
        HashMap wfs = null;
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());
            String url = URL_TEST + URL_PROCESSINSTANCE;
            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put("operatorType", "css");
            param.put("operatorId", String.valueOf(getLoginUserId()));
            param.put("instanceId", p.getInstanceId());
            param.put("statusId", p.getStatusId());
            param.put("actionId", p.getActionId());
            param.put("remark", p.getRemark());
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            LOG.info("start bpoAddCheck call workflow url:" + url + ": " + param.toString());
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info("end bpoAddCheck to call workflow resul is:" + str);
            wfs = JsonUtil.fromJsonObject(str, HashMap.class);
            Staff staffbean = new Staff();
            staffbean.setId(staff.getId());
            staffbean.setUpdateUser(getLoginUserCnName());
            if ("waitForFirstCheck".equals(p.getStatusId())) {
                //一审
                if ("0".equals(wfs.get("status"))) {
                    //审核通过
                    if ("allow".equals(p.getActionId())) staffbean.setReviewedStatus(20);
                    else staffbean.setReviewedStatus(21);
                    staffService.update(staffbean);
                } else {
                    return error();
                }

            } else {
                //2审
                if ("0".equals(wfs.get("status"))) {
                    //审核通过
                    if ("allow".equals(p.getActionId())) {
                        staffbean.setPositionStatus("3");//在职
                        staffbean.setReviewedStatus(24);
                    } else {
                        staffbean.setReviewedStatus(23);
                    }
                    staffService.update(staffbean);
                } else {
                    return error();
                }

            }
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
            return error();
        }
        return new Wrapper<HashMap>().result((HashMap) wfs.get("result"));
    }

    @RequestMapping(value = "bpoDimissionCheck")
    @ResponseBody
    public Wrapper<?> bpoDimissionCheck(Model model, Staff staff, NewInstanceParam p) {
        HashMap wfs = null;
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());
            String url = URL_TEST + URL_PROCESSINSTANCE;
            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put("operatorType", "css");
            param.put("operatorId", String.valueOf(getLoginUserId()));
            param.put("instanceId", p.getInstanceId());
            param.put("statusId", p.getStatusId());
            param.put("actionId", p.getActionId());
            param.put("remark", p.getRemark());
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            LOG.info("start bpoDimissionCheck call workflow url:" + url + ": " + param.toString());
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info("end bpoDimissionCheck to call workflow resul is:" + str);
            wfs = JsonUtil.fromJsonObject(str, HashMap.class);
            Staff staffbean = new Staff();
            staffbean.setId(staff.getId());
            staffbean.setUpdateUser(getLoginUserCnName());
            if ("waitForFirstCheck".equals(p.getStatusId())) {
                //一审
                if ("0".equals(wfs.get("status"))) {
                    //审核通过
                    if ("allow".equals(p.getActionId())) staffbean.setReviewedStatus(50);
                    else staffbean.setReviewedStatus(51);
                    staffService.update(staffbean);
                } else {
                    return error();
                }

            } else if ("waitForSecondCheck".equals(p.getStatusId())) {
                //2审
                if ("0".equals(wfs.get("status"))) {
                    //审核通过
                    if ("allow".equals(p.getActionId())) {
                        staffbean.setReviewedStatus(52);
                        MailSender.sendEmail(to, staffResult.getName() + "工号关闭", "您好:<br> &emsp;&emsp;" + staffResult.getDep().getName() + "," + staffResult.getName() + "离职二审通过，需要进行工号关闭。");
                    } else {
                        staffbean.setReviewedStatus(53);
                    }
                    staffService.update(staffbean);
                } else {
                    return error();
                }
            } else if ("closeJobNo".equals(p.getStatusId())) {//拒绝关闭工号请求
                if ("0".equals(wfs.get("status"))) {
                    //不关闭工号
                    if ("closeFail".equals(p.getActionId())) {
                        staffbean.setReviewedStatus(64);
                        staffService.update(staffbean);
                    }
                }
            } else {
                return error();
            }
            model.addAttribute("birthdate", DateHelper.format(staffResult.getBirthdate(), "yyyy-MM-dd"));//在后台将date转成string，否则在修改页面点击重置的时候，会重新变成date类型
            model.addAttribute("entryDate", DateHelper.format(staffResult.getEntryDate(), "yyyy-MM-dd"));
            model.addAttribute("onlineDate", DateHelper.format(staffResult.getOnlineDate(), "yyyy-MM-dd"));
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
            return error();
        }
        return new Wrapper<HashMap>().result((HashMap) wfs.get("result"));
    }

    @RequestMapping(value = "bpoLeave")
    public String bpoLeave(Model model, Staff staff, NewInstanceParam p) {
        try {
            model.addAttribute("outId", p.getOutId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());

            Leave leaveResult = leaveService.getLeaveById(Long.parseLong(p.getOutId()));
            model.addAttribute("leaveStartTime", DateHelper.format(leaveResult.getLeaveStartTime(), "yyyy-MM-dd"));
            model.addAttribute("leaveEndTime", DateHelper.format(leaveResult.getLeaveEndTime(), "yyyy-MM-dd"));
            model.addAttribute("leaveDays", leaveResult.getLeaveDays());
            model.addAttribute("leaveDesc", leaveResult.getLeaveDesc());

            int leaveType = leaveResult.getLeaveType();
            Dic leaveTypeDic = dicService.getDicByNum(19L, (long) leaveType);
            if (leaveTypeDic != null) {
                model.addAttribute("leaveType", leaveTypeDic.getName());
            }

            if (leaveResult.getStaffId() != null) {
                Staff staffResult = staffService.getStaffById(leaveResult.getStaffId());
                if (staffResult != null) {
                    model.addAttribute("csId", staffResult.getCsId());
                    model.addAttribute("name", staffResult.getName());

                    if (staffResult.getDep() != null) {
                        model.addAttribute("depName", staffResult.getDep().getName());
                    }
                } else {
                    LOG.error("bpoLeaveDetail error: 查询不到员工信息, id: " + leaveResult.getStaffId());
                }
            } else {
                LOG.error("bpoLeaveDetail error: 请假流程 " + p.getOutId() + " 的staff_id为空");
            }

            WorkFlowIndexQuery query = new WorkFlowIndexQuery();
            query.setFlowId(p.getFlowId());
            query.setInstanceId(p.getInstanceId());
            String str = getWFInstanceLog(staff, query);
            LOG.info("end to bpoOnLineDetail resul is:" + str);
            WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str,
                    new TypeReference<WfResponse<List<ProcessLog>>>() {
                    });
            if ("0".equals(wfs.getStatus())) {
                model.addAttribute("result", wfs.getResult());
            }
        } catch (Exception e) {
            LOG.error(" bpoLeave has error.", e);
        }
        return viewPrefix + "/bpoLeave";
    }

    @RequestMapping(value = "bpoLeaveDetail")
    public String bpoLeaveDetail(Model model, Staff staff, NewInstanceParam p) {
        try {
            model.addAttribute("outId", p.getOutId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());

            Leave leaveResult = leaveService.getLeaveById(Long.parseLong(p.getOutId()));
            model.addAttribute("leaveStartTime", DateHelper.format(leaveResult.getLeaveStartTime(), "yyyy-MM-dd"));
            model.addAttribute("leaveEndTime", DateHelper.format(leaveResult.getLeaveEndTime(), "yyyy-MM-dd"));
            model.addAttribute("leaveDays", leaveResult.getLeaveDays());
            model.addAttribute("leaveDesc", leaveResult.getLeaveDesc());

            int leaveType = leaveResult.getLeaveType();
            Dic leaveTypeDic = dicService.getDicByNum(19L, (long) leaveType);
            if (leaveTypeDic != null) {
                model.addAttribute("leaveType", leaveTypeDic.getName());
            }

            if (leaveResult.getStaffId() != null) {
                Staff staffResult = staffService.getStaffById(leaveResult.getStaffId());
                if (staffResult != null) {
                    model.addAttribute("csId", staffResult.getCsId());
                    model.addAttribute("name", staffResult.getName());

                    if (staffResult.getDep() != null) {
                        model.addAttribute("depName", staffResult.getDep().getName());
                    }
                } else {
                    LOG.error("bpoLeaveDetail error: 查询不到员工信息, id: " + leaveResult.getStaffId());
                }
            } else {
                LOG.error("bpoLeaveDetail error: 请假流程 " + p.getOutId() + " 的staff_id为空");
            }

            WorkFlowIndexQuery query = new WorkFlowIndexQuery();
            query.setFlowId(p.getFlowId());
            query.setInstanceId(p.getInstanceId());
            String str = getWFInstanceLog(staff, query);
            LOG.info("end to bpoOnLineDetail resul is:" + str);
            WfResponse<List<ProcessLog>> wfs = JsonUtil.fromJsonObject(str,
                    new TypeReference<WfResponse<List<ProcessLog>>>() {
                    });
            if ("0".equals(wfs.getStatus())) {
                model.addAttribute("result", wfs.getResult());
            }
        } catch (Exception e) {
            LOG.error(" bpoLeaveDetail has error.", e);
        }
        return viewPrefix + "/bpoLeaveDetail";
    }

    /**
     * @param model
     * @param staff 入职审核
     * @param p
     * @return
     */
    @RequestMapping(value = "bpoLeaveCheck")
    @ResponseBody
    public Wrapper<?> bpoLeaveCheck(Model model, Staff staff, NewInstanceParam p) {
        HashMap wfs = null;
        try {
            Staff staffResult = staffService.getStaffById(staff.getId());
            model.addAttribute("flowId", p.getFlowId());
            model.addAttribute("instanceId", p.getInstanceId());
            model.addAttribute("statusId", p.getStatusId());
            model.addAttribute("actionId", p.getActionId());
            String url = URL_TEST + URL_PROCESSINSTANCE;
            Map<String, String> param = new HashMap<String, String>();
            String timestamp = String.valueOf(System.currentTimeMillis());
            param.put("timestamp", timestamp.substring(0, timestamp.length() - 3));
            param.put("operatorType", "css");
            param.put("operatorId", String.valueOf(getLoginUserId()));
            param.put("instanceId", p.getInstanceId());
            param.put("statusId", p.getStatusId());
            param.put("actionId", p.getActionId());
            param.put("remark", p.getRemark());
            param.put(CommonConstants.Send_WorkFlow_Url_Parameter_Partner, CommonConstants.Send_WorkFlow_Url_Parameter_Partner_Value);
            param.put("sign", Md5Util.signTopRequest(param, CommonConstants.SIGN_METHOD_MD5));
            LOG.info("start bpoLeaveCheck call workflow url:" + url + ": " + param.toString());
            String str = HttpUtil.post(url, param, Charset.forName("UTF-8"));
            LOG.info("end bpoLeaveCheck to call workflow resul is:" + str);
            wfs = JsonUtil.fromJsonObject(str, HashMap.class);
            Staff staffbean = new Staff();
            staffbean.setId(staff.getId());
            staffbean.setUpdateUser(getLoginUserCnName());

            String responseStatus = (String) wfs.get("status");
            if ("0".equals(responseStatus)) {
                HashMap resultMap = (HashMap) wfs.get("result");
                String leflowStatusId = (String) resultMap.get("statusTo");
                int leaveStatus = getLeaveStatusFromLeflowStatus(leflowStatusId);
                Leave leaveBean = new Leave();
                leaveBean.setId(Long.parseLong(p.getOutId()));
                leaveBean.setStatus(leaveStatus);
                leaveBean.setCreateUser(String.valueOf(getLoginUserId()));
                leaveService.updateStatus(leaveBean);
            } else {
                return error();
            }
        } catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
            return error();
        }
        return new Wrapper<HashMap>().result((HashMap) wfs.get("result"));
    }

    private int getLeaveStatusFromLeflowStatus(String leflowStatus) {
        int status = 0;
        if ("waitForFirstCheck".equals(leflowStatus)) {
            status = 60;
        } else if ("waitForSecondCheck".equals(leflowStatus)) {
            status = 61;
        } else if ("finishedNormally".equals(leflowStatus)) {
            status = 62;
        } else if ("finishedByRejected".equals(leflowStatus)) {
            status = 63;
        }

        return status;
    }

    private String isNull(String result) {
        if (StringUtils.isEmpty(result)) return "";
        else return result;
    }

    /**
     * 将枚举值加入到model
     *
     * @param
     * @return
     */
    private void addEnumToModel(Model model, Staff staff) {
        DicQuery query = new DicQuery();
//    	query.setParentName("乐视复核人");
        List<Dic> diclist = dicService.queryDicList(query);
        for (Dic dic : diclist) {
            if (dic.getParentNum().equals(16L) && isNullInteger(staff.getWorkingProperty()) == dic.getNum().intValue())
                model.addAttribute("leReviewers", dic.getName());
            if (dic.getParentNum().equals(3L) && isNullInteger(staff.getEducation()) == dic.getNum().intValue())
                model.addAttribute("educations", dic.getName());
            if (dic.getParentNum().equals(1L) && dic.getNum().intValue() == staff.getChildren())
                model.addAttribute("childrens", dic.getName());
            if (dic.getParentNum().equals(6L) && isNullInteger(staff.getLeReviewer()) == dic.getNum().intValue())
                model.addAttribute("leReviewer", dic.getName());
            //合同性质
            if ("合同性质".equals(dic.getParentName()) && dic.getNum().intValue() == staff.getStaffContract()) {
                DicQuery dicQuery = new DicQuery();
                if (dic.getName().equals("BPO类合同")) {
                    //BPO类岗位
                    dicQuery.setParentName("员工岗位");

                } else {
                    //内部岗位
                    dicQuery.setParentName("内部岗位");
                }
                dicQuery.setNum(isNullInteger(staff.getJobTitle()));
                List<Dic> list1 = dicService.queryDicList(dicQuery);
                if (list1.size() > 0) {
                    model.addAttribute("jobTitles", list1.get(0).getName());
                }
            }
            if (dic.getParentNum().equals(9L) && isNullInteger(staff.getResult()) == dic.getNum().intValue())
                model.addAttribute("results", dic.getName());
            if (dic.getParentNum().equals(14L) && isNull(staff.getStructAdjustReason()).equals(String.valueOf(dic.getNum().intValue())))
                model.addAttribute("structuralAdjustments", dic.getName());
            if (dic.getParentNum().equals(10L) && isNullInteger(staff.getService()) == dic.getNum().intValue())
                model.addAttribute("services", dic.getName());
            if (dic.getParentNum().equals(8L) && isNullInteger(staff.getRank()) == dic.getNum().intValue())
                model.addAttribute("ranks", dic.getName());
            if (dic.getParentNum().equals(11L) && isNullInteger(staff.getStaffContract()) == dic.getNum().intValue())
                model.addAttribute("staffContracts", dic.getName());
            if (dic.getParentNum().equals(16L) && isNullInteger(staff.getWorkingProperty()) == dic.getNum().intValue())
                model.addAttribute("workingPropertys", dic.getName());
            if (dic.getParentNum().equals(13L) && isNull(staff.getPositionStatus()).equals(String.valueOf(dic.getNum())))
                model.addAttribute("positionStatus", dic.getName());
        }
    }

    private int isNullInteger(Integer i) {
        if (i == null) return 0;
        else return i;
    }

    private void addEnumToModel(Model model, Staff staff, AdjustChange ad) {
        DicQuery query = new DicQuery();
//    	query.setParentName("乐视复核人");
        List<Dic> diclist = dicService.queryDicList(query);
        for (Dic dic : diclist) {
            if (dic.getParentNum().equals(16L) && isNullInteger(staff.getWorkingProperty()) == dic.getNum().intValue())
                model.addAttribute("leReviewers", dic.getName());
            if (dic.getParentNum().equals(3L) && isNullInteger(staff.getEducation()) == dic.getNum().intValue())
                model.addAttribute("educations", dic.getName());
            if (dic.getParentNum().equals(1L) && dic.getNum().intValue() == isNullInteger(staff.getChildren()))
                model.addAttribute("childrens", dic.getName());
            if (dic.getParentNum().equals(6L) && isNullInteger(staff.getLeReviewer()) == dic.getNum().intValue())
                model.addAttribute("leReviewer", dic.getName());
            if (dic.getParentNum().equals(12L) && isNullInteger(staff.getJobTitle()) == dic.getNum().intValue())
                model.addAttribute("jobTitles", dic.getName());
            if (dic.getParentNum().equals(9L) && isNullInteger(staff.getResult()) == dic.getNum().intValue())
                model.addAttribute("results", dic.getName());
            if (dic.getParentNum().equals(14L) && isNull(staff.getStructAdjustReason()).equals(String.valueOf(dic.getNum().intValue())))
                model.addAttribute("structuralAdjustments", dic.getName());
//    		if(dic.getParentNum().equals(7L)&&staff.getStatus().equals(dic.getNum().intValue()))
//    			model.addAttribute("modifyRecordTypes", dic.getName());
            if (dic.getParentNum().equals(10L) && isNullInteger(staff.getService()) == dic.getNum().intValue())
                model.addAttribute("services", dic.getName());
            if (dic.getParentNum().equals(8L) && isNullInteger(staff.getRank()) == dic.getNum().intValue())
                model.addAttribute("ranks", dic.getName());
            if (dic.getParentNum().equals(11L) && isNullInteger(staff.getStaffContract()) == dic.getNum().intValue())
                model.addAttribute("staffContracts", dic.getName());
            if (dic.getParentNum().equals(16L) && isNullInteger(staff.getWorkingProperty()) == dic.getNum().intValue())
                model.addAttribute("workingPropertys", dic.getName());
            if (dic.getParentNum().equals(13L) && isNull(staff.getPositionStatus()).equals(String.valueOf(dic.getNum())))
                model.addAttribute("positionStatus", dic.getName());

            //合同性质
            if ("合同性质".equals(dic.getParentName()) && dic.getNum().intValue() == staff.getStaffContract()) {
                DicQuery dicQuery = new DicQuery();
                if (dic.getName().equals("BPO类合同")) {
                    //BPO类岗位
                    dicQuery.setParentName("员工岗位");

                } else {
                    //内部岗位
                    dicQuery.setParentName("内部岗位");
                }
                dicQuery.setNum(isNullInteger(ad.getOldPost()));
                List<Dic> list1 = dicService.queryDicList(dicQuery);
                if (list1.size() > 0) {
                    model.addAttribute("oldPost", list1.get(0).getName());
                }
            }
            //合同性质
            if ("合同性质".equals(dic.getParentName()) && dic.getNum().intValue() == staff.getStaffContract()) {
                DicQuery dicQuery = new DicQuery();
                if (dic.getName().equals("BPO类合同")) {
                    //BPO类岗位
                    dicQuery.setParentName("员工岗位");

                } else {
                    //内部岗位
                    dicQuery.setParentName("内部岗位");
                }
                dicQuery.setNum(isNullInteger(ad.getNewPost()));
                List<Dic> list1 = dicService.queryDicList(dicQuery);
                if (list1.size() > 0) {
                    model.addAttribute("newPost", list1.get(0).getName());
                }
            }

        }
        Dep oldd = depService.getDepById(ad.getOldDepartment());
        model.addAttribute("oldDepartment", oldd.getName());
        Dep nd = depService.getDepById(ad.getNewDepartment());
        model.addAttribute("newDepartment", nd.getName());
        //业务线

        if (ad.getOldService() != null) {
            DicQuery dicQuery = new DicQuery();
            dicQuery.setParentName("业务");
            dicQuery.setNum(ad.getOldService());
            List<Dic> oldList = dicService.queryDicList(dicQuery);
            model.addAttribute("oldService", oldList.size() > 0 ? oldList.get(0).getName() : "");
        }
        if (ad.getNewService() != null) {
            DicQuery dicQuery1 = new DicQuery();
            dicQuery1.setParentName("业务");
            dicQuery1.setNum(ad.getNewService());
            List<Dic> oldList1 = dicService.queryDicList(dicQuery1);
            model.addAttribute("newService", oldList1.size() > 0 ? oldList1.get(0).getName() : "");
        }
    }
}
