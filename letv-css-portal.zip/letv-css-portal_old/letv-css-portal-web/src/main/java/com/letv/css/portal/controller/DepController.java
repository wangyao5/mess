package com.letv.css.portal.controller;

import com.letv.common.utils.exception.ExistedException;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.constant.CommonConstants;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.domain.query.DicBusinessQuery;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.service.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

/**
 * 客服组织架构
 *
 * @Author menghan
 * @Version 2017-01-15 14:05:45
 */
@Controller
@RequestMapping("dep")
public class DepController extends CommonController{
	
	private static final Log LOG = LogFactory.getLog(DepController.class);
	@Autowired
	private DepService depService;
	@Autowired
	private UserService userService;
	@Autowired
	private UserDepService userDepService;
	@Autowired
	private StaffService staffService;
	@Autowired
	private DicService dicService;
	@Autowired
	private MenuService menuService;
	@Autowired
	private CommonQueueService commonQueueService;
	@Autowired
	private DepBusinessService depBusinessService;
	
	/**视图前缀*/
	private static final String VIEW_PREFIX = "dep";
	private static final String VIEW_INDEX = "index";
	private static final String VIEW_UPDATE = "update";
	
	@RequestMapping("")
	public String welcome(Model model, PageUtil page, DepQuery query){
		return index(model,page,query);
	}
	
	@RequestMapping("index")
	public String index(Model model, PageUtil page, DepQuery query){
		try {
			List<Dep> dataList = null;
			//数据权限控制
			User user = userService.getUserByUsername(getLoginUser().getUserName());
			String allowDepIds = getDepIds(user.getId());
			if(allowDepIds==null || "".equals(allowDepIds)){
				query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
			}else{
				query.setDepIds(allowDepIds);
			}
			if(query.getDepState()==null || "".equals(query.getDepState())){
				query.setDepState(0);
			}
			dataList = depService.queryDepList(query);
			//找到可见部门的根部门code
			List<String> depCode = computeDepLevel(dataList);
			//补全部门
			dataList = complementedDep(depCode,allowDepIds);
			//补全人员数量
			complementedDepQuantity(dataList);
			model.addAttribute("dataList", dataList);
			model.addAttribute("query", query);//查询条件
			addDepListToModel(model);
			addEnumToModel(model);
			addButtonPortals(model,user);//添加按钮权限控制
		} catch (Exception e) {
			LOG.error("DepController index has error.", e);
		}
		return VIEW_PREFIX + "/" + VIEW_INDEX;
	}
	
	/**
	 * 查询部门详细信息
	 * @param
	 * @return
	 */
	@RequestMapping(value="detail", method = RequestMethod.GET)
	@ResponseBody
	public Wrapper<?> detail(DepQuery query){
		if(null==query||null==query.getId()){
			return illegalArgument();
		}
		try {
			Dep dep = depService.getDepById(query.getId());
			if(dep!=null && dep.getParentId()!=null && dep.getParentId()>0){
				Dep parentDep = depService.getDepById(dep.getParentId());
				dep.setParentDep(parentDep);
			}
			if(dep!=null){
				Map<String, Object> map = new HashedMap();
				//业务线
				List<Dic> services = getService(query.getId());
				map.put("dep", dep);
				map.put("services", services);
				return new Wrapper<Map<String, Object>>().result(map);
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE,"查询部门详情失败！");
			}
		} catch (Exception e) {
			LOG.warn("dep has error.", e);
            return error();
		}
	}
	
	/**
     * 部门----添加
     * 			添加部门时要注意该部门是否存在上级部门
     * 			部门添加完成后，需要更新其父部门（如果存在）的信息
     * 						需要更新当前用户的数据权限（可见部门）信息
     * @return
     */
    @RequestMapping(value = "add",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> add(Dep dep, @RequestParam("serviceIds") String[] serviceIds) {
        try {
        	//存在上级部门的情况
        	if(dep.getParentId()!=0L){
	        	Long parentId = dep.getParentId();//父ID
	        	Dep parentDep = depService.getDepById(parentId);
	        	int level = parentDep.getLevel()+1;//层级
	        	String code = computeCode(parentDep.getId(),parentDep.getCode());//计算编码
	        	dep.setCode(code);
	        	dep.setNum(code);//num已经被废弃，使其与code内容一致
	        	dep.setLevel(level);
        	}else{
        		String code = computeCode(0L,"0");//计算编码
        		dep.setCode(code);
        		dep.setNum(code);//num已经被废弃，使其与code内容一致
        		dep.setLevel(1);
        	}
        	dep.setHasChild(0);
        	dep.setCreateUser(getLoginUserCnName());
        	dep.setCreateTime(new Date());
            if (depService.insert(dep)) {
            	//updateUserDepIds(dep.getCode());//更新当前用户的可见部门列表
				for (String dicNum : serviceIds) {
					DepBusiness depBusiness = new DepBusiness();
					depBusiness.setDepId(dep.getId());
					depBusiness.setDicNum(Integer.parseInt(dicNum));
					depBusiness.setCreateUser(getLoginUserName());
					depBusinessService.insert(depBusiness);
				}
            	updateParentDep(dep.getCode());//更新 新的父部门信息
            	updateUserParentDeps(dep.getCode());//更新所有拥有该部门上级部门用户的数据权限
				//插入commonQueue,同步工作流
				CommonQueue queue = new CommonQueue();
				queue.setOnlyId(dep.getId());
				queue.setOnlyType("dep id");
				queue.setEventId(EventConstants.EVENT_DEP_ADD);
				queue.setRequestRemake("新增部门流程");
				queue.setCreatedBy("DEP ADD");
				commonQueueService.insert(queue);
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "添加成功！");
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
            }
        } catch (ExistedException e) {
            LOG.warn("dep add fail, exist user.");
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败，已经存在");
        } catch (Exception e) {
            LOG.error("dep add has error.", e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
        }
    }
    

	/**
     * 部门----修改跳转
     * 
     * @param model
     * @param dep
     * @return
     */
    @RequestMapping(value = "updateForward")
    public String updateForward(Model model, Dep dep){
    	try {
    		Dep depResult = depService.getDepById(dep.getId());
    		model.addAttribute("dep", depResult);
            addEnumToModel(model);
            addFilterDepListToModel(model,depResult);
			//业务线
			List<Dic> list = getService(depResult.getId());
			model.addAttribute("services", list);
		} catch (Exception e) {
            LOG.error("staff updateForward has error.", e);
        }
        return VIEW_PREFIX + "/"+ VIEW_UPDATE;
    }
    
	/**
     * 部门----修改
     * 		检查该部门的上级部门是否发生了变化，
     * 		上级变化了需要重新计算当前部门的code、level，
     * 		需要检查原来的上级是否还有子部门，如果没有子部门的话需要将hasChild置为0,
     * 		检查当前部门的层级是否发生变化，层级变化了，需要修改子部门的层级和编号
     * @return
     */
    @RequestMapping(value = "update",method=RequestMethod.POST)
    @ResponseBody
    public Wrapper<?> update(Dep dep, @RequestParam("serviceIds") String[] serviceIds){
    	try{

			Set<String> set = new HashSet<>();
			Collections.addAll(set, serviceIds);
			String[] arrayResult = set.toArray(new String[set.size()]);


			//需要修改的部门
    		Dep curDep = depService.getDepById(dep.getId());
            Long oldPersonChargeId=curDep.getPersonChargeId();
    		//int curLevel = curDep.getLevel();
	    	Long parentId = dep.getParentId();//父编码
	    	//父部门Id改变的时候，需要重新计算当前部门的编码
	    	if(parentId != null && !Objects.equals(parentId, curDep.getParentId())){
	    		Dep parentDep = depService.getDepById(parentId);
	    		if(parentDep!=null){
		    		int level = parentDep.getLevel()+1;//层级
		    		String code = computeCode(parentDep.getId(),parentDep.getCode());//计算编码
		    		dep.setCode(code);
		    		dep.setNum(code);//num已经被废弃，使其与code内容一致
		    		dep.setLevel(level);
	    		}else{
	    			//部门变为一级部门的情况
	    			String code = computeCode(0L,"0");
	    			dep.setCode(code);
	    			dep.setNum(code);
	    			dep.setLevel(1);
	    		}
	    	}
	    	dep.setUpdateUser(getLoginUserCnName());
	    	dep.setUpdateTime(new Date());
	    	if (depService.update(dep)) {
	    		updateParentDep(dep.getCode());//更新新的父部门
	    		if(!Objects.equals(parentId, curDep.getParentId())){//更新原来的父部门
	    			updatePastParentDep(curDep.getParentId());
	    		}
	    		if(!Objects.equals(parentId, curDep.getParentId())){//更新当前部门的子部门
	    			curDep = depService.getDepById(dep.getId());
	    			updateChildDep(curDep.getId(),curDep.getCode());
	    		}
				//插入commonQueue,同步工作流
				CommonQueue queue = new CommonQueue();
				queue.setOnlyId(dep.getId());
				queue.setOnlyType("dep id");
				queue.setEventId(EventConstants.EVENT_DEP_ADD);
				queue.setRequestRemake("修改部门流程");
				queue.setCreatedBy("DEP ADD");
				commonQueueService.insert(queue);
				//修改部门的业务线
				changeService(dep, arrayResult);
                //修改部门负责人时 将部门本层级坐席的组长更新为当前部门的负责人
                if(!Objects.equals(dep.getPersonChargeId(),oldPersonChargeId)){
                    Staff staff  =new Staff();
                    staff.setSuperiorId(dep.getPersonChargeId());
                    staff.setSuperior(dep.getPersonCharge());
                    staff.setDepId(dep.getId());
                    boolean flag=staffService.updateSuperiorByDepId(staff);
                }

	            return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "修改成功！");
	        } else {
	            return WrapMapper.wrap(Wrapper.ERROR_CODE, "修改失败！");
	        }
	    } catch (ExistedException e) {
	        LOG.warn("dep update fail, exist user.");
	        return WrapMapper.wrap(Wrapper.ERROR_CODE, "修改失败，已经存在");
	    } catch (Exception e) {
	        LOG.error("dep update has error.", e);
	        return WrapMapper.wrap(Wrapper.ERROR_CODE, "修改失败！");
	    }
    }



	/**
     * 部门表----禁用
     * 
     * @return
     */
    @RequestMapping(value = "disable")
    @ResponseBody
    public Wrapper<?> disable(Dep dep) {
        try {
        	dep.setUpdateUser(getLoginUserCnName());
        	dep.setUpdateTime(new Date());
        	dep.setDepState(1);//设为禁用状态
            if (depService.update(dep)) {

				//插入commonQueue,同步工作流
				CommonQueue queue = new CommonQueue();
				queue.setOnlyId(dep.getId());
				queue.setOnlyType("dep id");
				queue.setEventId(EventConstants.EVENT_DEP_DISABLE);
				queue.setRequestRemake("禁用部门流程");
				queue.setCreatedBy("BPODep disable");
				commonQueueService.insert(queue);

                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "禁用成功！");
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "禁用失败！");
            }
        } catch (Exception e) {
            LOG.error("dep disable has error.", e);
            return WrapMapper.error();
        }
    }
    
    /**
     * 查询子部门
     * 
     * @param query
     * @return
     */
    @RequestMapping(value = "treeChild")
    @ResponseBody
    public Wrapper<?> treeChild(DepQuery query) {
    	if (null==query||null==query.getParentId()) {
			return illegalArgument();
		}
        try {
        	User user = userService.getUserByUsername(getLoginUser().getUserName());
			String allowDepIds = getDepIds(user.getId());
			query.setDepIds(allowDepIds);
            List<Dep> list = depService.queryTreeDepList(query);
            if (!CollectionUtils.isEmpty(list)) {
            	complementedDepQuantity(list);//补齐人员数量
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, Wrapper.SUCCESS_MESSAGE, list);
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "查询配置信息失败！");
            }
        } catch (Exception e) {
            LOG.error("dep query has error.", e);
            return WrapMapper.error();
        }
    }

	@RequestMapping(value = "serviceNew", method = RequestMethod.GET)
	@ResponseBody
	public Wrapper<?> serviceNew(long depId, long curDepId, long parentId){
		try {
			//上级业务线
			List<Dic> business = new ArrayList<>();
			//上级业务线
			List<DepBusiness> list1 = null;
			if(parentId==0){
				DicQuery query = new DicQuery();
				query.setParentName("业务");
				List<Dic> busDic = dicService.queryDicList(query);
				list1 = new ArrayList<DepBusiness>(busDic.size());
				for(Dic dic:busDic){
					DepBusiness depBus = new DepBusiness();
					depBus.setDicNum(dic.getNum().intValue());
					list1.add(depBus);
				}
			}else{
				list1 = depBusinessService.queryByDepId(depId);
			}
			//当前业务线
			List<DepBusiness> list2 = depBusinessService.queryByDepId(curDepId);

			List<DepBusiness> list3 = new ArrayList<>();

			for (DepBusiness depBusiness1 : list1) {
				int temp = 0;
				for (DepBusiness depBusiness2 : list2) {
					if(Objects.equals(depBusiness1.getDicNum(), depBusiness2.getDicNum())){
						temp = 1;
						break;
					}
				}
				if(temp == 0){
					list3.add(depBusiness1);
				}

			}

			if (list3.size() > 0) {
				DicBusinessQuery businessQuery = new DicBusinessQuery();
				businessQuery.setParentName("业务");
				businessQuery.setDicNums(list3);
				business = dicService.queryDicListById(businessQuery);
			}

			return new Wrapper<List<Dic>>().result(business);
		} catch (Exception e) {
			LOG.warn("detail staff has error.", e);
			return error();
		}
	}
	
	/**
	 * 添加枚举类信息到model
	 * @param
	 * @return
	 */
	private void addEnumToModel(Model model){
		DicQuery query = new DicQuery();
//		query.setParentName("部门范围");
//		List<Dic> depRanges = dicService.queryDicList(query);
//		model.addAttribute("depRanges", depRanges);//部门范围
		query.setParentName("部门层级");
		List<Dic> hierarchys = dicService.queryDicList(query);
		model.addAttribute("hierarchys",hierarchys);//部门层级
		model.addAttribute("depCharges", getDepCharges());//部门负责人
	}
	
	/**
     * 将当前用户的可见部门信息加入model
     * @param
     * @return
     */
    private void addDepListToModel(Model model) {
    	//获得当前用户
		User user = userService.getUserByUsername(getLoginUser().getUserName());
		//当前用户的可见部门列表
		if(user!=null){
			String allowDeps = getDepIds(user.getId());
			List<Dep> depList = depService.getDepListByIds(allowDeps);
			if(depList!=null && depList.size()!=0){
				for(Dep dep:depList){
					dep.setParentDep(depService.getDepById(dep.getParentId()));
				}
			}
			model.addAttribute("depList", depList);
		}
	}
    
    /***
     * 获得可见部门的id集合
     */
    private String getDepIds(Long userId){
    	List<UserDep> userDeps = userDepService.queryUserDepList(userId);
		StringBuilder sb = new StringBuilder();
		for(UserDep ud:userDeps){
			sb.append(ud.getDepId()+",");
		}
		String allowDeps = "";
		if(sb.length()>0){
			allowDeps = sb.substring(0, sb.length()-1);
		}
		return allowDeps;
    }
	
    /***
     * 计算部门编码，该编码不是指用户输入的num，而是code用来判断部门之间的父子关系
     * @param
     * @return
     */
    private String computeCode(Long parentId,String parentCode){
    	//父编号为0的情况
    	if(parentId == null || parentId == 0L){
    		List<String> list = depService.getChildrenCodByParentId(parentId);
    		StringBuffer sb = new StringBuffer("");
    		if(list!=null && list.size()!=0){
        		String tempCode = list.get(0);
        		int val = Integer.valueOf(tempCode);
        		val++;
        		sb.append(String.valueOf(val));
        		while(sb.length()<CommonConstants.DEP_CODE_BIT){
        			sb.insert(0, "0");
        		}
    		}else{
    			int val = 1;
    			sb.append(String.valueOf(val));
        		while(sb.length()<CommonConstants.DEP_CODE_BIT){
        			sb.insert(0, "0");
        		}
    		}
    		return sb.toString();
    	}
    	//父编号不为0的情况
    	List<String> list = depService.getChildrenCodByParentId(parentId);
    	int length = parentCode.length();
    	StringBuffer sb = new StringBuffer("");
    	if(list!=null && list.size()!=0){
    		String tempCode = list.get(0);
    		int val = Integer.valueOf(tempCode.substring(length, tempCode.length()));
    		val++;
    		sb.append(String.valueOf(val));
    		while(sb.length()<CommonConstants.DEP_CODE_BIT){
    			sb.insert(0, "0");
    		}
    	}else{
    		sb.append("0001");
    	}
    	sb.insert(0, parentCode);
    	return sb.toString();
    }
    
    /***
     * 更新当前用户的可见部门列表
     * 	   旧的逻辑(不在使用)：根据传入的部门编码num，获得当前部门信息；获得当前用户信息，将当前部门的ID加入到当前用户的allowDepIds。
     * 	   新的逻辑：根据传入的部门编码code，获得当前部门信息；更新user-dep表，添加一条该用户和部门的关联
     * @param
     * @return
     */
    private void updateUserDepIds(String code){
    	DepQuery query = new DepQuery();
    	query.setCode(code);
    	List<Dep> tempDeps = depService.queryDepListWithPage(query, null);
    	//更新用户的可见部门
    	if(tempDeps!=null && tempDeps.size()!=0){
    		Dep dep = tempDeps.get(0);
    		User tempUser = userService.getUserByUsername(getLoginUser().getUserName());
    		if(tempUser!=null){
		    	UserDep userDep = new UserDep();
		    	userDep.setUserId(tempUser.getId());
		    	userDep.setDepId(dep.getId());
		    	userDep.setCreateTime(new Date());
		    	userDep.setCreateUser(tempUser.getName());
		    	userDepService.insert(userDep);
    		}
    	}
    }
    
    /**
     * 当用户加入一个新的部门后，所有拥有该部门上级部门的用户，都需要让该部门对这些用户可见
     * @param
     * @return
     */
    private void updateUserParentDeps(String code) {
    	DepQuery query = new DepQuery();
    	query.setCode(code);
    	List<Dep> tempDeps = depService.queryDepListWithPage(query, null);
    	//更新用户的可见部门
    	if(tempDeps!=null && tempDeps.size()!=0){
    		Dep dep = tempDeps.get(0);
    		List<UserDep> userDeps = null;
    		try {
				userDeps = userDepService.queryUsersByDepId(dep.getParentId());
				for(UserDep ud:userDeps){
					UserDep userDep = new UserDep();
					userDep.setUserId(ud.getUserId());
					userDep.setDepId(dep.getId());
					userDep.setCreateUser(getLoginUserCnName());
					userDepService.insert(userDep);
				}
			} catch (Exception e) {
				LOG.error("DepController updateUserParentDeps error", e);
			}
    	}
		
	}
    
    
    /**
     * 更新 新的父部门信息，将其父部门中的hasChild更新为1
     * 		根据传入的部门编码code，获得当前部门信息；通过当前的部门的parentId，获得其父部门信息，将父部门的hasChild置为1，update。
     * @param
     * @return
     */
    private void updateParentDep(String code) {
    	DepQuery query = new DepQuery();
    	query.setCode(code);
    	//子部门信息
    	List<Dep> tempDeps = depService.queryDepListWithPage(query, null);
    	if(tempDeps!=null && tempDeps.size()!=0){
    		Dep dep = tempDeps.get(0);
    		//父部门信息
    		Dep parentDep = depService.getDepById(dep.getParentId());
    		if(parentDep!=null){
    			parentDep.setHasChild(1);
	    		depService.update(parentDep);
    		}
    	}
	}
    
    /**
     * 更新过去的父部门信息，判断其是否还有子部门，没有的话，将其hasChild置为0
     */
    private void updatePastParentDep(Long parentId) {
    	Dep dep = depService.getDepById(parentId);
		DepQuery query = new DepQuery();
		query.setParentId(parentId);
		//子部门信息
    	List<Dep> tempDeps = depService.queryDepList(query);
    	if(tempDeps == null || tempDeps.size() == 0){
    		dep.setHasChild(0);
    		depService.update(dep);
    	}
	}
    
    /**
     * 递归修改子部门的层级和code
     */
	private void updateChildDep(Long parentId,String parentCode) {
		DepQuery query = new DepQuery();
		query.setParentId(parentId);
		//子部门信息
    	List<Dep> deps = depService.queryDepList(query);
    	int index = 1;
    	StringBuilder sb= null;
		for(Dep dep:deps){
			sb = new StringBuilder();
			sb.append(String.valueOf(index));
			while(sb.length()<CommonConstants.DEP_CODE_BIT){
    			sb.insert(0, "0");
    		}
			sb.insert(0, parentCode);
			dep.setCode(sb.toString());
			dep.setNum(sb.toString());
			dep.setLevel(sb.length()/CommonConstants.DEP_CODE_BIT);
			depService.update(dep);
			index++;
			updateChildDep(dep.getId(),dep.getCode());
		}
	}
	
	/**
	 * 补全该部门的人员数量
	 * @param
	 * @return
	 */
	private void complementedDepQuantity(List<Dep> dataList) {
		if(dataList!=null && dataList.size()>0){
			for(Dep dep:dataList){
				int count = 0;
				int bpoCount = 0;
				int hroCount = 0;
				int leCount = 0;
				Map<Integer, Integer> map = depService.queryDepPersonQuantityByCode(dep.getCode());
				for (Integer i : map.keySet()) {
					count += map.get(i);
					if(i == 0){
						leCount += map.get(i);
					}else if(i == 2){
						bpoCount += map.get(i);
					}else{
						hroCount += map.get(i);
					}
				}
				dep.setPersonQuantity(count);
				dep.setBpoQuantity(bpoCount);
				dep.setHroQuantity(hroCount);
				dep.setLeQuantity(leCount);
			}
		}
	}
	
	/**
	 * 获得部门负责人
	 * 			目前没有规则，获得所有员工，后期需要改进
	 * @param
	 * @return
	 */
	private List<Staff> getDepCharges(){
		return staffService.queryStaffList(null);
	}
	
	/**
	 * 添加部门信息到model，过滤掉自己和自己的下级部门
	 * @param
	 * @return
	 */
	private void addFilterDepListToModel(Model model,Dep dep) {
		//获得当前用户
		User user = userService.getUserByUsername(getLoginUser().getUserName());
		//当前用户的可见部门列表
		if(user!=null){
			String allowDeps = getDepIds(user.getId());
			List<Dep> depList = depService.getDepListByIds(allowDeps);
			List<Dep> temp = new ArrayList<Dep>(depList.size());
			if(depList!=null && depList.size()!=0){
				for(Dep d:depList){
					if(Objects.equals(d.getId(),dep.getId()) || d.getCode().indexOf(dep.getCode())==0){
						//无操作，不添加自己和自己的下级部门
					}else{
						d.setParentDep(depService.getDepById(d.getParentId()));
						temp.add(d);
					}
				}
			}
			depList = temp;
			//检查当前部门的父部门是否在depList中，不在话加入depList
			Dep parentDep = depService.getDepById(dep.getParentId());
			if(parentDep!=null){
				boolean flag = false;
				for(Dep dd:depList){
					if(Objects.equals(dd.getId(),parentDep.getId())){
						flag = true;
						break;
					}
				}
				if(!flag){
					depList.add(parentDep);
				}
			}
			model.addAttribute("depList", depList);
		}
	}
	
	/**
	 * 找到不同部门的根部门code
	 * @param
	 * @return
	 */
	private List<String> computeDepLevel(List<Dep> dataList) {
		if(dataList!=null && dataList.size()>0){
			//根据根节点获得实体，根据实体中的优先级进行排序
			List<Dep> depList=new ArrayList<Dep>(dataList.size());
			List<String> strs = new ArrayList<String>(dataList.size());
			for(Dep d:dataList){
				strs.add(d.getCode());
			}
			List<String> result = new ArrayList<String>(dataList.size());
			if(strs!=null && strs.size()>0){
				String str = strs.get(0);
//				result.add(str);
				depList.add(dataList.get(0));
				for(int i=1;i<strs.size();i++){
					if(strs.get(i).indexOf(str)!=0){
						str = strs.get(i);
//						result.add(str);
						depList.add(dataList.get(i));
					}
				}
			}
			//处理depList，根据实体中的PRIORITY排序得到ID
			Collections.sort(depList, new Comparator() {
				public int compare(Object a, Object b) {
					int one = ((Dep) a).getPriority()==null?0:((Dep) a).getPriority();
					int two = ((Dep) b).getPriority()==null?0:((Dep) b).getPriority();
					return one - two;
				}
			});
			for (int i = 0; i < depList.size(); i++) {
				result.add(depList.get(i).getCode());
			}
			return result;
		}else{
			return null;
		}
	}

	/**
	 * 根据部门code集合，找到所有部门
	 * @param
	 * @return
	 */
	private List<Dep> complementedDep(List<String> depCode,String allowDepIds) {
		List<Dep> dataList = null;
		DepQuery query = new DepQuery();
		if(depCode!=null && depCode.size()>0){
			dataList = new ArrayList<Dep>(depCode.size());
			for(int i=0;i<depCode.size();i++){
				query.setCode(depCode.get(i));
				dataList.addAll(depService.queryDepList(query));
			}
		}
		query = new DepQuery();
		query.setDepIds(allowDepIds);
		List<Dep> deps = depService.queryDepList(query);
		if(dataList!=null && dataList.size()>0){
			for(Dep dep:dataList){
				Long id = dep.getId();
				boolean flag = false;
				for(Dep d:deps){
					if(d.getParentId()!=0 && Objects.equals(id,d.getParentId()) && dep.getDepState()==d.getDepState()){
						dep.setHasChild(1);
						flag = true;
					}
				}
				if(!flag){
					dep.setHasChild(0);
				}
			}
		}
		return dataList;
	}
	
	/**
     * 添加按钮级别的权限
     * @param
     * @return
     */
    private void addButtonPortals(Model model,User user){
    	Set<String> set = new HashSet<String>();
    	List<Resource> resources = menuService.queryButtonResources(user);
    	for(Resource r:resources){
    		if(r.getParentId()!=null){
    			set.add(r.getUrl());
    		}
    	}
    	model.addAttribute("buttonPortals", set);
    }
}
