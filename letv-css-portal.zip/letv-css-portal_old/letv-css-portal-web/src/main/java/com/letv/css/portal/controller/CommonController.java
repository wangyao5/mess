package com.letv.css.portal.controller;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.DepBusiness;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.domain.query.DicBusinessQuery;
import com.letv.css.portal.domain.query.UserQuery;
import com.letv.css.portal.service.*;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class CommonController extends BaseController {
    private static final Log LOG = LogFactory.getLog(CommonController.class);

    @Autowired
    private DepBusinessService depBusinessService;
    @Autowired
    private DicService dicService;

    List<Dic> getService(long depId) {
        List<Dic> business = new ArrayList<>();
        List<DepBusiness> list = depBusinessService.queryByDepId(depId);
        if (list.size() > 0) {
            DicBusinessQuery businessQuery = new DicBusinessQuery();
            businessQuery.setParentName("业务");
            businessQuery.setDicNums(list);
            business = dicService.queryDicListById(businessQuery);
        }
        return business;
    }

    void changeService(Dep dep, @RequestParam("serviceIds") String[] serviceIds) {
        List<DepBusiness> list = depBusinessService.queryByDepId(dep.getId());
        Map<String, DepBusiness> map = new HashedMap();
        for (DepBusiness depBusiness : list) {
            map.put(depBusiness.getDicNum() + "", depBusiness);
        }
        //新增的业务线
        for (String serviceId : serviceIds) {
            if(serviceId != null && !"".equals(serviceId)) {
                if (map.get(serviceId) == null) {
                    DepBusiness business = new DepBusiness();
                    business.setCreateUser(getLoginUserName());
                    business.setDicNum(Integer.parseInt(serviceId));
                    business.setDepId(dep.getId());
                    depBusinessService.insert(business);
                }
            }
        }
        //修改的业务线
        for (String s : map.keySet()) {
            int temp = 0;
            for (String serviceId : serviceIds) {
                if(s.equals(serviceId)){
                    temp = 1;
                    break;
                }
            }
            if(temp == 0){
                //删除业务线
                DepBusiness depBusiness = new DepBusiness();
                depBusiness.setDepId(dep.getId());
                depBusiness.setDicNum(Integer.parseInt(s));
                depBusiness.setUpdateUser(getLoginUserName());
                depBusinessService.update(depBusiness);
            }

        }
    }
}
