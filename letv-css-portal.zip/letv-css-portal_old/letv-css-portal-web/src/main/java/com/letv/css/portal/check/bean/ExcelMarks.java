package com.letv.css.portal.check.bean;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;

/**
 * Created by yangxinghe on 2017/6/30.
 */
public class ExcelMarks {
    /**
     * 创建工厂
     */
    private CreationHelper factory;
    /**
     * 画板
     */
    private Drawing drawing;
    /**
     * EXCEL 样式
     */
    private CellStyle style;

    public CreationHelper getFactory() {
        return factory;
    }

    public void setFactory(CreationHelper factory) {
        this.factory = factory;
    }

    public Drawing getDrawing() {
        return drawing;
    }

    public void setDrawing(Drawing drawing) {
        this.drawing = drawing;
    }

    public CellStyle getStyle() {
        return style;
    }

    public void setStyle(CellStyle style) {
        this.style = style;
    }
}
