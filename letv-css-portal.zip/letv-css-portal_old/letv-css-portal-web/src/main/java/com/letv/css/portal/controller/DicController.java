package com.letv.css.portal.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.Resource;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.service.DicService;
import com.letv.css.portal.service.MenuService;
import com.letv.css.portal.service.UserService;

/**
 * 数据字典维护页面
 *
 * @Author menghan
 * @Version 2017-02-17 16:37:14
 */
@Controller
@RequestMapping("dic")
public class DicController extends BaseController{

	private static final Log LOG = LogFactory.getLog(DicController.class);
	
	@Autowired
	private DicService dicService;
	@Autowired
	private MenuService menuService;
	@Autowired
	private UserService userService;
	
	/**视图前缀*/
	private static final String VIEW_PREFIX = "dic";
	private static final String VIEW_INDEX = "index";
	private static final String VIEW_UPDATE = "update";
	
	@RequestMapping("")
	public String welcome(Model model,PageUtil page,DicQuery query){
		return index(model,page,query);
	}

	@RequestMapping("index")
	public String index(Model model, PageUtil page, DicQuery query) {
		try {
			User user = userService.getUserByUsername(getLoginUser().getUserName());
			if(query.getName()==null || "".equals(query.getName()) && (query.getParentName()==null || "".equals(query.getParentName()))){
				query.setParentId(0L);
			}
			List<Dic> dataList = dicService.queryDicListWithPage(query, page);
			model.addAttribute("dataList", dataList);
			model.addAttribute("page", page);
			addButtonPortals(model,user);
		} catch (Exception e) {
			LOG.error("DicController index has error.", e);
		}
		
		return VIEW_PREFIX + "/" + VIEW_INDEX;
	}
	
	/**
	 * 查询父节点下的子节点的字典信息
	 * @param
	 * @return
	 */
	@RequestMapping("treeChild")
	@ResponseBody
	public Wrapper<?> treeChild(DicQuery query){
		if (null==query||null==query.getParentId()) {
			return illegalArgument();
		}
		try{
			List<Dic> dataList = dicService.queryDicList(query);
			if(CollectionUtils.isNotEmpty(dataList)){
				return WrapMapper.wrap(Wrapper.SUCCESS_CODE, Wrapper.SUCCESS_MESSAGE, dataList);
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE, "查询配置信息失败！");
	        }
	    } catch (Exception e) {
	        LOG.error("dic query has error.", e);
	        return WrapMapper.error();
	    }
	}
	
	/**
	 * 字典数据详情
	 * @param
	 * @return
	 */
	@RequestMapping(value="detail",method=RequestMethod.GET)
	@ResponseBody
	public Wrapper<?> detail(DicQuery query){
		if(null==query||null==query.getId()){
			return illegalArgument();
		}
		try {
			Dic dic = dicService.getDicById(query.getId());
			if(dic!=null && dic.getParentId()!=null && dic.getParentId() >0){
				Dic parentDic = dicService.getDicById(dic.getParentId());
				dic.setParentDic(parentDic);
			}
			if(dic!=null){
				return WrapMapper.wrap(Wrapper.SUCCESS_CODE, Wrapper.SUCCESS_MESSAGE, dic);
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE, "查询字典信息失败！");
			}
		}catch (Exception e) {
			LOG.warn("dic has error.", e);
            return error();
		}
	}
	
	/**
	 * 修改跳转
	 * @param
	 * @return
	 */
	@RequestMapping("updateForward")
	public String updateForward(Model model,Dic dic){
		try {
			Dic dicResult = dicService.getDicById(dic.getId());
			if(dicResult!=null && dicResult.getParentId()!=null && dicResult.getParentId() >0){
				Dic parentDic = dicService.getDicById(dicResult.getParentId());
				dicResult.setParentDic(parentDic);
			}
			model.addAttribute("dic", dicResult);
		} catch (Exception e) {
			LOG.error("staff updateForward has error.", e);
		}
		return VIEW_PREFIX + "/" + VIEW_UPDATE;
	}
	
	/**
	 * 修改字典数据
	 * @param
	 * @return
	 */
	@RequestMapping("update")
	@ResponseBody
	public Wrapper<?> update(Dic dic){
		try {
			dic.setUpdateUser(getLoginUserCnName());
			if(dicService.update(dic)){
				return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "更新成功！");
			}else{
				return WrapMapper.wrap(Wrapper.ERROR_CODE, "更新失败！");
			}
		} catch (Exception e) {
			LOG.error("user update has error.", e);
            return WrapMapper.error();
		}
	}
	
	/**
	 * 添加字典数据
	 * @param
	 * @return
	 */
	@RequestMapping("add")
	@ResponseBody
	public Wrapper<?> add(Dic dic){
		try {
			if(dic.getType()==null || "".equals(dic.getType())){
				dic.setType(null);
			}
			if(dic.getParentType()==null || "".equals(dic.getParentType())){
				dic.setParentType(null);
			}
			dic.setCreateUser(getLoginUserCnName());
			if(dicService.insert(dic)){
				return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "添加成功！");
			}else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
            }
		}  catch (Exception e) {
            LOG.error("dep add has error.", e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "添加失败！");
        }
	}
	
	/**
     * 添加按钮级别的权限
     * @param
     * @return
     */
    private void addButtonPortals(Model model,User user){
    	Set<String> set = new HashSet<String>();
    	List<Resource> resources = menuService.queryButtonResources(user);
    	for(Resource r:resources){
    		if(r.getParentId()!=null){
    			set.add(r.getUrl());
    		}
    	}
    	model.addAttribute("buttonPortals", set);
    }
}
