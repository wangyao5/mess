package com.letv.css.portal.controller.scheduling.apply;

import com.alibaba.fastjson.JSONObject;
import com.letv.common.controller.base.BaseController;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.domain.JsonData;
import com.letv.css.portal.domain.SchedulingInfo;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;
import com.letv.css.portal.service.ApprovalManageService;
import com.letv.css.portal.service.JsonDataService;
import com.letv.css.portal.service.SchedulingInfoService;
import com.letv.css.portal.tools.BPOApprovalValidate;
import com.letv.css.portal.domain.vo.workflow.bean.NewInstanceParam;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;

/**
 * @author yxh
 * @date  2017/10/23  14:40
 * @version V1.0
 */
@Controller
@RequestMapping("workflow")
public class MealAdjustApplyController extends BaseController {
    private static final Log LOG = LogFactory.getLog(MealAdjustApplyController.class);

    /**
     * 视图前缀
     */
    private static final String viewPrefix = "workflow";

    @Autowired
    private SchedulingInfoService schedulingInfoService;

    @Autowired
    private ApprovalManageService approvalManageService;

    @Autowired
    private JsonDataService jsonDataService;
    @Autowired
    private ScheduleApplyController scheduleApplyController;

    /**
     * 餐时上报审批展示
     *
     * @param
     * @return
     */
    @RequestMapping("mealAdjust")
    public String bpoMealAdjustDetail(Model model, String isDetail, Staff staff, NewInstanceParam p) {
        try {
            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isDetail", isDetail);
            boolean flag = false;
            if (isDetail != null && "2".equals(isDetail)) {
                flag = true;
                model.addAttribute("isCanSelect", "1");//可以修改
            }
            List<SchedulingInfo> dataList = scheduleApplyController.getApplySchedulingInfos(p, flag, 1);

            model.addAttribute("dataList", dataList);
            //查询审批信息
            addMealAdjustJsonModel(model, p);
            //历史信息
            scheduleApplyController.setFlowHistoryInModel(model, p);
        } catch (Exception e) {
            LOG.error("bpoMealAdjustDetail has error.", e);
        }
        if (StringUtils.isNotEmpty(isDetail) && "2".equals(isDetail)) {
            return viewPrefix + "/" + "bpoMealAdjustDetail";
        } else {
            return viewPrefix + "/" + "bpoMealAdjust";
        }
    }

    @RequestMapping("applyMealAdjust")
    @ResponseBody
    public Wrapper applyMealAdjust(String siIds, String approvalReason, String mealTime, Model model, NewInstanceParam p) {
        HashMap wfs = null;
        try {
        	
        	//校验排班记录是否还存在与b_scheduling_info表中
        	if("allow".equals(p.getActionId()) && !BPOApprovalValidate.validateSchedulingInfoIsExist(siIds,schedulingInfoService)){
        		return WrapMapper.wrap(10100, "排班明细中不存在这些记录或者这些记录已经被删除，请进行驳回操作！");
        	}
        	
            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isCanSelect", "0");//不可以修改
            //工作流向下走一步
            wfs = scheduleApplyController.workFlowStepNext(p, wfs);
            String responseStatus = (String) wfs.get("status");
            if ("0".equals(responseStatus)) {
                //首次同意时确认同意的数据
                if ("requested".equals(p.getStatusId()) && "allow".equals(p.getActionId())) {
                    //更新是否已经确认
                    if (StringUtils.isNotBlank(siIds)) {
                        approvalManageService.updateConfirmBySiId(siIds);
                    }
                }
                //确认同意，更新明细表记录
                if ("confirm".equals(p.getStatusId()) && "allow".equals(p.getActionId())) {
                    SchedulingInfoQuery queryBean = new SchedulingInfoQuery();
                    queryBean.setMealStandard(Integer.parseInt(mealTime));
                    queryBean.setJdId(Long.parseLong(p.getOutId()));
                    schedulingInfoService.updateByApplyFlow(queryBean);
                }
                //工作流流程走完 记录状态
                //更新是否已经确认
                if("confirm".equals(p.getStatusId())){
                    if (StringUtils.isNotBlank(p.getOutId())) {//JD_ID
                        approvalManageService.updateFinishByJdId(p.getOutId());
                    }
                }
            } else {
                return error();
            }
        } catch (Exception e) {
            LOG.error(" applyMealAdjust has error.", e);
            return error();
        }
        return new Wrapper<HashMap>().result((HashMap) wfs.get("result"));
    }

    @RequestMapping("mealConfirm")
    public String mealConfirmDetail(Model model, Staff staff, NewInstanceParam p) {
        try {
            scheduleApplyController.addWorkflowParam(model, p);
            model.addAttribute("isCanSelect", "1");//可以修改
            //根据排班ID获取选择的排班班段信息
            List<SchedulingInfo> dataList = scheduleApplyController.getApplySchedulingInfos(p, true, 1);

            model.addAttribute("dataList", dataList);
            //查询审批信息
            addMealAdjustJsonModel(model, p);

            //历史信息
            scheduleApplyController.setFlowHistoryInModel(model, p);
        } catch (Exception e) {
            LOG.error(" mealConfirmDetail has error.", e);
        }
        return viewPrefix + "/" + "bpoMealAdjust";
    }

    //餐时上报
    private void addMealAdjustJsonModel(Model model, NewInstanceParam p) {
        JsonData jsonData = jsonDataService.getById(Long.parseLong(p.getOutId()));
        JSONObject jsonObj = JSONObject.parseObject(jsonData.getJsonData());

//        model.addAttribute("adjustDate", jsonObj.get("adjustDate").toString());
        model.addAttribute("mealTime", jsonObj.get("mealTime").toString());
        model.addAttribute("adjustReason", jsonObj.get("adjustReason").toString());
    }

}
