package com.letv.css.portal.controller.rest;

import com.letv.css.portal.domain.vo.DicItem;
import com.letv.css.web.common.response.ResponseWrapper;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/dic")
public class DicRestController {
    @RequestMapping("/{dicID}")
    public ResponseWrapper<List<DicItem>> items(@PathVariable String dicID) {
        //todo
        return null;
    }
}
