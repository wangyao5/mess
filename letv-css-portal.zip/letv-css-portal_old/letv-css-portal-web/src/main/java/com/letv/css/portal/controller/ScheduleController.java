package com.letv.css.portal.controller;

import com.letv.common.utils.DateHelper;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.check.bean.ImpScheduleMsg;
import com.letv.css.portal.check.bean.ImportsErrorMessage;
import com.letv.css.portal.check.bean.ScheduleMessage;
import com.letv.css.portal.check.bean.SchedulePlanMessage;
import com.letv.css.portal.domain.*;
import com.letv.css.portal.domain.query.*;
import com.letv.css.portal.service.*;
import com.letv.css.portal.util.web.ExcelUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * BPO排班表导入页面
 *
 * @Author yxh
 * @Version 2017-06-01 22:51:37
 */
@Controller
@RequestMapping("schedule")
public class ScheduleController extends CommonController {

    private final static Log LOG = LogFactory.getLog(ScheduleController.class);
    //导入最大天数
    @Value("#{${schedule.max.imp.day.num}}")
    private int MAX_IMP_DAY_NUM;
    @Autowired
    private ScheduleService scheduleService;

    @Autowired
    private ScheduleDetailService scheduleDetailService;

    @Autowired
    private UserDepService userDepService;

    @Autowired
    private DepService depService;

    @Autowired
    private ShiftsService shiftsService;

    @Autowired
    private StaffService staffService;
    @Autowired
    private SchedulePlanDetailService schedulePlanDetailService;
    @Autowired
    private CommonQueueService commonQueueService;
    @Autowired
    private DicService dicService;
    @Autowired
    private JsonDataService jsonDataService;
    @Autowired
    private ApprovalManageService approvalManageService;
    /**
     * 视图前缀
     */
    private static final String VIEW_PREFIX = "schedule";
    private static final String VIEW_INDEX = "index";
    private static final String VIEW_INDEX_AUTOSCHEDULING = "indexAutoScheduling";

    @RequestMapping("")
    public String welcome(Model model, PageUtil page, ScheduleQuery query) {
        return index(model, page, query);
    }

    @RequestMapping("index")
    public String index(Model model, PageUtil page, ScheduleQuery query) {
        try {
            LOG.info("入参：" + JsonHelper.toJson(query));
            //数据权限控制
            String allowDepIds = getDepIds(getLoginUser().getUserId());
            if(allowDepIds==null || "".equals(allowDepIds)){
                query.setDepIds("-1");//当没有可见部门时，设置查询部门ids为-1
            }else{
                query.setDepIds(allowDepIds);
            }

            List<Schedule> dataList = scheduleService.queryScheduleListWithPage(query, page);
            LOG.info("出参：" + JsonHelper.toJson(dataList));

            DicQuery dicQuery = new DicQuery();
            dicQuery.setParentId(66L);//业务线在字典表的主键id
            List<Dic> businessList = dicService.queryDicList(dicQuery); //一次读取所有业务线信息
            model.addAttribute("businessList", businessList);

            model.addAttribute("dataList", dataList);
            model.addAttribute("page", page);// 分页
            model.addAttribute("query", query);
            addDepListToModel(model, allowDepIds);//部门
            addBusinessToModel(model);//业务线
        } catch (Exception e) {
            LOG.error("ScheduleController index has error.", e);
        }
        return VIEW_PREFIX + "/" + VIEW_INDEX;
    }

    /**
     * 导入BPO排班表excel
     *
     * @param
     * @return
     */
    @RequestMapping("imports")
    @ResponseBody
    public Wrapper<?> imports(@RequestParam("file") MultipartFile file, Schedule scheduleParam, HttpServletRequest request) throws Exception {
        //1.初始化导入错误信息
        ScheduleMessage scheduleMessage = new ScheduleMessage();
        scheduleMessage.setImpDate(new Date());
        scheduleMessage.setuName(getLoginUserName());
        String relativePath = request.getContextPath() + "/static/upload/";
        if (file != null && !file.isEmpty()) {
            try {
                //2.文件保存路径
                String filePath = saveExcelFile(file, request);

                //3.获取排班任务信息
                scheduleParam = scheduleService.getScheduleById(scheduleParam.getId());
                if (scheduleParam == null) {
                    return WrapMapper.wrap(Wrapper.ERROR_CODE, "导入失败，排班任务不存在！");
                }
                scheduleMessage.setSchedule(scheduleParam);
                //4.解析生成排班明细
                List<ScheduleDetail> scheduleDetailList = readExcelFile(filePath, scheduleMessage);
                LOG.info("导入的BPO排班表详细信息：" + JsonHelper.toJson(scheduleDetailList));
                //校验时间，如果出现时间格式错误直接返回
                if (scheduleDetailList == null) {
                    return WrapMapper.wrap(Wrapper.ERROR_CODE, "导入失败，排班日期为空或大于" + MAX_IMP_DAY_NUM + "天！");
                }
                //日期不能为空
                List<Date> planDate = scheduleMessage.getImpPlanDates();
                if (planDate.contains(null)) {
                    return WrapMapper.wrap(Wrapper.ERROR_CODE, "导入失败，表头中的排班日期存在空");
                } else {
                    //校验日期不能小于当前日期
                    Date nowDate = new Date();
                    for (int i = 0; i < planDate.size(); i++) {
                        if (!isLagerTwoDate(planDate.get(i), nowDate)) {
                            return WrapMapper.wrap(Wrapper.ERROR_CODE, "导入失败，排班日期不能小于当前日期");
                        }
                    }
                }
                //校验数据不重复
                validateScheduleDetail(scheduleMessage);
                //5.整个解析过程是否有错误，如果有结束
                if (!isEmptyList(scheduleMessage.getErrList())) {
                    LOG.info("ScheduleController.imports()导入失败，数据校验未通过！" + JsonHelper.toJson(scheduleMessage.getErrList()));
                    scheduleMessage.setCode(1);
                    scheduleMessage.setMsg("失败");
                    scheduleMessage.setExcelExpURL(relativePath + filePath.substring(filePath.lastIndexOf(File.separator), filePath.length()));
                    return WrapMapper.wrap(400, "数据校验错误!", scheduleMessage);
                }
                //4.解析生产班表导入记录
                List<Schedule> scheduleList = new ArrayList<>();
                scheduleParam.setUpdateUser(getLoginUser().getUserName());//设置更新人
                scheduleList.add(scheduleParam);
//                List<Schedule> scheduleList = getSchedulesByDetailList(scheduleDetailList);
//                LOG.info("班表导入记录错误信息：" + JsonHelper.toJson(scheduleMessage));
                //6.将信息插入到数据库中。
//                LOG.info("班表导入记录：" + JsonHelper.toJson(scheduleList));
                if (scheduleService.inserts(scheduleList, scheduleDetailList)) {
                    //插入commonQueue,生成班次信息
//                    for (Schedule schedule : scheduleList) {
//                        //插入commonQueue,标记已经删除班次信息
//                        addDisSchedulePeriodJob(schedule);
//
//                        addSchedulePeriodJob(schedule);
//                    }
                    return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "导入成功！");
                } else {
                    return WrapMapper.wrap(700, "数据操作异常！");
                }
            } catch (NumberFormatException nfe) {
                nfe.printStackTrace();
                LOG.error(nfe.getMessage());
                return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！");
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error(e.getMessage());
                return WrapMapper.wrap(600, "导入失败，导入过程中出现异常！");
            }
        }
        return WrapMapper.wrap(100, "导入失败，导入文件为空！");
    }

    /**
     * BPO排班表明细
     *
     * @param
     * @return
     */
    @RequestMapping(value = "detail", method = RequestMethod.GET)
    @ResponseBody
    public Wrapper<?> detail(ScheduleDetailQuery query) {
        if (query == null) {
            return illegalArgument();
        }
        try {
            LOG.info("入参：" + JsonHelper.toJson(query));
            List<ScheduleDetail> scheduleDetails = scheduleDetailService.queryScheduleDetailList(query);
            LOG.info("出参：" + JsonHelper.toJson(scheduleDetails));
            if (CollectionUtils.isNotEmpty(scheduleDetails)) {
                return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "查询成功", scheduleDetails);
            } else {
                return WrapMapper.wrap(Wrapper.ERROR_CODE, "BPO排班表详情为空！");
            }
        } catch (Exception e) {
            LOG.warn("detail staff has error.", e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "查询BPO排班表详情失败！");
        }
    }

    //验证总班表明细中是否有重复信息，判断依据：同一个职场，同一个人，同一个业务线
    private void validateScheduleDetail(ScheduleMessage scheduleMessage) {
        String validate = "";
        List<String> list = new ArrayList<String>();
        int len = scheduleMessage.getImpScheduleMsgList().size();
        for (int i = 1; i < len; i++) {
            ImpScheduleMsg message = scheduleMessage.getImpScheduleMsgList().get(i);
            validate = message.getDepName() + message.getCsId() + message.getBusName();
            int pos = list.indexOf(validate);
            if (pos > -1) {
                ImportsErrorMessage errorMessage = new ImportsErrorMessage();
                errorMessage.setRow(i);
                errorMessage.setCode("900001");
                errorMessage.setMessage("第" + i + "行数据信息与第" + (pos + 1) + "行重复！");
                scheduleMessage.getErrList().add(errorMessage);
                list.add(validate);
            } else {
                list.add(validate);
            }
            validate = "";
        }
    }
    /**
     * 将当前用户的可见部门信息加入model
     *
     * @param
     * @return
     */
    private void addDepListToModel(Model model, String allowDepIds) {
        //当前用户的可见部门列表
        if (StringUtils.isNotEmpty(allowDepIds)) {
            List<Dep> depList = depService.getDepListByIds(allowDepIds);
            model.addAttribute("depList", depList);
        }
    }
    /***
     * 获得可见部门的id集合
     */
    private String getDepIds(Long userId) {
        List<UserDep> userDeps = userDepService.queryUserDepList(userId);
        StringBuilder sb = new StringBuilder();
        for (UserDep ud : userDeps) {
            sb.append(ud.getDepId() + ",");
        }
        String allowDeps = "";
        if (sb.length() > 0) {
            allowDeps = sb.substring(0, sb.length() - 1);
        }
        return allowDeps;
    }


    //读取单元格的数据,把一行行的数据保存到list中，用map来过滤重复身份证的数据
    private List<ScheduleDetail> readExcelFile(String fileName, ScheduleMessage scheduleMessage) {
        List<ScheduleDetail> scheduleDetailList = new ArrayList<>();
        // 根据机构，日期，班次统计 总班表明细信息
        List<SchedulePlanDetail> excelSPDList = new ArrayList<>();
        Workbook wb = null;
        FileInputStream in = null;
        FileOutputStream os = null;
        try {
            in = new FileInputStream(fileName);
            wb = ExcelUtil.createWorkbook(fileName, wb, in);
            Sheet sheet = wb.getSheetAt(0);

            //抽取EXCEL导入数据的日期
            List<Date> planDates = getExcelAllDates(sheet, scheduleMessage);
            if (planDates.size() <= 0) {
                addError(scheduleMessage, 0, 6, "", 100000, "排期日期不能为空");
                os = new FileOutputStream(fileName);
                wb.write(os);
                return null;
            }
            if (planDates.size() > MAX_IMP_DAY_NUM) {
                addError(scheduleMessage, 0, 6 + planDates.size(), "排班天数：" + planDates.size(), 100001, "排班日期需要小于等于" + MAX_IMP_DAY_NUM + "天");
                os = new FileOutputStream(fileName);
                wb.write(os);
                return null;
            }
            //按Excel日期查询出所有的排班计划，然后判断实体是否存在
//            List<SchedulePlanDetail> sPlanDetailList = getSPDetailsByDates(planDates);
            List<SchedulePlanDetail> sPlanDetailList = getSPDetailsById(scheduleMessage.getSchedule().getSpId());
            //处理excel明细
            scheduleMessage.setImpPlanDates(planDates);
            //将标题信息存到importMessage中
            dealExcelSchedule(scheduleMessage, scheduleDetailList, sheet, sPlanDetailList, excelSPDList);
            //校验排班表人数是否超出总班表信息。
            checkPersonNumLimit(scheduleMessage, sPlanDetailList, excelSPDList);

            //输出
            os = new FileOutputStream(fileName);
            wb.write(os);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                wb.close();
                in.close();
                if (os != null) {
                    os.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return scheduleDetailList;
    }

    /**
     * 解析提交的table数据
     *
     * @param
     * @return
     */
    private List<ScheduleDetail> readTableContent(ScheduleMessage scheduleMessage) {
        List<ScheduleDetail> scheduleDetailList = new ArrayList<>();
        // 根据机构，日期，班次统计 总班表明细信息
        List<SchedulePlanDetail> excelSPDList = new ArrayList<>();
        try {
            ImpScheduleMsg firstImportsMessage = scheduleMessage.getImpScheduleMsgList().get(0);//table第一行，标题
            List<Date> planDates = new ArrayList<Date>();
            if (StringUtils.isNotEmpty(firstImportsMessage.getShiftsName1())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getShiftsName1(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getShiftsName2())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getShiftsName2(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getShiftsName3())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getShiftsName3(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getShiftsName4())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getShiftsName4(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getShiftsName5())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getShiftsName5(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getShiftsName6())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getShiftsName6(), "yyyy/MM/dd"));
            }
            if (StringUtils.isNotEmpty(firstImportsMessage.getShiftsName7())) {
                planDates.add(DateHelper.parseDate(firstImportsMessage.getShiftsName7(), "yyyy/MM/dd"));
            }
            if (planDates.size() <= 0) {
                addError(scheduleMessage, 0, 6, "", 100000, "排期日期不能为空");
                return null;
            }
            if (planDates.size() > MAX_IMP_DAY_NUM) {
                addError(scheduleMessage, 0, 6 + planDates.size(), "排班天数：" + planDates.size(), 100001, "排班日期需要小于等于" + MAX_IMP_DAY_NUM + "天");
                return null;
            }
            scheduleMessage.setImpPlanDates(planDates);
            //按Excel日期查询出所有的排班计划，然后判断实体是否存在
            List<SchedulePlanDetail> sPlanDetailList = getSPDetailsByDates(planDates);
            //将标题信息存到importMessage中
            dealListSchedule(scheduleMessage, scheduleDetailList, sPlanDetailList, excelSPDList);
            //校验排班表人数是否超出总班表信息。
            checkPersonNumLimit(scheduleMessage, sPlanDetailList, excelSPDList);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return scheduleDetailList;
    }

    /**
     * 校验是否超出总班表明细中数目
     *
     * @param errorRes
     * @param sPlanDetailList 总班表计划信息
     * @param excelSPDlist    EXCEL表格明细数目信息
     */
    private void checkPersonNumLimit(ScheduleMessage errorRes, List<SchedulePlanDetail> sPlanDetailList, List<SchedulePlanDetail> excelSPDlist) {
        //错误明细信息
        if (errorRes.getErrList() == null || errorRes.getErrList().isEmpty()) {
            for (SchedulePlanDetail schedulePlanDetail : excelSPDlist) {
                int index = sPlanDetailList.indexOf(schedulePlanDetail);
                if (index < 0 ||
                        (index > 0 && schedulePlanDetail.getNum() > sPlanDetailList.get(index).getNum())) {
                    String shiftName = shiftsService.getShiftsById(schedulePlanDetail.getShiftsId()).getShiftsName();
                    addError(errorRes, 0, 6 + MAX_IMP_DAY_NUM + 1, schedulePlanDetail.getNum().toString(), 100002,
                            DateHelper.formatDate(schedulePlanDetail.getPlanDate()) + "-" + schedulePlanDetail.getDep().getName() + "-" + shiftName + ",应排：" + sPlanDetailList.get(index).getNum() + ",实排：" + schedulePlanDetail.getNum() + "，班次人数不符合排班规定！");
                }
            }
        }
    }

    private void dealExcelSchedule(ScheduleMessage errorRes, List<ScheduleDetail> scheduleDetailList, Sheet sheet,
                                   List<SchedulePlanDetail> sPlanDetailList, List<SchedulePlanDetail> excelSPDList) {
        Row firstRow = sheet.getRow(0);
        //将标题信息存到importMessage中
        ImpScheduleMsg titleMessage = new ImpScheduleMsg();
        titleMessage.setDepName(ExcelUtil.readValue(firstRow.getCell(0)));
        titleMessage.setCsId(ExcelUtil.readValue(firstRow.getCell(1)));
        titleMessage.setuName(ExcelUtil.readValue(firstRow.getCell(2)));
        titleMessage.setJobTitleName(ExcelUtil.readValue(firstRow.getCell(3)));
        titleMessage.setBusName(ExcelUtil.readValue(firstRow.getCell(4)));
        titleMessage.setLeaderName(ExcelUtil.readValue(firstRow.getCell(5)));
        if (errorRes.getImpPlanDates().size() >= 1) {
            titleMessage.setShiftsName1(DateHelper.format(ExcelUtil.readDateValue(firstRow.getCell(6)), "yyyy/MM/dd"));
        }
        if (errorRes.getImpPlanDates().size() >= 2) {
            titleMessage.setShiftsName2(DateHelper.format(ExcelUtil.readDateValue(firstRow.getCell(7)), "yyyy/MM/dd"));
        }
        if (errorRes.getImpPlanDates().size() >= 3) {
            titleMessage.setShiftsName3(DateHelper.format(ExcelUtil.readDateValue(firstRow.getCell(8)), "yyyy/MM/dd"));
        }
        if (errorRes.getImpPlanDates().size() >= 4) {
            titleMessage.setShiftsName4(DateHelper.format(ExcelUtil.readDateValue(firstRow.getCell(9)), "yyyy/MM/dd"));
        }
        if (errorRes.getImpPlanDates().size() >= 5) {
            titleMessage.setShiftsName5(DateHelper.format(ExcelUtil.readDateValue(firstRow.getCell(10)), "yyyy/MM/dd"));
        }
        if (errorRes.getImpPlanDates().size() >= 6) {
            titleMessage.setShiftsName6(DateHelper.format(ExcelUtil.readDateValue(firstRow.getCell(11)), "yyyy/MM/dd"));
        }
        if (errorRes.getImpPlanDates().size() >= 7) {
            titleMessage.setShiftsName7(DateHelper.format(ExcelUtil.readDateValue(firstRow.getCell(12)), "yyyy/MM/dd"));
        }
        errorRes.getImpScheduleMsgList().add(titleMessage);

        Map<String, List<Staff>> depStaffMap = new HashMap();
        //班次信息
        List<Shifts> shiftsList = getShiftses();

        Shifts holidayShifts = shiftsService.getShiftsByName("休息");
        Dep dep = depService.getDepById(errorRes.getSchedule().getDepId());
        String depName = "";//职场名称，也就是部门
        String csId = "";//员工编号
        String uName = "";//用户名称
        String jobTitleName = "";//岗位
        String busName = "";//业务线名称
        Dic business = null;
        DicQuery dicQuery = new DicQuery();
        dicQuery.setParentId(66L);//业务线在字典表的主键id
        List<Dic> businessList = dicService.queryDicList(dicQuery); //一次读取所有业务线信息

        String leaderName = "";//组长
        String shiftsName = "";//班次名称
        Shifts shifts = new Shifts();
        Staff staff = new Staff();

        // 遍历所有单元格，读取单元格
        int rowNum = sheet.getLastRowNum();
        //读取excel中的数据，从第二行开始
        for (int i = 1; i <= rowNum; i++) {
            Row row = sheet.getRow(i);
            if (row == null) {
                continue;
            }
            //部门--职场名
            depName = ExcelUtil.readValue(row.getCell(0));
            if (StringUtils.isBlank(depName)) {
                addError(errorRes, i, 0, depName, 200002, "职场为空");
                continue;
            } else {
                if (!depName.equals(dep.getName())){
                    addError(errorRes, i, 0, depName, 200001, "职场错误");
                    LOG.error("职场错误！");
                    continue;
                }
            }
            //工号
            csId = ExcelUtil.readValue(row.getCell(1));
            if (StringUtils.isBlank(csId)) {
                addError(errorRes, i, 1, csId, 500001, "工号为空");
                continue;
            } else {
                if (staff == null || (staff != null && csId != staff.getCsId())) {
                    staff = null;
                    if (depStaffMap == null || !depStaffMap.containsKey(depName)) {//缓存人员信息
                        //根据部门查询部门可用人员
                        List<Staff> staffs = getStaffsByDepInfo(dep.getCode());
                        depStaffMap.put(depName, staffs);
                    }
                    if (depStaffMap.get(depName) != null) {
                        //获取人员信息
                        for (Staff staffTemp : depStaffMap.get(depName)) {
                            if (csId.equals(staffTemp.getCsId())) {
                                staff = staffTemp;
                                break;
                            }
                        }
                    }
                    if (staff == null) {
                        addError(errorRes, i, 1, csId, 500002, "部门下没有此人员");
                    }
                }
            }
            uName = ExcelUtil.readValue(row.getCell(2)); //姓名
            jobTitleName = ExcelUtil.readValue(row.getCell(3));//岗位
            busName = ExcelUtil.readValue(row.getCell(4));//业务
            if (business == null || !busName.equals(business.getName())) {
                business = null;
                for (Dic b : businessList) {
                    if (busName.equals(b.getName())) {
                        business = b;
                        break;
                    }
                }
            }
            //业务线不存在
            if (business == null) {
                addError(errorRes, i, 4, csId, 400001, "业务线：" + busName + "不存在");
            }
            leaderName = ExcelUtil.readValue(row.getCell(5)); //组长

            //excel行转列的地方，将一行七天的数据转换成七行一天的数据
            int index = 6;
            for (Date planDate : errorRes.getImpPlanDates()) {
                //班次名称
                shiftsName = ExcelUtil.readValue(row.getCell(index));
                if (StringUtils.isBlank(shiftsName)) {
                    addError(errorRes, i, index, shiftsName, 300002, "班次为空");
                    continue;
                } else {
                    if ("休息".equals(shiftsName)) {//排班记录中不存在
                        shifts = holidayShifts;
                    } else {
                        if (shifts.getShiftsName() == null || !shiftsName.equals(shifts.getShiftsName())) {
                            shifts = new Shifts();
                            shifts.setShiftsName(shiftsName);
                            int shiftsIndex = shiftsList.indexOf(shifts);
                            if (shiftsIndex > -1) {
                                shifts = shiftsList.get(shiftsIndex);
                            } else {
                                addError(errorRes, i, index, shiftsName, 300001, "班次不存在");
                                continue;
                            }
                        }
                    }
                }
                if (!"休息".equals(shiftsName) && dep != null && shifts != null) {
                    //判断本次 排班数据库中是否存在
                    SchedulePlanDetail schedulePlanDetail = setSchedulePlanDetail(dep, shifts, planDate);
                    int indexOfSPD = sPlanDetailList.indexOf(schedulePlanDetail);
                    if (indexOfSPD < 0) {
                        addError(errorRes, i, index, shiftsName, 600001, "排班表中无匹配记录");
                    } else {//增加排班数目
                        addSPDNum(excelSPDList, schedulePlanDetail);
                    }
                }
                if (isEmptyList(errorRes.getErrList())) {
                    ScheduleDetail detail = setScheduleDetail(dep, csId, uName, jobTitleName, busName, business.getNum(), leaderName, shiftsName, shifts, staff, planDate);
                    scheduleDetailList.add(detail);
                }
                index++;
            }
            //保存excel的数据，不做验证
            ImpScheduleMsg importsMessage = new ImpScheduleMsg();
            importsMessage.setDepName(ExcelUtil.readValue(row.getCell(0)));
            importsMessage.setCsId(ExcelUtil.readValue(row.getCell(1)));
            importsMessage.setuName(ExcelUtil.readValue(row.getCell(2)));
            importsMessage.setJobTitleName(ExcelUtil.readValue(row.getCell(3)));
            importsMessage.setBusName(ExcelUtil.readValue(row.getCell(4)));
            importsMessage.setLeaderName(ExcelUtil.readValue(row.getCell(5)));
            importsMessage.setShiftsName1(ExcelUtil.readValue(row.getCell(6)));
            importsMessage.setShiftsName2(ExcelUtil.readValue(row.getCell(7)));
            importsMessage.setShiftsName3(ExcelUtil.readValue(row.getCell(8)));
            importsMessage.setShiftsName4(ExcelUtil.readValue(row.getCell(9)));
            importsMessage.setShiftsName5(ExcelUtil.readValue(row.getCell(10)));
            importsMessage.setShiftsName6(ExcelUtil.readValue(row.getCell(11)));
            importsMessage.setShiftsName7(ExcelUtil.readValue(row.getCell(12)));
            errorRes.getImpScheduleMsgList().add(importsMessage);
        }
    }

    private void dealListSchedule(ScheduleMessage errorRes, List<ScheduleDetail> scheduleDetailList,
                                  List<SchedulePlanDetail> sPlanDetailList, List<SchedulePlanDetail> excelSPDList) {
        Map<String, List<Staff>> depStaffMap = new HashMap();
        //班次信息
        List<Shifts> shiftsList = getShiftses();
        Shifts holidayShifts = shiftsService.getShiftsByName("休息");
        Dep dep = depService.getDepById(errorRes.getSchedule().getDepId());
        String depName = "";//职场名称，也就是部门
        String csId = "";//员工编号
        String uName = "";//用户名称
        String jobTitleName = "";//岗位

        String busName = "";//业务线名称
        Dic business = null;
        DicQuery dicQuery = new DicQuery();
        dicQuery.setParentId(66L);//业务线在字典表的主键id
        List<Dic> businessList = dicService.queryDicList(dicQuery); //一次读取所有业务线信息

        String leaderName = "";//组长
        String shiftsName = "";//班次名称
        Shifts shifts = new Shifts();
        Staff staff = new Staff();
        List<ImpScheduleMsg> impScheduleMsgList = errorRes.getImpScheduleMsgList();
        for (int i = 1; i < impScheduleMsgList.size(); i++) {
            ImpScheduleMsg impScheduleMsg = impScheduleMsgList.get(i);
            if (impScheduleMsg == null)
                continue;
            //部门--职场名
            depName = impScheduleMsg.getDepName();
            if (StringUtils.isBlank(depName)) {
                addError(errorRes, i, 0, depName, 200002, "职场为空");
                continue;
            } else {
                if (!depName.equals(dep.getName())){
                    addError(errorRes, i, 0, depName, 200001, "职场错误");
                    LOG.error("职场错误！");
                    continue;
                }
            }
            //工号
            csId = impScheduleMsg.getCsId();
            if (StringUtils.isBlank(csId)) {
                addError(errorRes, i, 1, csId, 500001, "工号为空");
                continue;
            } else {
                if (staff == null || (staff != null && csId != staff.getCsId())) {
                    staff = null;
                    if (depStaffMap == null || !depStaffMap.containsKey(depName)) {//缓存人员信息
                        //根据部门查询部门可用人员
                        List<Staff> staffs = getStaffsByDepInfo(dep.getCode());
                        depStaffMap.put(depName, staffs);
                    }
                    if (depStaffMap.get(depName) != null) {
                        //获取人员信息
                        for (Staff staffTemp : depStaffMap.get(depName)) {
                            if (csId.equals(staffTemp.getCsId())) {
                                staff = staffTemp;
                                break;
                            }
                        }
                    }
                    if (staff == null) {
                        addError(errorRes, i, 1, csId, 500002, "部门下没有此人员");
                    }
                }
            }
            uName = impScheduleMsg.getuName(); //姓名
            jobTitleName = impScheduleMsg.getJobTitleName();//岗位
            busName = impScheduleMsg.getBusName();//业务
            if (business == null || !busName.equals(business.getName())) {
                business = null;
                for (Dic b : businessList) {
                    if (busName.equals(b.getName())) {
                        business = b;
                        break;
                    }
                }
            }
            //业务线不存在
            if (business == null) {
                addError(errorRes, i, 4, csId, 400001, "业务线：" + busName + "不存在");
            }
            leaderName = impScheduleMsg.getLeaderName(); //组长

            //excel行转列的地方，将一行七天的数据转换成七行一天的数据
            int colNum = 0;
            int pz = errorRes.getImpPlanDates().size();
            List<String> ShiftsNames = new ArrayList<String>(pz);
            if (pz >= 1) {
                ShiftsNames.add(impScheduleMsg.getShiftsName1());
            }
            if (pz >= 2) {
                ShiftsNames.add(impScheduleMsg.getShiftsName2());
            }
            if (pz >= 3) {
                ShiftsNames.add(impScheduleMsg.getShiftsName3());
            }
            if (pz >= 4) {
                ShiftsNames.add(impScheduleMsg.getShiftsName4());
            }
            if (pz >= 5) {
                ShiftsNames.add(impScheduleMsg.getShiftsName5());
            }
            if (pz >= 6) {
                ShiftsNames.add(impScheduleMsg.getShiftsName6());
            }
            if (pz >= 7) {
                ShiftsNames.add(impScheduleMsg.getShiftsName7());
            }
            int index = 6;
            for (Date planDate : errorRes.getImpPlanDates()) {
                //班次名称
                shiftsName = ShiftsNames.get(colNum);
                if (StringUtils.isBlank(shiftsName)) {
                    addError(errorRes, i, index, shiftsName, 300002, "班次为空");
                    continue;
                } else {
                    if ("休息".equals(shiftsName)) {//排班记录中不存在
                        shifts = holidayShifts;
                    } else {
                        if (shifts.getShiftsName() == null || !shiftsName.equals(shifts.getShiftsName())) {
                            shifts = new Shifts();
                            shifts.setShiftsName(shiftsName);
                            int shiftsIndex = shiftsList.indexOf(shifts);
                            if (shiftsIndex > -1) {
                                shifts = shiftsList.get(shiftsIndex);
                            } else {
                                addError(errorRes, i, index, shiftsName, 300001, "班次不存在");
                                continue;
                            }
                        }
                    }
                }
                if (!"休息".equals(shiftsName) && dep != null && shifts != null) {
                    //判断本次 排班数据库中是否存在
                    SchedulePlanDetail schedulePlanDetail = setSchedulePlanDetail(dep, shifts, planDate);
                    int indexOfSPD = sPlanDetailList.indexOf(schedulePlanDetail);
                    if (indexOfSPD < 0) {
                        addError(errorRes, i, index, shiftsName, 600001, "排班表中无匹配记录");
                    } else {//增加排班数目
                        addSPDNum(excelSPDList, schedulePlanDetail);
                    }
                }
                if (isEmptyList(errorRes.getErrList())) {
                    ScheduleDetail detail = setScheduleDetail(dep, csId, uName, jobTitleName, busName, business.getNum(), leaderName, shiftsName, shifts, staff, planDate);
                    scheduleDetailList.add(detail);
                }
                index++;
                colNum++;
            }
        }
    }

    /**
     * 设置总班表明细
     *
     * @param dep
     * @param shifts
     * @param planDate
     * @return
     */
    private SchedulePlanDetail setSchedulePlanDetail(Dep dep, Shifts shifts, Date planDate) {
        SchedulePlanDetail schedulePlanDetail = new SchedulePlanDetail();
        schedulePlanDetail.setDepId(dep.getId());
        schedulePlanDetail.setPlanDate(planDate);
        schedulePlanDetail.setShiftsId(shifts.getId());
        schedulePlanDetail.setDep(dep);
        schedulePlanDetail.setNum(1);
        return schedulePlanDetail;
    }

    /**
     * 增加排班信息数目
     *
     * @param excelSPDList
     * @param schedulePlanDetail
     */
    private void addSPDNum(List<SchedulePlanDetail> excelSPDList, SchedulePlanDetail schedulePlanDetail) {
        int indexList = excelSPDList.indexOf(schedulePlanDetail);
        if (indexList >= 0) {//判断是否存在，如果存在则不增加
            SchedulePlanDetail spd = excelSPDList.get(indexList);
            spd.setNum(spd.getNum() + 1);
        } else {
            excelSPDList.add(schedulePlanDetail);
        }
    }

    //按照日期查询出排班计划，然后判断实体是否存在
    private List<SchedulePlanDetail> getSPDetailsByDates(List<Date> planDates) {
        SchedulePlanDetailQuery schedulePlanDetailQuery = new SchedulePlanDetailQuery();
        schedulePlanDetailQuery.setQuerylanDate(planDates);
        return schedulePlanDetailService.querySchedulePlanDetailList(schedulePlanDetailQuery);
    }

    //按照日期查询出排班计划，然后判断实体是否存在
    private List<SchedulePlanDetail> getSPDetailsById(Long id) {
        SchedulePlanDetailQuery schedulePlanDetailQuery = new SchedulePlanDetailQuery();
        schedulePlanDetailQuery.setSpId(id);
        return schedulePlanDetailService.querySchedulePlanDetailList(schedulePlanDetailQuery);
    }

    //按照部门编码查询部门下的人
    private List<Staff> getStaffsByDepInfo(String code) {
        StaffQuery staffQuery = new StaffQuery();
        staffQuery.setCode(code);//部门编码
        staffQuery.setPositionStatus("3");//在职
        return staffService.queryStaffList(staffQuery);
    }

    /**
     * 设置排班明细实体值
     *
     * @param dep
     * @param csId
     * @param uName
     * @param jobTitleName
     * @param busName
     * @param leaderName
     * @param shiftsName
     * @param shifts
     * @param staff
     * @param planDate
     * @return
     */
    private ScheduleDetail setScheduleDetail(Dep dep, String csId, String uName, String jobTitleName, String busName, Long busNum, String leaderName, String shiftsName, Shifts shifts, Staff staff, Date planDate) {
        ScheduleDetail detail = new ScheduleDetail();
        detail.setDepName(dep.getName());
        detail.setDepId(dep.getId());//职场
        detail.setStaffId(staff.getId());//员工编号
        detail.setCsId(csId);//客服工号
        detail.setuName(uName);//用户名称
        detail.setJobTitleName(jobTitleName);//岗位名称
        detail.setBusName(busName);//业务
        detail.setBusId(busNum);//业务ID
        detail.setLeaderName(leaderName);//组长
        detail.setPlanDate(planDate);//排班日期
        detail.setShiftsId(shifts.getId());//班次
        detail.setShiftsName(shiftsName);//班次名称
        detail.setCreateUser(getLoginUserName());
        return detail;
    }

    //班次信息
    private List<Shifts> getShiftses() {
        ShiftsQuery shiftsQuery = new ShiftsQuery();
        shiftsQuery.setStatus(1);
        return shiftsService.queryShiftsList(shiftsQuery);
    }

    //抽取EXCEL导入数据的日期
    private List<Date> getExcelAllDates(Sheet sheet, ScheduleMessage errorRes) {
        Row firstRow = sheet.getRow(0);//excel第一行，标题
        List<Date> planDates = new ArrayList<>();
        Date nowDate = new Date();

        for (int i = 6; firstRow.getCell(i) != null; i++) {//从第一行、第6列开始，是2月13日的日期。
            Date date = null;

            try {
                date = ExcelUtil.readDateValue(firstRow.getCell(i));
            } catch (Exception e) {
                LOG.error("第一行，第" + i + "列getDates导入日期格式错误" + e);
                addError(errorRes, 0, i, firstRow.getCell(i).toString(), 700001, "日期格式错误");
            }
            planDates.add(date);
        }
        return planDates;
    }

//    /**
//     * 向CommcnQueue增加删除班段信息，用于JOB轮询
//     *
//     * @param schedule
//     */
//    private void addDisSchedulePeriodJob(Schedule schedule) {
//        CommonQueue queue = new CommonQueue();
//        queue.setOnlyId(schedule.getId());
//        queue.setOnlyType("scheduleDetail sId disable");
//        queue.setEventId(EventConstants.EVENT_SCHEDULE_INFO_DISABLE);
//        queue.setRequestRemake("更新删除排班班段信息");
//        queue.setCreatedBy("SCHEDULE ADD");
//        commonQueueService.insert(queue);
//    }
//
//    /**
//     * 向CommcnQueue增加班段信息，用于JOB轮询
//     *
//     * @param schedule
//     */
//    private void addSchedulePeriodJob(Schedule schedule) {
//        CommonQueue queue = new CommonQueue();
//        queue.setOnlyId(schedule.getId());
//        queue.setOnlyType("scheduleDetail sId");
//        queue.setEventId(EventConstants.EVENT_SCHEDULE_INFO_ADD);
//        queue.setRequestRemake("生成排班班段信息 ");
//        queue.setCreatedBy("SCHEDULE ADD");
//        commonQueueService.insert(queue);
//    }

    /**
     * 增加错误明细信息
     *
     * @param errorRes
     * @param rowNum
     * @param lineNum
     * @param Msg
     */
    private void addError(ScheduleMessage errorRes, int rowNum, int lineNum, String value, int code, String Msg) {
        ImportsErrorMessage impError = new ImportsErrorMessage();
        impError.setRow(rowNum);
        impError.setColumn(lineNum);
        impError.setValue(value);
        impError.setCode(code + "");
        impError.setMessage(Msg);
        errorRes.getErrList().add(impError);
    }

    /**
     * 从BPO排班表详细信息中，抽取出BPO排班表导入记录
     *
     * @param
     * @return
     */
//    private List<Schedule> getSchedulesByDetailList(List<ScheduleDetail> excellist) {
//        Date startDate = null;//起始日期
//        Date endDate = null;//结束日期
//        Set<Long> depIds = new LinkedHashSet<Long>();//部门--职场，导入的职场可能有多个
//        List<Date> dates = new ArrayList<Date>();//排班日期列表，排序完成后，第一个为起始日期，最后一个为结束日期
//        String username = getLoginUserName();
//        List<Schedule> schedules = new ArrayList<Schedule>();
//        for (ScheduleDetail detail : excellist) {
//            depIds.add(detail.getDepId());//部门--职场列表去重
//            dates.add(detail.getPlanDate());//加入排班日期
//        }
//        try {
//            Collections.sort(dates);//排班日期排序
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        startDate = dates.get(0);
//        endDate = dates.get(dates.size() - 1);
//        for (Long depId : depIds) {//按部门--职场加入到集合中
//            Schedule plan = new Schedule();
//            plan.setDepId(depId);
//            plan.setBeginTime(startDate);
//            plan.setEndTime(endDate);
//            plan.setCreateUser(username);
//            schedules.add(plan);
//        }
//        return schedules;
//    }

    /**
     * 导出修改后的excel数据
     *
     * @param
     * @return
     * @throws IOException
     */
    @RequestMapping("exportExcelInfo")
    public void exportExcelInfo(HttpServletResponse response, HttpServletRequest request) throws IOException {
        String isReadyDate=request.getParameter("isReadyDate");
        String param="";
        if("1".equals(isReadyDate)){
            param = request.getParameter("exportReadyJsonStr");
        }else{
            param = request.getParameter("exportJsonStr");
        }

        LOG.info(param);
        String fileName = "scheduling_info" + new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + ".xls";
        response.setContentType("application/x-excel");
        response.setCharacterEncoding("UTF-8");
        response.addHeader("Content-Disposition", "attachment;filename="
                + new String(fileName.getBytes(), "iso-8859-1"));// excel文件名
        List<ImpScheduleMsg> messages = Arrays.asList(JsonHelper.toBean(param, ImpScheduleMsg[].class));
        LOG.info(messages);
        exportExcel(fileName, messages, response.getOutputStream());

    }

    /**
     * 将修改后的总班表信息导出到excel
     *
     * @param
     * @return
     */
    private void exportExcel(String fileName, List<ImpScheduleMsg> messages,
                             ServletOutputStream outputStream) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet();
        sheet.setDefaultColumnWidth(15);
        HSSFCellStyle style = workbook.createCellStyle();
        HSSFCellStyle dateStyle = workbook.createCellStyle();
        HSSFDataFormat dataFormat = workbook.createDataFormat();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        HSSFRow row = sheet.createRow(0);
        ImpScheduleMsg header = messages.get(0);
        //excel表头
        for (int i = 0; i < 13; i++) {
            HSSFCell cell = row.createCell(i);
            style.setFillBackgroundColor(HSSFColor.CORAL.index);
            cell.setCellStyle(style);
            if (i >= 6) {
                dateStyle.setDataFormat(dataFormat.getFormat("yyyy/MM/dd"));
                cell.setCellStyle(dateStyle);
            }
            if (i == 0) {
                cell.setCellValue(header.getDepName());
            } else if (i == 1) {
                cell.setCellValue(header.getCsId());
            } else if (i == 2) {
                cell.setCellValue(header.getuName());
            } else if (i == 3) {
                cell.setCellValue(header.getJobTitleName());
            } else if (i == 4) {
                cell.setCellValue(header.getBusName());
            } else if (i == 5) {
                cell.setCellValue(header.getLeaderName());
            } else if (i == 6) {
                cell.setCellValue(header.getShiftsName1());
            } else if (i == 7) {
                cell.setCellValue(header.getShiftsName2());
            } else if (i == 8) {
                cell.setCellValue(header.getShiftsName3());
            } else if (i == 9) {
                cell.setCellValue(header.getShiftsName4());
            } else if (i == 10) {
                cell.setCellValue(header.getShiftsName5());
            } else if (i == 11) {
                cell.setCellValue(header.getShiftsName6());
            } else if (i == 12) {
                cell.setCellValue(header.getShiftsName7());
            }
        }
        int len = messages.size();
        for (int i = 1; i < len; i++) {
            row = sheet.createRow(i);
            ImpScheduleMsg message = messages.get(i);
            row.createCell(0).setCellValue(message.getDepName());
            row.createCell(1).setCellValue(message.getCsId());
            row.createCell(2).setCellValue(message.getuName());
            row.createCell(3).setCellValue(message.getJobTitleName());
            row.createCell(4).setCellValue(message.getBusName());
            row.createCell(5).setCellValue(message.getLeaderName());
            row.createCell(6).setCellValue(message.getShiftsName1());
            row.createCell(7).setCellValue(message.getShiftsName2());
            row.createCell(8).setCellValue(message.getShiftsName3());
            row.createCell(9).setCellValue(message.getShiftsName4());
            row.createCell(10).setCellValue(message.getShiftsName5());
            row.createCell(11).setCellValue(message.getShiftsName6());
            row.createCell(12).setCellValue(message.getShiftsName7());
        }
        try {
            workbook.write(outputStream);
            outputStream.flush();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 提交table数据：先根据table的内容生成excel，并将excel文件保存到服务器，解析excel数据。
     *
     * @param
     * @return
     */
    @RequestMapping("submitTableInfo")
    @ResponseBody
    public Wrapper<?> submitTableInfo(String param, Schedule scheduleParam) {
        if (StringUtils.isNotEmpty(param)) {
            SchedulePlanMessage schedulePlanMessage = new SchedulePlanMessage();
            //3.获取排班任务信息
            scheduleParam = scheduleService.getScheduleById(scheduleParam.getId());
            if (scheduleParam == null) {
                return WrapMapper.wrap(102, "导入失败，排班任务不存在！");
            }

            try {
                //将table内容转换成ImportsMessage
                List<ImpScheduleMsg> impScheduleMsgs = Arrays.asList(JsonHelper.toBean(param, ImpScheduleMsg[].class));
                LOG.info(JsonHelper.toJson(impScheduleMsgs));

                //1.初始化导入错误信息
                ScheduleMessage scheduleMessage = new ScheduleMessage();
                scheduleMessage.setImpDate(new Date());
                scheduleMessage.setuName(getLoginUserName());
                scheduleMessage.setImpScheduleMsgList(impScheduleMsgs);

                scheduleMessage.setSchedule(scheduleParam);

                //3.解析生成排班明细
                List<ScheduleDetail> scheduleDetailList = readTableContent(scheduleMessage);
                LOG.info("导入的BPO排班表详细信息：" + JsonHelper.toJson(scheduleDetailList));
                //5.整个解析过程是否有错误，如果有结束
                if (!isEmptyList(scheduleMessage.getErrList())) {
                    LOG.info("ScheduleController.imports()导入失败，数据校验未通过！" + JsonHelper.toJson(scheduleMessage.getErrList()));
                    scheduleMessage.setCode(1);
                    scheduleMessage.setMsg("失败");
                    return WrapMapper.wrap(400, "数据校验错误!", scheduleMessage);
                }
                //4.解析生产班表导入记录
                List<Schedule> scheduleList = new ArrayList<>();
                scheduleParam.setUpdateUser(getLoginUser().getUserName());//设置更新人
                scheduleList.add(scheduleParam);
//                List<Schedule> scheduleList = getSchedulesByDetailList(scheduleDetailList);
//                LOG.info("班表导入记录错误信息：" + JsonHelper.toJson(scheduleMessage));
//                //6.将信息插入到数据库中。
//                LOG.info("班表导入记录：" + JsonHelper.toJson(scheduleList));
                if (scheduleService.inserts(scheduleList, scheduleDetailList)) {
//                    //插入commonQueue,生成班次信息
//                    for (Schedule schedule : scheduleList) {
//                        //插入commonQueue,标记已经删除班次信息
//                        addDisSchedulePeriodJob(schedule);
//
//                        addSchedulePeriodJob(schedule);
//                    }
                    return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "导入成功！");
                } else {
                    return WrapMapper.wrap(700, "数据操作异常！");
                }

            } catch (NumberFormatException nfe) {
                return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！", schedulePlanMessage);
            } catch (IllegalStateException ise) {
                return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！", schedulePlanMessage);
            } catch (Exception e) {
                return WrapMapper.wrap(300, "导入失败，格式解析错误，请下载模板！", schedulePlanMessage);
            }
        }
        return WrapMapper.wrap(101, "提交数据失败，提交的数据为空！");
    }

    /**
     * @param dateOne
     * @param dateTwo
     * @return 年月日格式比较2个日期之前的大小
     * 如果参数 Date 等于此 Date，则返回值 0；
     * 如果此 Date 在 Date 参数之前，则返回小于 0 的值；
     * 如果此 Date 在 Date 参数之后，则返回大于 0 的值。
     */
    public static boolean isLagerTwoDate(Date dateOne, Date dateTwo) {
        if (dateOne == null) {
            return false;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dateOneStr = sdf.format(dateOne);
        String dateTwoStr = sdf.format(dateTwo);
        if (dateOneStr.compareTo(dateTwoStr) > 0) {
            return true;
        } else {
            return false;
        }
    }

    // 保存文件,返回路径
    private String saveExcelFile(@RequestParam("file") MultipartFile file, HttpServletRequest request) throws IOException {
        String uploadpath = request.getSession().getServletContext().getRealPath("static/upload") + File.separatorChar;
        File uploadfile = new File(uploadpath);
        if (!uploadfile.exists())
            uploadfile.mkdirs();
        //处理中文名称问题
        String extensionName = file.getOriginalFilename();
        extensionName = extensionName.substring(extensionName.lastIndexOf("."), extensionName.length());
        String filePath = uploadpath + new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()) + (int) (Math.random() * 1000) + "paiban" + extensionName;
        // 转存文件
        file.transferTo(new File(filePath));
        LOG.info("转存的文件路径：" + filePath);
        return filePath;
    }

    //判断LIST是否为空
    public static boolean isEmptyList(Collection<?> collection) {
        return collection == null || (collection != null && collection.isEmpty());
    }

    /**
     * 自动排班页面展示
     *
     * @param model
     * @param schedule
     * @return
     */
    @RequestMapping(value = "indexAutoScheduling")
    public String indexAutoScheduling(Model model, Schedule schedule) {
        try {
            Long sId = schedule.getId();
            //获取排班任务信息
            schedule = scheduleService.getScheduleById(sId);

            DicQuery dicQuery = new DicQuery();
            dicQuery.setParentId(66L);//业务线在字典表的主键id
            List<Dic> businessList = dicService.queryDicList(dicQuery); //一次读取所有业务线信息

            ShiftsQuery shiftsQuery = new ShiftsQuery();
            shiftsQuery.setStatus(1);
            List<Shifts> shiftsList = shiftsService.queryShiftsList(shiftsQuery);//一次读取所有班次信息


            model.addAttribute("businessList", businessList);
            model.addAttribute("shiftsList", shiftsList);

            model.addAttribute("schedule", schedule);
        } catch (Exception e) {
            logger.error("Schedule indexAutoScheduling has error.", e);
            e.printStackTrace();
        }
        return VIEW_PREFIX + "/" + VIEW_INDEX_AUTOSCHEDULING;
    }
    /**
     * 提交排班审批
     *
     * @param
     * @return
     */
    @RequestMapping("addAutoScheduling")
    @ResponseBody
    public Wrapper<?> addAutoScheduling(String spId, String sId) {
        try {
            //校验是否重复-一个任务 只能提交一次
//            if (!validIsHavaFinishedFlow(siIds, 1)) {
//                return WrapMapper.wrap(1200, "支援审批提交失败，已有任务在处理中！");
//            }
            scheduleService.addAutoScheduleFlow(spId, sId,getLoginUserId(),getLoginUserName());

        } catch (Exception e) {
            LOG.error("添加支援审批信息失败！" + e);
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "支援审批提交失败！");
        }
        return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "支援审批提交成功！");
    }
    /**
     * 将业务线加到model
     *
     * @param
     * @return
     */
    private void addBusinessToModel(Model model) {
        List<Dic> business = getBusiness();
        model.addAttribute("business", business);
    }
    /***
     * 获得所有业务线
     * @return
     */
    private List<Dic> getBusiness() {
        DicQuery query = new DicQuery();
        query.setParentName("业务");
        List<Dic> business = dicService.queryDicList(query);
        return business;
    }
}
