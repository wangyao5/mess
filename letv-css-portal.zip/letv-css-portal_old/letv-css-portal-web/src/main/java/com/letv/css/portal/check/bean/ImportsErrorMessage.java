package com.letv.css.portal.check.bean;

/**
 * 记录数据导入时的错误信息
 *
 * @Author menghan
 * @Version 2017-06-13 17:31:35
 */
public class ImportsErrorMessage {

	//错误代码
	private String code;
	//错误信息
	private String message;
	//错误行
	private Integer row;
	//错误列
	private Integer column;

	private String value;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getRow() {
		return row;
	}
	public void setRow(Integer row) {
		this.row = row;
	}
	public Integer getColumn() {
		return column;
	}
	public void setColumn(Integer column) {
		this.column = column;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
