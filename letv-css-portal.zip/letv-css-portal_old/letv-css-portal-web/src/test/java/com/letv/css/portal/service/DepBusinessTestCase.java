package com.letv.css.portal.service;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.letv.common.utils.serialize.JsonHelper;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.test.BaseTestCase;

/**
 * 部门信息管理测试用例
 *
 * @Author menghan
 * @Version 2017-01-13 10:38:55
 */
public class DepBusinessTestCase extends BaseTestCase{

	@Autowired
	private DepService depService;
	
	@Test
	public void testGetDepById(){
		Long id = 3L;
		Dep dep = depService.getDepById(id);
		logger.info(JsonHelper.toJson(dep));
	}
	
	@Test
	public void testGetDepListByIds(){
		String ids = "1,2,4,6,100";
		List<Dep> deps = depService.getDepListByIds(ids);
		Assert.notEmpty(deps);
		logger.info("deps大小："+deps.size());
		logger.info(JsonHelper.toJson(deps));
	}
	
	@Test
	public void testGetChildrenCodByParentId(){
		Long parentId = 0L;
		List<String> list = depService.getChildrenCodByParentId(parentId);
		System.out.println(JsonHelper.toJson(list));
	}
	
	@Test
	public void testQueryTreeDepList(){
		Long parentId = 0L;
		DepQuery query = new DepQuery();
		query.setParentId(parentId);
		List<Dep> deps = depService.queryTreeDepList(query);
		System.out.println(JsonHelper.toJson(deps));
	}
	
}
