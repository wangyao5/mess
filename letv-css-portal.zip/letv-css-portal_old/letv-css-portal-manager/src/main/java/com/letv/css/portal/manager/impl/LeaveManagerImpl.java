package com.letv.css.portal.manager.impl;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.AdjustChangeDao;
import com.letv.css.portal.dao.CommonQueueDao;
import com.letv.css.portal.dao.LeaveDao;
import com.letv.css.portal.dao.StaffDao;
import com.letv.css.portal.domain.AdjustChange;
import com.letv.css.portal.domain.Leave;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.domain.query.StaffQuery;
import com.letv.css.portal.manager.LeaveManager;
import com.letv.css.portal.manager.StaffManager;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class LeaveManagerImpl extends BaseManager implements LeaveManager {

	private final static Log LOG = LogFactory.getLog(LeaveManagerImpl.class);
	@Autowired
	private LeaveDao leaveDao;
	@Autowired
	private CommonQueueDao commonQueueDao;

	@Override
	public boolean addLeave(Leave bean) {
		leaveDao.insert(bean);

		//插入commonQueue,同步工作流
		CommonQueue queue = new CommonQueue();
		queue.setOnlyId(bean.getId());
		queue.setOnlyType("leave id");
		queue.setEventId(EventConstants.EVENT_LEAVE);
		queue.setCreatedBy(bean.getCreateUser() + "");

		boolean resultFlag = commonQueueDao.insert(queue);
		return resultFlag;
	}

	@Override
	public Leave getLeaveById(Long id) {
		return leaveDao.getLeaveById(id);
	}

	@Override
	public boolean updateStatus(Leave bean) {
		return leaveDao.updateStatus(bean);
	}

	@Override
	public List<Leave> queryRepeatedLeave(Long staffId, Date leaveStartTime, Date leaveEndTime) {
		return leaveDao.queryRepeatedLeave( staffId, leaveStartTime, leaveEndTime );
	}
}
