package com.letv.css.portal.manager;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.ShiftsPeriod;
import com.letv.css.portal.domain.query.ShiftsPeriodQuery;

import java.util.List;

/**
 * Created by yangxinghe on 2017/5/16.
 */
public interface ShiftsPeriodManager {
    /**
     * 根据查询参数查询信息集合
     * @param
     * @return
     */
    List<ShiftsPeriod> queryShiftsPeriodList(ShiftsPeriodQuery queryBean);

    /**
     * 根据查询参数查询信息集合
     * @param
     * @return
     */
    List<ShiftsPeriod> queryShiftsPeriodListWithPage(ShiftsPeriodQuery queryBean, PageUtil pageUtil);
    /**
     * 根据查询Bean获取对象信息总数
     *
     * @param queryBean
     *            对象信息查询对象
     * @return 对象信息总数
     */
    int queryShiftsPeriodCount(ShiftsPeriodQuery queryBean);

    /**
     * 新增对象
     *
     * @param bean
     * @return
     */
    boolean insert(ShiftsPeriod bean);

    /**
     * 更新对象
     *
     * @param bean
     * @return
     */
    boolean update(ShiftsPeriod bean);


    /**
     * 根据主键删除记录
     *
     * @param id
     * @return
     */
    boolean delete(Long id);

    /**
     * 根据主键获取对象
     *
     * @param id 主键字段
     * @return
     */
    ShiftsPeriod getShiftsPeriodById(Long id);

    /*
    *  批量更新状态
     */
    boolean updateStatus(String[] ids, int status, String updateUser);
}
