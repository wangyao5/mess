package com.letv.css.portal.manager.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.css.portal.dao.MenuLogsDao;
import com.letv.css.portal.domain.MenuLogs;
import com.letv.css.portal.manager.MenuLogsManager;

/**
 * 访问菜单日志manager实现类
 *
 * @Author menghan
 * @Version 2017-05-17 18:40:59
 */
@Component
public class MenuLogsManagerImpl extends BaseManager implements MenuLogsManager{

	@Autowired
	private MenuLogsDao menuLogsDao;
	
	/**
	 * {@inheritDoc}
	 */
	public boolean addLog(MenuLogs menuLogs) {
		return menuLogsDao.addLog(menuLogs);
	}

}
