package com.letv.css.portal.manager.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.DepDao;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.manager.DepManager;

/**
 * User: gaohongjing Date: 2014-04-08 Time: 18:43:58
 */
@Component
public class DepManagerImpl extends BaseManager implements DepManager {
    private final static Log log = LogFactory.getLog(DepManagerImpl.class);
    @Autowired
    private DepDao depDao;

    public boolean insert(final List<Dep> beanList) {
        boolean resultFlag = true;
        if (null != beanList && beanList.size() > 0) {
            for (Dep bean : beanList) {
                resultFlag = depDao.insert(bean);
                if (!resultFlag) {
                    throw new RuntimeException("批量新增表信息异常");
                }
            }
        }

        return resultFlag;
    }

    public boolean insert(Dep bean) {
        return depDao.insert(bean);
    }

    public boolean update(final Dep bean) {
        boolean resultFlag = true;
        if (null != bean) {
            resultFlag = depDao.update(bean);
            if (!resultFlag) {
                throw new RuntimeException("单个表信息更新异常,ID:[" + bean.getId() + "]!");
            }
        } else {
            log.debug("DepManagerImpl!update(Dep bean) Error,参数为空!");
            throw new RuntimeException("单个表信息更新时，表信息对象为NULL!");
        }

        return resultFlag;
    }

    public List<Dep> queryDepList(DepQuery queryBean) {
        return depDao.queryDepList(queryBean);
    }

    public List<Dep> queryDepListWithPage(DepQuery queryBean, PageUtil pageUtil) {
		if (null == queryBean) {
			queryBean = new DepQuery();
		}

		// 查询总数
		int totalItem = queryDepCount(queryBean);

		if (pageUtil == null) {
			pageUtil = new PageUtil();
		}
		pageUtil.setTotalRow(totalItem);
		pageUtil.init();

		if (totalItem > 0) {
			queryBean.setPageIndex(pageUtil.getCurPage());
			queryBean.setPageSize(pageUtil.getPageSize());
			// 调用Dao翻页方法
			return depDao.queryDepListWithPage(queryBean);
		}
		return null;
    }

    public int queryDepCount(DepQuery queryBean) {
        return depDao.queryDepCount(queryBean);
    }

    public boolean delete(Long id) {
        return depDao.deleteDepById(id);
    }

    public Dep getDepById(Long id) {
        return depDao.getDepById(id);
    }
    
	public List<Dep> getDepListByIds(String ids) {
		return depDao.getDepListByIds(ids);
	}

    public boolean delete(final String[] ids) {
        boolean resultFlag = true;
        if (null != ids && ids.length > 0) {
            for (int i = 0; i < ids.length; i++) {
                resultFlag = delete(Long.parseLong(ids[i]));
                if (!resultFlag) {
                    throw new RuntimeException("批量删除表信息异常!");
                }
            }
        } else {
            log.error("ids param is null!");
        }

        return resultFlag;
    }

	public List<String> getChildrenCodByParentId(Long parentId) {
		return depDao.getChildrenCodByParentId(parentId);
	}

	public List<Dep> queryTreeDepList(DepQuery query) {
		return depDao.queryTreeDepList(query);
	}

	public List<Dep> queryDepTree(Long userId) {
		return depDao.queryDepTree(userId);
	}

	public Integer queryDepPersonQuantity(Long depId) {
		return depDao.queryDepPersonQuantity(depId);
	}

	@Override
	public Map<Integer, Integer> queryDepPersonQuantityByCode(String code) {
		return depDao.queryDepPersonQuantityByCode(code);
	}

	/**
	 * {@inheritDoc}
	 */
	public Dep getDepByName(String name) {
		return depDao.getDepByName(name);
	}


//    public int syncDepDatas(List<Dep> deps) {
//        int addCount = 0;
//        int updateCount = 0;
//        if (deps != null && deps.size() > 0) {
//            for (Dep dep : deps) {
//                Dep tempDep = this.getDepByCode(dep.getCode());
//                if (tempDep == null) {
//                    this.insert(dep);
//                    addCount++;
//                } else if (tempDep.getLastModifyTime().getTime() < dep.getLastModifyTime().getTime()) {
//                	dep.setId(tempDep.getId());
//                	this.update(dep);
//                    updateCount++;
//                } else {
//                    log.info("syncDepDatas 最后更新时间不大于当前最后更新时间判断为不更新数据！");
//                }
//            }
//            log.info("总共记录：【" + deps.size() + "】条，新增：【" + addCount + "】条，更新：【" + updateCount + "】条。");
//        }
//
//        // 返回操作数据库条数
//        return addCount + updateCount;
//    }

}
