package com.letv.css.portal.manager.impl;

import java.util.List;

import com.letv.css.portal.dao.CommonQueueDao;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.css.portal.dao.UserDepDao;
import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.domain.query.UserDepQuery;
import com.letv.css.portal.manager.UserDepManager;

/**
 * 用户和部门（数据权限）关系 manager实现类
 *
 * @Author menghan
 * @Version 2017-01-22 16:24:55
 */
@Component
public class UserDepManagerImpl extends BaseManager implements UserDepManager{

	@Autowired
	private UserDepDao userDepDao;
	@Autowired
	private CommonQueueDao commonQueueDao;
	
	/**
	 * {@inheritDoc}
	 */
	public boolean update(UserDep oldUserDep, List<UserDep> newUserDeps, long loginId) {
		userDepDao.deleteUserDep(oldUserDep);

		CommonQueue queue = new CommonQueue();
		queue.setOnlyId(oldUserDep.getUserId());
		queue.setOnlyType("user id");
		queue.setEventId(EventConstants.EVENT_USER_DEP);
		queue.setRequestRemake("用户组流程");
		queue.setCreatedBy(loginId + "");
		commonQueueDao.insert(queue);
		
		if(!CollectionUtils.isEmpty(newUserDeps)){
			boolean resultFlag = false;
			for(UserDep userDep:newUserDeps){
				resultFlag = this.userDepDao.insert(userDep);
				if (!resultFlag) {
					throw new RuntimeException("批量新增表信息异常");
				}
			}
			return resultFlag;
		}
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<UserDep> queryUserDepList(Long userId) {
		return userDepDao.queryUserDepList(userId);
	}
	
	/**
	 * {@inheritDoc}
	 */
	public List<UserDep> queryDepListByUserIds(UserDepQuery userDepQuery) {
		return userDepDao.queryDepListByUserIds(userDepQuery);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean insert(UserDep userDep) {
		return userDepDao.insert(userDep);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<UserDep> queryUsersByDepId(Long depId) {
		return userDepDao.queryUsersByDepId(depId);
	}

}
