package com.letv.css.portal.manager;

import com.letv.css.portal.domain.ThresholdValue;

/**
 * @Author gexuliang
 */
public interface ThresholdValueManager {

	ThresholdValue getInfoByCode (String code);
}
