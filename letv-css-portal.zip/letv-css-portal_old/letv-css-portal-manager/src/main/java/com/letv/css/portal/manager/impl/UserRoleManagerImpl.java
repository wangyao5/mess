package com.letv.css.portal.manager.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.letv.common.manager.BaseManager;
import com.letv.css.portal.dao.UserRoleDao;
import com.letv.css.portal.domain.UserRole;
import com.letv.css.portal.domain.query.UserRoleQuery;
import com.letv.css.portal.manager.UserRoleManager;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-22 11:26:02
 */
@Component
public class UserRoleManagerImpl extends BaseManager implements UserRoleManager {

	private final static Log log = LogFactory.getLog(UserRoleManagerImpl.class);

	@Autowired
	private UserRoleDao userRoleDao;

	/**
	 * {@inheritDoc}
	 */
	public boolean insert(List<UserRole> beanList) {
		boolean resultFlag = true;
		if (null != beanList && beanList.size() > 0) {
			for (UserRole bean : beanList) {
				resultFlag = this.userRoleDao.insert(bean);
				if (!resultFlag) {
					throw new RuntimeException("批量新增表信息异常");
				}
			}
		}
		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean insert(UserRole bean) {
		return this.userRoleDao.insert(bean);
	}

	/**
	 * {@inheritDoc}
	 */
	public int queryUserRoleCount(UserRoleQuery queryBean) {
		return this.userRoleDao.queryUserRoleCount(queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<UserRole> queryUserRoleList(UserRoleQuery queryBean) {
		return this.userRoleDao.queryUserRoleList(queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean update(UserRole bean) {
		boolean resultFlag = true;
		if (null != bean) {
			resultFlag = this.userRoleDao.update(bean);
			if (!resultFlag) {
				throw new RuntimeException("单个表信息更新异常,ID:[" + bean.getId()
						+ "]!");
			}
		} else {
			log.debug("UserRoleManagerImpl!update(UserRole bean) Error,参数为空!");
			throw new RuntimeException("单个表信息更新时，表信息对象为NULL!");
		}

		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean delete(Long id) {
		return this.userRoleDao.deleteUserRoleById(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public UserRole getUserRoleById(Long id) {
		return this.userRoleDao.getUserRoleById(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean delete(String[] ids) {
		boolean resultFlag = true;
		if (null != ids && ids.length > 0) {
			for (int i = 0; i < ids.length; i++) {
				resultFlag = delete(Long.parseLong(ids[i]));
				if (!resultFlag) {
					throw new RuntimeException("批量删除表信息异常!");
				}
			}
		} else {
			log.error("ids param is null!");
		}

		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean batchSave(Long userId, String[] roleIds, String createUser) {
		this.userRoleDao.deleteUserRoleByUserId(userId);
		if (roleIds != null && roleIds.length > 0) {
			List<UserRole> beanList = new ArrayList<UserRole>(roleIds.length);
			for (String roleId : roleIds) {
				UserRole userRole = new UserRole();
				userRole.setUserId(userId);
				userRole.setRoleId(Long.parseLong(roleId));
				userRole.setCreateUser(createUser);
				beanList.add(userRole);
			}
			return insert(beanList);
		}
		return true;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean batchSaveRoleUsers(Long roleId, String[] userIds, String createUser) {
		this.userRoleDao.deleteUserRoleByRoleId(roleId);
		if (userIds != null && userIds.length > 0) {
			List<UserRole> beanList = new ArrayList<UserRole>(userIds.length);
			for (String userId : userIds) {
				UserRole userRole = new UserRole();
				userRole.setRoleId(roleId);
				userRole.setUserId(Long.parseLong(userId));
				userRole.setCreateUser(createUser);
				beanList.add(userRole);
			}
			return insert(beanList);
		}
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean batchSaves(String[] userIds, String[] roleIds,
			String createUser) {
		boolean resultFlag = true;
		for (String userId : userIds) {
			List<UserRole> beanList = new ArrayList<UserRole>(roleIds.length);
			for (String roleId : roleIds) {
				UserRole userRole = new UserRole();
				userRole.setUserId(Long.valueOf(userId));
				userRole.setRoleId(Long.parseLong(roleId));
				userRole.setCreateUser(createUser);
				userRole.setRemark("");
				beanList.add(userRole);
			}
			resultFlag = insert(beanList);
			if (!resultFlag) {
				return resultFlag;
			}
		}
		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<UserRole> queryUsersByRoleId(Long roleId) {
		return this.userRoleDao.queryUsersByRoleId(roleId);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<UserRole> queryRoleUserList(UserRoleQuery query) {
		return this.userRoleDao.queryRoleUserList(query);
	}

}
