package com.letv.css.portal.manager;

import java.util.List;

import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.query.SchedulePlanDetailQuery;

/**
 * 操作总班表明细manager
 *
 * @Author menghan
 * @Version 2017-05-24 17:27:26
 */
public interface SchedulePlanDetailManager {
	/**
	 * 插入一条总班表明细记录
	 * @param
	 * @return
	 */
	boolean insert(SchedulePlanDetail schedulePlanDetail);
	
	/**
	 * 批量插入总班表明细记录
	 * @param
	 * @return
	 */
	boolean inserts(List<SchedulePlanDetail> schedulePlanDetails);
	
	/***
	 * 根据总班表Id查询总班表明细列表
	 * @param
	 * @return
	 */
	List<SchedulePlanDetail> querySchedulePlanDetailList(SchedulePlanDetailQuery query);

	/***
	 * 修改总班表明细信息
	 * @param
	 * @return
	 */
	boolean update(SchedulePlanDetail schedulePlanDetail);
	
	/**
	 * 根据ID删除总班表明细信息
	 * @param
	 * @return
	 */
	boolean delete(Long id);
	
	/**
	 * 根据query，批量删除总班表明细信息
	 * @param
	 * @return
	 */
	boolean deletes(SchedulePlanDetailQuery query);
}
