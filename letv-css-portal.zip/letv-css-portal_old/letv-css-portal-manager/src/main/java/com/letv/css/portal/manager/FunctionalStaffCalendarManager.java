package com.letv.css.portal.manager;

import java.util.List;

import com.letv.css.portal.domain.FunctionalStaffCalendar;
import com.letv.css.portal.domain.query.FunctionalStaffCalendarQuery;

/**
 * 数据字典 manager接口
 * @Author greg
 */
public interface FunctionalStaffCalendarManager {
	/**
	 * 新增
	 * @param
	 * @return
	 */
	boolean insert(FunctionalStaffCalendar functionalStaffCalendar);
	
	/** 
	 * 更新
	 * @param
	 * @return
	 */
	boolean update(FunctionalStaffCalendar functionalStaffCalendar);
	
	List<FunctionalStaffCalendar> queryList(FunctionalStaffCalendarQuery query);

}
