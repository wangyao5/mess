package com.letv.css.portal.manager.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import com.letv.css.portal.dao.ScheduleDetailDao;
import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.query.ScheduleDetailQuery;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.DateHelper;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.ScheduleDao;
import com.letv.css.portal.dao.SchedulePlanDao;
import com.letv.css.portal.dao.SchedulePlanDetailDao;
import com.letv.css.portal.domain.Schedule;
import com.letv.css.portal.domain.SchedulePlan;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.domain.query.SchedulePlanDetailQuery;
import com.letv.css.portal.domain.query.SchedulePlanQuery;
import com.letv.css.portal.domain.query.ScheduleQuery;
import com.letv.css.portal.manager.SchedulePlanManager;

/**
 * 总班表导入manager实现类
 *
 * @Author menghan
 * @Version 2017-05-24 13:51:51
 */
@Component
public class SchedulePlanManagerImpl extends BaseManager implements SchedulePlanManager{

	private final static Log LOG = LogFactory.getLog(SchedulePlanManagerImpl.class);
	
	@Autowired
	private SchedulePlanDao schedulePlanDao;
	
	@Autowired
	private SchedulePlanDetailDao schedulePlanDetailDao;
	
	@Autowired
	private ScheduleDao scheduleDao;
	
	@Autowired
	private ScheduleDetailDao scheduleDetailDao;

	/**
	 * {@inheritDoc}
	 */
	public boolean insert(SchedulePlan schedulePlan) {
		return schedulePlanDao.insert(schedulePlan);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean inserts(List<SchedulePlan> schedulePlans) {
//		boolean flag = false;
//		if(CollectionUtils.isNotEmpty(schedulePlans)){
//			for(SchedulePlan plan:schedulePlans){
//				flag = schedulePlanDao.insert(plan);
//				if(!flag){
//					throw new RuntimeException("批量插入总班表导入记录失败");
//				}
//			}
//		}
		return schedulePlanDao.inserts(schedulePlans);
	}

	/**
	 * {@inheritDoc}
	 */
	public SchedulePlan getSchedulePlanById(Long id) {
		return schedulePlanDao.getSchedulePlanById(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<SchedulePlan> querySchedulePlanListWithPage(SchedulePlanQuery query,PageUtil pageUtil) {
		if (null == query) {
			query = new SchedulePlanQuery();
		}

		// 查询总数
		int totalItem = schedulePlanDao.querySchedulePlanCount(query);

		if (pageUtil == null) {
			pageUtil = new PageUtil();
		}
		pageUtil.setTotalRow(totalItem);
		pageUtil.init();

		if (totalItem > 0) {
			query.setPageIndex(pageUtil.getCurPage());
			query.setPageSize(pageUtil.getPageSize());
			// 调用Dao翻页方法
			return schedulePlanDao.querySchedulePlanListWithPage(query);
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<SchedulePlan> querySchedulePlanList(SchedulePlanQuery query) {
		return schedulePlanDao.querySchedulePlanList(query);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean inserts(List<SchedulePlan> schedulePlans,
			List<SchedulePlanDetail> schedulePlanDetails) {
		boolean flag = false;
		int /*start = 0, end = 0,*/ n = schedulePlanDetails.size();
		Long spId = 0L;
		SchedulePlanQuery schedulePlanQuery = new SchedulePlanQuery();
		SchedulePlanDetailQuery schedulePlanDetailQuery = new SchedulePlanDetailQuery();

		ScheduleDetailQuery scheduleDetailQuery = new ScheduleDetailQuery();
		//一条总班表导入记录对应多条总班表明细记录，依靠总班表id进行关联
		for(SchedulePlan schedulePlan:schedulePlans){
			//先插入总班表导入记录
			schedulePlan.setStatus(1);
			//判断该时间段内，是否存在一样的总班表记录。判断条件：职场id、业务id、起始日期、结束日期。如果符合判断条件，将原来的数据yn置为0，并插入新数据。
			schedulePlanQuery.setDepId(schedulePlan.getDepId());//职场id
			schedulePlanQuery.setBusId(schedulePlan.getBusId());//业务id
			schedulePlanQuery.setStartTime(DateHelper.format(schedulePlan.getBeginTime(), "yyyy-MM-dd"));//起始日期
			schedulePlanQuery.setEndTime(DateHelper.format(schedulePlan.getEndTime(), "yyyy-MM-dd"));//结束日期
			List<SchedulePlan> plans = schedulePlanDao.querySchedulePlanList(schedulePlanQuery);//查询符合条件的总班表导入记录
			if(CollectionUtils.isEmpty(plans)){
				//不存在该记录，则直接插入
				flag = schedulePlanDao.insert(schedulePlan);
			}else{
				//存在该记录，先标记删除，在插入
				SchedulePlan plan = plans.get(0);
				spId = plan.getId();
				plan.setYn(0);
				plan.setUpdateUser(schedulePlan.getCreateUser());
				schedulePlanDao.update(plan);
				flag = schedulePlanDao.insert(schedulePlan);
			}
			
			//将总班表数据同步插入到班表中
			ScheduleQuery scheduleQuery = new ScheduleQuery();
			scheduleQuery.setBusId(schedulePlan.getBusId());
			scheduleQuery.setDepId(schedulePlan.getDepId());
			scheduleQuery.setStartTime(DateHelper.format(schedulePlan.getBeginTime(), "yyyy-MM-dd"));
			scheduleQuery.setEndTime(DateHelper.format(schedulePlan.getEndTime(), "yyyy-MM-dd"));
			List<Schedule> schedules = scheduleDao.queryScheduleList(scheduleQuery);
			Schedule schedule = new Schedule();
			schedule.setDepId(schedulePlan.getDepId());
			schedule.setBusId(schedulePlan.getBusId());
			schedule.setBeginTime(schedulePlan.getBeginTime());
			schedule.setEndTime(schedulePlan.getEndTime());
			schedule.setCreateUser(schedulePlan.getCreateUser());
			schedule.setSpId(schedulePlan.getId());
			if(CollectionUtils.isEmpty(schedules)){
				//直接插入
				flag = scheduleDao.insert(schedule);
			}else{
				//先标记删除在插入
				Schedule s = schedules.get(0);
				s.setYn(0);
				scheduleDao.update(s);
				flag = scheduleDao.insert(schedule);
			}
			
			if(!flag){
				try {
					throw new Exception("插入总班表数据失败");
				} catch (Exception e) {
					e.printStackTrace();
				}
				return false;
			}
			
			//待插入的总班表明细记录
			List<SchedulePlanDetail> spDetails = new ArrayList<SchedulePlanDetail>();
			//关联总班表和总班表明细，总班表导入的时候，职场-业务线可能没有规则，乱序出现，所有要扫描全部总班表明细
			for(int i=0;i<n;i++){
				SchedulePlanDetail detail = schedulePlanDetails.get(i);
				if(Objects.equals(schedulePlan.getDepId(),detail.getDepId()) && Objects.equals(schedulePlan.getBusId().intValue(),detail.getBusId())){//部门id和业务线id
					detail.setSpId(schedulePlan.getId());//设置总班表明细与总班表记录的关联ID
					spDetails.add(detail);
//					end ++;
//				}else{
//					break;
				}
			}
			
			//根据总班表明细，删除导入的班表明细信息。删除规则：职场、业务线、排班日期
			List<ScheduleDetail> allDetails = new ArrayList<ScheduleDetail>();

			//判断schedulePlanDetails中的数据是否已经存在。查找条件：部门、业务线与排班日期已经寻在
			List<SchedulePlanDetail> allPlanDetails = new ArrayList<SchedulePlanDetail>();
			if(CollectionUtils.isNotEmpty(spDetails)){
				//查询总班表明细信息
				Date tempDate = spDetails.get(0).getPlanDate();
				schedulePlanDetailQuery.setDepId(schedulePlan.getDepId());//部门ID
				schedulePlanDetailQuery.setBusId(schedulePlan.getBusId().intValue());//业务线id
				schedulePlanDetailQuery.setPlanDate(tempDate);//排班日期
				List<SchedulePlanDetail> planList = schedulePlanDetailDao.querySchedulePlanDetailList(schedulePlanDetailQuery);
				allPlanDetails.addAll(planList);

				//查询班表明细
				scheduleDetailQuery.setDepId(schedulePlan.getDepId());//部门ID
				scheduleDetailQuery.setBusId(schedulePlan.getBusId().intValue());//业务线id
				scheduleDetailQuery.setPlanDate(tempDate);//排班日期
				List<ScheduleDetail> list = scheduleDetailDao.queryScheduleDetailList(scheduleDetailQuery);
				allDetails.addAll(list);

				for(int i=1;i<spDetails.size();i++){
					if(!Objects.equals(tempDate.getTime(),spDetails.get(i).getPlanDate().getTime())){
						//查询总班表明细信息
						tempDate = spDetails.get(i).getPlanDate();
						schedulePlanDetailQuery.setPlanDate(tempDate);
						List<SchedulePlanDetail> planTemp = schedulePlanDetailDao.querySchedulePlanDetailList(schedulePlanDetailQuery);
						allPlanDetails.addAll(planTemp);

						//查询班表明细
						scheduleDetailQuery.setPlanDate(tempDate);
						List<ScheduleDetail> temp = scheduleDetailDao.queryScheduleDetailList(scheduleDetailQuery);
						allDetails.addAll(temp);
					}else{
						break;
					}
				}
			}
			//删除班表明细
			if(CollectionUtils.isNotEmpty(allDetails)){
				//先标记删除旧数据
				scheduleDetailDao.batchDelete(allDetails);
			}

			//插入总班表明细记录
			if(CollectionUtils.isNotEmpty(allPlanDetails)){
				//先标记删除旧数据
//				schedulePlanDetailQuery.setSpId(spId);
//				List<SchedulePlanDetail> list = schedulePlanDetailDao.querySchedulePlanDetailList(schedulePlanDetailQuery);
				schedulePlanDetailDao.batchDelete(allPlanDetails);
				//在插入新数据
				flag = schedulePlanDetailDao.inserts(spDetails);
			}else{
				//直接插入新数据
				if( CollectionUtils.isNotEmpty(spDetails)){
					flag = schedulePlanDetailDao.inserts(spDetails);
				}
			}
			if(!flag){
				try {
					throw new Exception("插入总班表数据失败");
				} catch (Exception e) {
					e.printStackTrace();
				}
				return false;
			}
//			start = end;
			spId = 0L;
		}
		return flag;
	}

}
