package com.letv.css.portal.manager.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.css.portal.dao.MenuDao;
import com.letv.css.portal.domain.Resource;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.dto.MenuDto;
import com.letv.css.portal.domain.dto.SystemMenuDto;
import com.letv.css.portal.manager.MenuManager;

/**
 * 系统菜单查询Manager实现
 *
 * @Author menghan
 * @Version 2017-01-22 14:15:15
 */
@Component
public class MenuManagerImpl implements MenuManager {

    @Autowired
    private MenuDao menuDao;

    /**
     * {@inheritDoc}
     */
    public List<MenuDto> getMenus(User user) {
        return menuDao.getMenus(user);
    }

    /**
     * {@inheritDoc}
     */
    public List<Resource> queryResourceListByUserId(User user) {
        return menuDao.queryResourceListByUserId(user);
    }

    /**
     * {@inheritDoc}
     */
    public List<Resource> queryButtonResources(Map<String, Object> map) {
        return menuDao.queryButtonResources(map);
    }

	public List<MenuDto> getSystemMenus(Map<String, Object> paramMap) {
		return menuDao.getSystemMenus(paramMap);
	}
	
	public List<SystemMenuDto> getAllSystemMenus(Map<String, Object> paramMap) {
		return menuDao.getAllSystemMenus(paramMap);
	}

	public List<MenuDto> queryAuthMenusWithLevel(Map<String, Object> paramMap) {
		return menuDao.queryAuthMenusWithLevel(paramMap);
	}

	public List<MenuDto> queryMenusWithLevel(Map<String, Object> paramMap) {
		return menuDao.queryMenusWithLevel(paramMap);
	}

	public List<Resource> getShortCutMenus(User user) {
		return menuDao.getShortCutMenus(user);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Resource> queryAllSubMenu() {
		return menuDao.queryAllSubMenu();
	}
}
