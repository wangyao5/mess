package com.letv.css.portal.manager.impl;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.CommonQueueDao;
import com.letv.css.portal.dao.DepDao;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.manager.CommonQueueManager;
import com.letv.css.portal.manager.DepManager;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CommonQueueImpl extends BaseManager implements CommonQueueManager {
    private final static Log log = LogFactory.getLog(CommonQueueImpl.class);
    @Autowired
    private CommonQueueDao commonQueueDao;

    public boolean insert(CommonQueue commonQueue) {
        return commonQueueDao.insert(commonQueue);
    }

}
