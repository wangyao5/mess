package com.letv.css.portal.manager;

import java.util.List;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.query.UserQuery;
import com.letv.css.portal.domain.query.UserRoleQuery;

/**
 * User: gaohongjing Date: 2014-04-08 Time: 18:43:58
 */
public interface UserManager {

    /**
     * 批量增加对象信息
     * 
     * @param beanList
     * @return
     */
    boolean insert(List<User> beanList);

    /**
     * 单个增加对象信息
     * 
     * @param bean
     * @return
     */
    boolean insert(User bean);

    /**
     * 更新 对象信息
     * 
     * @param bean
     *            对象信息对象
     * @return false：失败 true：成功
     */
    boolean update(User bean);

    /**
     * 根据登录账号更新 对象信息
     * 
     * @param bean
     *            对象信息对象
     * @return false：失败 true：成功
     */
    boolean updateByName(User bean);

    /**
     * 根据查询Bean获取对象集合，无翻页
     * 
     * @param queryBean
     * @return
     */
    List<User> queryUserList(UserQuery queryBean);

    /**
     * 根据查询Bean获取对象集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<User> queryUserListWithPage(UserQuery queryBean, PageUtil pageUtil);
   
    /**
     * 根据查询Bean获取对象集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<User> queryUserDepStaffListWhere(UserQuery queryBean, PageUtil pageUtil);
    
    /**
     * 根据查询Bean获取对象集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<User> queryUserListWithPage4Side(UserQuery queryBean, PageUtil pageUtil);


    /**
     * 根据查询Bean获取对象信息总数
     * 
     * @param queryBean
     *            对象信息查询对象
     * @return 对象信息总数
     */
    int queryUserCount(UserQuery queryBean);
    
    /**
     * 根据查询Bean获取对象信息总数
     * 
     * @param queryBean
     *            对象信息查询对象
     * @return 对象信息总数
     */
    int queryUserCount4Side(UserQuery queryBean);

    /**
     * 根据主键删除对象信息，该处做的是逻辑删除
     * 
     * @param id
     *            主键字段
     * @return
     */
    boolean delete(Long id);

    /**
     * 根据主键获取对象信息
     * 
     * @param id
     *            主键字段
     * @return 对象信息
     */
    User getUserById(Long id);

    /**
     * 根据主键集合批量删除对象信息，该处做的是逻辑删除
     * 
     * @param ids
     *            主键集合
     * @return
     */
    boolean delete(String[] ids);

    /**
     * 根据登录账号获取用户信息
     * 
     * @param name
     * @return
     */
    User getUserByUsername(String name);

    /**
     * 获取登陆账号信息 去除邮箱后缀
     * 
     * @param name
     * @return
     */
    User getUserByNameTemp(String name);

    /**
     * 同步用户信息
     * 
     * @param users
     * @return
     */
    int syncUserDatas(List<User> users);
    
    int insertSyncUser(User user);
    
    /**
     * 提供代下单 查询 成本中心,组织
     * 
     * @param queryBean
     * @return
     */
    List<User> queryUserCost(UserQuery queryBean);
    
    /**
     * 根据员工ID获取用户信息
     * 
     * @param name
     * @return
     */
    User getUserByStaffId(Long staffId);
    
    /**
     * 根据ids查询用户列表信息
     * @param
     * @return
     */
    List<User> queryUsersByIds(String[] ids);
    
    /**
     * 获得所有用户信息
     * @param
     * @return
     */
    List<User> getAllUsers();
    
    /**
     * 查询可用的（角色未已配置的）用户信息
     * @param
     * @return
     */
    List<User> queryAvailableUserList(Long roleId);
    
    /**
     * 查询已配置该角色的用户信息
     * @param
     * @return
     */
    List<User> queryConfigedUserList(Long roleId);
}
