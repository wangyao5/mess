package com.letv.css.portal.manager;

import java.util.List;
import java.util.Map;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.query.DepQuery;

/**
 * User: gaohongjing Date: 2014-04-08 Time: 18:43:58
 */
public interface DepManager {

    /**
     * 批量增加对象信息
     * 
     * @param beanList
     * @return
     */
    boolean insert(List<Dep> beanList);

    /**
     * 单个增加对象信息
     * 
     * @param bean
     * @return
     */
    boolean insert(Dep bean);

    /**
     * 更新 对象信息
     * 
     * @param bean
     *            对象信息对象
     * @return false：失败 true：成功
     */
    boolean update(Dep bean);

    /**
     * 根据查询Bean获取对象集合，无翻页
     * 
     * @param queryBean
     * @return
     */
    List<Dep> queryDepList(DepQuery queryBean);

    /**
     * 根据查询Bean获取对象集合，带翻页
     * 
     * @param queryBean
     * @param pageUtil
     * @return
     */
    List<Dep> queryDepListWithPage(DepQuery queryBean, PageUtil pageUtil);

    /**
     * 根据查询Bean获取对象信息总数
     * 
     * @param queryBean
     *            对象信息查询对象
     * @return 对象信息总数
     */
    int queryDepCount(DepQuery queryBean);

    /**
     * 根据主键删除对象信息，该处做的是逻辑删除
     * 
     * @param id
     *            主键字段
     * @return
     */
    boolean delete(Long id);

    /**
     * 根据主键获取对象信息
     * 
     * @param id
     *            主键字段
     * @return 对象信息
     */
    Dep getDepById(Long id);
    
    /**
     * 根据主键获得对象信息集合
     * @param
     * @return
     */
    List<Dep> getDepListByIds(String ids);

    /**
     * 根据主键集合批量删除对象信息，该处做的是逻辑删除
     * 
     * @param ids
     *            主键集合
     * @return
     */
    boolean delete(String[] ids);
    
    /**
     * 根据父部门编号查询子部门编号集合
     * @param
     * @return
     */
    List<String> getChildrenCodByParentId(Long parentId);

    /**
    * 查询子部门树
    * @param
    * @return
    */
    List<Dep> queryTreeDepList(DepQuery query);
    
    
    /**
     * 给用户分配部门时，依据用户ID查询部门信息
     * @param
     * @return
     */
    List<Dep> queryDepTree(Long userId);
    
    /**
     * 计算该部门当前的在职和培训人数
     * @param
     * @return
     */
    Integer queryDepPersonQuantity(Long depId);
    
    /**
     * 计算该部门当前的在职和培训人数，包括本部门和下级部门
     * @param
     * @return
     */
    Map<Integer, Integer> queryDepPersonQuantityByCode(String code);
    
    /**
     * 根据部门-职场名称获得该部门-职场
     * @param
     * @return
     */
    Dep getDepByName(String name);
//    /**
//     * 同步部门信息
//     * 
//     * @param deps
//     * @return
//     */
//    int syncDepDatas(List<Dep> deps);

}
