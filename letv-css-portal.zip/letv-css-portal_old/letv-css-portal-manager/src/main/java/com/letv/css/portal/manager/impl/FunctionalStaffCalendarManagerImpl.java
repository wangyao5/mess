package com.letv.css.portal.manager.impl;

import java.util.List;

import com.letv.css.portal.domain.query.FunctionalStaffCalendarQuery;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.css.portal.dao.FunctionalStaffCalendarDao;
import com.letv.css.portal.domain.FunctionalStaffCalendar;
import com.letv.css.portal.manager.FunctionalStaffCalendarManager;

/**
 * 数据字典 manager实现类
 * @Author greg
 */
@Component
public class FunctionalStaffCalendarManagerImpl extends BaseManager implements FunctionalStaffCalendarManager {

	private final static Log LOG = LogFactory.getLog(FunctionalStaffCalendarManagerImpl.class);
	
	@Autowired
	private FunctionalStaffCalendarDao functionalStaffCalendarDao;
	

	@Override
	public boolean insert(FunctionalStaffCalendar functionalStaffCalendar) {
		return functionalStaffCalendarDao.insert(functionalStaffCalendar);
	}

	@Override
	public boolean update(FunctionalStaffCalendar functionalStaffCalendar) {
		boolean flag = false;
		if(null != functionalStaffCalendar){
			flag = functionalStaffCalendarDao.update(functionalStaffCalendar);
			if(!flag){
				throw new RuntimeException("单个表信息更新异常,ID:[" + functionalStaffCalendar.getId() + "]!");
			}
		}else{
			LOG.debug("FunctionalStaffCalendarManagerImpl!update(FunctionalStaffCalendar functionalStaffCalendar) Error,参数为空!");
            throw new RuntimeException("单个表信息更新时，表信息对象为NULL!");
		}
		return flag;
	}

	@Override
	public List<FunctionalStaffCalendar> queryList(FunctionalStaffCalendarQuery query) {
		return functionalStaffCalendarDao.queryList(query);
	}
	

}
