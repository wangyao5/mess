package com.letv.css.portal.manager.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.css.portal.dao.JsonDataDao;
import com.letv.css.portal.domain.JsonData;
import com.letv.css.portal.manager.JsonDataManager;
/**
 * 审批提交数据manager
 *
 * @Author menghan
 * @Version 2017-06-22 16:39:54
 */
@Component
public class JsonDataManagerImpl extends BaseManager implements JsonDataManager{

	@Autowired
	private JsonDataDao jsonDataDao;
	
	/**
	 * {@inheritDoc}
	 */
	public boolean insert(JsonData jsonData) {
		return jsonDataDao.insert(jsonData);
	}
	public JsonData getById(Long id){
		return jsonDataDao.getById(id);
	}

}
