package com.letv.css.portal.manager.impl;

import com.letv.css.portal.dao.ThresholdValueDao;
import com.letv.css.portal.domain.ThresholdValue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.css.portal.manager.ThresholdValueManager;

/**
 * @Author gexuliang
 */
@Component
public class ThresholdValueManagerImpl extends BaseManager implements ThresholdValueManager{

	private final static Log LOG = LogFactory.getLog(ThresholdValueManagerImpl.class);
	@Autowired
	private ThresholdValueDao thresholdValueDao;
	
	@Override
	public ThresholdValue getInfoByCode(String code) {
		ThresholdValue thresholdValue = null;
		if(code!= null && code.trim().equals("")){
			thresholdValue = thresholdValueDao.getInfoByCode(code);
		}
		return thresholdValue;
	}
	
	
	
}
