package com.letv.css.portal.manager;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.PreShifts;
import com.letv.css.portal.domain.query.PreShiftsQuery;

import java.util.List;

/**
 * yxh
 * 2017-08-29 11:58:33
 */
public interface PreShiftsManager {

    /**
     * 新增对象
     * 
     * @param bean
     * @return
     */
    boolean insert(PreShifts bean);
    /**
     * 批量新增对象
     *
     * @param beanList
     * @return
     */
    boolean insert(final List<PreShifts> beanList);

    /**
     * 更新对象
     * 
     * @param bean
     * @return
     */
    boolean update(PreShifts bean);
    

    /**
     * 根据查询Bean获取对象集合，不带翻页
     * 
     * @param queryBean
     * @return
     */
    List<PreShifts> queryPreShiftsList(PreShiftsQuery queryBean);

    /**
     * 根据查询Bean获取总数
     * 
     * @param queryBean
     * @return
     */
    int queryPreShiftsCount(PreShiftsQuery queryBean);
    
    /**
     * 根据查询Bean获取总数
     * 
     * @param queryBean
     * @return
     */
    int queryPreShiftsCount4Side(PreShiftsQuery queryBean);

    /**
     * 根据查询Bean获取集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<PreShifts> queryPreShiftsListWithPage(PreShiftsQuery queryBean, PageUtil pageUtil);

    /**
     * 根据查询Bean获取集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<PreShifts> queryPreShiftsListWithPage4Side(PreShiftsQuery queryBean, PageUtil pageUtil);
    

    /**
     * 根据主键删除记录
     * 
     * @param id
     * @return
     */
    boolean delete(Long id);

    /**
     * 批量根据主键删除记录
     *
     * @param ids
     * @return
     */
    boolean delete(final String[] ids);

    /**
     * 根据主键获取对象
     * 
     * @param id
     *            主键字段
     * @return
     */
    PreShifts getPreShiftsById(Long id);

}
