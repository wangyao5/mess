package com.letv.css.portal.manager.impl;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.common.utils.serialize.JsonHelper;
import com.letv.css.portal.dao.*;
import com.letv.css.portal.domain.ApprovalManage;
import com.letv.css.portal.domain.JsonData;
import com.letv.css.portal.domain.Schedule;
import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.domain.query.ScheduleDetailQuery;
import com.letv.css.portal.domain.query.ScheduleQuery;
import com.letv.css.portal.manager.ScheduleManager;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * BPO排班表导入manager实现类
 *
 * @Author yxh
 * @Version 2017-05-31 22:32:04
 */
@Component
public class ScheduleManagerImpl extends BaseManager implements ScheduleManager{

	private final static Log LOG = LogFactory.getLog(ScheduleManagerImpl.class);
	
	@Autowired
	private ScheduleDao scheduleDao;
	
	@Autowired
	private ScheduleDetailDao scheduleDetailDao;
	@Autowired
	private JsonDataDao jsonDataDao;
	@Autowired
	private CommonQueueDao commonQueueDao;
	@Autowired
	private ApprovalManageDao approvalManageDao;

	/**
	 * {@inheritDoc}
	 */
	public boolean insert(Schedule schedule) {
		return scheduleDao.insert(schedule);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean inserts(List<Schedule> schedules) {
//		boolean flag = false;
//		if(CollectionUtils.isNotEmpty(schedules)){
//			for(Schedule plan:schedules){
//				flag = scheduleDao.insert(plan);
//				if(!flag){
//					throw new RuntimeException("批量插入总班表导入记录失败");
//				}
//			}
//		}
		return scheduleDao.inserts(schedules);
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean update(Schedule bean){
		return scheduleDao.update(bean);
	}

	/**
	 * {@inheritDoc}
	 */
	public Schedule getScheduleById(Long id) {
		return scheduleDao.getScheduleById(id);
	}
	
	/**
	 * {@inheritDoc}
	 * greg
	 */
	public Schedule getScheduleBySpid(Long spid) {
		return scheduleDao.getScheduleBySpid(spid);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Schedule> queryScheduleListWithPage(ScheduleQuery query,PageUtil pageUtil) {
		if (null == query) {
			query = new ScheduleQuery();
		}

		// 查询总数
		int totalItem = scheduleDao.queryScheduleCount(query);

		if (pageUtil == null) {
			pageUtil = new PageUtil();
		}
		pageUtil.setTotalRow(totalItem);
		pageUtil.init();

		if (totalItem > 0) {
			query.setPageIndex(pageUtil.getCurPage());
			query.setPageSize(pageUtil.getPageSize());
			// 调用Dao翻页方法
			return scheduleDao.queryScheduleListWithPage(query);
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Schedule> queryScheduleList(ScheduleQuery query) {
		return scheduleDao.queryScheduleList(query);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean inserts(List<Schedule> schedules,
			List<ScheduleDetail> scheduleDetails) {
		boolean flag = false;
		int start = 0, end = 0, n = scheduleDetails.size();
		for(Schedule schedule:schedules){
			//先更新BPO排班表导入记录
			flag = scheduleDao.update(schedule);
			if(!flag){
				break;
			}
			for(int i=start;i<n;i++){
				ScheduleDetail detail = scheduleDetails.get(i);
				if(schedule.getDepId().intValue() == detail.getDepId().intValue()){
					detail.setsId(schedule.getId());
					end ++;
				}else{
					break;
				}
			}
			//先删除已经存在的班次班段数据
			scheduleDetailDao.deleteBySid(schedule.getId());
			//再插入BPO排班表明细记录
			flag = scheduleDetailDao.inserts(scheduleDetails.subList(start, end));
			if(!flag){
				break;
			}
			start = end;
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean addAutoScheduleFlow(String spId, String sId,Long userId,String userName) {
		boolean flag;
		//1.插入JSON工作流推送数据
		JsonData jsonData = new JsonData();
		jsonData.setType(8);
		Map<String, String> map = new HashMap<>();
		map.put("spId", spId);
		map.put("sId", sId);
		String data = JsonHelper.toJson(map);
		jsonData.setJsonData(data);
		jsonData.setCreateUser(userName);
		LOG.info("入参：" + JsonHelper.toJson(jsonData));
		flag=jsonDataDao.insert(jsonData);

		if(!flag){
			return false;
		}
		//2.插入工作流循环数据
		CommonQueue queue = new CommonQueue();
		queue.setOnlyId(jsonData.getId());
		queue.setOnlyType("jsonData id");
		queue.setEventId(EventConstants.EVENT_SCHEDULING);
		queue.setRequestRemake("排班审批申请");
		queue.setCreatedBy(String.valueOf(userId));
		flag=commonQueueDao.insert(queue);
		if(!flag){
			return false;
		}
		//3.插入工作流业务状态标记数据
		List<ApprovalManage> approvalManages = new ArrayList<ApprovalManage>();
		ApprovalManage manage = new ApprovalManage();
		manage.setSiId(Long.parseLong(sId));
		manage.setJdId(jsonData.getId());
		manage.setType(8);
		manage.setConfirm(0);
		manage.setCreateUser(userName);
		approvalManages.add(manage);
		flag=approvalManageDao.inserts(approvalManages);
		if(!flag){
			return false;
		}
		//4.更改排班任务状态-不可以修改
		Schedule schedule=new Schedule();
		schedule.setId(Long.parseLong(sId));
		schedule.setStatus(1);//已提交
		schedule.setUpdateUser(userName);
		flag=scheduleDao.update(schedule);
		return flag;
	}
}
