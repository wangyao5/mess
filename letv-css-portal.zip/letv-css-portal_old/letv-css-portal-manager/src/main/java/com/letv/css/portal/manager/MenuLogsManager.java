package com.letv.css.portal.manager;

import com.letv.css.portal.domain.MenuLogs;

/**
 * 菜单访问日志manager
 *
 * @Author menghan
 * @Version 2017-05-17 18:39:45
 */
public interface MenuLogsManager {

	public boolean addLog(MenuLogs menuLogs);
	
}
