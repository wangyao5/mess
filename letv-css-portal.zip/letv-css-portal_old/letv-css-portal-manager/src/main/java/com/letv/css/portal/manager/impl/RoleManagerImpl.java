package com.letv.css.portal.manager.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.RoleDao;
import com.letv.css.portal.domain.Role;
import com.letv.css.portal.domain.query.ResourceRoleQuery;
import com.letv.css.portal.domain.query.RoleQuery;
import com.letv.css.portal.domain.query.UserRoleQuery;
import com.letv.css.portal.manager.RoleManager;
import com.letv.css.portal.util.codegenerate.BusinessCodeGenerator;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-22 11:13:11
 */
@Component
public class RoleManagerImpl implements RoleManager{

	private final static Log log = LogFactory.getLog(RoleManagerImpl.class);
	@Autowired
	private RoleDao roleDao;

	/**
	 * {@inheritDoc}
	 */
	public boolean insert(final List<Role> beanList) {
		boolean resultFlag = true;
		if (null != beanList && beanList.size() > 0) {
			for (Role bean : beanList) {
				resultFlag = roleDao.insert(bean);
				if (!resultFlag) {
					throw new RuntimeException("批量新增表信息异常");
				}
			}
		}

		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean insert(Role bean) {
		boolean resultFlag = false;
		resultFlag = roleDao.insert(bean);
		if (resultFlag) {
			String code = BusinessCodeGenerator.getRoleCode(bean.getId());
			bean.setCode(code);
			resultFlag = roleDao.update(bean);
		} else {
			throw new RuntimeException("信息更新异常,ID:[" + bean.getId() + "]!");
		}
		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean update(final Role bean) {
		boolean resultFlag = true;
		if (null != bean) {
			resultFlag = roleDao.update(bean);
			if (!resultFlag) {
				throw new RuntimeException("单个表信息更新异常,ID:[" + bean.getId()
						+ "]!");
			}
		} else {
			log.debug("RoleManagerImpl!update(Role bean) Error,参数为空!");
			throw new RuntimeException("单个表信息更新时，表信息对象为NULL!");
		}

		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryRoleList(RoleQuery queryBean) {
		return roleDao.queryRoleList(queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryRoles(RoleQuery queryBean) {
		return roleDao.queryRoles(queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryRoleListWithPage(RoleQuery queryBean,
			PageUtil pageUtil) {
		if (null == queryBean) {
			queryBean = new RoleQuery();
		}

		// 查询总数
		int totalItem = queryRoleCount(queryBean);

		if (pageUtil == null) {
			pageUtil = new PageUtil();
		}
		pageUtil.setTotalRow(totalItem);
		pageUtil.init();

		if (totalItem > 0) {
			queryBean.setPageIndex(pageUtil.getCurPage());
			queryBean.setPageSize(pageUtil.getPageSize());
			// 调用Dao翻页方法
			return roleDao.queryRoleListWithPage(queryBean);
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public int queryRoleCount(RoleQuery queryBean) {
		return roleDao.queryRoleCount(queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean delete(Long id) {
		return roleDao.deleteRoleById(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public Role getRoleById(Long id) {
		return roleDao.getRoleById(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean delete(final String[] ids) {
		boolean resultFlag = true;
		if (null != ids && ids.length > 0) {
			for (int i = 0; i < ids.length; i++) {
				resultFlag = delete(Long.parseLong(ids[i]));
				if (!resultFlag) {
					throw new RuntimeException("批量删除表信息异常!");
				}
			}
		} else {
			log.error("ids param is null!");
		}

		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryConfigedRoleList(UserRoleQuery queryBean) {
		return roleDao.queryConfigedRoleList(queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryAvailableRoleList(UserRoleQuery queryBean) {
		return roleDao.queryAvailableRoleList(queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryResourceConfigedRoleList(ResourceRoleQuery query) {
		return roleDao.queryResourceConfigedRoleList(query);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryResourceAvailableRoleList(ResourceRoleQuery query) {
		return roleDao.queryResourceAvailableRoleList(query);
	}

}
