package com.letv.css.portal.manager;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Schedule;
import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.query.ScheduleQuery;

import java.util.List;

/**
 * BPO排班表导入manager
 *
 * @Author yxh
 * @Version 2017-05-31 22:25:30
 */
public interface ScheduleManager {

	/**
	 * 插入一条BPO排班表记录
	 * @param
	 * @return
	 */
	boolean insert(Schedule schedule);
	
	/**
	 * 批量插入BPO排班表记录
	 * @param
	 * @return
	 */
	boolean inserts(List<Schedule> schedules);
	/**
	 * 根据主键更新对象信息
	 *
	 * @param bean
	 *            对象信息对象
	 * @return Result 对象
	 */
	boolean update(Schedule bean);
	
	/**
	 * 根据id获得BPO排班表信息
	 * @param
	 * @return
	 */
	Schedule getScheduleById(Long id);
	
	/**
	 * 根据班表ID获取BPO排班表信息
	 * @param spid
	 * @return
	 */
	Schedule getScheduleBySpid(Long spid);
	
	/**
	 * 根据query查询BPO排班表信息，翻页
	 * @param
	 * @return
	 */
	List<Schedule> queryScheduleListWithPage(ScheduleQuery query, PageUtil pageUtil);
	
	/**
	 * 根据query查询BPO排班表信息，不翻页
	 * @param
	 * @return
	 */
	List<Schedule> queryScheduleList(ScheduleQuery query);
	
	/**
	 * 插入BPO排班表导入记录与BPO排班表明细
	 * @param schedules BPO排班表记录，scheduleDetails 总班表明细
	 * @return 同时插入成功返回true，否则返回false
	 */
	boolean inserts(List<Schedule> schedules, List<ScheduleDetail> scheduleDetails);

	/**
	 * 添加自动排班工作流
	 * @param spId
	 * @param sId
	 * @param userId
	 * @param userName
	 * @return
	 */
	boolean addAutoScheduleFlow(String spId, String sId,Long userId,String userName);
}
