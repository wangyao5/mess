package com.letv.css.portal.manager;

import com.letv.css.portal.domain.query.CommonQueue;

public interface CommonQueueManager {

    boolean insert(CommonQueue commonQueue);

}
