package com.letv.css.portal.manager.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.css.portal.dao.SchedulePlanDetailDao;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.query.SchedulePlanDetailQuery;
import com.letv.css.portal.manager.SchedulePlanDetailManager;

/**
 * 操作总班表明细manager
 *
 * @Author menghan
 * @Version 2017-05-24 17:30:57
 */
@Component
public class SchedulePlanDetailManagerImpl extends BaseManager implements SchedulePlanDetailManager {

	private final static Log LOG = LogFactory.getLog(SchedulePlanDetailManagerImpl.class);
	
	@Autowired
	private SchedulePlanDetailDao schedulePlanDetailDao;
	
	/**
	 * {@inheritDoc}
	 */
	public boolean insert(SchedulePlanDetail schedulePlanDetail) {
		return schedulePlanDetailDao.insert(schedulePlanDetail);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean inserts(List<SchedulePlanDetail> schedulePlanDetails) {
		boolean flag = false;
		int count = 1000;//一次批量插入数据过多，mybatis会报异常，所以分批次插入，每次1000条
		int n = schedulePlanDetails.size();//数据总数
		List<SchedulePlanDetail> list = null;
		
		int num = n/count;//一共要插入的次数
		int rest = n%count;//不足1000次的部分
		int i = 0;
		//循环插入
		for(i=0;i<num;i++){
			list = schedulePlanDetails.subList(i*count, (i+1)*count);
			flag = schedulePlanDetailDao.inserts(list);
		}
		//插入剩余的部分
		list = schedulePlanDetails.subList(i*count, i*count + rest);
		flag = schedulePlanDetailDao.inserts(list);
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<SchedulePlanDetail> querySchedulePlanDetailList(SchedulePlanDetailQuery query) {
		return schedulePlanDetailDao.querySchedulePlanDetailList(query); 
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean update(SchedulePlanDetail schedulePlanDetail) {
		return schedulePlanDetailDao.update(schedulePlanDetail);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean delete(Long id) {
		return schedulePlanDetailDao.delete(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean deletes(SchedulePlanDetailQuery query) {
		return schedulePlanDetailDao.deletes(query);
	}

}
