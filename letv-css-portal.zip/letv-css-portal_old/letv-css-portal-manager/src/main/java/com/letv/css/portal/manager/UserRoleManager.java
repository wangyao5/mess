package com.letv.css.portal.manager;

import java.util.List;

import com.letv.css.portal.domain.UserRole;
import com.letv.css.portal.domain.query.UserRoleQuery;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-22 11:24:36
 */
public interface UserRoleManager {

	/**
     * 批量增加对象信息
     * 
     * @param beanList
     * @return
     */
    boolean insert(List<UserRole> beanList);

    /**
     * 新增对象
     * 
     * @param bean
     * @return
     */
    boolean insert(UserRole bean);

    /**
     * 更新对象
     * 
     * @param bean
     * @return
     */
    boolean update(UserRole bean);

    /**
     * 根据查询Bean获取对象集合，不带翻页
     * 
     * @param queryBean
     * @return
     */
    List<UserRole> queryUserRoleList(UserRoleQuery queryBean);

    /**
     * 根据查询Bean获取总数
     * 
     * @param queryBean
     * @return
     */
    int queryUserRoleCount(UserRoleQuery queryBean);

    /**
     * 根据主键删除记录
     * 
     * @param id
     * @return
     */
    boolean delete(Long id);

    /**
     * 根据主键集合批量删除对象信息，该处做的是逻辑删除
     * 
     * @param ids
     *            主键集合
     * @return
     */
    boolean delete(String[] ids);

    /**
     * 根据主键获取对象
     * 
     * @param id
     *            主键字段
     * @return
     */
    UserRole getUserRoleById(Long id);

    /**
     * @param userId
     * @param roleIds
     * @param createUser
     * @return
     */
    boolean batchSave(Long userId, String[] roleIds, String createUser);

    /**
     * 根据roleId，批量存取user信息
     * @param
     * @return
     */
    public boolean batchSaveRoleUsers(Long roleId, String[] userIds, String createUser);
    
    /**
     * 批量分配用户角色
     * 
     * @param userIds
     * @param roleIds
     * @param createUser
     * @return
     */
    boolean batchSaves(String[] userIds, String[] roleIds, String createUser);
	
    /**
     * 根据角色ID查询拥有该角色的用户信息
     * @param
     * @return
     */
    List<UserRole> queryUsersByRoleId(Long roleId);
    
    /**
     * 根据角色ID，查询拥有该角色的用户信息，与queryUsersByRoleId区别，queryUsersByRoleId仅返回userId
     * @param
     * @return
     */
    List<UserRole> queryRoleUserList(UserRoleQuery query);
}
