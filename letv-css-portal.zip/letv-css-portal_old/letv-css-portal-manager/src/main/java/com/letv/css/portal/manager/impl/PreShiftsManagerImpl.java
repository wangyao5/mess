package com.letv.css.portal.manager.impl;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.PreShiftsDao;
import com.letv.css.portal.domain.PreShifts;
import com.letv.css.portal.domain.query.PreShiftsQuery;
import com.letv.css.portal.manager.PreShiftsManager;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * PreShifts: gaohongjing Date: 2014-04-08 Time: 18:43:58
 */
@Component
public class PreShiftsManagerImpl extends BaseManager implements PreShiftsManager {
    private final static Log log = LogFactory.getLog(PreShiftsManagerImpl.class);
    @Autowired
    private PreShiftsDao PreShiftsDao;

    public boolean insert(final List<PreShifts> beanList) {
        boolean resultFlag = true;
        if (null != beanList && beanList.size() > 0) {
            for (PreShifts bean : beanList) {
                resultFlag = PreShiftsDao.insert(bean);
                if (!resultFlag) {
                    throw new RuntimeException("批量新增表信息异常");
                }
            }
        }

        return resultFlag;
    }

    public boolean insert(PreShifts bean) {
        return PreShiftsDao.insert(bean);
    }

    public boolean update(final PreShifts bean) {
        boolean resultFlag = true;
        if (null != bean) {
            resultFlag = PreShiftsDao.update(bean);
            if (!resultFlag) {
                throw new RuntimeException("单个表信息更新异常,ID:[" + bean.getId() + "]!");
            }
        } else {
            log.debug("PreShiftsManagerImpl!update(PreShifts bean) Error,参数为空!");
            throw new RuntimeException("单个表信息更新时，表信息对象为NULL!");
        }

        return resultFlag;
    }


    public List<PreShifts> queryPreShiftsList(PreShiftsQuery queryBean) {
        return PreShiftsDao.queryPreShiftsList(queryBean);
    }
    

    public List<PreShifts> queryPreShiftsListWithPage(PreShiftsQuery queryBean, PageUtil pageUtil) {
        if (null == queryBean) {
            queryBean = new PreShiftsQuery();
        }

        // 查询总数
        int totalItem = queryPreShiftsCount(queryBean);

        if (pageUtil == null) {
            pageUtil = new PageUtil();
        }
        pageUtil.setTotalRow(totalItem);
        pageUtil.init();

        if (totalItem > 0) {
            queryBean.setPageIndex(pageUtil.getCurPage());
            queryBean.setPageSize(pageUtil.getPageSize());
            // 调用Dao翻页方法
            return PreShiftsDao.queryPreShiftsListWithPage(queryBean);
        }
        return null;
    }
    
    public List<PreShifts> queryPreShiftsListWithPage4Side(PreShiftsQuery queryBean, PageUtil pageUtil) {
        if (null == queryBean) {
            queryBean = new PreShiftsQuery();
        }

        // 查询总数
        int totalItem = queryPreShiftsCount4Side(queryBean);

        if (pageUtil == null) {
            pageUtil = new PageUtil();
        }
        pageUtil.setTotalRow(totalItem);
        pageUtil.init();

        if (totalItem > 0) {
            queryBean.setPageIndex(pageUtil.getCurPage());
            queryBean.setPageSize(pageUtil.getPageSize());
            // 调用Dao翻页方法
            return PreShiftsDao.queryPreShiftsListWithPage4Side(queryBean);
        }
        return null;
    }
    public int queryPreShiftsCount(PreShiftsQuery queryBean) {
        return PreShiftsDao.queryPreShiftsCount(queryBean);
    }

    @Override
    public int queryPreShiftsCount4Side(PreShiftsQuery queryBean) {
        return PreShiftsDao.queryPreShiftsCount4Side(queryBean);
    }

    public boolean delete(Long id) {
        return PreShiftsDao.delete(id);
    }

    public PreShifts getPreShiftsById(Long id) {
        return PreShiftsDao.getPreShiftsById(id);
    }

    public boolean delete(final String[] ids) {
        boolean resultFlag = true;
        if (null != ids && ids.length > 0) {
            for (int i = 0; i < ids.length; i++) {
                resultFlag = delete(Long.parseLong(ids[i]));
                if (!resultFlag) {
                    throw new RuntimeException("批量删除表信息异常!");
                }
            }
        } else {
            log.error("ids param is null!");
        }

        return resultFlag;
    }
}
