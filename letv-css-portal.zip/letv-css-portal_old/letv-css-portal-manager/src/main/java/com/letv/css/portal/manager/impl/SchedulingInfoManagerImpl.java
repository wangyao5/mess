package com.letv.css.portal.manager.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.SchedulingInfoDao;
import com.letv.css.portal.domain.SchedulingInfo;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;
import com.letv.css.portal.manager.SchedulingInfoManager;

/**
 * 排班信息表manager实现类
 *
 * @Author menghan
 * @Version 2017-06-21 11:30:16
 */
@Component
public class SchedulingInfoManagerImpl extends BaseManager implements SchedulingInfoManager {

	@Autowired
	private SchedulingInfoDao schedulingInfoDao;
	
	/**
	 * {@inheritDoc}
	 */
	public List<SchedulingInfo> querySchedulingInfoList(
			SchedulingInfoQuery queryBean) {
		return schedulingInfoDao.querySchedulingInfoList(queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<SchedulingInfo> querySchedulingInfoListWithPage(
			SchedulingInfoQuery queryBean,PageUtil pageUtil) {
		if (null == queryBean) {
			queryBean = new SchedulingInfoQuery();
		}

		// 查询总数
		int totalItem = querySchedulingInfoCount(queryBean);

		if (pageUtil == null) {
			pageUtil = new PageUtil();
		}
		pageUtil.setTotalRow(totalItem);
		pageUtil.init();

		if (totalItem > 0) {
			queryBean.setPageIndex(pageUtil.getCurPage());
			queryBean.setPageSize(pageUtil.getPageSize());
			// 调用Dao翻页方法
			return schedulingInfoDao.querySchedulingInfoListWithPage(queryBean);
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public int querySchedulingInfoCount(SchedulingInfoQuery queryBean) {
		return schedulingInfoDao.querySchedulingInfoCount(queryBean);
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean updateByApplyFlow(SchedulingInfoQuery queryBean){
		return schedulingInfoDao.updateByApplyFlow(queryBean);
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean update(SchedulingInfoQuery queryBean){
		return schedulingInfoDao.update(queryBean);
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean updateAdjInfo(SchedulingInfoQuery queryBean){
		boolean flag=false;
		if(queryBean != null && StringUtils.isNotBlank(queryBean.getIds())) {
			String[] siIdAttr = queryBean.getIds().split(",");
			for (String siId:siIdAttr) {
				queryBean.setId(Long.parseLong(siId));
				flag=schedulingInfoDao.update(queryBean);
			}
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean insert(SchedulingInfo sInfoEntity){
		return schedulingInfoDao.insert(sInfoEntity);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<SchedulingInfo> querySchedulingInfoByTime(
			SchedulingInfo schedulingInfo) {
		return schedulingInfoDao.querySchedulingInfoByTime(schedulingInfo);
	}

	/**
	 * {@inheritDoc}
	 */
	public SchedulingInfo getSchedulingInfoById(Long id) {
		return schedulingInfoDao.getSchedulingInfoById(id);
	}
}
