package com.letv.css.portal.manager;

import com.letv.css.portal.domain.DepBusiness;

import java.util.List;

public interface DepBusinessManager {
    List<DepBusiness> queryByDepId(Long depId);

    boolean insert(DepBusiness depBusiness);

    boolean update(DepBusiness depBusiness);

}
