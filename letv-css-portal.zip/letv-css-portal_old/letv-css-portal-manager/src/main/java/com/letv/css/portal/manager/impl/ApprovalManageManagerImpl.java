package com.letv.css.portal.manager.impl;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.DateHelper;
import com.letv.css.portal.dao.ApprovalManageDao;
import com.letv.css.portal.dao.SchedulingInfoDao;
import com.letv.css.portal.dao.ShiftsPeriodDao;
import com.letv.css.portal.domain.ApprovalManage;
import com.letv.css.portal.domain.SchedulingInfo;
import com.letv.css.portal.domain.ShiftsPeriod;
import com.letv.css.portal.domain.query.ApprovalManageQuery;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;
import com.letv.css.portal.manager.ApprovalManageManager;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 审批管理manager实现类
 *
 * @Author menghan
 * @Version 2017-06-22 17:43:16
 */
@Component
public class ApprovalManageManagerImpl extends BaseManager implements ApprovalManageManager{

	@Autowired
	private ApprovalManageDao approvalManageDao;

	@Autowired
	private SchedulingInfoDao schedulingInfoDao;

	@Autowired
	private ShiftsPeriodDao shiftsPeriodDao;
	/**
	 * {@inheritDoc}
	 */
	public boolean insert(ApprovalManage approvalManage) {
		return approvalManageDao.insert(approvalManage);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean update(ApprovalManage approvalManage) {
		return approvalManageDao.update(approvalManage);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean inserts(List<ApprovalManage> approvalManages) {
		return approvalManageDao.inserts(approvalManages);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<ApprovalManage> queryAppManageList(Long jdId){
		return approvalManageDao.queryAppManageList(jdId);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean updateConfirmBySiId(String siId){
		return approvalManageDao.updateConfirmBySiId(siId);
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean updateFinishByJdId(String siId){
		return approvalManageDao.updateFinishByJdId(siId);
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean updateApplyShift(String siIds,String shiftSiId,Long userId) {
		boolean flag=false;
		SchedulingInfo siIdsInfo;
		SchedulingInfo shiftSiIdInfo;
		if(StringUtils.isNotBlank(siIds) && StringUtils.isNotBlank(shiftSiId)){

			flag=approvalManageDao.updateConfirmBySiId(siIds);
			if(flag){
				SchedulingInfoQuery queryBean=new SchedulingInfoQuery();
				queryBean.setId(Long.parseLong(siIds));
				List<SchedulingInfo> siIdsListInfo=schedulingInfoDao.querySchedulingInfoList(queryBean);
				if(siIdsListInfo.size()>0){
					 siIdsInfo=siIdsListInfo.get(0);
				}else{
					throw new NullPointerException("排班信息不存在！ID【" + siIds + "】");
				}

				queryBean=new SchedulingInfoQuery();
				queryBean.setId(Long.parseLong(shiftSiId));
				List<SchedulingInfo> shiftSiIdListInfo=schedulingInfoDao.querySchedulingInfoList(queryBean);
				if(shiftSiIdListInfo.size()>0){
					shiftSiIdInfo=shiftSiIdListInfo.get(0);
				}else{
					throw new NullPointerException("排班信息不存在！ID【" + shiftSiId + "】");
				}
				queryBean=new SchedulingInfoQuery();
				queryBean.setUpdateUser(userId.toString());
				if(flag){
					queryBean.setId(Long.parseLong(siIds));
					queryBean.setSpId(shiftSiIdInfo.getSpId());
					queryBean.setDepId(shiftSiIdInfo.getDepId());
					queryBean.setStaffId(shiftSiIdInfo.getStaffId());
					queryBean.setCsId(shiftSiIdInfo.getCsId());
					queryBean.setPlanDate(DateHelper.formatDateTime(shiftSiIdInfo.getPlanDate()));
					queryBean.setRemark(userId+"进行了班次交互，交互班次为"+ shiftSiId);
					flag=schedulingInfoDao.update(queryBean);
				}
				if(flag){
					queryBean=new SchedulingInfoQuery();
					queryBean.setUpdateUser(userId.toString());
					queryBean.setId(Long.parseLong(shiftSiId));
					queryBean.setSpId(siIdsInfo.getSpId());
					queryBean.setDepId(siIdsInfo.getDepId());
					queryBean.setStaffId(siIdsInfo.getStaffId());
					queryBean.setCsId(siIdsInfo.getCsId());
					queryBean.setPlanDate(DateHelper.formatDateTime(siIdsInfo.getPlanDate()));
					queryBean.setRemark(userId+"进行了班次交互，交互班次为"+ siIds);
					flag=schedulingInfoDao.update(queryBean);
				}
			}
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean initSchedulAndApproval(Map<String,String> paramMap){
		boolean flag = false;
		ShiftsPeriod sPeriod=null;
		List<ApprovalManage> approvalManages = new ArrayList<>();

		if(StringUtils.isNotBlank(paramMap.get("shiftsPeriod"))){
			sPeriod=shiftsPeriodDao.getShiftsPeriodById(Long.parseLong(paramMap.get("shiftsPeriod")));
		}

		if(sPeriod !=null){
			String[] siIdAttr = paramMap.get("siIds").split(",");
			Date plantDate= DateHelper.parseDate(paramMap.get("adjustTime").substring(0,paramMap.get("adjustTime").indexOf(" ")) + " 00:00:00");
			for (String sid:siIdAttr) {
				String[] sidAttr = sid.split("\\$");
				SchedulingInfo sInfoEntity=new SchedulingInfo();
				sInfoEntity.setDepId(Long.parseLong(sidAttr[2]));
				sInfoEntity.setStaffId(Long.parseLong(sidAttr[0]));
				sInfoEntity.setCsId(sidAttr[3]);
				sInfoEntity.setBusId(Long.parseLong(paramMap.get("business")));
				sInfoEntity.setBusName(paramMap.get("businessName"));
				sInfoEntity.setPlanDate(plantDate);
				sInfoEntity.setShiftsId(Long.parseLong(paramMap.get("shifts")));
				sInfoEntity.setPeriodId(Long.parseLong(paramMap.get("shiftsPeriod")));
				sInfoEntity.setBeginTime(sPeriod.getBeginTime());
				sInfoEntity.setEndTime(sPeriod.getEndTime());
				sInfoEntity.setMealStandard(sPeriod.getMealStandard());
				sInfoEntity.setCreateUser(paramMap.get("userName"));
				sInfoEntity.setRemark(paramMap.get("remark").length()>30?paramMap.get("remark").substring(0,30)+"增加":paramMap.get("remark")+"增加");
				sInfoEntity.setYn(0);//初始为未生效数据
				schedulingInfoDao.insert(sInfoEntity);
				// 2.装填人员待确认记录
				ApprovalManage manage = new ApprovalManage();
				manage.setSiId(sInfoEntity.getId());
				manage.setJdId(Long.parseLong(paramMap.get("outId")));
				manage.setType(4);
				manage.setConfirm(0);
				manage.setCreateUser(paramMap.get("userName"));
				approvalManages.add(manage);
			}
		}
		//生成人员待确认记录
		flag=approvalManageDao.inserts(approvalManages);
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	public Integer queryAppManageCount(ApprovalManageQuery approvalManageQuery) {
		return  approvalManageDao.queryAppManageCount(approvalManageQuery);
	}
	/**
	 * {@inheritDoc}
	 */
	public Integer queryValidCount(ApprovalManageQuery approvalManageQuery) {
		return  approvalManageDao.queryValidCount(approvalManageQuery);
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean updateByJdId(String jdId){
		return approvalManageDao.updateByJdId(jdId);
	}
}
