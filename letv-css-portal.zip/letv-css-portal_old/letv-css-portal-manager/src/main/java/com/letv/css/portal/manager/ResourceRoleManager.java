package com.letv.css.portal.manager;

import com.letv.css.portal.domain.ResourceRole;
import com.letv.css.portal.domain.query.ResourceRoleQuery;

import java.util.List;

/**
 * 资源和角色的绑定关系 Manager接口
 *
 * @Author menghan
 * @Version 2017-01-22 11:51:44
 */
public interface ResourceRoleManager {
    /**
     * 修改资源和角色的绑定关系： 1.删除原来的关系；2.新增新的关系
     * 
     * @param oldResourceRole
     *            原来的关系
     * @param newResourceRoles
     *            新的关系
     * @return
     */
    boolean update(ResourceRole oldResourceRole, List<ResourceRole> newResourceRoles);

    /**
     * 根据角色获取已经分配的资源列表
     * 
     * @param roleId
     * @return
     */
    List<ResourceRole> queryResourceRoleList(Long roleId);

    /**
     * 根据角色ID集合查询拥有资源列表
     * 
     * @param resourceRoleQuery
     *            #roleIds
     */
    public List<ResourceRole> queryResourceListByRoleIds(ResourceRoleQuery resourceRoleQuery);
}
