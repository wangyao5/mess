package com.letv.css.portal.manager;

import java.util.List;

import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.domain.query.UserDepQuery;

/**
 * 用户和部门（数据权限）关系 manager接口
 *
 * @Author menghan
 * @Version 2017-01-22 16:21:23
 */
public interface UserDepManager {
	
	/**
     * 新增部门和用户关系
     * 
     * @param userDep
     * @return
     */
    boolean insert(UserDep userDep);

	/**
     * 修改资源和角色的绑定关系： 1.删除原来的关系；2.新增新的关系
     * 
     * @param oldUserDep
     *            原来的关系
     * @param newUserDeps
     *            新的关系
     * @return
     */
    boolean update(UserDep oldUserDep, List<UserDep> newUserDeps, long loginId);

    /**
     * 根据用户获取已经分配的部门列表
     * 
     * @param roleId
     * @return
     */
    List<UserDep> queryUserDepList(Long userId);

    /**
     * 根据用户Id集合查询拥有部门列表
     * 
     * @param userDepQuery
     *            #userIds
     */
    public List<UserDep> queryDepListByUserIds(UserDepQuery userDepQuery);
    
    /**
     * 根据部门ID，获得所有拥护该部门权限的用户
     * @param
     * @return
     */
    List<UserDep> queryUsersByDepId(Long depId);
	
}
