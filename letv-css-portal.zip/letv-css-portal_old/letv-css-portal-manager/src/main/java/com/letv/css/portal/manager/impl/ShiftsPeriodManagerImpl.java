package com.letv.css.portal.manager.impl;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.ShiftsPeriodDao;
import com.letv.css.portal.domain.ShiftsPeriod;
import com.letv.css.portal.domain.query.ShiftsPeriodQuery;
import com.letv.css.portal.manager.ShiftsPeriodManager;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by yangxinghe on 2017/5/16.
 */
@Component
public class ShiftsPeriodManagerImpl extends BaseManager implements ShiftsPeriodManager {
    private final static Log log = LogFactory.getLog(ShiftsPeriodManagerImpl.class);
    @Autowired
    private ShiftsPeriodDao shiftsPeriodDao;

    /**
     * {@inheritDoc}
     */
    public List<ShiftsPeriod> queryShiftsPeriodList(ShiftsPeriodQuery queryBean) {
        return this.shiftsPeriodDao.queryShiftsPeriodList(queryBean);
    }

    /**
     * {@inheritDoc}
     */
    public List<ShiftsPeriod> queryShiftsPeriodListWithPage(ShiftsPeriodQuery queryBean, PageUtil pageUtil) {
        if (null == queryBean) {
            queryBean = new ShiftsPeriodQuery();
        }

        // 查询总数
        int totalItem = this.shiftsPeriodDao.queryShiftsPeriodCount(queryBean);

        if (pageUtil == null) {
            pageUtil = new PageUtil();
        }
        pageUtil.setTotalRow(totalItem);
        pageUtil.init();

        if (totalItem > 0) {
            queryBean.setPageIndex(pageUtil.getCurPage());
            queryBean.setPageSize(pageUtil.getPageSize());
            // 调用Dao翻页方法
            return shiftsPeriodDao.queryShiftsPeriodListWithPage(queryBean);
        }
        return null;

    }

    /**
     * {@inheritDoc}
     */
    public int queryShiftsPeriodCount(ShiftsPeriodQuery queryBean) {
        return this.shiftsPeriodDao.queryShiftsPeriodCount(queryBean);
    }

    /**
     * {@inheritDoc}
     */
    public boolean insert(ShiftsPeriod bean) {
        return this.shiftsPeriodDao.insert(bean);
    }

    /**
     * {@inheritDoc}
     */
    public boolean update(final ShiftsPeriod bean) {
        boolean resultFlag = true;
        if (null != bean) {
            resultFlag = shiftsPeriodDao.update(bean);
            if (!resultFlag) {
                throw new RuntimeException("单个表信息更新异常,ID:[" + bean.getId() + "]!");
            }
        } else {
            log.debug("ShiftsPeriodManagerImpl!update(ShiftsPeriod bean) Error,参数为空!");
            throw new RuntimeException("单个表信息更新时，表信息对象为NULL!");
        }

        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    public boolean delete(Long id) {
        return this.shiftsPeriodDao.deleteShiftsPeriodById(id);
    }

    /**
     * {@inheritDoc}
     */
    public ShiftsPeriod getShiftsPeriodById(Long id) {
        return this.shiftsPeriodDao.getShiftsPeriodById(id);
    }

    /*
    *  批量更新状态
     */
    public boolean updateStatus(String[] ids,int status ,String updateUser){
        boolean resultFlag=false;

        ShiftsPeriod shiftsPeriod=new ShiftsPeriod();
        //设置更新状态
        shiftsPeriod.setYn(status);
        //设置更新人
        shiftsPeriod.setUpdateUser(updateUser);
        for (int i = 0; i < ids.length; i++) {
            shiftsPeriod.setId(Long.parseLong(ids[i]));
            resultFlag=this.shiftsPeriodDao.update(shiftsPeriod);
            if (!resultFlag) {
                throw new RuntimeException("批量更新班段状态信息异常");
            }
        }
        return resultFlag;
    }
}
