package com.letv.css.portal.manager.impl;

import java.util.Date;
import java.util.List;

import com.letv.common.utils.wrap.WrapMapper;
import com.letv.common.utils.wrap.Wrapper;
import com.letv.css.portal.dao.AdjustChangeDao;
import com.letv.css.portal.dao.CommonQueueDao;
import com.letv.css.portal.domain.AdjustChange;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.StaffDao;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.domain.query.StaffQuery;
import com.letv.css.portal.manager.StaffManager;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-06 16:55:08
 */
@Component
public class StaffManagerImpl extends BaseManager implements StaffManager{

	private final static Log LOG = LogFactory.getLog(StaffManagerImpl.class);
	@Autowired
	private StaffDao staffDao;
	@Autowired
	private CommonQueueDao commonQueueDao;
	@Autowired
	private AdjustChangeDao adjustChangeDao;
	@Override
	public boolean jobChange(Staff staff, long userId, int changeType){
		//原部门岗位
		Staff oldStaff = staffDao.getStaffById(staff.getId());

		//插入中间表
		AdjustChange change = new AdjustChange();
		if(changeType == 0){
			change.setChangeDate(staff.getStructAdjustDate());
			change.setReason(staff.getStructAdjustReason());
		}else {
			change.setChangeDate(staff.getJobTitleAdjustmentDate());
			change.setReason(staff.getJobTitleAdjustmentReason());
		}
		change.setNewDepartment(staff.getDepId());
		change.setOldDepartment(oldStaff.getDep().getId());
		change.setNewPost(staff.getJobTitle());
		change.setOldPost(oldStaff.getJobTitle());
		change.setStaffId(staff.getId());
		change.setChangeType(changeType);
		change.setOldService(oldStaff.getService());
		change.setNewService(staff.getService());
		adjustChangeDao.insert(change);
		//插入commonQueue,同步工作流
		CommonQueue queue = new CommonQueue();
		queue.setOnlyId(change.getId());
		queue.setOnlyType("adjustChange id");
		queue.setEventId(EventConstants.EVENT_ORGANIZATION);
		queue.setRequestRemake("部门岗位调整流程");
		queue.setCreatedBy(userId + "");
		//审核前不修改部门信息
		staff.setDepId(oldStaff.getDep().getId());
		staff.setJobTitle(oldStaff.getJobTitle());
		staff.setService(oldStaff.getService());
		//修改部门调整信息
		staffDao.update(staff);


		boolean resultFlag = commonQueueDao.insert(queue);
		return resultFlag;
	}
	 
	@Override
	public boolean insert(Staff bean) {
		return staffDao.insert(bean);
	}

	@Override
	public boolean update(Staff bean) {
		boolean resultFlag = true;
        if (null != bean) {
            resultFlag = staffDao.update(bean);
            if (!resultFlag) {
                throw new RuntimeException("单个表信息更新异常,ID:[" + bean.getId() + "]!");
            }
        } else {
            LOG.debug("DepManagerImpl!update(Dep bean) Error,参数为空!");
            throw new RuntimeException("单个表信息更新时，表信息对象为NULL!");
        }
        return resultFlag;
	}

	@Override
	public List<Staff> queryStaffList(StaffQuery queryBean) {
		return staffDao.queryStaffList(queryBean);
	}

	@Override
	public List<Staff> queryStaffListWithPage(StaffQuery queryBean,
			PageUtil pageUtil) {
		if (null == queryBean) {
			queryBean = new StaffQuery();
		}
		// 查询总数
		int totalItem = queryStaffCount(queryBean);
		if (pageUtil == null) {
			pageUtil = new PageUtil();
		}
		pageUtil.setTotalRow(totalItem);
		pageUtil.init();
		if (totalItem > 0) {
			queryBean.setPageIndex(pageUtil.getCurPage());
			queryBean.setPageSize(pageUtil.getPageSize());
			// 调用Dao翻页方法
			return staffDao.queryStaffListWithPage(queryBean);
		}
		return null;
	}

	@Override
	public int queryStaffCount(StaffQuery queryBean) {
		return staffDao.queryStaffCount(queryBean);
	}

	@Override
	public boolean delete(Long id) {
		return staffDao.deleteStaffById(id);
	}

	@Override
	public Staff getStaffById(Long id) {
		return staffDao.getStaffById(id);
	}

	@Override
	public boolean online(Staff staff) {
		boolean resultFlag = true;
        if (null != staff) {
            resultFlag = staffDao.online(staff);
            if (!resultFlag) {
                throw new RuntimeException("单个表信息更新异常,ID:[" + staff.getId() + "]!");
            }
        } else {
            LOG.debug("DepManagerImpl!update(Dep bean) Error,参数为空!");
            throw new RuntimeException("单个表信息更新时，表信息对象为NULL!");
        }
        return resultFlag;
	}

	@Override
	public Staff getStaffByCsId(String csId) {
		return staffDao.getStaffByCsId(csId);
	}

	@Override
	public Staff getStaffByLeAccount(String leAccount) {
		return staffDao.getStaffByLeAccount(leAccount);
	}

	@Override
	public Staff getStaffByEmployeeNum(String employeeNum) {
		return staffDao.getStaffByEmployeeNum(employeeNum);
	}

	@Override
	public Long getStaffId(String name) {
		return staffDao.getStaffId(name);
	}
    @Override
    public  boolean updateSuperiorByDepId(Staff staff){
        return  staffDao.updateSuperiorByDepId(staff);
    }
}
