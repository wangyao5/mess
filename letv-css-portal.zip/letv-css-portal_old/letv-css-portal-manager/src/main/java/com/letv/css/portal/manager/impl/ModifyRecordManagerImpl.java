package com.letv.css.portal.manager.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.ModifyRecordDao;
import com.letv.css.portal.domain.ModifyRecord;
import com.letv.css.portal.domain.query.ModifyRecordQuery;
import com.letv.css.portal.manager.ModifyRecordManager;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-14 11:57:47
 */
@Component
public class ModifyRecordManagerImpl extends BaseManager implements ModifyRecordManager{

	private static final Log LOG = LogFactory.getLog(ModifyRecordManagerImpl.class);
	
	@Autowired
	private ModifyRecordDao modifyRecordDao;
	
	/**
	 * {@inheritDoc}
	 */
	public ModifyRecord getModifyRecordById(Long id) {
		return modifyRecordDao.getModifyRecordById(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean insert(ModifyRecord modifyRecord) {
		return modifyRecordDao.insert(modifyRecord);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean deleteModifyRecordById(Long id) {
		return modifyRecordDao.deleteModifyRecordById(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public int queryModifyRecordCount(ModifyRecordQuery bean) {
		return modifyRecordDao.queryModifyRecordCount(bean);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<ModifyRecord> queryModifyRecordListWithPage(ModifyRecordQuery bean,PageUtil pageUtil) {
		if(null == bean){
			bean = new ModifyRecordQuery();
		}
		//查询总数
		int total = queryModifyRecordCount(bean);
		
		if(pageUtil == null){
			pageUtil = new PageUtil();
		}
		pageUtil.setTotalRow(total);
		pageUtil.init();
		if (total > 0) {
			bean.setPageIndex(pageUtil.getCurPage());
			bean.setPageSize(pageUtil.getPageSize());
			// 调用Dao翻页方法
			return modifyRecordDao.queryModifyRecordListWithPage(bean);
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<ModifyRecord> queryEntryFlow(ModifyRecordQuery bean) {
		return modifyRecordDao.queryEntryFlow(bean);
	}

}
