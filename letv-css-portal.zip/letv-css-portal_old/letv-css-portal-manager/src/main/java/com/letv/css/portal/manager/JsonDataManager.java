package com.letv.css.portal.manager;

import com.letv.css.portal.domain.JsonData;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-06-22 16:38:36
 */
public interface JsonDataManager {

	/**
	 * 插入一条审批提交的数据
	 * @param
	 * @return
	 */
	boolean insert(JsonData jsonData);
	/**
	 * 根据ID查询实体
	 * @param id
	 * @return
	 */
	JsonData getById(Long id);

}
