package com.letv.css.portal.manager;

import java.util.List;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.SchedulePlan;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.query.SchedulePlanQuery;

/**
 * 总班表导入manager
 *
 * @Author menghan
 * @Version 2017-05-24 13:50:24
 */
public interface SchedulePlanManager {

	/**
	 * 插入一条总班表记录
	 * @param
	 * @return
	 */
	boolean insert(SchedulePlan schedulePlan);
	
	/**
	 * 批量插入总班表记录
	 * @param
	 * @return
	 */
	boolean inserts(List<SchedulePlan> schedulePlans);
	
	/**
	 * 根据id获得总班表信息
	 * @param
	 * @return
	 */
	SchedulePlan getSchedulePlanById(Long id);
	
	/**
	 * 根据query查询总班表信息，翻页
	 * @param
	 * @return
	 */
	List<SchedulePlan> querySchedulePlanListWithPage(SchedulePlanQuery query,PageUtil pageUtil);
	
	/**
	 * 根据query查询总班表信息，不翻页
	 * @param
	 * @return
	 */
	List<SchedulePlan> querySchedulePlanList(SchedulePlanQuery query);
	
	/**
	 * 插入总班表导入记录与总班表明细
	 * @param schedulePlans 总班表记录，schedulePlanDetails 总班表明细
	 * @return 同时插入成功返回true，否则返回false
	 */
	boolean inserts(List<SchedulePlan> schedulePlans, List<SchedulePlanDetail> schedulePlanDetails);
}
