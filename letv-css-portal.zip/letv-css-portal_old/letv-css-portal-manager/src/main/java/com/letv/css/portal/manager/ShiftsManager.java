package com.letv.css.portal.manager;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Shifts;
import com.letv.css.portal.domain.query.ShiftsQuery;

import java.util.List;

/**
 * Created by yangxinghe on 2017/5/16.
 */
public interface ShiftsManager {
    /**
     * 根据查询参数查询班次信息集合
     * @param
     * @return
     */
    List<Shifts> queryShiftsList(ShiftsQuery queryBean);
    
    /**
     * 根据查询参数查询班次信息集合 按照最小开始时间排序
     * @param queryBean
     * @return
     */
    List<Shifts> queryShiftsListByMinBeginTime(ShiftsQuery queryBean);
    
    /**
     * 根据查询参数查询班次信息集合
     * @param
     * @return
     */
    List<Shifts> queryOptionShiftsList(ShiftsQuery queryBean);
    /**
     * 根据查询参数查询班次信息集合
     * @param
     * @return
     */
    List<Shifts> queryShiftsListWithPage(ShiftsQuery queryBean, PageUtil pageUtil);
    /**
     * 根据查询Bean获取对象信息总数
     *
     * @param queryBean
     *            对象信息查询对象
     * @return 对象信息总数
     */
    int queryShiftsCount(ShiftsQuery queryBean);

    /**
     * 新增对象
     *
     * @param bean
     * @return
     */
    boolean insert(Shifts bean);

    /**
     * 更新对象
     *
     * @param bean
     * @return
     */
    boolean update(Shifts bean);


    /**
     * 根据主键删除记录
     *
     * @param id
     * @return
     */
    boolean delete(Long id);

    /**
     * 根据主键获取对象
     *
     * @param id 主键字段
     * @return
     */
    Shifts getShiftsById(Long id);

    /**
     * 根据名称查询班次
     * @param shiftsName
     * @return
     */
    Shifts getShiftsByName(String shiftsName);
    /*
    *  班次批量更新状态
     */
    boolean updateStatus(String[] ids,int status,String updateUser);
}
