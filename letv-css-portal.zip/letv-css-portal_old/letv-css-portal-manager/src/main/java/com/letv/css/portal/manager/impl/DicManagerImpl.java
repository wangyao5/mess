package com.letv.css.portal.manager.impl;

import java.util.List;

import com.letv.css.portal.domain.DepBusiness;
import com.letv.css.portal.domain.query.DicBusinessQuery;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.letv.common.manager.BaseManager;
import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.dao.DicDao;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.manager.DicManager;

/**
 * 数据字典 manager实现类
 *
 * @Author menghan
 * @Version 2017-02-14 20:38:09
 */
@Component
public class DicManagerImpl extends BaseManager implements DicManager {

	private final static Log LOG = LogFactory.getLog(DicManagerImpl.class);
	
	@Autowired
	private DicDao dicDao;
	
	/**
	 * {@inheritDoc}
	 */
	public boolean insert(Dic dic) {
		return dicDao.insert(dic);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean update(Dic dic) {
		boolean flag = false;
		if(null != dic){
			flag = dicDao.update(dic);
			if(!flag){
				throw new RuntimeException("单个表信息更新异常,ID:[" + dic.getId() + "]!");
			}
		}else{
			LOG.debug("DicManagerImpl!update(Dic dic) Error,参数为空!");
            throw new RuntimeException("单个表信息更新时，表信息对象为NULL!");
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean deleteById(Long id) {
		return dicDao.deleteById(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public Dic getDicById(Long id) {
		return dicDao.getDicById(id);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Dic> queryDicList(DicQuery query) {
		return dicDao.queryDicList(query);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Dic> queryDicListWithPage(DicQuery query, PageUtil pageUtil) {
		if(null == query){
			query = new DicQuery();
		}
		//查询总数
		int total = queryDicCount(query);
		if (pageUtil == null) {
			pageUtil = new PageUtil();
		}
		pageUtil.setTotalRow(total);
		pageUtil.init();

		if (total > 0) {
			query.setPageIndex(pageUtil.getCurPage());
			query.setPageSize(pageUtil.getPageSize());
			// 调用Dao翻页方法
			return dicDao.queryDicListWithPage(query);
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public Integer queryDicCount(DicQuery query) {
		return dicDao.queryDicCount(query);
	}

	/**
	 * {@inheritDoc}
	 */
	public Long getDicNum(Long parentId) {
		return dicDao.getDicNum(parentId);
	}

	@Override
	public List<Dic> queryDicListById(DicBusinessQuery businessQuery) {
		return dicDao.queryDicListById(businessQuery);
	}

	@Override
	public Dic getDicByNum(Long parentNum, Long num) {
		return dicDao.getDicByNum(parentNum, num);
	}
}
