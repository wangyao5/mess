package com.letv.css.portal.manager.impl;

import com.letv.common.manager.BaseManager;
import com.letv.css.portal.dao.DepBusinessDao;
import com.letv.css.portal.domain.DepBusiness;
import com.letv.css.portal.manager.DepBusinessManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DepBusinessManagerImpl extends BaseManager implements DepBusinessManager {

    @Autowired
    private DepBusinessDao depBusinessDao;

    @Override
    public List<DepBusiness> queryByDepId(Long depId) {
        return depBusinessDao.queryByDepId(depId);
    }

    @Override
    public boolean insert(DepBusiness depBusiness) {
        return depBusinessDao.insert(depBusiness);
    }

    @Override
    public boolean update(DepBusiness depBusiness) {
        return depBusinessDao.update(depBusiness);
    }
}
