package com.letv.css.portal.manager.impl;

import com.letv.common.manager.BaseManager;
import com.letv.css.portal.dao.ScheduleDetailDao;
import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.query.ScheduleDetailQuery;
import com.letv.css.portal.manager.ScheduleDetailManager;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 操作BPO排班表明细manager
 *
 * @Author yxh
 * @Version 2017-06-01 17:51:39
 */
@Component
public class ScheduleDetailManagerImpl extends BaseManager implements ScheduleDetailManager {

	private final static Log LOG = LogFactory.getLog(ScheduleDetailManagerImpl.class);
	
	@Autowired
	private ScheduleDetailDao scheduleDetailDao;
	
	/**
	 * {@inheritDoc}
	 */
	public boolean insert(ScheduleDetail scheduleDetail) {
		return scheduleDetailDao.insert(scheduleDetail);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean inserts(List<ScheduleDetail> scheduleDetails) {
		boolean flag = false;
		int count = 1000;//一次批量插入数据过多，mybatis会报异常，所以分批次插入，每次1000条
		int n = scheduleDetails.size();//数据总数
		List<ScheduleDetail> list = null;
		
		int num = n/count;//一共要插入的次数
		int rest = n%count;//不足1000次的部分
		int i = 0;
		//循环插入
		for(i=0;i<num;i++){
			list = scheduleDetails.subList(i*count, (i+1)*count);
			flag = scheduleDetailDao.inserts(list);
		}
		//插入剩余的部分
		list = scheduleDetails.subList(i*count, i*count + rest);
		flag = scheduleDetailDao.inserts(list);
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<ScheduleDetail> queryScheduleDetailList(ScheduleDetailQuery query) {
		return scheduleDetailDao.queryScheduleDetailList(query);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean update(ScheduleDetail scheduleDetail) {
		return scheduleDetailDao.update(scheduleDetail);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean delete(Long id) {
		return scheduleDetailDao.delete(id);
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean deleteBySDetail(List<ScheduleDetail> scheduleDetails) {
		return scheduleDetailDao.updateYnBySDetail(scheduleDetails);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean deletes(ScheduleDetailQuery query) {
		return scheduleDetailDao.deletes(query);
	}
	
	/**
	 * {@inheritDoc}
	 */
	public boolean deleteBySid(Long sid){
		return scheduleDetailDao.deleteBySid(sid);
	}
	
}
