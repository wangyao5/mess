package com.letv.css.portal.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.domain.ResourceRole;
import com.letv.css.portal.manager.ResourceRoleManager;
import com.letv.css.portal.service.ResourceRoleService;

/**
 * 资源和角色关系Service实现类
 *
 * @Author menghan
 * @Version 2017-01-22 11:54:06
 */
@Service
public class ResourceRoleServiceImpl implements ResourceRoleService {
    private final static Log log = LogFactory.getLog(ResourceRoleServiceImpl.class);
    @Autowired
    private ResourceRoleManager resourceRoleManager;

    public List<ResourceRole> queryResourceRoleList(Long roleId) {
        List<ResourceRole> resourceRoleList = null;
        try {
            resourceRoleList = resourceRoleManager.queryResourceRoleList(roleId);
        } catch (Exception e) {
            log.error("ResourceRoleServiceImpl -> queryResourceRoleList() error!!", e);
        }
        return resourceRoleList;
    }

    /**
     * {@inheritDoc}
     */
    public boolean update(ResourceRole oldResourceRole, List<ResourceRole> newResourceRoles) {
        boolean resultFlag = false;
        try {
            if (null != oldResourceRole && (null != oldResourceRole.getRoleId() || null != oldResourceRole.getResId())) {
                resultFlag = this.resourceRoleManager.update(oldResourceRole, newResourceRoles);
            } else {
                log.warn("ResourceRoleServiceImpl.update has Illegal params.");
            }
        } catch (Exception e) {
            log.error("ResourceRoleServiceImpl.update has error,", e);
        }
        return resultFlag;
    }
}
