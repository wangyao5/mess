package com.letv.css.portal.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

import com.letv.common.utils.DateHelper;
import com.letv.css.portal.domain.SchedulingInfo;
import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;
import com.letv.css.portal.manager.UserDepManager;
import com.letv.css.portal.service.SchedulingInfoService;

import com.sun.org.apache.xpath.internal.operations.Bool;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.query.StaffQuery;
import com.letv.css.portal.manager.StaffManager;
import com.letv.css.portal.service.StaffService;

/**
 * 员工信息操作 实现类
 *
 * @Author menghan
 * @Version 2017-01-06 17:02:58
 */
@Service
public class StaffServiceImpl implements StaffService{

	private final static Log LOG = LogFactory.getLog(UserServiceImpl.class);

	@Autowired
	private StaffManager staffManager;
	@Autowired
	private UserDepManager userDepManager;
	@Autowired
	private SchedulingInfoService schedulingInfoService;

	@Profiled(tag = "StaffService.insert")
	public boolean insert(Staff bean) {
		boolean flag = false;
		try {
			if(null!=bean){
				flag = staffManager.insert(bean);
			}else{
				LOG.error("param is null!");
			}
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> insert(Staff bean) error", e);
		}
		return flag;
	}
	@Profiled(tag = "StaffService.jobChange")
	public boolean jobChange(Staff staff, long userId, int changeType) {
		boolean flag = false;
		try {
			flag = staffManager.jobChange(staff, userId, changeType);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> update() error", e);
		}
		return flag;
	}

	@Profiled(tag = "StaffService.update")
	public boolean update(Staff bean) {
		boolean flag = false;
		try {
			flag = staffManager.update(bean);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> update() error", e);
		}
		return flag;
	}

	@Profiled(tag = "StaffService.queryStaffList")
	public List<Staff> queryStaffList(StaffQuery queryBean) {
		List<Staff> staffList = null;
		try {
			staffList = staffManager.queryStaffList(queryBean);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> queryStaffList() error", e);
		}
		return staffList;
	}

	@Profiled(tag = "StaffService.queryStaffListWithPage")
	public List<Staff> queryStaffListWithPage(StaffQuery queryBean,
			PageUtil pageUtil) {
		List<Staff> staffList = null;
		try {
			staffList = staffManager.queryStaffListWithPage(queryBean,pageUtil);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> queryStaffListWithPage() error", e);
		}
		return staffList;
	}

	@Profiled(tag = "StaffService.queryStaffCount")
	public int queryStaffCount(StaffQuery queryBean) {
		int total = 0;
		try {
			total = staffManager.queryStaffCount(queryBean);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> queryStaffCount() error", e);
		}
		return total;
	}

	@Profiled(tag = "StaffService.delete")
	public boolean delete(Long id) {
		boolean flag = false;
		try {
			flag = staffManager.delete(id);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> delete() error", e);
		}
		return flag;
	}

	@Profiled(tag = "StaffService.getStaffById")
	public Staff getStaffById(Long id) {
		Staff staff = null;
		try {
			staff = staffManager.getStaffById(id);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> getStaffById() error", e);
		}
		return staff;
	}

	@Profiled(tag = "StaffService.online")
	public boolean online(Staff staff) {
		boolean flag = false;
		try {
			flag = staffManager.online(staff);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> online() error", e);
		}
		return flag;
	}

	@Profiled(tag = "StaffService.getStaffByCsId")
	public Staff getStaffByCsId(String csId) {
		Staff staff = null;
		try {
			staff = staffManager.getStaffByCsId(csId);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> getStaffByCsId() error", e);
		}
		return staff;
	}

	@Profiled(tag = "StaffService.getStaffByLeAccount")
	public Staff getStaffByLeAccount(String leAccount) {
		Staff staff = null;
		try {
			staff = staffManager.getStaffByLeAccount(leAccount);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> getStaffByLeAccount() error", e);
		}
		return staff;
	}

	@Profiled(tag = "StaffService.getStaffByEmployeeNum")
	public Staff getStaffByEmployeeNum(String employeeNum) {
		Staff staff = null;
		try {
			staff = staffManager.getStaffByEmployeeNum(employeeNum);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> getStaffByEmployeeNum() error", e);
		}
		return staff;
	}

	@Profiled(tag = "StaffService.getStaffId")
	public Long getStaffId(String name) {
		Long id = 0L;
		try {
			id = staffManager.getStaffId(name);
		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> getStaffId() error", e);
		}
		return id;
	}

	@Profiled(tag = "StaffService.getOvertimeStaff")
	public List<Staff> getOvertimeStaff(StaffQuery queryBean,Long userId) {
		//防止异常
		CopyOnWriteArrayList<Staff> staffWRList=null;
		try {
			if(queryBean != null) {
				//查询可见部门
				List<UserDep> userDeps = userDepManager.queryUserDepList(userId);
				if (userDeps == null) {
					return null;
				}
				//查询可见部门人
				List<Staff> staffList = staffManager.queryStaffList(queryBean);
				if (staffList == null) {
					return null;
				}
				staffWRList = new CopyOnWriteArrayList(staffList.toArray());

				//去除 已经编码的人
				SchedulingInfoQuery schedulingInfoQuery =new SchedulingInfoQuery();
				schedulingInfoQuery.setPlanDate(DateHelper.format(queryBean.getAdjustTime(),"yyyy-MM-dd HH:mm:ss"));
				List<SchedulingInfo> sInfoList =schedulingInfoService.querySchedulingInfoList(schedulingInfoQuery);

				for (Staff staff : staffWRList) {
					Boolean flag = false;
					//去除无操作权限的人
					for (UserDep ud : userDeps) {
						if (Objects.equals(ud.getDepId() , staff.getDepId())) {
							flag = true;
							break;
						}
					}
					//去除已经排班的人
					for (SchedulingInfo sInfo : sInfoList) {
						if (Objects.equals(sInfo.getStaffId(),staff.getId())) {
							flag = true;
							break;
						}
					}
					if (flag) {
						staffWRList.remove(staff);
					}
				}
			}

		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> getOvertimeStaff() error", e);
		}
		return staffWRList;
	}
	@Profiled(tag = "StaffService.getPreShiftsStaff")
	public List<Staff> getPreShiftsStaff(StaffQuery queryBean,Long userId) {
		//防止异常
		CopyOnWriteArrayList<Staff> staffWRList=null;
		try {
			if(queryBean != null) {
				//查询可见部门
				List<UserDep> userDeps = userDepManager.queryUserDepList(userId);
				if (userDeps == null) {
					return null;
				}
				//查询可见部门人
				List<Staff> staffList = staffManager.queryStaffList(queryBean);
				if (staffList == null) {
					return null;
				}
				staffWRList = new CopyOnWriteArrayList(staffList.toArray());

				for (Staff staff : staffWRList) {
					Boolean flag = false;
					//去除无操作权限的人
					for (UserDep ud : userDeps) {
						if (Objects.equals(ud.getDepId() , staff.getDepId())) {
							flag = true;
							break;
						}
					}
					if (flag) {
						staffWRList.remove(staff);
					}
				}
			}

		} catch (Exception e) {
			LOG.error("StaffServiceImpl -> getPreShiftsStaff() error", e);
		}
		return staffWRList;
	}


    /**
     *   //修改部门负责人时 将部门本层级坐席的组长更新为当前部门的负责人
     * @param staff
     * @return
     */
    @Profiled(tag = "StaffService.updateSuperiorByDepId")
    public boolean updateSuperiorByDepId(Staff staff) {
        Boolean returnFlag =false;
        try {
            if(staff != null) {
                return  this.staffManager.updateSuperiorByDepId(staff);
            }
        } catch (Exception e) {
            LOG.error("StaffServiceImpl -> getPreShiftsStaff() error", e);
        }
        return returnFlag;
    }
}
