package com.letv.css.portal.service;

import java.util.Map;

/**
 * 单点登录服务接口
 * 
 * @author lijianzhong
 * 
 */
public interface SSOService {

    /**
     * 用户账号密码验证
     * 
     * @param name
     * @param password
     * @return
     */
    boolean checkUser(String name, String password);
    
    /**
     * 依据账号查询详细信息
     * 
     * @param username
     * @return
     */
    Map<String, Object> queryUser(String username);

    /**
     * 加密
     * 
     * @param value
     * @return
     */
    String encode(String value);

    /**
     * 解密
     * 
     * @param value
     * @return
     */
    String decode(String value);
}
