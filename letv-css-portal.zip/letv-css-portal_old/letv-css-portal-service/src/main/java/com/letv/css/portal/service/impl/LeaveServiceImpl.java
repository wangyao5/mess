package com.letv.css.portal.service.impl;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Leave;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.query.StaffQuery;
import com.letv.css.portal.manager.LeaveManager;
import com.letv.css.portal.manager.StaffManager;
import com.letv.css.portal.service.LeaveService;
import com.letv.css.portal.service.StaffService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * 员工请假操作 实现类
 *
 * @Author menghan
 * @Version 2017-01-06 17:02:58
 */
@Service
public class LeaveServiceImpl implements LeaveService {

	private final static Log LOG = LogFactory.getLog(UserServiceImpl.class);

	@Autowired
	private LeaveManager leaveManager;

	@Profiled(tag = "LeaveService.addLeave")
	public boolean addLeave(Leave bean) {
		boolean flag = false;
		try {
			if(null!=bean){
				flag = leaveManager.addLeave(bean);
			}else{
				LOG.error("param is null!");
			}
		} catch (Exception e) {
			LOG.error("LeaveServiceImpl -> addLeave(Leave bean) error", e);
		}
		return flag;
	}

	@Override
	public Leave getLeaveById(Long id) {
		return leaveManager.getLeaveById(id);
	}

	@Override
	public boolean updateStatus(Leave bean) {
		return leaveManager.updateStatus(bean);
	}

	@Override
	public List<Leave> queryRepeatedLeave(Long staffId, Date leaveStartTime, Date leaveEndTime) {
		return leaveManager.queryRepeatedLeave( staffId, leaveStartTime, leaveEndTime );
	}
}
