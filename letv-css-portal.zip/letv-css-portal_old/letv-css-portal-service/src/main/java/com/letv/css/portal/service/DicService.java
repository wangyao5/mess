package com.letv.css.portal.service;

import java.util.List;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.DepBusiness;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.query.DicBusinessQuery;
import com.letv.css.portal.domain.query.DicQuery;

/**
 * 数据字典 service接口
 *
 * @Author menghan
 * @Version 2017-02-14 20:49:12
 */
public interface DicService {
	/**
	 * 新增
	 * @param
	 * @return
	 */
	boolean insert(Dic dic);
	
	/**
	 * 更新
	 * @param
	 * @return
	 */
	boolean update(Dic dic);
	
	/**
	 * 根据ID删除
	 * @param
	 * @return
	 */
	boolean deleteById(Long id);
	
	/**
	 * 根据ID获得Dic实体
	 * @param
	 * @return
	 */
	Dic getDicById(Long id);
	
	/**
	 * 根据query，获得Dic实体集合，不分页
	 * @param
	 * @return
	 */
	List<Dic> queryDicList(DicQuery query);
	
	/**
	 * 根据query，获得Dic实体集合，分页
	 * @param
	 * @return
	 */
	List<Dic> queryDicListWithPage(DicQuery query, PageUtil pageUtil);

	List<Dic> queryDicListById(DicBusinessQuery businessQuery);

	Dic getDicByNum(Long parentNum, Long num);

}
