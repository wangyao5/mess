package com.letv.css.portal.service.impl;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Shifts;
import com.letv.css.portal.domain.query.ShiftsQuery;
import com.letv.css.portal.manager.ShiftsManager;
import com.letv.css.portal.service.ShiftsService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by yangxinghe on 2017/5/16.
 */
@Service
public class ShiftsServiceImpl implements ShiftsService {
    private final static Log log = LogFactory.getLog(ShiftsServiceImpl.class);
    @Autowired
    private ShiftsManager shiftsManager;

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.queryShiftsList")
    public List<Shifts> queryShiftsList(ShiftsQuery query) {
        List<Shifts> shiftsList = null;
        try {
            if (query != null) {
                shiftsList = shiftsManager.queryShiftsList(query);
            } else {
                log.error("ShiftsServiceImpl!queryShiftsList(ShiftsQuery query) param:" + query + "is null");
            }
        } catch (Exception e) {
            log.error("ShiftsServiceImpl!queryShiftsList(ShiftsQuery query) error!", e);
        }
        return shiftsList;
    }
    
    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.queryShiftsListByMinBeginTime")
    public List<Shifts> queryShiftsListByMinBeginTime(ShiftsQuery query) {
        List<Shifts> shiftsList = null;
        try {
            if (query != null) {
                shiftsList = shiftsManager.queryShiftsListByMinBeginTime(query);
            } else {
                log.error("ShiftsServiceImpl!queryShiftsListByMinBeginTime(ShiftsQuery query) param:" + query + "is null");
            }
        } catch (Exception e) {
            log.error("ShiftsServiceImpl!queryShiftsListByMinBeginTime(ShiftsQuery query) error!", e);
        }
        return shiftsList;
    }
    
    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.queryOptionShiftsList")
    public List<Shifts> queryOptionShiftsList(ShiftsQuery query) {
        List<Shifts> shiftsList = null;
        try {
            if (query != null) {
                shiftsList = shiftsManager.queryOptionShiftsList(query);
            } else {
                log.error("ShiftsServiceImpl!queryShiftsList(ShiftsQuery query) param:" + query + "is null");
            }
        } catch (Exception e) {
            log.error("ShiftsServiceImpl!queryShiftsList(ShiftsQuery query) error!", e);
        }
        return shiftsList;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.queryShiftsListWithPage")
    public List<Shifts> queryShiftsListWithPage(ShiftsQuery query, PageUtil pageUtil) {
        List<Shifts> shiftsList = null;
        try {
            if (query != null) {
                shiftsList = shiftsManager.queryShiftsListWithPage(query, pageUtil);
            } else {
                log.error("ShiftsServiceImpl!queryShiftsList(ShiftsQuery query) param:" + query + "is null");
            }
        } catch (Exception e) {
            log.error("ShiftsServiceImpl!queryShiftsList(ShiftsQuery query) error!", e);
        }
        return shiftsList;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.insert")
    public boolean insert(Shifts bean) {
        {
            boolean resultFlag = false;
            try {
                if (null != bean) {
                    resultFlag = shiftsManager.insert(bean);
                } else {
                    log.error("param is null!");
                }
            } catch (Exception e) {
                log.error("ShiftsServiceImpl!insert(Shifts bean) error!", e);
            }
            return resultFlag;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.update")
    public boolean update(Shifts bean) {
        boolean resultFlag = false;
        try {
            resultFlag = shiftsManager.update(bean);
        } catch (Exception e) {
            log.error("ShiftsServiceImpl!update(Shifts bean) error!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.delete")
    public boolean delete(Long id) {
        boolean resultFlag = false;
        try {
            if (null != id && id.intValue() > 0) {
                resultFlag = shiftsManager.delete(id);
            } else {
                log.error("ShiftsServiceImpl!delete(Long id) param: " + id + " Illegal!");
            }
        } catch (Exception e) {
            log.error("ShiftsServiceImpl!delete(Integer id) error!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.getShiftsById")
    public Shifts getShiftsById(Long id) {
        Shifts shifts = null;
        try {
            shifts = shiftsManager.getShiftsById(id);
        } catch (Exception e) {
            log.error("UserServiceImpl!getUserById(Integer id) error!", e);
        }
        return shifts;
    }
    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.getShiftsByName")
    public Shifts getShiftsByName(String shiftsName) {
        Shifts shifts = null;
        try {
            shifts = shiftsManager.getShiftsByName(shiftsName);
        } catch (Exception e) {
            log.error("UserServiceImpl!getShiftsByName(String shiftsName) error!", e);
        }
        return shifts;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.updateStatus")
    public boolean updateStatus(String idBoxs, String status,String updateUser) {
        boolean flag = false;
        try {
            if (idBoxs != null && !"".equals(idBoxs)) {
                String[] ids = idBoxs.split(",");
                if (status != null && !"".equals(status)) {
                    int statusInt = Integer.parseInt(status);
                    flag = shiftsManager.updateStatus(ids, statusInt,updateUser);
                }
            }
        } catch (Exception e) {
            log.error("ShiftsServiceImpl!updateStatus(String idBoxs, String status) error!", e);
        }
        return flag;
    }
    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsServiceImpl.getShiftsId")
    public Long getShiftsId(String shiftsName) {
        if (shiftsName != null && !"".equals(shiftsName)) {
            Shifts shifts = getShiftsByName(shiftsName);
            if (shifts != null)
                return shifts.getId();
            return -1L;
        }
        return null;
    }

}
