package com.letv.css.portal.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.letv.css.portal.domain.query.ApprovalManageQuery;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;
import com.letv.css.portal.service.SchedulingInfoService;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.domain.ApprovalManage;
import com.letv.css.portal.manager.ApprovalManageManager;
import com.letv.css.portal.service.ApprovalManageService;

/**
 * 审批管理service实现类
 *
 * @Author menghan
 * @Version 2017-06-22 17:45:22
 */
@Service
public class ApprovalManageServiceImpl implements ApprovalManageService{

	private static final Log LOG = LogFactory.getLog(ApprovalManageServiceImpl.class);
	
	@Autowired
	private ApprovalManageManager approvalManageManager;
	@Autowired
	private SchedulingInfoService schedulingInfoService;
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.insert")
	public boolean insert(ApprovalManage approvalManage) {
		boolean flag = false;
		try {
			if(approvalManage!=null){
				flag = approvalManageManager.insert(approvalManage);
			}else{
				LOG.error("ApprovalManageServiceImpl.insert(ApprovalManage approvalManage) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.insert(ApprovalManage approvalManage) error,"+e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.inserts")
	public boolean inserts(List<ApprovalManage> approvalManages) {
		boolean flag = false;
		try {
			if(approvalManages!=null){
				flag = approvalManageManager.inserts(approvalManages);
			}else{
				LOG.error("ApprovalManageServiceImpl.inserts(List<ApprovalManage> approvalManages) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.inserts(List<ApprovalManage> approvalManages) error,"+e);
		}
		return flag;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.update")
	public boolean update(ApprovalManage approvalManage) {
		boolean flag = false;
		try {
			if(approvalManage!=null){
				flag = approvalManageManager.update(approvalManage);
			}else{
				LOG.error("ApprovalManageServiceImpl.update(ApprovalManage approvalManage) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.update(ApprovalManage approvalManage) error,"+e);
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.queryAppManageList")
	public List<ApprovalManage> queryAppManageList(Long jdId) {
		List<ApprovalManage> approvalManageList = null;
		try {
			if(jdId!=null){
				approvalManageList = approvalManageManager.queryAppManageList(jdId);
			}else{
				LOG.error("DepServiceImpl!queryDepList(DepQuery query) param:" + jdId + "is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl!queryAppManageList(ApprovalManage query) error!", e);
		}
		return approvalManageList;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.updateConfirmBySiId")
	public boolean updateConfirmBySiId(String siId) {
		boolean flag = false;
		try {
			if(siId!=null){
				flag = approvalManageManager.updateConfirmBySiId(siId);
			}else{
				LOG.error("ApprovalManageServiceImpl.updateConfirmBySiId(String siId) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.updateConfirmBySiId(String siId) error,"+e);
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.updateFinishByJdId")
	public boolean updateFinishByJdId(String siId) {
		boolean flag = false;
		try {
			if(siId!=null){
				flag = approvalManageManager.updateFinishByJdId(siId);
			}else{
				LOG.error("ApprovalManageServiceImpl.updateFinishByJdId(String siId) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.updateFinishByJdId(String siId) error,"+e);
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.applyShiftsAdjust")
	public boolean applyShiftsAdjust(String siIds,String  adjustType,int adjustTime,Long userId) {
		boolean flag = false;
		Integer adjBeginTime=null;
		Integer adjEndTime=null;
		boolean isDel=false;
		String reMark=userId+"进行班次调整";
		try {
			if(StringUtils.isNotBlank(siIds)){

				if ("提前上班".equals(adjustType)) {//开始时间-调整时间
					adjBeginTime = -adjustTime;
					reMark = reMark + "-提前上班" + adjustTime + "min";
				} else if ("延迟上班".equals(adjustType)) {//开始时间+调整时间
					adjBeginTime = adjustTime;
					reMark = reMark + "-延迟上班" + adjustTime + "min";
				} else if ("提前下班".equals(adjustType)) {//结束时间-调整时间
					adjEndTime = -adjustTime;
					reMark = reMark + "-提前下班" + adjustTime + "min";
				} else if ("延迟下班".equals(adjustType)) {////结束时间+调整时间
					adjEndTime = adjustTime;
					reMark = reMark + "-延迟下班" + adjustTime + "min";
				} else if ("放休".equals(adjustType)) {//标记删除
					isDel = true;
					reMark = reMark + "-放休删除";
				} else {
					LOG.error("ApprovalManageServiceImpl.applyShiftsAdjust(String siId) param is error");
					return false;
				}
				//执行更新操作
				SchedulingInfoQuery queryBean=new SchedulingInfoQuery();
				queryBean.setAdjBeginTime(adjBeginTime);
				queryBean.setAdjEndTime(adjEndTime);
				if(isDel){
					queryBean.setYn(0);
				}
				queryBean.setUpdateUser(userId.toString());
				queryBean.setRemark(reMark);
				queryBean.setIds(siIds);
				schedulingInfoService.updateAdjInfo(queryBean);
			}else{
				LOG.error("ApprovalManageServiceImpl.applyShiftsAdjust(String siId) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.applyShiftsAdjust(String siId) error,"+e);
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.applyTempLeaveAdjust")
	public boolean applyTempLeaveAdjust(String siIds,String tempLeaveType,String  timeType,int adjustTime,Long userId) {
		boolean flag = false;
		Integer adjBeginTime=null;
		Integer adjEndTime=null;
		String reMark=userId+"进行临时请假,原因："+ tempLeaveType;
		try {
			if(StringUtils.isNotBlank(siIds)){

				if ("早走".equals(timeType)) {//结束时间-调整时间
					adjEndTime = -adjustTime;
					reMark = reMark + "-早走" + adjustTime + "min";
				} else if ("晚到".equals(timeType)) {//开始时间+调整时间
					adjBeginTime = adjustTime;
					reMark = reMark + "-晚到" + adjustTime + "min";
				} else {
					LOG.error("ApprovalManageServiceImpl.applyTempLeaveAdjust(String siIds,String tempLeaveType,String  timeType,int adjustTime,Long userId) param is error");
					return false;
				}
				//执行更新操作
				SchedulingInfoQuery queryBean=new SchedulingInfoQuery();
				queryBean.setAdjBeginTime(adjBeginTime);
				queryBean.setAdjEndTime(adjEndTime);
				queryBean.setUpdateUser(userId.toString());
				queryBean.setRemark(reMark);
				queryBean.setIds(siIds);
				schedulingInfoService.updateAdjInfo(queryBean);
			}else{
				LOG.error("ApprovalManageServiceImpl.applyTempLeaveAdjust(String siIds,String tempLeaveType,String  timeType,int adjustTime,Long userId) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.applyTempLeaveAdjust(String siIds,String tempLeaveType,String  timeType,int adjustTime,Long userId) error,"+e);
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "ApprovalManageServiceImpl.updateApplyShift")
	public boolean updateApplyShift(String siIds, String shiftSiId, Long userId) {
		boolean flag = false;
		try {
			if (StringUtils.isNotBlank(siIds) && StringUtils.isNotBlank(shiftSiId)) {

				flag = approvalManageManager.updateApplyShift(siIds, shiftSiId, userId);

			} else {
				LOG.error("ApprovalManageServiceImpl.updateApplyShift(String siIds,String shiftSiId,Long userId) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.updateApplyShift(String siIds,String shiftSiId,Long userId) error," + e);
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "ApprovalManageServiceImpl.initSchedulAndApproval")
	public boolean initSchedulAndApproval(Map<String,String> paramMap) {
		boolean flag = false;
		try {
			if (!paramMap.isEmpty()&&StringUtils.isNotBlank(paramMap.get("siIds"))) {

				flag = approvalManageManager.initSchedulAndApproval(paramMap);

			} else {
				LOG.error("ApprovalManageServiceImpl.initSchedulAndApproval(Map<String,String> paramMap) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.initSchedulAndApproval(Map<String,String> paramMap) error," + e);
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.queryAppManageCount")
	public Integer queryAppManageCount(ApprovalManageQuery approvalManageQuery) {
		Integer count = 0;
		try {
			if(approvalManageQuery!=null &&StringUtils.isNotEmpty(approvalManageQuery.getSiIds())){
				count = approvalManageManager.queryAppManageCount(approvalManageQuery);
			}else{
				LOG.error("ApprovalManageServiceImpl.queryAppManageCount(ApprovalManageQuery approvalManageQuery) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.queryAppManageCount(ApprovalManageQuery approvalManageQuery) error,"+e);
		}
		return count;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.queryValidCount")
	public Integer queryValidCount(ApprovalManageQuery approvalManageQuery) {
		Integer count = 0;
		try {
			if(approvalManageQuery!=null &&StringUtils.isNotEmpty(approvalManageQuery.getSiIds())){
				count = approvalManageManager.queryValidCount(approvalManageQuery);
			}else{
				LOG.error("ApprovalManageServiceImpl.queryValidCount(ApprovalManageQuery approvalManageQuery) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.queryValidCount(ApprovalManageQuery approvalManageQuery) error,"+e);
		}
		return count;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="ApprovalManageServiceImpl.updateByJdId")
	public boolean updateByJdId(String jdId) {
		boolean flag = false;
		try {
			if(jdId!=null){
				flag = approvalManageManager.updateByJdId(jdId);
			}else{
				LOG.error("ApprovalManageServiceImpl.updateByJdId(String jdId) param is null");
			}
		} catch (Exception e) {
			LOG.error("ApprovalManageServiceImpl.updateByJdId(String jdId) error,"+e);
		}
		return flag;
	}
}