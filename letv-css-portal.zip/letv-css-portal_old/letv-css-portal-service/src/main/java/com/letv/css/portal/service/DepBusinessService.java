package com.letv.css.portal.service;

import com.letv.css.portal.domain.DepBusiness;

import java.util.List;

public interface DepBusinessService {

    List<DepBusiness> queryByDepId(Long depId);

    boolean insert(DepBusiness depBusiness);

    boolean update(DepBusiness depBusiness);
}
