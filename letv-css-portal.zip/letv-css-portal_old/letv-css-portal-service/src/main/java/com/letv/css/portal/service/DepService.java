package com.letv.css.portal.service;

import java.util.List;
import java.util.Map;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.query.DepQuery;

/**
 * 部门信息接口类
 *
 * @Author menghan
 * @Version 2017-01-13 10:09:12
 */
public interface DepService {

	/**
	 * 增加部门信息
	 * @param
	 * @return
	 */
	boolean insert(Dep dep);
	
	/**
	 * 修改部门信息
	 * @param
	 * @return
	 */
	boolean update(Dep dep);
	
	/**
	 * 根据主键，删除部门信息
	 * @param
	 * @return
	 */
	boolean delete(Long id);
	
	/**
	 * 根据主键，获得部门信息
	 * @param
	 * @return
	 */
	Dep getDepById(Long id);
	
	/**
	 * 根据多个主键，获得部门信息集合
	 * @param
	 * @return
	 */
	List<Dep> getDepListByIds(String ids);
	
	/**
	 * 根据查询参数查询部门信息集合
	 * @param
	 * @return
	 */
	List<Dep> queryDepList(DepQuery query);
	
	/**
	 * 根据查询参数查询部门信息集合
	 * @param
	 * @return
	 */
	List<Dep> queryDepListWithPage(DepQuery query,PageUtil pageUtil);
	
	/***
	 * 根号父部门编号查询子部门编码集合
	 * @param
	 * @return
	 */
	List<String> getChildrenCodByParentId(Long parentId);
	
	/**
    * 查询子部门树
    * @param
    * @return
    */
	List<Dep> queryTreeDepList(DepQuery query);
	
	/**
     * 给用户分配部门时，依据用户ID查询部门信息
     * @param
     * @return
     */
    List<Dep> queryDepTree(Long userId);
    
    /**
     * 计算该部门当前的在职和培训人数
     * @param
     * @return
     */
    Integer queryDepPersonQuantity(Long depId);
    
    /**
     * 计算该部门当前的在职和培训人数，包括本部门和下级部门
     * @param
     * @return
     */
	Map<Integer, Integer> queryDepPersonQuantityByCode(String code);
	
	/**
     * 根据部门-职场名称获得该部门-职场
     * @param
     * @return
     */
    Dep getDepByName(String name);
}
