package com.letv.css.portal.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.domain.Resource;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.dto.MenuDto;
import com.letv.css.portal.domain.dto.SubMenuDto;
import com.letv.css.portal.domain.dto.SystemMenuDto;
import com.letv.css.portal.manager.MenuManager;
import com.letv.css.portal.service.MenuService;

/**
 * 系统菜单服务实现类：提供登录用户的菜单（资源）查询服务
 *
 * @Author menghan
 * @Version 2017-01-22 14:17:02
 */
@Service
public class MenuServiceImpl implements MenuService {

    private final static Log log = LogFactory.getLog(MenuServiceImpl.class);

    @Autowired
    private MenuManager menuManager;

    /**
     * 依据用户ID或账号查询菜单（一级和二级）列表
     * 
     * @param user
     * @return
     */
    @Profiled(tag = "MenuService.getMenus")
    public List<MenuDto> getMenus(User user) {
        List<MenuDto> menuDtos = null;
        try {
            menuDtos = menuManager.getMenus(user);
        } catch (Exception e) {
            log.error("MenuServiceImpl -> getMenus(User user) error!!", e);
        }
        return menuDtos;
    }

    @Profiled(tag = "MenuService.getSystemMenus")
	public List<MenuDto> getSystemMenus(Map<String, Object> paramMap) {
        List<MenuDto> menuDtos = null;
        try {
            menuDtos = menuManager.getSystemMenus(paramMap);
        } catch (Exception e) {
            log.error("MenuServiceImpl -> getSystemMenus(Map<String, Object> paramMap) error!!", e);
        }
        return menuDtos;
    }
    
    @Profiled(tag = "MenuService.getAllSystemMenus")
	public List<SystemMenuDto> getAllSystemMenus(Map<String, Object> paramMap) {
        List<SystemMenuDto> menuDtos = null;
        try {
            menuDtos = menuManager.getAllSystemMenus(paramMap);
        } catch (Exception e) {
            log.error("MenuServiceImpl -> getAllSystemMenus(Map<String, Object> paramMap) error!!", e);
        }
        return menuDtos;
    }
    
    @Profiled(tag = "MenuService.queryAuthMenusWithLevel")
	public List<MenuDto> queryAuthMenusWithLevel(Map<String, Object> paramMap) {
        List<MenuDto> menuDtos = null;
        try {
            menuDtos = menuManager.queryAuthMenusWithLevel(paramMap);
        } catch (Exception e) {
            log.error("MenuServiceImpl -> queryAuthMenusWithLevel(Map<String, Object> paramMap) error!!", e);
        }
        return menuDtos;
    }

    @Profiled(tag = "MenuService.queryMenusWithLevel")
	public List<MenuDto> queryMenusWithLevel(Map<String, Object> paramMap) {
        List<MenuDto> menuDtos = null;
        try {
            menuDtos = menuManager.queryMenusWithLevel(paramMap);
        } catch (Exception e) {
            log.error("MenuServiceImpl -> queryMenusWithLevel(Map<String, Object> paramMap) error!!", e);
        }
        return menuDtos;
    }

    @Profiled(tag = "MenuService.getShortCutMenus")
	public List<MenuDto> getShortCutMenus(User user) {
    	List<MenuDto> menuDtos = new ArrayList<MenuDto>();
        List<Resource> res = null;
        //for local test
        MenuDto menu = new MenuDto();
        menu.setMenuCode("shortcut");
        menu.setMenuName("快捷菜单");
        menu.setMenuHKName("快捷菜單");
        menu.setMenuENName("ShortCutMenu");
        menu.setMenuIcon("icon-desktop");
        try {
        	List<SubMenuDto> subMenus = null;
        	res = menuManager.getShortCutMenus(user);
//        	if(res!=null&&!res.isEmpty()){
	        	subMenus = this.adaptSubMenu(res);
//        	}
        	menu.setSubMenus(subMenus);
        	menuDtos.add(menu);
        } catch (Exception e) {
            log.error("MenuServiceImpl -> getShortCutMenus(User user) error!!", e);
        }
        return menuDtos;
    }

	private List<SubMenuDto> adaptSubMenu(List<Resource> res) {
		List<SubMenuDto> subMenus = new ArrayList<SubMenuDto>();
		SubMenuDto subm = null;
		for(Resource r:res){
			subm = new SubMenuDto();
			subm.setSubMenuCode(r.getCode());
			subm.setSubMenuName(r.getName());
			subm.setSubMenuHKName(r.getHkname());
			subm.setSubMenuENName(r.getEnname());
			subm.setSubMenuUrl(r.getUrl());
			subm.setSubMenuIcon(r.getIcon());
			subMenus.add(subm);
		}
		subm = new SubMenuDto();
		subm.setSubMenuCode("addMenu");
		subm.setSubMenuName("新增快捷菜单");
		subm.setSubMenuHKName("新增快捷菜單");
		subm.setSubMenuENName("AddMenu");
		subm.setSubMenuUrl("scMenu/addForward");
		subMenus.add(subm);
		return subMenus;
	}

	@Profiled(tag = "MenuService.queryButtonResources")
	public List<Resource> queryButtonResources(User user) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("userId", user.getId());
		List<Resource> list = null;
		try {
			list = menuManager.queryButtonResources(map);
		} catch (Exception e) {
			log.error("MenuServiceImpl -> queryButtonResources(User user) error!!", e);
		}
		return list;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "MenuService.queryAllSubMenu")
	public List<Resource> queryAllSubMenu() {
		return menuManager.queryAllSubMenu();
	}

}
