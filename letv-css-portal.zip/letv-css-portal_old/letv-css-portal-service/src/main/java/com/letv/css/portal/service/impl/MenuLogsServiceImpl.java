package com.letv.css.portal.service.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.domain.MenuLogs;
import com.letv.css.portal.manager.MenuLogsManager;
import com.letv.css.portal.service.MenuLogsService;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-05-17 18:43:59
 */
@Service
public class MenuLogsServiceImpl implements MenuLogsService{

	private static final Log LOG = LogFactory.getLog(MenuLogsServiceImpl.class);
	
	@Autowired
	private MenuLogsManager menuLogsManager;
	
	@Profiled(tag="MenuLogsServiceImpl.addLog")
	public boolean addLog(MenuLogs menulogs) {
		boolean flag = false;
		try {
			if(menulogs!=null){
				flag = menuLogsManager.addLog(menulogs);
			}else{
				LOG.error("【MenuLogsServiceImpl.addLog】 menulogs param is null!");
			}
		} catch (Exception e) {
			LOG.error("【MenuLogsServiceImpl.addLog(MenuLogs menulogs)】 error!",e);
		}
		return flag;
	}

}
