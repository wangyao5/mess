package com.letv.css.portal.service.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.dao.AdjustChangeDao;
import com.letv.css.portal.domain.AdjustChange;
import com.letv.css.portal.service.AdjustChangeService;

@Service
public class AdjustChangeServiceImpl implements AdjustChangeService{
    private static final Log LOG = LogFactory.getLog(AdjustChangeServiceImpl.class);
    @Autowired
    AdjustChangeDao adjustChangeDao;

	@Override
	public AdjustChange selectById(Long id) {
		return adjustChangeDao.selectById(id);
	}
    
}
