package com.letv.css.portal.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.manager.UserDepManager;
import com.letv.css.portal.service.UserDepService;

/**
 *  用户和部门（数据权限）关系service实现类
 *
 * @Author menghan
 * @Version 2017-01-22 16:41:28
 */
@Service
public class UserDepServiceImpl implements UserDepService{

	private final static Log log = LogFactory.getLog(ResourceRoleServiceImpl.class);
    @Autowired
    private UserDepManager userDepManager;
	
    /**
     * {@inheritDoc}
     */
	public boolean update(UserDep oldUserDep, List<UserDep> newUserDeps, long loginId) {
		boolean resultFlag = false;
        try {
            if (null != oldUserDep && (null != oldUserDep.getUserId() || null != oldUserDep.getDepId())) {
                resultFlag = this.userDepManager.update(oldUserDep, newUserDeps, loginId);
            } else {
                log.warn("UserDepServiceImpl.update has Illegal params.");
            }
        } catch (Exception e) {
            log.error("UserDepServiceImpl.update has error,", e);
        }
        return resultFlag;
	}

	/**
     * {@inheritDoc}
     */
	public List<UserDep> queryUserDepList(Long userId) {
		List<UserDep> userDepList = null;
        try {
        	userDepList = userDepManager.queryUserDepList(userId);
        } catch (Exception e) {
            log.error("UserDepServiceImpl -> queryUserDepList() error!!", e);
        }
        return userDepList;
	}

	/**
     * {@inheritDoc}
     */
	public boolean insert(UserDep userDep) {
		boolean resultFlag = false;
        try {
            if (null != userDep && (null != userDep.getUserId() || null != userDep.getDepId())) {
                resultFlag = this.userDepManager.insert(userDep);
            } else {
                log.warn("UserDepServiceImpl.insert has Illegal params.");
            }
        } catch (Exception e) {
            log.error("UserDepServiceImpl.insert has error,", e);
        }
        return resultFlag;
	}

	/**
     * {@inheritDoc}
     */
	public List<UserDep> queryUsersByDepId(Long depId) {
		List<UserDep> userDepList = null;
		try {
        	userDepList = userDepManager.queryUsersByDepId(depId);
        } catch (Exception e) {
            log.error("UserDepServiceImpl -> queryUsersByDepId() error!!", e);
        }
        return userDepList;
	}
    /**
     * {@inheritDoc}
     */
    public String getDepIds(Long userId) {
        List<UserDep> userDeps = queryUserDepList(userId);
        StringBuilder sb = new StringBuilder();
        for (UserDep ud : userDeps) {
            sb.append(ud.getDepId() + ",");
        }
        String allowDeps = "";
        if (sb.length() > 0) {
            allowDeps = sb.substring(0, sb.length() - 1);
        }
        return allowDeps;
    }


}
