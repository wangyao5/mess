package com.letv.css.portal.service;

import java.util.List;
import java.util.Map;

import com.letv.css.portal.domain.Resource;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.dto.MenuDto;
import com.letv.css.portal.domain.dto.SystemMenuDto;

/**
 * 系统菜单服务接口：提供登录用户的菜单（资源）查询服务
 *
 * @Author menghan
 * @Version 2017-01-22 14:16:08
 */
public interface MenuService {

    /**
     * 依据用户ID或账号查询菜单（一级和二级）列表
     * 
     * @param user
     * @return
     */
    List<MenuDto> getMenus(User user);
    
    /** 
    * @Title: getShortCutMenus 2.0
    * @Description: 根据用户ID或帐号查询快捷菜单
    * @param user 用户
    * @return List<MenuDto> 快捷菜单集合
    * @throws 
    */
    List<MenuDto> getShortCutMenus(User user);
    
    /** 
    * @Title: getSystemMenus v2.0
    * @Description: 运行时 根据用户id和系统code查询系统下有权限的菜单
    * @param paramMap 用户id（uid）系统code（syscode）
    * @return List<MenuDto>  
    * @throws 
    */
    List<MenuDto> getSystemMenus(Map<String, Object> paramMap);
    
	/**
	 * 根据用户id查询用户在所有系统有权菜单
	 * 
	 * @param paramMap
	 * @return
	 */
	List<SystemMenuDto> getAllSystemMenus(Map<String, Object> paramMap);
    
    /** 
    * @Title: queryAuthMenusWithLevel v2.0
    * @Description: 根据用户id,系统code,父节点id查询系统下用户有授权的菜单
    * @param  paramMap 户id（uid）,系统code（syscode）,父节点id（pid） 
    * @return List<MenuDto> 
    * @throws 
    */
    List<MenuDto> queryAuthMenusWithLevel(Map<String, Object> paramMap);
    
    /** 
    * @Title: queryMenusWithLevel v2.0
    * @Description: 根据父节点id和系统code查询某一级菜单
    * @param paramMap
    * @return List<MenuDto>  
    * @throws 
    */
    List<MenuDto> queryMenusWithLevel(Map<String, Object> paramMap);
    
    /**
     * 根据用户ID和父资源查询按钮资源列表
     * 
     * @param map
     * @return
     */
    List<Resource> queryButtonResources(User user);
    
    /***
	 * 获得所有子菜单
	 * @param
	 * @return
	 */
	List<Resource> queryAllSubMenu();
}
