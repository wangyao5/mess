package com.letv.css.portal.service.impl;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.domain.UserRole;
import com.letv.css.portal.domain.query.UserRoleQuery;
import com.letv.css.portal.manager.UserRoleManager;
import com.letv.css.portal.service.UserRoleService;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-22 11:29:22
 */
@Service
public class UserRoleServiceImpl implements UserRoleService {

    private final static Log log = LogFactory.getLog(UserRoleServiceImpl.class);

    @Autowired
    private UserRoleManager userRoleManager;

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.batchInsert")
    public boolean insert(List<UserRole> beanList) {
        boolean resultFlag = false;
        try {
            resultFlag = this.userRoleManager.insert(beanList);
        } catch (Exception e) {
            log.error("UserRoleServiceImpl -> insert() error!!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.insert")
    public boolean insert(UserRole bean) {
        boolean resultFlag = false;
        try {
            if (null != bean) {
                resultFlag = this.userRoleManager.insert(bean);
            } else {
                log.error("param is null!");
            }
        } catch (Exception e) {
            log.error("UserRoleServiceImpl!insert(UserRole bean) error!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.queryUserRoleList")
    public List<UserRole> queryUserRoleList(UserRoleQuery queryBean) {
        List<UserRole> userRoleList = null;
        try {
            userRoleList = this.userRoleManager.queryUserRoleList(queryBean);
        } catch (Exception e) {
            log.error("UserRoleServiceImpl -> queryUserRoleList() error!!", e);
        }
        return userRoleList;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.update")
    public boolean update(UserRole bean) {
        boolean resultFlag = false;
        try {
            resultFlag = this.userRoleManager.update(bean);
        } catch (Exception e) {
            log.error("UserRoleServiceImpl!update(UserRole bean) error!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.delete")
    public boolean delete(Long id) {
        boolean resultFlag = false;
        try {
            if (null != id && id.intValue() > 0) {
                resultFlag = this.userRoleManager.delete(id);
            } else {
                log.error("UserRoleServiceImpl!delete(Long id) param: " + id + " Illegal!");
            }
        } catch (Exception e) {
            log.error("UserRoleServiceImpl!delete(Integer id) error!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.batchDelete")
    public boolean delete(String[] ids) {
        boolean resultFlag = false;
        try {
            resultFlag = this.userRoleManager.delete(ids);
        } catch (Exception e) {
            log.error("UserRoleServiceImpl -> delete() error!!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.getUserRoleById")
    public UserRole getUserRoleById(Long id) {
        UserRole userRole = null;
        try {
            userRole = this.userRoleManager.getUserRoleById(id);
        } catch (Exception e) {
            log.error("UserRoleServiceImpl!getUserRoleById(Integer id) error!", e);
        }
        return userRole;
    }

    /**
     * {@inheritDoc}
     */
    public boolean batchSave(Long userId, String[] roleIds, String createUser) {
        boolean resultFlag = false;
        try {
            if (null != userId) {
                resultFlag = this.userRoleManager.batchSave(userId, roleIds, createUser);
            } else {
                log.error("UserRoleServiceImpl!batchSave param: " + userId + " , roleIds:" + Arrays.toString(roleIds)
                        + " Illegal!");
            }
        } catch (Exception e) {
            log.error("UserRoleServiceImpl!delete(Integer id) error!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    public boolean batchSaves(String[] userIds, String[] roleIds, String createUser) {

        boolean resultFlag = false;
        try {
            if (null != userIds && roleIds != null) {
                resultFlag = this.userRoleManager.batchSaves(userIds, roleIds, createUser);
            } else {
                log.error("UserRoleServiceImpl!batchSaves param: " + userIds + " , roleIds:" + Arrays.toString(roleIds)
                        + " Illegal!");
            }
        } catch (Exception e) {
            log.error("UserRoleServiceImpl!delete(Integer id) error!", e);
        }
        return resultFlag;
    }
    
    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.queryUsersByRoleId")
	public List<UserRole> queryUsersByRoleId(Long roleId) {
		List<UserRole> userRoles = null;
		try {
			userRoles = this.userRoleManager.queryUsersByRoleId(roleId);
		} catch (Exception e) {
			log.error("UserRoleServiceImpl!queryUsersByRoleId(Long id) error!", e);
		}
		return userRoles;
	}

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.queryRoleUserList")
	public List<UserRole> queryRoleUserList(UserRoleQuery query) {
    	List<UserRole> userRoles = null;
        try {
        	userRoles = this.userRoleManager.queryRoleUserList(query);
        } catch (Exception e) {
            log.error("UserRoleServiceImpl!queryRoleUserList(UserRoleQuery query) error!", e);
        }
        return userRoles;
	}

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "UserRoleService.batchSaveRoleUsers")
	public boolean batchSaveRoleUsers(Long roleId, String[] userIds,
			String createUser) {
    	 boolean resultFlag = false;
         try {
             if (null != roleId) {
                 resultFlag = this.userRoleManager.batchSaveRoleUsers(roleId, userIds, createUser);
             } else {
                 log.error("UserRoleServiceImpl!batchSaveRoleUsers param: " + roleId + " , roleIds:" + Arrays.toString(userIds)
                         + " Illegal!");
             }
         } catch (Exception e) {
             log.error("UserRoleServiceImpl!batchSaveRoleUsers(Long roleId, String[] userIds, String createUser) error!", e);
         }
         return resultFlag;
	}
}
