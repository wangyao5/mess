package com.letv.css.portal.service;

import com.letv.css.portal.domain.Leave;

import java.util.Date;
import java.util.List;

/**
 * 员工请假操作 接口
 */
public interface LeaveService {
	/**
	 * 新增请假申请
	 * @param
	 * @return
	 */
	boolean addLeave(Leave bean);

	/**
	 * 根据主键获取对象
	 *
	 * @param id
	 *            主键字段
	 * @return
	 */
	Leave getLeaveById(Long id);

	boolean updateStatus(Leave bean);

	/**
	 * 查找员工在此时间段重复的请假申请
	 * @param staffId
	 * @param leaveStartTime
	 * @param leaveEndTime
	 * @return
	 */
    List<Leave> queryRepeatedLeave(Long staffId, Date leaveStartTime, Date leaveEndTime);
}
