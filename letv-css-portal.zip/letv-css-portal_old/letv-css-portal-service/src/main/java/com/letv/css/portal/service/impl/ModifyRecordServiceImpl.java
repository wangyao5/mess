package com.letv.css.portal.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.ModifyRecord;
import com.letv.css.portal.domain.query.ModifyRecordQuery;
import com.letv.css.portal.manager.ModifyRecordManager;
import com.letv.css.portal.service.ModifyRecordService;

/**
 * 修改记录日志实现类
 *
 * @Author menghan
 * @Version 2017-01-14 13:44:31
 */
@Service
public class ModifyRecordServiceImpl implements ModifyRecordService{

	private static final Log LOG = LogFactory.getLog(ModifyRecordServiceImpl.class);
	
	@Autowired
	private ModifyRecordManager modifyRecordManager;
	
	@Profiled(tag="ModifyRecordServiceImpl.getModifyRecordById")
	public ModifyRecord getModifyRecordById(Long id) {
		ModifyRecord modifyRecord = null;
		try {
			if(null!=id && id.intValue()>0){
				modifyRecord = modifyRecordManager.getModifyRecordById(id);
			}else{
				LOG.error("ModifyRecordServiceImpl!getModifyRecordById(Long id) param: " + id + " Illegal!");
			}
		} catch (Exception e) {
			LOG.error("ModifyRecordServiceImpl!getModifyRecordById(Long id) error!", e);
		}
		return modifyRecord;
	}

	@Profiled(tag="ModifyRecordServiceImpl.insert")
	public boolean insert(ModifyRecord modifyRecord) {
		boolean flag = false;
		try {
			if(modifyRecord!=null){
				flag = modifyRecordManager.insert(modifyRecord);
			}else{
				LOG.error("【ModifyRecordServiceImpl.insert】 modifyRecord param is null!");
			}
		} catch (Exception e) {
			LOG.error("【ModifyRecordServiceImpl.insert(ModifyRecord modifyRecord)】 error!",e);
		}
		return flag;
	}

	@Profiled(tag="ModifyRecordServiceImpl.deleteModifyRecordById")
	public boolean deleteModifyRecordById(Long id) {
		boolean flag = false;
		try {
			if(null!=id && id.intValue()>0){
				flag = modifyRecordManager.deleteModifyRecordById(id);
			}else{
				LOG.error("ModifyRecordServiceImpl!deleteModifyRecordById(Long id) param: " + id + " Illegal!");
			}
		} catch (Exception e) {
			LOG.error("ModifyRecordServiceImpl!deleteModifyRecordById(Long id) error!", e);
		}
		return flag;
	}

	@Profiled(tag="ModifyRecordServiceImpl.queryModifyRecordCount")
	public int queryModifyRecordCount(ModifyRecordQuery bean) {
		int total = 0;
		try {
			if(bean!=null){
				total = modifyRecordManager.queryModifyRecordCount(bean);
			}else{
				LOG.error("ModifyRecordServiceImpl!queryModifyRecordCount(ModifyRecordQuery bean) param: " + bean + " Illegal!");
			}
		} catch (Exception e) {
			LOG.error("ModifyRecordServiceImpl!queryModifyRecordCount(ModifyRecordQuery bean) error!", e);
		}
		return total;
	}

	@Profiled(tag="ModifyRecordServiceImpl.queryModifyRecordListWithPage")
	public List<ModifyRecord> queryModifyRecordListWithPage(
			ModifyRecordQuery bean, PageUtil pageUtil) {
		List<ModifyRecord> modifyRecords = null;
		try {
			modifyRecords = modifyRecordManager.queryModifyRecordListWithPage(bean, pageUtil);
		} catch (Exception e) {
			LOG.error("ModifyRecordServiceImpl -> queryModifyRecordListWithPage() error", e);
		}
		return modifyRecords;
	}

	@Profiled(tag="ModifyRecordServiceImpl.queryEntryFlow")
	public List<ModifyRecord> queryEntryFlow(ModifyRecordQuery bean) {
		List<ModifyRecord> modifyRecords = null;
		try {
			modifyRecords = modifyRecordManager.queryEntryFlow(bean);
		} catch (Exception e) {
			LOG.error("ModifyRecordServiceImpl -> queryEntryFlow() error", e);
		}
		return modifyRecords;
	}

}
