package com.letv.css.portal.service.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.query.SchedulePlanDetailQuery;
import com.letv.css.portal.manager.SchedulePlanDetailManager;
import com.letv.css.portal.service.SchedulePlanDetailService;

/**
 * 操作总班表明细service实现类
 *
 * @Author menghan
 * @Version 2017-05-24 17:47:58
 */
@Service
public class SchedulePlanDetailServiceImpl implements SchedulePlanDetailService{

	private final static Log LOG = LogFactory.getLog(SchedulePlanDetailServiceImpl.class);
	
	@Autowired
	private SchedulePlanDetailManager schedulePlanDetailManager;

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanDetailServiceImpl.insert")
	public boolean insert(SchedulePlanDetail schedulePlanDetail) {
		boolean flag = false;
		try {
			if(schedulePlanDetail!=null){
				flag = schedulePlanDetailManager.insert(schedulePlanDetail);
			}else{
				LOG.error("SchedulePlanDetailServiceImpl.insert(SchedulePlanDetail schedulePlanDetail), param schedulePlanDetail is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanDetailServiceImpl.insert(SchedulePlanDetail schedulePlanDetail) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanDetailServiceImpl.inserts")
	public boolean inserts(List<SchedulePlanDetail> schedulePlanDetails) {
		boolean flag = false;
		try {
			if(CollectionUtils.isNotEmpty(schedulePlanDetails)){
				flag = schedulePlanDetailManager.inserts(schedulePlanDetails);
			}else{
				LOG.error("SchedulePlanDetailServiceImpl.inserts(List<SchedulePlanDetail> schedulePlanDetails), param schedulePlanDetails is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanDetailServiceImpl.inserts(List<SchedulePlanDetail> schedulePlanDetails) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanDetailServiceImpl.querySchedulePlanDetailList")
	public List<SchedulePlanDetail> querySchedulePlanDetailList(SchedulePlanDetailQuery query) {
		List<SchedulePlanDetail> schedulePlanDetails = null;
		try {
			if(query!=null){
				schedulePlanDetails = schedulePlanDetailManager.querySchedulePlanDetailList(query);
			}else{
				LOG.error("SchedulePlanDetailServiceImpl.querySchedulePlanDetailList(SchedulePlanDetailQuery query) param:" + query + " is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanDetailServiceImpl.querySchedulePlanDetailList(SchedulePlanDetailQuery query) error!", e);
		}
		return schedulePlanDetails;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanDetailServiceImpl.update")
	public boolean update(SchedulePlanDetail schedulePlanDetail) {
		boolean flag = false;
		try {
			if(schedulePlanDetail!=null){
				flag = schedulePlanDetailManager.update(schedulePlanDetail);
			}else{
				LOG.error("SchedulePlanDetailServiceImpl.update(SchedulePlanDetail schedulePlanDetail) param: "+schedulePlanDetail +" is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanDetailServiceImpl.update(SchedulePlanDetail schedulePlanDetail) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanDetailServiceImpl.delete")
	public boolean delete(Long id) {
		boolean flag = false;
		try {
			if(id!=null && id.intValue()>0){
				flag = schedulePlanDetailManager.delete(id);
			}else{
				LOG.error("SchedulePlanDetailServiceImpl.delete(Long id) param: "+id +" is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanDetailServiceImpl.delete(Long id) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanDetailServiceImpl.deletes")
	public boolean deletes(SchedulePlanDetailQuery query) {
		boolean flag = false;
		try {
			if(query!=null){
				flag = schedulePlanDetailManager.deletes(query);
			}else{
				LOG.error("SchedulePlanDetailServiceImpl.deletes(SchedulePlanDetailQuery query) param: "+query +" is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanDetailServiceImpl.deletes(SchedulePlanDetailQuery query) error!",e);
		}
		return flag;
	}

}
