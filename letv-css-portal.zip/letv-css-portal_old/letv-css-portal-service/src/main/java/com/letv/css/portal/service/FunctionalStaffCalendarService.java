package com.letv.css.portal.service;

import java.util.List;

import com.letv.css.portal.domain.FunctionalStaffCalendar;
import com.letv.css.portal.domain.query.FunctionalStaffCalendarQuery;

/**
 * 工作日历 service接口
 * @Author greg
 */
public interface FunctionalStaffCalendarService {
	/**
	 * 新增
	 * @param
	 * @return
	 */
	boolean inserts(List<FunctionalStaffCalendar> calendarList);
	
	/**
	 * 根据query，不分页
	 * @param
	 * @return
	 */
	List<FunctionalStaffCalendar> queryList(FunctionalStaffCalendarQuery query);

}
