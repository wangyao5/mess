package com.letv.css.portal.service.impl;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Schedule;
import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.query.ScheduleQuery;
import com.letv.css.portal.manager.ScheduleManager;
import com.letv.css.portal.service.ScheduleService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * BPO排班表导入service实现类
 *
 * @Author yxh
 * @Version 2017-05-31 22:37:29
 */
@Service
public class ScheduleServiceImpl implements ScheduleService {

    private final static Log LOG = LogFactory.getLog(ScheduleServiceImpl.class);

    @Autowired
    private ScheduleManager scheduleManager;

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ScheduleServiceImpl.insert")
    public boolean insert(Schedule schedule) {
        boolean flag = false;
        try {
            if (schedule != null) {
                flag = scheduleManager.insert(schedule);
            } else {
                LOG.error("ScheduleServiceImpl.insert(Schedule schedule), param schedule is null");
            }
        } catch (Exception e) {
            LOG.error("ScheduleServiceImpl.insert(Schedule schedule) error!", e);
        }
        return flag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ScheduleServiceImpl.inserts")
    public boolean inserts(List<Schedule> schedules) {
        boolean flag = false;
        try {
            if (CollectionUtils.isNotEmpty(schedules)) {
                flag = scheduleManager.inserts(schedules);
            } else {
                LOG.error("ScheduleServiceImpl.inserts(List<Schedule> schedules), param schedules is null");
            }
        } catch (Exception e) {
            LOG.error("ScheduleServiceImpl.inserts(List<Schedule> schedules) error!", e);
        }
        return flag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ScheduleServiceImpl.update")
    public boolean update(Schedule bean) {
        boolean resultFlag = false;
        try {
            resultFlag = scheduleManager.update(bean);
        } catch (Exception e) {
            LOG.error("ScheduleServiceImpl!update(Schedule bean) error!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ScheduleServiceImpl.getScheduleById")
    public Schedule getScheduleById(Long id) {
        Schedule schedule = null;
        try {
            if (id != null && id.intValue() > 0) {
                schedule = scheduleManager.getScheduleById(id);
            } else {
                LOG.error("ScheduleServiceImpl.getScheduleById(Long id) param: " + id + " Illegal!");
            }
        } catch (Exception e) {
            LOG.error("ScheduleServiceImpl.getScheduleById(Long id) error", e);
        }
        return schedule;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ScheduleServiceImpl.queryScheduleListWithPage")
    public List<Schedule> queryScheduleListWithPage(
            ScheduleQuery query, PageUtil pageUtil) {
        List<Schedule> schedules = null;
        try {
            if (query != null) {
                schedules = scheduleManager.queryScheduleListWithPage(query, pageUtil);
            } else {
                LOG.error("ScheduleServiceImpl.queryScheduleListWithPage(ScheduleQuery query, PageUtil pageUtil) param:" + query + "is null");
            }
        } catch (Exception e) {
            LOG.error("ScheduleServiceImpl.queryScheduleListWithPage(ScheduleQuery query,PageUtil pageUtil) error!", e);
        }
        return schedules;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ScheduleServiceImpl.queryScheduleList")
    public List<Schedule> queryScheduleList(ScheduleQuery query) {
        List<Schedule> schedules = null;
        try {
            if (query != null) {
                schedules = scheduleManager.queryScheduleList(query);
            } else {
                LOG.error("ScheduleServiceImpl.queryScheduleList(ScheduleQuery query) param:" + query + "is null");
            }
        } catch (Exception e) {
            LOG.error("ScheduleServiceImpl.queryScheduleList(ScheduleQuery query) error!", e);
        }
        return schedules;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ScheduleServiceImpl.inserts")
    public boolean inserts(List<Schedule> schedules,
                           List<ScheduleDetail> scheduleDetails) {
        boolean flag = false;
        try {
            if (CollectionUtils.isNotEmpty(schedules) && CollectionUtils.isNotEmpty(scheduleDetails)) {
                flag = scheduleManager.inserts(schedules, scheduleDetails);
            } else {
                LOG.error("ScheduleServiceImpl.inserts(List<Schedule> schedules, List<ScheduleDetail> scheduleDetails) param is null");
            }
        } catch (Exception e) {
            LOG.error("ScheduleServiceImpl.inserts(List<Schedule> schedules, List<ScheduleDetail> scheduleDetails) error ", e);
        }
        return flag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ScheduleServiceImpl.addAutoScheduleFlow")
    public boolean addAutoScheduleFlow(String spId, String sId, Long userId, String userName) {
        boolean flag = false;
        try {
            if (StringUtils.isNotBlank(spId) && StringUtils.isNotBlank(sId)) {
                flag = scheduleManager.addAutoScheduleFlow(spId, sId, userId, userName);
            } else {
                LOG.error("ScheduleServiceImpl.addAutoScheduleFlow(String spId, String sId, Long userId, String userName) param is null");
            }
        } catch (Exception e) {
            LOG.error("ScheduleServiceImpl.addAutoScheduleFlow(String spId, String sId, Long userId, String userName) error", e);
        }
        return flag;
    }


}
