package com.letv.css.portal.service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.ShiftsPeriod;
import com.letv.css.portal.domain.query.ShiftsPeriodQuery;

import java.util.List;

/**
 * 班段信息接口类
 * Created by yangxinghe on 2017/5/16.
 */
public interface ShiftsPeriodService {
    /**
     * 根据查询参数查询班段信息集合
     *
     * @param
     * @return
     */
    List<ShiftsPeriod> queryShiftsPeriodList(ShiftsPeriodQuery query);

    /**
     * 根据查询参数查询班段信息集合
     *
     * @param
     * @return
     */
    List<ShiftsPeriod> queryShiftsPeriodListWithPage(ShiftsPeriodQuery query, PageUtil pageUtil);

    /**
     * 新增对象
     *
     * @param bean
     * @return
     */
    boolean insert(ShiftsPeriod bean);

    /**
     * 更新对象
     *
     * @param bean
     * @return
     */
    boolean update(ShiftsPeriod bean);


    /**
     * 根据主键删除记录
     *
     * @param id
     * @return
     */
    boolean delete(Long id);

    /**
     * 根据主键获取对象
     *
     * @param id 主键字段
     * @return
     */
    ShiftsPeriod getShiftsPeriodById(Long id);

    /**
     * 根据主键批量禁用或启用 班段
     */
    boolean updateStatus(String idBoxs, String status, String updateUser);

}
