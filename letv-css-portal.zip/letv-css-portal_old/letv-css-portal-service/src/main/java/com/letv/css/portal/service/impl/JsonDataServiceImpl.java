package com.letv.css.portal.service.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.domain.JsonData;
import com.letv.css.portal.manager.JsonDataManager;
import com.letv.css.portal.service.JsonDataService;

/**
 * 审批提交数据service实现类
 *
 * @Author menghan
 * @Version 2017-06-22 16:42:55
 */
@Service
public class JsonDataServiceImpl implements JsonDataService{

	private static final Log LOG = LogFactory.getLog(JsonDataServiceImpl.class);
	
	@Autowired
	private JsonDataManager jsonDataManager;
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="JsonDataServiceImpl.insert")
	public boolean insert(JsonData jsonData) {
		boolean flag = false;
		try {
			if(jsonData!=null){
				flag = jsonDataManager.insert(jsonData);
			}else{
				LOG.error("【JsonDataServiceImpl.insert】 jsonData param is null!");
			}
		} catch (Exception e) {
			LOG.error("JsonDataServiceImpl.insert(JsonData jsonData)】 error!",e);
		}
		return flag;
	}
	@Override
	public JsonData getById(Long id) {
		return jsonDataManager.getById(id);
	}

}
