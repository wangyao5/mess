package com.letv.css.portal.service;

import java.util.List;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.query.StaffQuery;

/**
 * 员工信息操作 接口
 *
 * @Author menghan
 * @Version 2017-01-06 17:01:20
 */
public interface StaffService {
	/**
	 * 增加对象信息
	 * @param
	 * @return
	 */
	boolean insert(Staff bean);

	boolean jobChange(Staff staff, long userId, int changeType);
	/**
	 * 更新对象信息
	 * @param
	 * @return
	 */
	boolean update(Staff bean);
	
	/**
	 * 根据查询Bean获取对象集合，无翻页
	 * @param
	 * @return
	 */
	List<Staff> queryStaffList(StaffQuery queryBean);

	/**
	 * 根据查询Bean获取对象集合，带翻页
	 * @param
	 * @return
	 */
	List<Staff> queryStaffListWithPage(StaffQuery queryBean,PageUtil pageUtil);

	/**
	 * 根据查询Bean获取对象信息总数
	 * @param
	 * @return
	 */
	int queryStaffCount(StaffQuery queryBean);
	
	/**
     * 根据主键删除对象信息，该处做的是逻辑删除
     * 
     * @param id
     *            主键字段
     * @return
     */
    boolean delete(Long id);

    /**
     * 根据主键获取对象信息
     * 
     * @param id
     *            主键字段
     * @return 对象信息
     */
    Staff getStaffById(Long id);

    /**
     * 员工上线
     * @param
     * @return
     */
	boolean online(Staff staff);
	
	/**
	 * 通过客服工号获得员工信息
	 * @param
     * @return
	 */
	Staff getStaffByCsId(String csId);
	
	/**
	 * 通过乐视账号获得员工信息
	 * @param
     * @return
	 */
	Staff getStaffByLeAccount(String leAccount);
	
	/**
	 * 通过员工编号获得员工信息
	 * @param
     * @return
	 */
	Staff getStaffByEmployeeNum(String employeeNum);
	
	/**
	 * 通过员工姓名，获得最新插入的员工ID
	 * @param
	 * @return
	 */
	Long getStaffId(String name);

	/**
	 * 查询某时段未排班的信息
	 * @param queryBean
	 * @return
     */
	List<Staff> getOvertimeStaff(StaffQuery queryBean,Long userId);
	/**
	 * 根据职场、业务线查询人，判断职场是否在权限范围内
	 * @param queryBean
	 * @return
     */
	List<Staff> getPreShiftsStaff(StaffQuery queryBean,Long userId);

    /**
     *   //修改部门负责人时 将部门本层级坐席的组长更新为当前部门的负责人
     * @param staff
     * @return
     */
    boolean updateSuperiorByDepId(Staff staff);
}
