package com.letv.css.portal.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.letv.css.portal.domain.FunctionalStaffCalendar;
import com.letv.css.portal.domain.query.FunctionalStaffCalendarQuery;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.css.portal.manager.FunctionalStaffCalendarManager;
import com.letv.css.portal.service.FunctionalStaffCalendarService;

/**
 * 工作日历 service实现类
 * @Author greg
 */
@Service
public class FunctionalStaffCalendarServiceImpl implements FunctionalStaffCalendarService{

	private final static Log LOG = LogFactory.getLog(FunctionalStaffCalendarServiceImpl.class);
	
	@Autowired
	private FunctionalStaffCalendarManager functionalStaffCalendarManager;
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="FunctionalStaffCalendarServiceImpl.inserts")
	public boolean inserts(List<FunctionalStaffCalendar> calendarList) {
		boolean flag = false;
		try {
			if(CollectionUtils.isNotEmpty(calendarList)){
				Date planDate = calendarList.get(0).getPlanDate();
				if(planDate != null){
					FunctionalStaffCalendarQuery query = new FunctionalStaffCalendarQuery();
					query.setPlanYear(planDate.getYear());
					query.setPlanYear(planDate.getMonth());
					List<FunctionalStaffCalendar> readyCalendarList = queryList(query);
					
					if(readyCalendarList != null && readyCalendarList.size() > 0){
						List<Date> readyPlanDateList = new ArrayList<Date>();
						for(int i = 0; i < readyCalendarList.size(); i ++){
							readyPlanDateList.add(readyCalendarList.get(i).getPlanDate());
						}
						for(int j = 0; j < calendarList.size(); j ++){
							planDate = null;
							FunctionalStaffCalendar functionalStaffCalendar = calendarList.get(j);
							planDate = functionalStaffCalendar.getPlanDate();
							if(!readyPlanDateList.contains(planDate)){
								flag = functionalStaffCalendarManager.insert(functionalStaffCalendar);
							}else{
								flag = functionalStaffCalendarManager.update(functionalStaffCalendar);
							}
						}
					}else{
						for(int i = 0; i < calendarList.size(); i ++){
							FunctionalStaffCalendar functionalStaffCalendar = calendarList.get(i);
							flag = functionalStaffCalendarManager.insert(functionalStaffCalendar);
						}
					}
				}else{
					LOG.error("FunctionalStaffCalendarServiceImpl.inserts(List<FunctionalStaffCalendar> calendarList), param planDate is null");
				}
			}else{
				LOG.error("FunctionalStaffCalendarServiceImpl.inserts(List<FunctionalStaffCalendar> calendarList), param calendarList is null");
			}
		} catch (Exception e) {
			LOG.error("FunctionalStaffCalendarServiceImpl.inserts(List<FunctionalStaffCalendar> calendarList) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="FunctionalStaffCalendarServiceImpl.queryList")
	public List<FunctionalStaffCalendar> queryList(FunctionalStaffCalendarQuery query) {
		List<FunctionalStaffCalendar> list = new ArrayList<FunctionalStaffCalendar>();
		try {
			if(null != query){
				list = functionalStaffCalendarManager.queryList(query);
			}else{
				LOG.error("FunctionalStaffCalendarServiceImpl!queryList(FunctionalStaffCalendarQuery query) param:" + query + "is null");
			}
		} catch (Exception e) {
			LOG.error("FunctionalStaffCalendarServiceImpl!queryList(FunctionalStaffCalendarQuery query) error!", e);
		}
		return list;
	}
}
