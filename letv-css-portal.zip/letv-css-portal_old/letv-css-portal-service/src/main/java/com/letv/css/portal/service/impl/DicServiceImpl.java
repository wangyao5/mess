package com.letv.css.portal.service.impl;

import java.util.List;

import com.letv.css.portal.domain.DepBusiness;
import com.letv.css.portal.domain.query.DicBusinessQuery;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.manager.DicManager;
import com.letv.css.portal.service.DicService;

/**
 * 数据字典 service实现类
 *
 * @Author menghan
 * @Version 2017-02-14 20:50:27
 */
@Service
public class DicServiceImpl implements DicService{

	private final static Log LOG = LogFactory.getLog(DicServiceImpl.class);
	
	@Autowired
	private DicManager dicmanager;
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DicServiceImpl.insert")
	public boolean insert(Dic dic) {
		boolean flag = false;
		try {
			if(dic!=null){
				Long num = dicmanager.getDicNum(dic.getParentId());
				num = (num == null ? 0 : num);
				dic.setNum(++num);
				flag = dicmanager.insert(dic);
			}else{
				LOG.error("【DicServiceImpl.insert】 dic param is null!");
			}
		} catch (Exception e) {
			LOG.error("【DicServiceImpl.insert(Dic dic)】 error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DicServiceImpl.update")
	public boolean update(Dic dic) {
		boolean flag = false;
		try {
			if(dic!=null){
				flag = dicmanager.update(dic);
			}else{
				LOG.error("【DicServiceImpl.update】 dic param is null!");
			}
		} catch (Exception e) {
			LOG.error("【DicServiceImpl.update(Dic dic)】 error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DicServiceImpl.deleteById")
	public boolean deleteById(Long id) {
		boolean flag = false;
		try {
			if(null != id && id.intValue()>0){
				flag = dicmanager.deleteById(id);
			}else{
				LOG.error("DicServiceImpl!deleteById(Long id) param: " + id + " Illegal!");
			}
		} catch (Exception e) {
			LOG.error("DicServiceImpl!deleteById(Long id) error!", e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DicServiceImpl.getDicById")
	public Dic getDicById(Long id) {
		Dic dic = null;
		try {
			if(null != id && id.intValue()>0){
				dic = dicmanager.getDicById(id);
			}else{
				LOG.error("DicServiceImpl!getDicById(Long id) param: " + id + " Illegal!");
			}
		} catch (Exception e) {
			LOG.error("DicServiceImpl!getDicById(Long id) error!", e);
		}
		return dic;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DicServiceImpl.queryDicList")
	public List<Dic> queryDicList(DicQuery query) {
		List<Dic> list = null;
		try {
			if(null!=query){
				list = dicmanager.queryDicList(query);
			}else{
				LOG.error("DicServiceImpl!queryDicList(DicQuery query) param:" + query + "is null");
			}
		} catch (Exception e) {
			LOG.error("DicServiceImpl!queryDicList(DicQuery query) error!", e);
		}
		return list;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DicServiceImpl.queryDicListWithPage")
	public List<Dic> queryDicListWithPage(DicQuery query, PageUtil pageUtil) {
		List<Dic> list = null;
		try {
			if(null!=query){
				list = dicmanager.queryDicListWithPage(query,pageUtil);
			}else{
				LOG.error("DicServiceImpl!queryDicListWithPage(DicQuery query, PageUtil pageUtil) param:" + query + "is null");
			}
		} catch (Exception e) {
			LOG.error("DicServiceImpl!queryDicListWithPage(DicQuery query, PageUtil pageUtil) error!", e);
		}
		return list;
	}

	@Profiled(tag="DicServiceImpl.queryDicListById")
	public List<Dic> queryDicListById(DicBusinessQuery businessQuery) {
		List<Dic> list = null;
		try {
			if(null!=businessQuery){
				list = dicmanager.queryDicListById(businessQuery);
			}else{
				LOG.error("DicServiceImpl!queryDicListById(List<DepBusiness> depBusinesses) param:" + businessQuery + "is null");
			}
		} catch (Exception e) {
			LOG.error("DicServiceImpl!queryDicListById(List<DepBusiness> depBusinesses) error!", e);
		}
		return list;
	}

	@Override
	public Dic getDicByNum(Long parentNum, Long num) {
		return dicmanager.getDicByNum(parentNum, num);
	}
}
