package com.letv.css.portal.service;

import java.util.List;

import com.letv.css.portal.domain.UserRole;
import com.letv.css.portal.domain.query.UserRoleQuery;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-22 11:27:59
 */
public interface UserRoleService {

	/**
     * 批量增加对象信息
     * 
     * @param beanList
     * @return
     */
    boolean insert(List<UserRole> beanList);

    /**
     * 单个增加对象信息
     * 
     * @param bean
     * @return
     */
    boolean insert(UserRole bean);

    /**
     * 根据主键更新对象信息
     * 
     * @param bean
     *            对象信息对象
     * @return Result 对象
     */
    boolean update(UserRole bean);

    /**
     * 根据查询Bean获取对象集合，无翻页
     * 
     * @param queryBean
     * @return
     */
    List<UserRole> queryUserRoleList(UserRoleQuery queryBean);

    /**
     * 根据主键删除对象信息，该处做的是逻辑删除
     * 
     * @param id
     * @return
     */
    boolean delete(Long id);

    /**
     * 根据对象信息ID，主键获取对象信息
     * 
     * @param id
     * @return
     */
    UserRole getUserRoleById(Long id);

    /**
     * 根据主键集合删除对象信息，该处做的是逻辑删除
     * 
     * @param ids
     *            主键集合
     * @return
     */
    boolean delete(String[] ids);

    /**
     * 批量绑定用户、角色关系： 1.删除用户原有角色 2.添加新的用户角色关系
     * 
     * @param userId
     * @param roleIds
     * @param createUser
     * @return
     */
    boolean batchSave(Long userId, String[] roleIds, String createUser);

    /**
     * 批量分配用户、角色关系： 1.删除用户原有角色 2.添加新的用户角色关系
     * 
     * @param userId
     * @param roleIds
     * @param createUser
     * @return
     */
    boolean batchSaves(String[] userIds, String[] roleIds, String createUser);
	
    /**
     * 根据角色ID查询拥有该角色的用户信息
     * @param
     * @return
     */
    List<UserRole> queryUsersByRoleId(Long roleId);
    
    /**
     * 根据角色ID，查询拥有该角色的用户信息，与queryUsersByRoleId区别，queryUsersByRoleId仅返回userId
     * @param
     * @return
     */
    List<UserRole> queryRoleUserList(UserRoleQuery query);
    
    /**
     * 根据roleId，批量存取user信息
     * @param
     * @return
     */
    boolean batchSaveRoleUsers(Long roleId, String[] userIds, String createUser);
}
