package com.letv.css.portal.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Role;
import com.letv.css.portal.domain.query.ResourceRoleQuery;
import com.letv.css.portal.domain.query.RoleQuery;
import com.letv.css.portal.domain.query.UserRoleQuery;
import com.letv.css.portal.manager.RoleManager;
import com.letv.css.portal.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {
	private final static Log log = LogFactory.getLog(RoleServiceImpl.class);
	@Autowired
	private RoleManager roleManager;

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "RoleService.batchInsert")
	public boolean insert(List<Role> beanList) {
		boolean resultFlag = false;
		try {
			resultFlag = roleManager.insert(beanList);
		} catch (Exception e) {
			log.error("RoleServiceImpl -> insert() error!!", e);
		}
		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "RoleService.insert")
	public boolean insert(Role bean) {
		boolean resultFlag = false;
		try {
			if (null != bean) {
				resultFlag = roleManager.insert(bean);
			} else {
				log.error("param is null!");
			}
		} catch (Exception e) {
			log.error("RoleServiceImpl!insert(Role bean) error!", e);
		}
		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "RoleService.update")
	public boolean update(Role bean) {
		boolean resultFlag = false;
		try {
			resultFlag = roleManager.update(bean);
		} catch (Exception e) {
			log.error("RoleServiceImpl!update(Role bean) error!", e);
		}
		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "RoleService.queryRoleList")
	public List<Role> queryRoleList(RoleQuery queryBean) {
		List<Role> roleList = null;
		try {
			roleList = roleManager.queryRoleList(queryBean);
		} catch (Exception e) {
			log.error("RoleServiceImpl -> queryRoleList() error!!", e);
		}
		return roleList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="RoleService.queryRoles")
	public List<Role> queryRoles(RoleQuery queryBean) {
		List<Role> roleList = null;
		try {
			roleList = roleManager.queryRoleList(queryBean);
		} catch (Exception e) {
			log.error("RoleServiceImpl -> queryRoles() error!!", e);
		}
		return roleList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "RoleService.queryRoleListWithPage")
	public List<Role> queryRoleListWithPage(RoleQuery queryBean,
			PageUtil pageUtil) {
		List<Role> roleList = null;
		try {
			roleList = roleManager.queryRoleListWithPage(queryBean, pageUtil);
		} catch (Exception e) {
			log.error("RoleServiceImpl -> queryRolePages() error!!", e);
		}
		return roleList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "RoleService.delete")
	public boolean delete(Long id) {
		boolean resultFlag = false;
		try {
			if (null != id && id.intValue() > 0) {
				resultFlag = roleManager.delete(id);
			} else {
				log.error("RoleServiceImpl!delete(Long id) param: " + id
						+ " Illegal!");
			}
		} catch (Exception e) {
			log.error("RoleServiceImpl!delete(Integer id) error!", e);
		}
		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "RoleService.batchDelete")
	public boolean delete(String[] ids) {
		boolean resultFlag = false;
		try {
			resultFlag = roleManager.delete(ids);
		} catch (Exception e) {
			log.error("RoleServiceImpl -> delete() error!!", e);
		}
		return resultFlag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "RoleService.getRoleById")
	public Role getRoleById(Long id) {
		Role role = null;
		try {
			role = roleManager.getRoleById(id);
		} catch (Exception e) {
			log.error("RoleServiceImpl!getRoleById(Integer id) error!", e);
		}
		return role;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryConfigedRoleList(UserRoleQuery queryBean) {
		List<Role> roleList = null;
		try {
			roleList = roleManager.queryConfigedRoleList(queryBean);
		} catch (Exception e) {
			log.error("RoleServiceImpl -> queryConfigedRoleList() error!!", e);
		}
		return roleList;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryAvailableRoleList(UserRoleQuery queryBean) {
		List<Role> roleList = null;
		try {
			roleList = roleManager.queryAvailableRoleList(queryBean);
		} catch (Exception e) {
			log.error("RoleServiceImpl -> queryAvailableRoleList() error!!", e);
		}
		return roleList;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryResourceConfigedRoleList(ResourceRoleQuery query) {
		List<Role> roleList = null;
		try {
			roleList = roleManager.queryResourceConfigedRoleList(query);
		} catch (Exception e) {
			log.error(
					"RoleServiceImpl -> queryResourceConfigedRoleList() error!!",
					e);
		}
		return roleList;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Role> queryResourceAvailableRoleList(ResourceRoleQuery query) {
		List<Role> roleList = null;
		try {
			roleList = roleManager.queryResourceAvailableRoleList(query);
		} catch (Exception e) {
			log.error(
					"RoleServiceImpl -> queryResourceAvailableRoleList() error!!",
					e);
		}
		return roleList;
	}
}