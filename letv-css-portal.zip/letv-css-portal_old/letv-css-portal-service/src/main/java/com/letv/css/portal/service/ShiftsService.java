package com.letv.css.portal.service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Shifts;
import com.letv.css.portal.domain.query.ShiftsQuery;

import java.util.List;

/**
 * 班次信息接口类
 * Created by yangxinghe on 2017/5/16.
 */
public interface ShiftsService {
    /**
     * 根据查询参数查询班次信息集合
     *
     * @param
     * @return
     */
    List<Shifts> queryShiftsList(ShiftsQuery query);
    
    /**
     * 根据查询参数查询班次信息集合 按照最小开始时间排序
     * @param query
     * @return
     */
    List<Shifts> queryShiftsListByMinBeginTime(ShiftsQuery query);
    
    /**
     * 根据查询参数查询班次信息集合 用于下拉列表
     *
     * @param
     * @return
     */
    List<Shifts> queryOptionShiftsList(ShiftsQuery query);

    /**
     * 根据查询参数查询班次信息集合
     *
     * @param
     * @return
     */
    List<Shifts> queryShiftsListWithPage(ShiftsQuery query, PageUtil pageUtil);

    /**
     * 新增对象
     *
     * @param bean
     * @return
     */
    boolean insert(Shifts bean);

    /**
     * 更新对象
     *
     * @param bean
     * @return
     */
    boolean update(Shifts bean);


    /**
     * 根据主键删除记录
     *
     * @param id
     * @return
     */
    boolean delete(Long id);

    /**
     * 根据主键获取对象
     *
     * @param id 主键字段
     * @return
     */
    Shifts getShiftsById(Long id);

    /**
     * 根据名称查询班次
     * @param shiftsName
     * @return
     */
    Shifts getShiftsByName(String shiftsName);

    /**
     * 根据主键批量禁用或启用 班次
     */
    boolean updateStatus(String idBoxs,String status,String updateUser);
    /**
     * 根据班次名称获得班次id
     *
     * @param shiftsName
     * @return
     */
    Long getShiftsId(String shiftsName) ;

}
