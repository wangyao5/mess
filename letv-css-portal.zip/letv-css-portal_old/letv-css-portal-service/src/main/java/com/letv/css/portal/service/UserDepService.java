package com.letv.css.portal.service;

import java.util.List;

import com.letv.css.portal.domain.UserDep;

/**
 * 用户和部门（数据权限）关系service接口
 *
 * @Author menghan
 * @Version 2017-01-22 16:39:20
 */
public interface UserDepService {

	/**
     * 新增部门和用户关系
     * 
     * @param userDep
     * @return
     */
    boolean insert(UserDep userDep);
	
	/**
     * 修改资源和角色的绑定关系： 1.删除原来的关系；2.新增新的关系
     * 
     * @param oldUserDep
     *            原来的关系
     * @param newUserDeps
     *            新的关系
     * @return
     */
    boolean update(UserDep oldUserDep, List<UserDep> newUserDeps, long loginId);

    /**
     * 根据角色获取已经分配的资源列表
     * 
     * @param roleId
     * @return
     */
    List<UserDep> queryUserDepList(Long userId);
    
    /**
     * 根据部门ID，获得所有拥护该部门权限的用户
     * @param
     * @return
     */
    List<UserDep> queryUsersByDepId(Long depId);
    /***
     * 获得可见部门的id集合
     */
    String getDepIds(Long userId);
}
