package com.letv.css.portal.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.query.DepQuery;
import com.letv.css.portal.manager.DepManager;
import com.letv.css.portal.service.DepService;

/**
 * 部门信息实现类
 *
 * @Author menghan
 * @Version 2017-01-13 10:13:21
 */
@Service
public class DepServiceImpl implements DepService{

	private static final Log LOG = LogFactory.getLog(DepServiceImpl.class);
	
	@Autowired
	private DepManager depManager;
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.insert")
	public boolean insert(Dep dep) {
		boolean flag = false;
		try {
			if(dep!=null){
				flag = depManager.insert(dep);
			}else{
				LOG.error("【DepServiceImpl.insert】 dep param is null!");
			}
		} catch (Exception e) {
			LOG.error("【DepServiceImpl.insert(Dep dep)】 error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.update")
	public boolean update(Dep dep) {
		boolean flag = false;
		try {
			if(dep!=null){
				flag = depManager.update(dep);
			}else{
				LOG.error("【DepServiceImpl.update】 dep param is null!");
			}
		} catch (Exception e) {
			LOG.error("【DepServiceImpl.update(Dep dep)】 error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.delete")
	public boolean delete(Long id) {
		boolean flag = false;
		try {
			if(null!=id && id.intValue()>0){
				flag = depManager.delete(id);
			}else{
				LOG.error("DepServiceImpl!delete(Long id) param: " + id + " Illegal!");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!delete(Long id) error!", e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.getDepById")
	public Dep getDepById(Long id) {
		Dep dep = null;
		try {
			if(null!=id && id.intValue()>0){
				dep = depManager.getDepById(id);
			}else{
				LOG.error("DepServiceImpl!getDepById(Long id) param: " + id + " Illegal!");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!getDepById(Long id) error!", e);
		}
		return dep;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.getDepListByIds")
	public List<Dep> getDepListByIds(String ids) {
		List<Dep> depList = null;
		try {
			if(null!=ids && !"".equals(ids)){
				depList = depManager.getDepListByIds(ids);
			}else{
				LOG.error("DepServiceImpl!getDepListByIds(String ids) param:" + ids + "is null");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!getDepListByIds(String ids) error!", e);
		}
		return depList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.queryDepListWithPage")
	public List<Dep> queryDepListWithPage(DepQuery query,PageUtil pageUtil) {
		List<Dep> depList = null;
		try {
			if(query!=null){
				depList = depManager.queryDepListWithPage(query, pageUtil);
			}else{
				LOG.error("DepServiceImpl!queryDepListWithPage(DepQuery query,PageUtil pageUtil) param:" + query + "is null");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!queryDepListWithPage(DepQuery query,PageUtil pageUtil) error!", e);
		}
		return depList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.queryDepList")
	public List<Dep> queryDepList(DepQuery query) {
		List<Dep> depList = null;
		try {
			if(query!=null){
				depList = depManager.queryDepList(query);
			}else{
				LOG.error("DepServiceImpl!queryDepList(DepQuery query) param:" + query + "is null");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!queryDepList(DepQuery query) error!", e);
		}
		return depList;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.getChildrenCodByParentId")
	public List<String> getChildrenCodByParentId(Long parentId) {
		List<String> list = null;
		try {
			if(parentId!=null){
				list = depManager.getChildrenCodByParentId(parentId);
			}else{
				LOG.error("DepServiceImpl!getChildrenCodByParentId(Long parentId) param:" + parentId + " is null");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!getChildrenCodByParentId(Long parentId) error!", e);
		}
		return list;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.queryTreeDepList")
	public List<Dep> queryTreeDepList(DepQuery query) {
		List<Dep> depList = null;
		try {
			if(query!=null){
				depList = depManager.queryTreeDepList(query);
			}else{
				LOG.error("DepServiceImpl!queryTreeDepList(DepQuery query) param:" + query + "is null");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!queryTreeDepList(DepQuery query) error!", e);
		}
		return depList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.queryDepTree")
	public List<Dep> queryDepTree(Long userId) {
		List<Dep> depList = null;
		try {
			if(userId!=null && userId>0){
				depList = depManager.queryDepTree(userId);
			}else{
				LOG.error("DepServiceImpl!queryDepTree(Long userId) param:" + userId + " is null");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!queryDepTree(Long userId) error!", e);
		}
		return depList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.queryDepPersonQuantity")
	public Integer queryDepPersonQuantity(Long depId) {
		Integer count = 0;
		try {
			if(depId!=null && depId>0){
				count = depManager.queryDepPersonQuantity(depId);
			}else{
				LOG.error("DepServiceImpl!queryDepPersonQuantity(Long depId) param:" + depId + " is null");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!queryDepPersonQuantity(Long depId) error!", e);
		}
		return count;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.queryDepPersonQuantityByCode")
	public Map<Integer, Integer> queryDepPersonQuantityByCode(String code) {
		try {
			if(code!=null && !"".equals(code)){
				return depManager.queryDepPersonQuantityByCode(code);
			}else{
				LOG.error("DepServiceImpl!queryDepPersonQuantityByCode(String code) param:" + code + " is null");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!queryDepPersonQuantityByCode(String code)  error!", e);
		}
		return new HashedMap();
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="DepServiceImpl.getDepByName")
	public Dep getDepByName(String name) {
		Dep dep = null;
		try {
			if(name!=null && !"".equals(name)){
				dep = depManager.getDepByName(name);
			}else{
				LOG.error("DepServiceImpl!getDepByName(String name) param: " + name + " Illegal!");
			}
		} catch (Exception e) {
			LOG.error("DepServiceImpl!getDepByName(String name) error!", e);
		}
		return dep;
	}

	

}
