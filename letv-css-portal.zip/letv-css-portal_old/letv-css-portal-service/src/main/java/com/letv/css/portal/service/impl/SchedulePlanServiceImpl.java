package com.letv.css.portal.service.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.SchedulePlan;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.query.SchedulePlanQuery;
import com.letv.css.portal.manager.SchedulePlanManager;
import com.letv.css.portal.service.SchedulePlanService;

/**
 * 总班表导入service实现类
 *
 * @Author menghan
 * @Version 2017-05-24 14:12:00
 */
@Service
public class SchedulePlanServiceImpl implements SchedulePlanService{

	private final static Log LOG = LogFactory.getLog(SchedulePlanServiceImpl.class);
	
	@Autowired
	private SchedulePlanManager schedulePlanManager;
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanServiceImpl.insert")
	public boolean insert(SchedulePlan schedulePlan) {
		boolean flag = false;
		try {
			if(schedulePlan!=null){
				flag = schedulePlanManager.insert(schedulePlan);
			}else{
				LOG.error("SchedulePlanServiceImpl.insert(SchedulePlan schedulePlan), param schedulePlan is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanServiceImpl.insert(SchedulePlan schedulePlan) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanServiceImpl.inserts")
	public boolean inserts(List<SchedulePlan> schedulePlans) {
		boolean flag = false;
		try {
			if(CollectionUtils.isNotEmpty(schedulePlans)){
				flag = schedulePlanManager.inserts(schedulePlans);
			}else{
				LOG.error("SchedulePlanServiceImpl.inserts(List<SchedulePlan> schedulePlans), param schedulePlans is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanServiceImpl.inserts(List<SchedulePlan> schedulePlans) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanServiceImpl.getSchedulePlanById")
	public SchedulePlan getSchedulePlanById(Long id) {
		SchedulePlan schedulePlan = null;
		try {
			if(id!=null && id.intValue()>0){
				schedulePlan = schedulePlanManager.getSchedulePlanById(id);
			}else{
				LOG.error("SchedulePlanServiceImpl.getSchedulePlanById(Long id) param: " + id + " Illegal!");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanServiceImpl.getSchedulePlanById(Long id) error",e);
		}
		return schedulePlan;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanServiceImpl.querySchedulePlanListWithPage")
	public List<SchedulePlan> querySchedulePlanListWithPage(
			SchedulePlanQuery query, PageUtil pageUtil) {
		List<SchedulePlan> schedulePlans = null;
		try {
			if(query!=null){
				schedulePlans = schedulePlanManager.querySchedulePlanListWithPage(query, pageUtil);
			}else{
				LOG.error("SchedulePlanServiceImpl.querySchedulePlanListWithPage(SchedulePlanQuery query, PageUtil pageUtil) param:" + query + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanServiceImpl.querySchedulePlanListWithPage(SchedulePlanQuery query,PageUtil pageUtil) error!", e);
		}
		return schedulePlans;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanServiceImpl.querySchedulePlanList")
	public List<SchedulePlan> querySchedulePlanList(SchedulePlanQuery query) {
		List<SchedulePlan> schedulePlans = null;
		try {
			if(query!=null){
				schedulePlans = schedulePlanManager.querySchedulePlanList(query);
			}else{
				LOG.error("SchedulePlanServiceImpl.querySchedulePlanList(SchedulePlanQuery query) param:" + query + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanServiceImpl.querySchedulePlanList(SchedulePlanQuery query) error!", e);
		}
		return schedulePlans;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "SchedulePlanServiceImpl.inserts")
	public boolean inserts(List<SchedulePlan> schedulePlans,
			List<SchedulePlanDetail> schedulePlanDetails) {
		boolean flag = false;
		try {
			if(CollectionUtils.isNotEmpty(schedulePlans) && CollectionUtils.isNotEmpty(schedulePlanDetails)){
				flag = schedulePlanManager.inserts(schedulePlans, schedulePlanDetails);
			}else{
				LOG.error("SchedulePlanServiceImpl.inserts(List<SchedulePlan> schedulePlans, List<SchedulePlanDetail> schedulePlanDetails) param is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulePlanServiceImpl.inserts(List<SchedulePlan> schedulePlans, List<SchedulePlanDetail> schedulePlanDetails) error ", e);
		}
		return flag;
	}

}
