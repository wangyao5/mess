package com.letv.css.portal.service;

import com.letv.css.portal.domain.JsonData;

/**
 * 审批提交数据service
 *
 * @Author menghan
 * @Version 2017-06-22 16:42:10
 */
public interface JsonDataService {

	/**
	 * 插入一条审批提交的数据
	 * @param
	 * @return
	 */
	boolean insert(JsonData jsonData);

	/**
	 * 根据ID查询实体
	 * @param id
	 * @return
     */
	JsonData getById(Long id);
}
