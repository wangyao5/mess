package com.letv.css.portal.service;

import com.letv.css.portal.domain.MenuLogs;

/**
 * 菜单访问日志service
 *
 * @Author menghan
 * @Version 2017-05-17 18:42:38
 */
public interface MenuLogsService {

	public boolean addLog(MenuLogs menulogs);
	
}
