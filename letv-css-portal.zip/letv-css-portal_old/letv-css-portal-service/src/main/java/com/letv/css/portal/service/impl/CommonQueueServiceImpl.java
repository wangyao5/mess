package com.letv.css.portal.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.letv.css.portal.dao.ResourceDao;
import com.letv.css.portal.dao.ResourceRoleDao;
import com.letv.css.portal.dao.RoleDao;
import com.letv.css.portal.dao.UserRoleDao;
import com.letv.css.portal.domain.Resource;
import com.letv.css.portal.domain.ResourceRole;
import com.letv.css.portal.domain.Role;
import com.letv.css.portal.domain.UserRole;
import com.letv.css.portal.domain.constant.enums.EventConstants;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.manager.CommonQueueManager;
import com.letv.css.portal.service.CommonQueueService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
public class CommonQueueServiceImpl implements CommonQueueService {

    private static final Log LOG = LogFactory.getLog(CommonQueueServiceImpl.class);
    
    
    @Value("#{'${portal.Authority}'.split(',')}")
    private String [] AuthorityLIST;

    @Autowired
    private CommonQueueManager commonQueueManager;
    
	@Autowired
	private UserRoleDao userRoleDao;
	
	@Autowired
	private ResourceDao resourceDao;
	

    @Profiled(tag = "CommonQueueServiceImpl.insert")
    public boolean insert(CommonQueue commonQueue) {
        boolean flag = false;
        try {
            if (commonQueue != null) {
                flag = commonQueueManager.insert(commonQueue);
            } else {
                LOG.error("【CommonQueueServiceImpl.insert】 dep param is null!");
            }
        } catch (Exception e) {
            LOG.error("【CommonQueueServiceImpl.insert(CommonQueue commonQueue)】 error!", e);
        }
        return flag;
    }
    
	public boolean updateAuthority(List<ResourceRole> newResourceRoles,Long uid,String createUser,String requestRemake){
		for(ResourceRole re:newResourceRoles){
			Resource r=resourceDao.getResourceById(re.getResId());
			if(r==null) LOG.info("【CommonQueueServiceImpl.updateAuthority get Resource id】 is null");
			for(String s:AuthorityLIST){
				if(s.equals(r.getCode())){
					CommonQueue commonQueue=new CommonQueue();
					commonQueue.setOnlyId(uid);
					commonQueue.setCreatedBy(createUser);
					commonQueue.setEventId(EventConstants.EVENT_ROLE);
					commonQueue.setChangeDate(new Date());
					commonQueue.setOnlyType("uesr id add");
					commonQueue.setStatus(0);
					commonQueue.setRequestRemake(requestRemake);
					insert(commonQueue);
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean updateAuthorityByRoles(List<ResourceRole> rrlist ,ResourceRole resourceRoles,String[] roleIds,String createUser,String requestRemake){
		Resource r=resourceDao.getResourceById(resourceRoles.getResId());
		if(r==null) LOG.info("【CommonQueueServiceImpl.updateAuthorityByRoles get Resource id】 is null");
		//从所有资源中找到减少的资源
		List<ResourceRole> rrslist=new ArrayList<ResourceRole>();
		if(!CollectionUtils.isEmpty(rrlist)){
			for (ResourceRole tr:rrlist){
				Long roleid=tr.getRoleId();
				boolean flag=true;
				for(String rid:roleIds) {
					if (rid.equals(String.valueOf(roleid))){
						flag=false;
						break;
					}
				}
				if (flag)rrslist.add(tr);
			}

		}
		//修改资源
		if(!CollectionUtils.isEmpty(rrslist)) {
			String[] arids = new String[rrlist.size()];
			for (int i = 0; i < rrslist.size(); i++) {
				arids[i] = String.valueOf(rrslist.get(i).getRoleId());
			}
			for (String s : AuthorityLIST) {
				if (s.equals(r.getCode())) {
					List<UserRole> ulist = userRoleDao.queryUsersIdListByRoleIds(arids);
					for (UserRole u : ulist) {
						CommonQueue commonQueue = new CommonQueue();
						commonQueue.setOnlyId(u.getUserId());
						commonQueue.setCreatedBy(createUser);
						commonQueue.setEventId(EventConstants.EVENT_ROLE);
						commonQueue.setChangeDate(new Date());
						commonQueue.setOnlyType("uesr id minus");
						commonQueue.setStatus(0);
						commonQueue.setRequestRemake(requestRemake);
						insert(commonQueue);
					}
				}
			}
		}

			for(String s:AuthorityLIST){
				if(s.equals(r.getCode())){
					List<UserRole> ulist=userRoleDao.queryUsersIdListByRoleIds(roleIds);
					for(UserRole u:ulist){
					CommonQueue commonQueue=new CommonQueue();
					commonQueue.setOnlyId(u.getUserId());
					commonQueue.setCreatedBy(createUser);
					commonQueue.setEventId(EventConstants.EVENT_ROLE);
					commonQueue.setChangeDate(new Date());
					commonQueue.setOnlyType("uesr id add");
					commonQueue.setStatus(0);
					commonQueue.setRequestRemake(requestRemake);
					insert(commonQueue);
					}
					return true;
				}
			}
		return false;
	}

	
	public boolean updateAuthority(Long uid, String createUser,String requestRemake) {
		CommonQueue commonQueue = new CommonQueue();
		commonQueue.setOnlyId(uid);
		commonQueue.setCreatedBy(createUser);
		commonQueue.setEventId(EventConstants.EVENT_ROLE);
		commonQueue.setChangeDate(new Date());
		commonQueue.setOnlyType("uesr id add");
		commonQueue.setStatus(0);
		commonQueue.setRequestRemake(requestRemake);
		insert(commonQueue);
		return true;
	}

}
