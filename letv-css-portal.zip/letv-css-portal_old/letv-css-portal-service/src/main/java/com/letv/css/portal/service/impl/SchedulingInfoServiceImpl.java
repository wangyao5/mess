package com.letv.css.portal.service.impl;

import java.util.List;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.SchedulingInfo;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;
import com.letv.css.portal.manager.SchedulingInfoManager;
import com.letv.css.portal.service.SchedulingInfoService;

/**
 * 排班信息表service实现类
 *
 * @Author menghan
 * @Version 2017-06-21 11:38:51
 */
@Service
public class SchedulingInfoServiceImpl implements SchedulingInfoService{

	private static final Log LOG = LogFactory.getLog(SchedulingInfoServiceImpl.class);
	
	@Autowired
	private SchedulingInfoManager schedulingInfoManager;
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="SchedulingInfoServiceImpl.querySchedulingInfoList")
	public List<SchedulingInfo> querySchedulingInfoList(
			SchedulingInfoQuery queryBean) {
		List<SchedulingInfo> list = null;
		try {
			if(queryBean!=null){
				list = schedulingInfoManager.querySchedulingInfoList(queryBean);
			}else{
				LOG.error("SchedulingInfoServiceImpl!querySchedulingInfoList(SchedulingInfoQuery queryBean) param:" + queryBean + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulingInfoServiceImpl!querySchedulingInfoList(SchedulingInfoQuery queryBean) error!", e);
		}
		return list;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="SchedulingInfoServiceImpl.querySchedulingInfoListWithPage")
	public List<SchedulingInfo> querySchedulingInfoListWithPage(
			SchedulingInfoQuery queryBean, PageUtil pageUtil) {
		List<SchedulingInfo> list = null;
		try {
			if(queryBean!=null){
				list = schedulingInfoManager.querySchedulingInfoListWithPage(queryBean,pageUtil);
			}else{
				LOG.error("SchedulingInfoServiceImpl!querySchedulingInfoListWithPage(SchedulingInfoQuery queryBean, PageUtil pageUtil) param:" + queryBean + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulingInfoServiceImpl!querySchedulingInfoListWithPage(SchedulingInfoQuery queryBean, PageUtil pageUtil) error!", e);
		}
		return list;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="SchedulingInfoServiceImpl.updateByApplyFlow")
	public boolean updateByApplyFlow(SchedulingInfoQuery queryBean){
		boolean flag=false;
		try {
			if(queryBean!=null){
				flag= schedulingInfoManager.updateByApplyFlow(queryBean);
			}else{
				LOG.error("SchedulingInfoServiceImpl!updateByApplyFlow(SchedulingInfoQuery queryBean, PageUtil pageUtil) param:" + queryBean + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulingInfoServiceImpl!updateByApplyFlow(SchedulingInfoQuery queryBean, PageUtil pageUtil) error!", e);
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="SchedulingInfoServiceImpl.update")
	public boolean update(SchedulingInfoQuery queryBean){
		boolean flag=false;
		try {
			if(queryBean!=null){
				flag= schedulingInfoManager.update(queryBean);
			}else{
				LOG.error("SchedulingInfoServiceImpl!update(SchedulingInfoQuery queryBean, PageUtil pageUtil) param:" + queryBean + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulingInfoServiceImpl!update(SchedulingInfoQuery queryBean, PageUtil pageUtil) error!", e);
		}
		return flag;
	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="SchedulingInfoServiceImpl.updateAdjInfo")
	public boolean updateAdjInfo(SchedulingInfoQuery queryBean) {
		boolean flag=false;
		try {
			if(queryBean != null && queryBean.getIds()!=null){
				schedulingInfoManager.updateAdjInfo(queryBean);
			}else{
				LOG.error("SchedulingInfoServiceImpl!updateAdjInfo(SchedulingInfoQuery queryBean)param:" + queryBean + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulingInfoServiceImpl!updateAdjInfo(SchedulingInfoQuery queryBean) error!", e);
		}
		return flag;


	}
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="SchedulingInfoServiceImpl.insert")
	public boolean insert(SchedulingInfo queryBean){
		boolean flag=false;
		try {
			if(queryBean!=null){
				flag= schedulingInfoManager.insert(queryBean);
			}else{
				LOG.error("SchedulingInfoServiceImpl!insert(SchedulingInfo queryBean) param:" + queryBean + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulingInfoServiceImpl!insert(SchedulingInfo queryBean) error!", e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="SchedulingInfoServiceImpl.querySchedulingInfoByTime")
	public List<SchedulingInfo> querySchedulingInfoByTime(
			SchedulingInfo schedulingInfo) {
		List<SchedulingInfo> list = null;
		try {
			if(schedulingInfo != null){
				list = schedulingInfoManager.querySchedulingInfoByTime(schedulingInfo);
			}else{
				LOG.error("SchedulingInfoServiceImpl!querySchedulingInfoByTime(SchedulingInfo schedulingInfo) param:" + schedulingInfo + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulingInfoServiceImpl!querySchedulingInfoByTime(SchedulingInfo schedulingInfo) error!", e);
		}
		return list;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag="SchedulingInfoServiceImpl.getSchedulingInfoById")
	public SchedulingInfo getSchedulingInfoById(Long id) {
		SchedulingInfo schedulingInfo = null;
		try {
			if(id !=null && id>0){
				schedulingInfo = schedulingInfoManager.getSchedulingInfoById(id);
			}else{
				LOG.error("SchedulingInfoServiceImpl!getSchedulingInfoById(Long id) param:" + id + "is null");
			}
		} catch (Exception e) {
			LOG.error("SchedulingInfoServiceImpl!getSchedulingInfoById(Long id) error!", e);
		}
		return schedulingInfo;
	}
}
