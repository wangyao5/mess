package com.letv.css.portal.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.User;
//import com.letv.css.portal.domain.UserCost;
import com.letv.css.portal.domain.query.UserQuery;
import com.letv.css.portal.domain.query.UserRoleQuery;
import com.letv.css.portal.manager.DepManager;
import com.letv.css.portal.manager.UserManager;
import com.letv.css.portal.service.UserService;

/**
 * User: gaohongjing Date: 2014-04-15 Time: 10:22:04
 */
@Service
public class UserServiceImpl implements UserService {
    private final static Log log = LogFactory.getLog(UserServiceImpl.class);
    @Autowired
    private UserManager userManager;
    
//    @Autowired
//    private DepManager depManager;

    @Profiled(tag = "UserService.batchInsert")
    public boolean insert(List<User> beanList) {
        boolean resultFlag = false;
        try {
            resultFlag = userManager.insert(beanList);
        } catch (Exception e) {
            log.error("UserServiceImpl -> insert() error!!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "UserService.insert")
    public boolean insert(User bean) {
        boolean resultFlag = false;
        try {
            if (null != bean) {
                resultFlag = userManager.insert(bean);
            } else {
                log.error("param is null!");
            }
        } catch (Exception e) {
            log.error("UserServiceImpl!insert(User bean) error!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "UserService.update")
    public boolean update(User bean) {
        boolean resultFlag = false;
        try {
            resultFlag = userManager.update(bean);
        } catch (Exception e) {
            log.error("UserServiceImpl!update(User bean) error!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "UserService.queryUserList")
    public List<User> queryUserList(UserQuery queryBean) {
        List<User> userList = null;
        try {
            userList = userManager.queryUserList(queryBean);
        } catch (Exception e) {
            log.error("UserServiceImpl -> queryUserList() error!!", e);
        }
        return userList;
    }

    @Profiled(tag = "UserService.queryUserListWithPage")
    public List<User> queryUserListWithPage(UserQuery queryBean, PageUtil pageUtil) {
        List<User> userList = null;
        try {
            userList = userManager.queryUserListWithPage(queryBean, pageUtil);
        } catch (Exception e) {
            log.error("UserServiceImpl -> queryUserPages() error!!", e);
        }
        return userList;
    }
    
    @Profiled(tag = "UserService.queryUserListWithPage4Side")
    public List<User> queryUserListWithPage4Side(UserQuery queryBean, PageUtil pageUtil) {
        List<User> userList = null;
        try {
            userList = userManager.queryUserListWithPage4Side(queryBean, pageUtil);
        } catch (Exception e) {
            log.error("UserServiceImpl -> queryUserPages() error!!", e);
        }
        return userList;
    }

    @Profiled(tag = "UserService.delete")
    public boolean delete(Long id) {
        boolean resultFlag = false;
        try {
            if (null != id && id.intValue() > 0) {
                resultFlag = userManager.delete(id);
            } else {
                log.error("UserServiceImpl!delete(Long id) param: " + id + " Illegal!");
            }
        } catch (Exception e) {
            log.error("UserServiceImpl!delete(Integer id) error!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "UserService.batchDelete")
    public boolean delete(String[] ids) {
        boolean resultFlag = false;
        try {
            resultFlag = userManager.delete(ids);
        } catch (Exception e) {
            log.error("UserServiceImpl -> delete() error!!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "UserService.getUserById")
    public User getUserById(Long id) {
        User user = null;
        try {
            user = userManager.getUserById(id);
        } catch (Exception e) {
            log.error("UserServiceImpl!getUserById(Integer id) error!", e);
        }
        return user;
    }

    @Profiled(tag = "UserService.getUserByName")
    public User getUserByUsername(String name) {
        User user = null;
        try {
            if (StringUtils.isEmpty(name)) {
                throw new IllegalArgumentException("argument [name] must be net null");
            }
            user = userManager.getUserByUsername(name);
        } catch (Exception e) {
            log.error("UserServiceImpl!getUserByName(String name) error!", e);
        }
        return user;
    }

    @Profiled(tag = "UserService.exist")
    public boolean exist(User user) {
        if (null == user) {
            return false;
        }
        return null != this.getUserByUsername(user.getName());
    }

	@Override
	public List<User> queryUserDepStaffListWhere(UserQuery queryBean,
			PageUtil pageUtil) {
		List<User> userList = null;
        try {
            userList = userManager.queryUserDepStaffListWhere(queryBean, pageUtil);
        } catch (Exception e) {
            log.error("UserServiceImpl -> queryUserDepStaffListWhere() error!!", e);
        }
        return userList;
	}

	@Override
	public User getUserByStaffId(Long staffId) {
		User user = null;
        try {
            if (staffId==null || staffId<=0) {
                throw new IllegalArgumentException("argument [staffId] must be net null");
            }
            user = userManager.getUserByStaffId(staffId);
        } catch (Exception e) {
            log.error("UserServiceImpl!getUserByStaffId(Long staffId) error!", e);
        }
        return user;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "UserService.queryUsersByIds")
	public List<User> queryUsersByIds(String[] ids) {
		List<User> userList = null;
        try {
            userList = userManager.queryUsersByIds(ids);
        } catch (Exception e) {
            log.error("UserServiceImpl -> queryUsersByIds() error!!", e);
        }
        return userList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "UserService.getAllUsers")
	public List<User> getAllUsers() {
		List<User> userList = null;
        try {
            userList = userManager.getAllUsers();
        } catch (Exception e) {
            log.error("UserServiceImpl -> getAllUsers() error!!", e);
        }
        return userList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "UserService.queryAvailableUserList")
	public List<User> queryAvailableUserList(Long roleId) {
		List<User> userList = null;
        try {
            userList = userManager.queryAvailableUserList(roleId);
        } catch (Exception e) {
            log.error("UserServiceImpl -> queryAvailableUserList(roleId) error!!", e);
        }
        return userList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "UserService.queryConfigedUserList")
	public List<User> queryConfigedUserList(Long roleId) {
		List<User> userList = null;
        try {
            userList = userManager.queryConfigedUserList(roleId);
        } catch (Exception e) {
            log.error("UserServiceImpl -> queryConfigedUserList(Long roleId) error!!", e);
        }
        return userList;
	}

//    @Profiled(tag = "UserService.getUserCost")
//	public List<UserCost> getUserCost(UserQuery query) {
//    	 List<User> userList = null;
//    	 List<UserCost> userCosts = new ArrayList<UserCost>();
//         try {
//             userList = userManager.queryUserCost(query);
//             if(userList != null){
//            	 for (User user : userList) {
//            		 UserCost userCost = new UserCost();
//            		 userCost.setCnName(user.getCnName());
//            		 userCost.setCostCenter(user.getCostCenter());
//            		 userCost.setEmail(user.getEmail());
//            		 userCost.setName(user.getName());
//            		 userCost.setId(user.getId());
//            		 userCost.setCode(user.getCode());
//            		 Dep dep= user.getDep();
//            		 String DepName = null;
//            		 if(dep!=null && StringUtils.isNotBlank(dep.getCode())){
//            			 userCost.setDepCode(user.getDep().getCode());
////            			 DepName = depManager.queryDepName(dep.getCode());
//            		 }else{
//            			 userCost.setDepCode("Default");
//            		 }
//            		 if(StringUtils.isNotBlank(DepName)){  
//            			 userCost.setDepName(DepName);
//            		 }else{
//            			 userCost.setDepName("Default");
//            		 }
//            		 userCosts.add(userCost);
//            	 }
//             }
//         } catch (Exception e) {
//             log.error("UserServiceImpl -> getUserCost() error!!", e);
//         }
//         return userCosts;
//	}
}
