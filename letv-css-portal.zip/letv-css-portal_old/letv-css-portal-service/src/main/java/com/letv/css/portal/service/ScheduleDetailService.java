package com.letv.css.portal.service;

import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.query.ScheduleDetailQuery;

import java.util.List;

/**
 * 操作BPO排班表明细service
 *
 * @Author yxh
 * @Version 2017-06-01 18:07:08
 */
public interface ScheduleDetailService {
	/**
	 * 插入一条BPO排班表明细记录
	 * @param
	 * @return
	 */
	boolean insert(ScheduleDetail scheduleDetail);
	
	/**
	 * 批量插入BPO排班表明细记录
	 * @param
	 * @return
	 */
	boolean inserts(List<ScheduleDetail> scheduleDetails);
	
	/***
	 * 根据BPO排班表Id查询BPO排班表明细列表
	 * @param
	 * @return
	 */
	List<ScheduleDetail> queryScheduleDetailList(ScheduleDetailQuery query);
	
	/***
	 * 修改BPO排班表明细信息
	 * @param
	 * @return
	 */
	boolean update(ScheduleDetail scheduleDetail);
	
	/**
	 * 根据ID删除BPO排班表明细信息
	 * @param
	 * @return
	 */
	boolean delete(Long id);
	
	/**
	 * 根据query，批量删除BPO排班表明细信息
	 * @param
	 * @return
	 */
	boolean deletes(ScheduleDetailQuery query);
	
	/**
	 * 根据ID删除BPO排班表明细信息
	 * @param
	 * @return
	 */
	boolean deleteBySid(Long Sid);
}
