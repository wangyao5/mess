package com.letv.css.portal.service.impl;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.PreShifts;
import com.letv.css.portal.domain.query.PreShiftsQuery;
import com.letv.css.portal.manager.PreShiftsManager;
import com.letv.css.portal.service.PreShiftsService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * yxh 2017年8月29日 13:33:47
 */
@Service
public class PreShiftsServiceImpl implements PreShiftsService {
    private final static Log log = LogFactory.getLog(PreShiftsServiceImpl.class);
    @Autowired
    private PreShiftsManager PreShiftsManager;

    @Profiled(tag = "PreShiftsService.batchInsert")
    public boolean insert(List<PreShifts> beanList) {
        boolean resultFlag = false;
        try {
            resultFlag = PreShiftsManager.insert(beanList);
        } catch (Exception e) {
            log.error("PreShiftsServiceImpl -> insert() error!!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "PreShiftsService.insert")
    public boolean insert(PreShifts bean) {
        boolean resultFlag = false;
        try {
            if (null != bean) {
                resultFlag = PreShiftsManager.insert(bean);
            } else {
                log.error("param is null!");
            }
        } catch (Exception e) {
            log.error("PreShiftsServiceImpl!insert(PreShifts bean) error!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "PreShiftsService.update")
    public boolean update(PreShifts bean) {
        boolean resultFlag = false;
        try {
            resultFlag = PreShiftsManager.update(bean);
        } catch (Exception e) {
            log.error("PreShiftsServiceImpl!update(PreShifts bean) error!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "PreShiftsService.queryPreShiftsList")
    public List<PreShifts> queryPreShiftsList(PreShiftsQuery queryBean) {
        List<PreShifts> PreShiftsList = null;
        try {
            PreShiftsList = PreShiftsManager.queryPreShiftsList(queryBean);
        } catch (Exception e) {
            log.error("PreShiftsServiceImpl -> queryPreShiftsList() error!!", e);
        }
        return PreShiftsList;
    }

    @Profiled(tag = "PreShiftsService.queryPreShiftsListWithPage")
    public List<PreShifts> queryPreShiftsListWithPage(PreShiftsQuery queryBean, PageUtil pageUtil) {
        List<PreShifts> PreShiftsList = null;
        try {
            PreShiftsList = PreShiftsManager.queryPreShiftsListWithPage(queryBean, pageUtil);
        } catch (Exception e) {
            log.error("PreShiftsServiceImpl -> queryPreShiftsPages() error!!", e);
        }
        return PreShiftsList;
    }
    
    @Profiled(tag = "PreShiftsService.queryPreShiftsListWithPage4Side")
    public List<PreShifts> queryPreShiftsListWithPage4Side(PreShiftsQuery queryBean, PageUtil pageUtil) {
        List<PreShifts> PreShiftsList = null;
        try {
            PreShiftsList = PreShiftsManager.queryPreShiftsListWithPage4Side(queryBean, pageUtil);
        } catch (Exception e) {
            log.error("PreShiftsServiceImpl -> queryPreShiftsPages() error!!", e);
        }
        return PreShiftsList;
    }

    @Profiled(tag = "PreShiftsService.delete")
    public boolean delete(Long id) {
        boolean resultFlag = false;
        try {
            if (null != id && id.intValue() > 0) {
                resultFlag = PreShiftsManager.delete(id);
            } else {
                log.error("PreShiftsServiceImpl!delete(Long id) param: " + id + " Illegal!");
            }
        } catch (Exception e) {
            log.error("PreShiftsServiceImpl!delete(Integer id) error!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "PreShiftsService.batchDelete")
    public boolean delete(String[] ids) {
        boolean resultFlag = false;
        try {
            resultFlag = PreShiftsManager.delete(ids);
        } catch (Exception e) {
            log.error("PreShiftsServiceImpl -> delete() error!!", e);
        }
        return resultFlag;
    }

    @Profiled(tag = "PreShiftsService.getPreShiftsById")
    public PreShifts getPreShiftsById(Long id) {
        PreShifts PreShifts = null;
        try {
            PreShifts = PreShiftsManager.getPreShiftsById(id);
        } catch (Exception e) {
            log.error("PreShiftsServiceImpl!getPreShiftsById(Integer id) error!", e);
        }
        return PreShifts;
    }
}
