package com.letv.css.portal.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letv.common.utils.DateHelper;
import com.letv.css.portal.clients.sso.SsoDataCenterClient;
import com.letv.css.portal.clients.sso.SsoUserClient;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.constant.CommonConstants;
//import com.letv.css.portal.manager.DepManager;
import com.letv.css.portal.manager.UserManager;
import com.letv.css.portal.service.SyncDataService;

/**
 * 数据同步服务
 * 
 * @author zhaohengchong
 * @email zhaohengchong@letv.com
 * @version 2014-4-15 下午04:30:58
 */
@Service("syncDataService")
public class SyncDataServiceImpl implements SyncDataService {

	@Autowired
	private UserManager userManager;

//	@Autowired
//	private DepManager depManager;

	@Autowired
	private SsoDataCenterClient ssoDataCenterClient;

	@Autowired
	private SsoUserClient ssoUserClient;

	private final static Log log = LogFactory.getLog(SSOServiceImpl.class);

	@Profiled(tag = "SyncDataService.executeDep")
	public void executeDep() {
		try {
			List<Map<String, Object>> depDtos = ssoDataCenterClient.getDepData();
			List<Dep> deps = toDepList(depDtos);
//			this.depManager.syncDepDatas(deps);
		} catch (Exception e) {
			log.error("SyncDataService executeDep has error,", e);
		}
	}

	@Profiled(tag = "SyncDataService.executeUser")
	public void executeUser() {
		try {

			List<Map<String, Object>> userDtos = ssoDataCenterClient.getUserData();
			List<User> users = toUserList(userDtos);
			this.syncUserDatas(users);
		} catch (Exception e) {
			log.error("SyncDataService executeUser has error,", e);
		}
	}

	int syncUserDatas(List<User> users) {
		int c = 0;
		int i = 0;
		if (users != null && users.size() > 0) {
			for (User user : users) {
				if(StringUtils.isBlank(user.getEmail()) || StringUtils.isBlank(user.getUsername())){
					continue;
				}
				int a = this.userManager.insertSyncUser(user);
				c += a;
				i += 1;
			log.info("SSO总共记录：【" + users.size() + "】条。正在執行"+ i  + "条。");
			}
		}
		log.info("SSO总共记录：【" + users.size() + "】条。同步成功"+ c + "条。");

		// 返回操作数据库条数
		return c;
	}

	@Profiled(tag = "SyncDataService.syncUser")
	public User syncUser(String username) {
		User user = null;
		try {
			Map<String, Object> userMap = ssoUserClient.queryUser(username);
			if (userMap != null && !userMap.isEmpty()) {
				List<Map<String, Object>> userMapList = new ArrayList<Map<String, Object>>(1);
				userMapList.add(userMap);
				List<User> users = this.toUserList(userMapList);
				int count = this.userManager.syncUserDatas(users);
				if (count > 0) {
					user = users.get(0);
				}
			}
		} catch (Exception e) {
			log.error("SyncDataService syncUser has error,", e);
		}
		return user;
	}

	private List<Dep> toDepList(List<Map<String, Object>> depDtoMaps) {
		if (depDtoMaps == null || depDtoMaps.size() <= 0) {
			return null;
		}
		List<Dep> deps = new ArrayList<Dep>();
		for (Map<String, Object> depMap : depDtoMaps) {
			Dep dep = new Dep();
			dep.setLevel((Integer) depMap.get("level"));
			dep.setCode((String) depMap.get("org_num"));
			dep.setName((String) depMap.get("org_name"));
//			dep.setParentCode((String) depMap.get("pnum"));
			dep.setLastModifyTime(DateHelper.toDate((Long) depMap.get("last_modify_date")));
			dep.setEffect((Integer) depMap.get("effect"));
			deps.add(dep);
		}
		return deps;
	}

	private List<User> toUserList(List<Map<String, Object>> userDtoMaps) {
		if (userDtoMaps == null || userDtoMaps.isEmpty()) {
			return null;
		}

		List<User> users = new ArrayList<User>();
		for (Map<String, Object> userMap : userDtoMaps) {
			User user = new User();
			user.setCode((String) userMap.get("staff_no"));
			user.setCostCenter((String) userMap.get("cost_center"));
			user.setUsername(((String) userMap.get("username")).split("@")[0]);
			user.setName((String) userMap.get("nickname"));
			if (CommonConstants.SYNC_USER_STATUS_OFF.equals((String) userMap.get("status"))) {
				user.setStatus(CommonConstants.USER_STATUS_OFF);
			} else {
				user.setStatus(CommonConstants.USER_STATUS_ON);
			}

			String orgNum = (String) userMap.get("org_num");
//			if (StringUtils.isNotBlank(orgNum)) {
//				Dep dep = this.depManager.getDepByCode(orgNum);
//				if (dep != null) {
//					user.setDepId(dep.getId());
//				}
//			}

			user.setUserType(CommonConstants.USER_TYPE_INNER);
			user.setPhoneNo((String) userMap.get("phone"));
			user.setEmail((String) userMap.get("email"));
			user.setJobTitle((String) userMap.get("job_title"));
			Object lastModifyDate = userMap.get("last_modify_date");
			if (lastModifyDate != null) {
				user.setLastModifyTime(DateHelper.toDate((Long) userMap.get("last_modify_date")));
			} else {
				user.setLastModifyTime(new Date());
			}
			users.add(user);
		}
		return users;
	}
}
