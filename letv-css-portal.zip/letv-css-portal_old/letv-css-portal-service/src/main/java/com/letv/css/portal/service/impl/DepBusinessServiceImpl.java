package com.letv.css.portal.service.impl;

import com.letv.css.portal.domain.DepBusiness;
import com.letv.css.portal.manager.DepBusinessManager;
import com.letv.css.portal.service.DepBusinessService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepBusinessServiceImpl implements DepBusinessService {

    private final static Log log = LogFactory.getLog(ResourceRoleServiceImpl.class);
    @Autowired
    private DepBusinessManager depBusinessManager;

    @Override
    public List<DepBusiness> queryByDepId(Long depId) {
        List<DepBusiness> list = null;
        try {
            list = depBusinessManager.queryByDepId(depId);
        } catch (Exception e) {
            log.error("DepBusinessServiceImpl -> queryByDepId() error!!", e);
        }
        return list;
    }

    @Override
    public boolean insert(DepBusiness depBusiness) {
        boolean flag = false;
        try {
            if(null!=depBusiness){
                flag = depBusinessManager.insert(depBusiness);
            }else{
                log.error("param is null!");
            }
        } catch (Exception e) {
            log.error("DepBusinessServiceImpl -> insert(DepBusiness depBusiness) error", e);
        }
        return flag;
    }

    @Override
    public boolean update(DepBusiness depBusiness) {
        boolean flag = false;
        try {
            if(depBusiness!=null){
                flag = depBusinessManager.update(depBusiness);
            }else{
                log.error("【DepBusinessServiceImpl.update】 depBusiness param is null!");
            }
        } catch (Exception e) {
            log.error("【DepBusinessServiceImpl.update(DepBusiness depBusiness)】 error!",e);
        }
        return flag;
    }
}
