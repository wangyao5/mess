package com.letv.css.portal.service;

import com.letv.css.portal.domain.ApprovalManage;
import com.letv.css.portal.domain.query.ApprovalManageQuery;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 审批管理service
 *
 * @Author menghan
 * @Version 2017-06-22 17:44:32
 */
public interface ApprovalManageService {

	/**
	 * 插入
	 * @param
	 * @return
	 */
	boolean insert(ApprovalManage approvalManage);
	
	/**
	 * 批量插入
	 * @param
	 * @return
	 */
	boolean inserts(List<ApprovalManage> approvalManages);
	
	/**
	 * 修改
	 * @param
	 * @return
	 */
	boolean update(ApprovalManage approvalManage);

	/**
	 * 查询List
	 */
	public List<ApprovalManage> queryAppManageList(Long jdId);

	/**
	 * 更新记录已经确认
	 * @param siId
	 * @return
     */
	boolean updateConfirmBySiId(String siId);
	/**
	 * 更新记录已经完成
	 */
	boolean updateFinishByJdId(String siId);
	/**
	 * 处理班次调整业务
	 * @return
     */
	boolean applyShiftsAdjust(String siIds,String  adjustType,int adjustTime,Long userId);
	/**
	 * 处理班临时请假整业务
	 * @return
     */
	boolean applyTempLeaveAdjust(String siIds,String tempLeaveType,String  timeType,int adjustTime,Long userId);

	/**
	 * 处理班次交换
     */
	boolean updateApplyShift(String siIds,String shiftSiId,Long userId);


	boolean initSchedulAndApproval(Map<String,String> paramMap);

	/**
	 * 根据
	 *
	 * @param approvalManageQuery
	 * @return
	 */
	Integer queryAppManageCount(ApprovalManageQuery approvalManageQuery);

	Integer queryValidCount(ApprovalManageQuery approvalManageQuery);

	boolean updateByJdId(String jdId);
}
