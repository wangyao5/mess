package com.letv.css.portal.service;

import com.letv.css.portal.domain.AdjustChange;

public interface AdjustChangeService {
	AdjustChange selectById(Long id);

}
