package com.letv.css.portal.service;

import com.letv.css.portal.domain.ThresholdValue;

/**
 * 阈值参数
 * @Author gexuliang
 */
public interface ThresholdValueService {
	
	ThresholdValue getInfoByCode (String code);
}
