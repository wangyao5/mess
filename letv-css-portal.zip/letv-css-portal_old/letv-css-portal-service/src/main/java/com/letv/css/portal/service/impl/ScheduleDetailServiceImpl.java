package com.letv.css.portal.service.impl;

import com.letv.common.utils.serialize.JsonHelper;
import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.query.ScheduleDetailQuery;
import com.letv.css.portal.manager.ScheduleDetailManager;
import com.letv.css.portal.service.ScheduleDetailService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 操作BPO排班表明细service实现类
 *
 * @Author yxh
 * @Version 2017-06-01 18:08:32
 */
@Service
public class ScheduleDetailServiceImpl implements ScheduleDetailService{

	private final static Log LOG = LogFactory.getLog(ScheduleDetailServiceImpl.class);

	@Autowired
	private ScheduleDetailManager scheduleDetailManager;

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "ScheduleDetailServiceImpl.insert")
	public boolean insert(ScheduleDetail scheduleDetail) {
		boolean flag = false;
		try {
			if(scheduleDetail!=null){
				flag = scheduleDetailManager.insert(scheduleDetail);
			}else{
				LOG.error("ScheduleDetailServiceImpl.insert(ScheduleDetail scheduleDetail), param scheduleDetail is null");
			}
		} catch (Exception e) {
			LOG.error("ScheduleDetailServiceImpl.insert(ScheduleDetail scheduleDetail) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "ScheduleDetailServiceImpl.inserts")
	public boolean inserts(List<ScheduleDetail> scheduleDetails) {
		boolean flag = false;
		try {
			if(CollectionUtils.isNotEmpty(scheduleDetails)){
				flag = scheduleDetailManager.inserts(scheduleDetails);
			}else{
				LOG.error("ScheduleDetailServiceImpl.inserts(List<ScheduleDetail> scheduleDetails), param scheduleDetails is null");
			}
		} catch (Exception e) {
			LOG.error("ScheduleDetailServiceImpl.inserts(List<ScheduleDetail> scheduleDetails) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "ScheduleDetailServiceImpl.queryScheduleDetailList")
	public List<ScheduleDetail> queryScheduleDetailList(ScheduleDetailQuery query) {
		List<ScheduleDetail> scheduleDetails = null;
		try {
			if(query!=null){
				scheduleDetails = scheduleDetailManager.queryScheduleDetailList(query);
			}else{
				LOG.error("ScheduleDetailServiceImpl.queryScheduleDetailList(Long spId) param:" + JsonHelper.toJson(query) + " is null");
			}
		} catch (Exception e) {
			LOG.error("ScheduleDetailServiceImpl.queryScheduleDetailList(Long spId) error!", e);
		}
		return scheduleDetails;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "ScheduleDetailServiceImpl.update")
	public boolean update(ScheduleDetail scheduleDetail) {
		boolean flag = false;
		try {
			if(scheduleDetail!=null){
				flag = scheduleDetailManager.update(scheduleDetail);
			}else{
				LOG.error("ScheduleDetailServiceImpl.update(ScheduleDetail scheduleDetail) param: "+scheduleDetail +" is null");
			}
		} catch (Exception e) {
			LOG.error("ScheduleDetailServiceImpl.update(ScheduleDetail scheduleDetail) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "ScheduleDetailServiceImpl.delete")
	public boolean delete(Long id) {
		boolean flag = false;
		try {
			if(id!=null && id.intValue()>0){
				flag = scheduleDetailManager.delete(id);
			}else{
				LOG.error("ScheduleDetailServiceImpl.delete(Long id) param: "+id +" is null");
			}
		} catch (Exception e) {
			LOG.error("ScheduleDetailServiceImpl.delete(Long id) error!",e);
		}
		return flag;
	}

	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "ScheduleDetailServiceImpl.deletes")
	public boolean deletes(ScheduleDetailQuery query) {
		boolean flag = false;
		try {
			if(query!=null){
				flag = scheduleDetailManager.deletes(query);
			}else{
				LOG.error("ScheduleDetailServiceImpl.deletes(ScheduleDetailQuery query) param: "+query +" is null");
			}
		} catch (Exception e) {
			LOG.error("ScheduleDetailServiceImpl.deletes(ScheduleDetailQuery query) error!",e);
		}
		return flag;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Profiled(tag = "ScheduleDetailServiceImpl.deleteBySid")
	public boolean deleteBySid(Long Sid) {
		boolean flag = false;
		try {
			if(Sid!=null && Sid.intValue()>0){
				flag = scheduleDetailManager.deleteBySid(Sid);
			}else{
				LOG.error("ScheduleDetailServiceImpl.deleteBySid(Long Sid) param: "+Sid +" is null");
			}
		} catch (Exception e) {
			LOG.error("ScheduleDetailServiceImpl.delete(Long id) error!",e);
		}
		return flag;
	}

}
