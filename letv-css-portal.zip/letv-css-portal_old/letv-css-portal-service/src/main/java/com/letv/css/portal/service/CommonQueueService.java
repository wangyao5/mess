package com.letv.css.portal.service;

import java.util.List;

import com.letv.css.portal.domain.ResourceRole;
import com.letv.css.portal.domain.query.CommonQueue;

public interface CommonQueueService {

    boolean insert(CommonQueue commonQueue);
    
    boolean updateAuthority(List<ResourceRole> newResourceRoles,Long uid,String createUser,String requestRemake);
    
    boolean updateAuthorityByRoles(List<ResourceRole> rrlist ,ResourceRole resourceRoles,String[] roleIds,String createUser,String requestRemake);
    
    boolean updateAuthority(Long uid, String createUser,String requestRemake);

}
