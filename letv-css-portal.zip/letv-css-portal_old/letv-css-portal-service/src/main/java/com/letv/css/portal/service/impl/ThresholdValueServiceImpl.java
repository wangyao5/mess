package com.letv.css.portal.service.impl;

import com.letv.css.portal.domain.ThresholdValue;
import com.letv.css.portal.manager.ThresholdValueManager;
import com.letv.css.portal.service.ThresholdValueService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 阈值参数 实现类
 *
 * @Author gexuliang
 */
@Service
public class ThresholdValueServiceImpl implements ThresholdValueService{

	private final static Log LOG = LogFactory.getLog(ThresholdValueServiceImpl.class);

	@Autowired
	private ThresholdValueManager thresholdValueManager;


	@Profiled(tag = "ThresholdValueService.getInfoByCode")
	public ThresholdValue getInfoByCode(String code) {
		ThresholdValue thresholdValue = null;
		try {
			thresholdValue = thresholdValueManager.getInfoByCode(code);
		} catch (Exception e) {
			LOG.error("ThresholdValueService -> getInfoByCode() error", e);
		}
		return thresholdValue;
	}
	
}
