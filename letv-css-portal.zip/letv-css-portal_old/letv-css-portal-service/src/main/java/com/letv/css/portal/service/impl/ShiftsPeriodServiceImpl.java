package com.letv.css.portal.service.impl;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.ShiftsPeriod;
import com.letv.css.portal.domain.query.ShiftsPeriodQuery;
import com.letv.css.portal.manager.ShiftsPeriodManager;
import com.letv.css.portal.service.ShiftsPeriodService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by yangxinghe on 2017/5/16.
 */
@Service
public class ShiftsPeriodServiceImpl implements ShiftsPeriodService {
    private final static Log log = LogFactory.getLog(ShiftsPeriodServiceImpl.class);
    @Autowired
    private ShiftsPeriodManager shiftsPeriodManager;

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsPeriodServiceImpl.queryShiftsPeriodList")
    public List<ShiftsPeriod> queryShiftsPeriodList(ShiftsPeriodQuery query) {
        List<ShiftsPeriod> ShiftsPeriodList = null;
        try {
            if (query != null) {
                ShiftsPeriodList = shiftsPeriodManager.queryShiftsPeriodList(query);
            } else {
                log.error("ShiftsPeriodServiceImpl!queryShiftsPeriodList(ShiftsPeriodQuery query) param:" + query + "is null");
            }
        } catch (Exception e) {
            log.error("ShiftsPeriodServiceImpl!queryShiftsPeriodList(ShiftsPeriodQuery query) error!", e);
        }
        return ShiftsPeriodList;
    }


    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsPeriodServiceImpl.queryShiftsPeriodListWithPage")
    public List<ShiftsPeriod> queryShiftsPeriodListWithPage(ShiftsPeriodQuery query, PageUtil pageUtil) {
        List<ShiftsPeriod> ShiftsPeriodList = null;
        try {
            if (query != null) {
                ShiftsPeriodList = shiftsPeriodManager.queryShiftsPeriodListWithPage(query, pageUtil);
            } else {
                log.error("ShiftsPeriodServiceImpl!queryShiftsPeriodList(ShiftsPeriodQuery query) param:" + query + "is null");
            }
        } catch (Exception e) {
            log.error("ShiftsPeriodServiceImpl!queryShiftsPeriodList(ShiftsPeriodQuery query) error!", e);
        }
        return ShiftsPeriodList;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsPeriodServiceImpl.insert")
    public boolean insert(ShiftsPeriod bean) {
        {
            boolean resultFlag = false;
            try {
                if (null != bean) {
                    resultFlag = shiftsPeriodManager.insert(bean);
                } else {
                    log.error("param is null!");
                }
            } catch (Exception e) {
                log.error("ShiftsPeriodServiceImpl!insert(ShiftsPeriod bean) error!", e);
            }
            return resultFlag;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsPeriodServiceImpl.update")
    public boolean update(ShiftsPeriod bean) {
        boolean resultFlag = false;
        try {
            resultFlag = shiftsPeriodManager.update(bean);
        } catch (Exception e) {
            log.error("ShiftsPeriodServiceImpl!update(ShiftsPeriod bean) error!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsPeriodServiceImpl.delete")
    public boolean delete(Long id) {
        boolean resultFlag = false;
        try {
            if (null != id && id.intValue() > 0) {
                resultFlag = shiftsPeriodManager.delete(id);
            } else {
                log.error("ShiftsPeriodServiceImpl!delete(Long id) param: " + id + " Illegal!");
            }
        } catch (Exception e) {
            log.error("ShiftsPeriodServiceImpl!delete(Integer id) error!", e);
        }
        return resultFlag;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsPeriodServiceImpl.getShiftsPeriodById")
    public ShiftsPeriod getShiftsPeriodById(Long id) {
        ShiftsPeriod ShiftsPeriod = null;
        try {
            ShiftsPeriod = shiftsPeriodManager.getShiftsPeriodById(id);
        } catch (Exception e) {
            log.error("UserServiceImpl!getUserById(Integer id) error!", e);
        }
        return ShiftsPeriod;
    }

    /**
     * {@inheritDoc}
     */
    @Profiled(tag = "ShiftsPeriodServiceImpl.updateStatus")
    public boolean updateStatus(String idBoxs, String status,String updateUser) {
        boolean flag = false;
        try {
            if (idBoxs != null && !"".equals(idBoxs)) {
                String[] ids = idBoxs.split(",");
                if (status != null && !"".equals(status)) {
                    int statusInt = Integer.parseInt(status);
                    flag = shiftsPeriodManager.updateStatus(ids, statusInt,updateUser);
                }
            }
        } catch (Exception e) {
            log.error("ShiftsPeriodServiceImpl!updateStatus(String idBoxs, String status) error!", e);
        }
        return flag;
    }

}
