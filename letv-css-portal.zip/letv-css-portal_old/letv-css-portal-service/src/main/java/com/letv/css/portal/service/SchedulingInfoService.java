package com.letv.css.portal.service;

import java.util.List;

import com.letv.common.utils.page.PageUtil;
import com.letv.css.portal.domain.SchedulingInfo;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;

/**
 * 排班信息表service
 *
 * @Author menghan
 * @Version 2017-06-21 11:37:40
 */
public interface SchedulingInfoService {
	/**
     * 根据查询Bean获取对象集合，不带翻页
     * 
     * @param queryBean
     * @return
     */
    List<SchedulingInfo> querySchedulingInfoList(SchedulingInfoQuery queryBean);
    
    /**
     * 根据查询Bean获取集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<SchedulingInfo> querySchedulingInfoListWithPage(SchedulingInfoQuery queryBean,PageUtil pageUtil);

    /**
     * 申请工作流审批同意后修改排班信息
     */
    public boolean updateByApplyFlow(SchedulingInfoQuery queryBean);

    /**
     * 更新排班信息
     */
    public boolean update(SchedulingInfoQuery queryBean);
    /**
     * 更新排班信息
     */
    public boolean updateAdjInfo(SchedulingInfoQuery queryBean);

    /**
     * 插入
     * @return
     */
    public boolean insert(SchedulingInfo sInfoEntity);
    
    /**
     * 根据调整的起始日期和结束日期、业务线名称、排班日期查询符合要求的排班明细
     * @param schedulingInfo
     * @return
     */
    List<SchedulingInfo> querySchedulingInfoByTime(SchedulingInfo schedulingInfo);
    
    /**
     * 根据id查询指定记录
     * @param id
     * @return
     */
    SchedulingInfo getSchedulingInfoById(Long id);
}
