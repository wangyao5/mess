package com.letv.css.mobile.api.utils;

import com.letv.common.utils.serialize.JsonHelper;
import com.letv.css.web.common.response.ResponseStatusEnum;
import com.letv.css.web.common.response.ResponseWrapper;
import com.letv.css.web.common.interceptor.AuthenticationInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LoginRequireActionByDirect implements AuthenticationInterceptor.LoginRequireAction {

    @Override
    public void action(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.addHeader("Content-Type", "application/json; charset=utf-8");
        response.getWriter().append(JsonHelper.toJson(new ResponseWrapper<>(ResponseStatusEnum.UNAUTHORIZED)));
    }
}
