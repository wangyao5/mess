package com.letv.css.mobile.api.controller;

import com.letv.css.web.common.response.ResponseWrapper;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/notice")
public class NoticeController {
    /**
     * 阅读系统通知
     * @param noticeID
     * @return
     */
    public ResponseWrapper<String> read(@PathVariable int noticeID) {
        return null;
    }
}
