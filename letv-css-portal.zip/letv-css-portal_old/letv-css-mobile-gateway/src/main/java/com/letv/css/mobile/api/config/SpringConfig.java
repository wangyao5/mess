package com.letv.css.mobile.api.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource(locations = "classpath:spring/spring-config.xml")
public class SpringConfig {
}
