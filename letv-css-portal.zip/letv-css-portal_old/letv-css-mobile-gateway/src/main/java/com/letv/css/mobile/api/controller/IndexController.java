package com.letv.css.mobile.api.controller;

import com.letv.common.utils.security.MD5Util;
import com.letv.common.web.context.LoginUser;
import com.letv.common.web.context.UserContext;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.service.UserService;
import com.letv.css.web.common.authen.BaseTokenManager;
import com.letv.css.web.common.annotation.ExcludeAuthentication;
import com.letv.css.web.common.response.ResponseStatusEnum;
import com.letv.css.web.common.response.ResponseWrapper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@RestController
@RequestMapping("/")
public class IndexController {

    private final UserService userService;
    private final BaseTokenManager tokenManager;

    private final Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    public IndexController(UserService userService, BaseTokenManager tokenManager) {
        this.userService = userService;
        this.tokenManager = tokenManager;
    }

    @RequestMapping(value = {"/", "/welcome"}, method = RequestMethod.GET)
    @ExcludeAuthentication
    ResponseWrapper<String> welcome() {
        return new ResponseWrapper<String>("Hello css-gateway!");
    }

    /**
     * 系统登录
     *
     * @return
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ExcludeAuthentication
    ResponseWrapper<String> login(HttpServletResponse response, @RequestBody UserParam userParam) {
        String name = userParam.getUsername().split("@")[0];
        String password = userParam.getPassword();
        this.logger.info("loginSys: user name=" + name);

        try {
            User user = userService.getUserByUsername(name);
            if (user == null) {
                return new ResponseWrapper<>(ResponseStatusEnum.ILLEGAL_ERROR_ARGUMENT.getCode(), "您请求的用户名或密码错误");
            }
            boolean checkResult = MD5Util.md5Hex(password + tokenManager.getPasswordSalt()).equals(user.getPassword());
            if (!checkResult) {
                return new ResponseWrapper<>(ResponseStatusEnum.ILLEGAL_ERROR_ARGUMENT.getCode(), "您请求的用户名或密码错误");
            }
            LoginUser loginUser = new LoginUser();
            loginUser.setUserId(user.getId());
            loginUser.setUserName(user.getUsername());
            loginUser.setCnName(user.getName());
            if (null != user.getDep()) {
                loginUser.setDepId(user.getDep().getId());
                loginUser.setDepName(user.getDep().getName());
            }
            String userJson = loginUser.toString();// 用户信息的json值
            return new ResponseWrapper<>(tokenManager.conferToken(response, loginUser.getUserName(), userJson));
        } catch (Exception e) {
            return new ResponseWrapper<>(ResponseStatusEnum.ILLEGAL_ERROR_ARGUMENT.getCode(), "您请求的用户名或密码错误");
        }
    }

    /**
     * 系统退出
     *
     * @return
     */
    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    @ExcludeAuthentication
    ResponseWrapper<String> logout(HttpServletRequest request, HttpServletResponse response) {
        LoginUser loginUser = UserContext.get().getUser();
        if (loginUser != null) {
            tokenManager.invalidateToken(request, response, loginUser.getUserName());
        } else {
            tokenManager.invalidateToken(request, response, null);
        }
        return new ResponseWrapper<>(ResponseStatusEnum.SUCCESS);
    }

    /**
     * 申请新token
     *
     * @return
     */
    @RequestMapping(value = "/refreshtoken", method = RequestMethod.GET)
    ResponseWrapper<String> refreshToken(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, InvalidKeyException {
        LoginUser loginUser = UserContext.get().getUser();
        tokenManager.invalidateToken(request, response, loginUser.getUserName());
        String userJson = loginUser.toString();// 用户信息的json值
        return new ResponseWrapper<>(tokenManager.conferToken(response, loginUser.getUserName(), userJson));

    }

    private static class UserParam {
        private String username;
        private String password;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }
}