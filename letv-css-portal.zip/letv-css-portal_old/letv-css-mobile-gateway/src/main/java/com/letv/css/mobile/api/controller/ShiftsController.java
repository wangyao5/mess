package com.letv.css.mobile.api.controller;

import com.letv.css.web.common.response.ResponseWrapper;
import com.letv.css.portal.domain.Shifts;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/shifts")
public class ShiftsController {
    /**
     * 读取系统班次设置信息
     *
     * @return
     */
    @RequestMapping("/list")
    public ResponseWrapper<Shifts[]> list() {
        //todo
        return null;
    }
}
