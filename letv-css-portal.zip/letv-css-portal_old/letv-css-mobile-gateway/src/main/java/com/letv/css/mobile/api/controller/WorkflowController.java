package com.letv.css.mobile.api.controller;

import com.letv.css.portal.domain.vo.workflow.bean.Instance;
import com.letv.css.portal.domain.vo.workflow.bean.ProcessLog;
import com.letv.css.web.common.response.ResponseWrapper;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/workflow")
public class WorkflowController {
    /**
     * 查询我发起的流程
     *
     * @return
     */
    @RequestMapping("/mycreated")
    public ResponseWrapper<Instance[]> myCreated(
            @RequestParam int pageSize,
            @RequestParam int startIndex,
            @RequestParam String orderBy) {
        //todo
        return null;
    }

    /**
     * 查询我的已办流程
     *
     * @return
     */
    @RequestMapping("/myprocessed")
    public ResponseWrapper<Instance[]> myProcessed(
            @RequestParam int pageSize,
            @RequestParam int startIndex,
            @RequestParam String creator,
            @RequestParam String orderBy) {
        //todo
        return null;
    }

    /**
     * 查询我的待办流程
     *
     * @return
     */
    @RequestMapping("/myopen")
    public ResponseWrapper<Instance[]> myOpen(
            @RequestParam int pageSize,
            @RequestParam int startIndex,
            @RequestParam String creator,
            @RequestParam String orderBy) {
        //todo
        return null;
    }

    /**
     * 查询我的待办流程
     *
     * @return
     */
    @RequestMapping("/instancelog/{instanceID}")
    public ResponseWrapper<ProcessLog[]> log(@PathVariable int instanceID) {
        //todo
        return null;
    }
}
