package com.letv.css.portal.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.UserDao;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.query.UserQuery;
import com.letv.css.portal.domain.query.UserRoleQuery;

/**
 * User: gaohongjing Date: 2014-04-08 Time: 18:43:58
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class UserDaoImpl extends BaseDao implements UserDao {

    @Override
    public List<User> queryUserList(UserQuery queryBean) {
        return (List<User>) queryForList("User.queryUserList", queryBean);
    }

    @Override
    public boolean insert(User bean) {
        return insert("User.insert", bean);
    }

    @Override
    public boolean update(User bean) {
        return update("User.update", bean);
    }

    @Override
    public boolean updateByName(User bean) {
        return update("User.updateByName", bean);
    }

    @Override
    public int queryUserCount(UserQuery queryBean) {
        return (Integer) queryForObject("User.queryUserCount", queryBean);
    }
    
    @Override
    public int queryUserCount4Side(UserQuery queryBean) {
        return (Integer) queryForObject("User.queryUserCount4Side", queryBean);
    }

    @Override
    public List<User> queryUserListWithPage(UserQuery queryBean) {
        return (List<User>) queryForList("User.queryUserListWithPage", queryBean);
        
    }
    
    @Override
    public List<User> queryUserListWithPage4Side(UserQuery queryBean) {
        return (List<User>) queryForList("User.queryUserDepListWhere4Side", queryBean);
        
    }

    @Override
    public boolean deleteUserById(Long id) {
        return delete("User.deleteUserById", id);
    }

    @Override
    public User getUserById(Long id) {
        return (User) queryForObject("User.getUserById", id);
    }

    @Override
    public User getUserByUsername(String name) {
        return (User) queryForObject("User.getUserByUsername", name);
    }
    
    @Override
    public User getUserByEmail(String name) {
        return (User) queryForObject("User.getUserByEmail", name);
    }
    
    @Override
    public List<User> queryUserCost(UserQuery queryBean) {
        return (List<User>) queryForList("User.queryUserCost", queryBean);
    }

	@Override
    public List<User> queryUserDepStaffListWhere(UserQuery query) {
		return (List<User>) queryForList("User.queryUserDepStaffListWhere",query);
	}

	@Override
    public User getUserByStaffId(Long staffId) {
		return (User)queryForObject("User.getUserByStaffId", staffId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<User> queryUsersByIds(String[] ids) {
		return queryForList("User.queryUsersByIds", ids);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<User> getAllUsers() {
		return queryForList("User.getAllUsers");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<User> queryAvailableUserList(Long roleId) {
		return queryForList("User.queryAvailableUserList", roleId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<User> queryConfigedUserList(Long roleId) {
		return queryForList("User.queryConfigedUserList", roleId);
	}
    
}
