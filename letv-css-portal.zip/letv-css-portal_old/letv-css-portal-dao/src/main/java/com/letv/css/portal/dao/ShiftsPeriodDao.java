package com.letv.css.portal.dao;

import com.letv.css.portal.domain.ShiftsPeriod;
import com.letv.css.portal.domain.query.ShiftsPeriodQuery;

import java.util.List;

/**
 * Created by yangxinghe on 2017/5/16.
 */
public interface ShiftsPeriodDao {


    /**
     * * 根据查询Bean获取对象集合，不带翻页
     *
     * @param queryBean
     * @return
     */
    List<ShiftsPeriod> queryShiftsPeriodList(ShiftsPeriodQuery queryBean);
    /**
     * * 根据查询Bean获取对象集合，翻页
     *
     * @param queryBean
     * @return
     */
    List<ShiftsPeriod> queryShiftsPeriodListWithPage(ShiftsPeriodQuery queryBean);

    /**
     * 根据查询Bean获取总数
     *
     * @param queryBean
     * @return
     */
    int queryShiftsPeriodCount(ShiftsPeriodQuery queryBean);


    /**
     * 新增对象
     *
     * @param bean
     * @return
     */
    boolean insert(ShiftsPeriod bean);

    /**
     * 更新对象
     *
     * @param bean
     * @return
     */
    boolean update(ShiftsPeriod bean);


    /**
     * 根据主键删除记录
     *
     * @param id
     * @return
     */
    boolean deleteShiftsPeriodById(Long id);

    /**
     * 根据主键获取对象
     *
     * @param id 主键字段
     * @return
     */
    ShiftsPeriod getShiftsPeriodById(Long id);


}
