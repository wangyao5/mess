package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.ScheduleDao;
import com.letv.css.portal.domain.Schedule;
import com.letv.css.portal.domain.query.ScheduleQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * BPO排班表导入dao实现类
 *
 * @Author yxh
 * @Version 2017-05-31 22:08:26
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class ScheduleDaoImpl extends BaseDao implements ScheduleDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(Schedule schedule) {
		return insert("Schedule.insert", schedule);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean update(Schedule schedule) {
		return update("Schedule.update", schedule);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean inserts(List<Schedule> schedules) {
		return insert("Schedule.inserts", schedules);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
    public Schedule getScheduleById(Long id) {
		return (Schedule) queryForObject("Schedule.getScheduleById", id);
	}
	
	/**
	 * {@inheritDoc}
	 * greg
	 */
	@Override
    public Schedule getScheduleBySpid(Long spid) {
		return (Schedule) queryForObject("Schedule.getScheduleBySpid", spid);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<Schedule> queryScheduleListWithPage(ScheduleQuery query) {
		return queryForList("Schedule.queryScheduleListWithPage", query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<Schedule> queryScheduleList(ScheduleQuery query) {
		return queryForList("Schedule.queryScheduleList", query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Integer queryScheduleCount(ScheduleQuery query) {
		return (Integer) queryForObject("Schedule.queryScheduleCount", query);
	}

}
