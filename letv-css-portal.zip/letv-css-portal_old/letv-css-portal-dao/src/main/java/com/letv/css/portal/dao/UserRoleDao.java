package com.letv.css.portal.dao;

import java.util.List;

import com.letv.css.portal.domain.UserRole;
import com.letv.css.portal.domain.query.UserRoleQuery;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-22 11:20:10
 */
public interface UserRoleDao {

	/**
     * 新增对象
     * 
     * @param bean
     * @return
     */
    boolean insert(UserRole bean);

    /**
     * 更新对象
     * 
     * @param bean
     * @return
     */
    boolean update(UserRole bean);

    /**
     * 根据查询Bean获取对象集合，不带翻页
     * 
     * @param queryBean
     * @return
     */
    List<UserRole> queryUserRoleList(UserRoleQuery queryBean);

    /**
     * 根据查询Bean获取总数
     * 
     * @param queryBean
     * @return
     */
    int queryUserRoleCount(UserRoleQuery queryBean);

    /**
     * 根据查询Bean获取集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<UserRole> queryUserRoleListWithPage(UserRoleQuery queryBean);

    /**
     * 根据主键删除记录
     * 
     * @param id
     * @return
     */
    boolean deleteUserRoleById(Long id);

    /**
     * 根据主键获取对象
     * 
     * @param id
     *            主键字段
     * @return
     */
    UserRole getUserRoleById(Long id);

    /**
     * @param userId
     */
    boolean deleteUserRoleByUserId(Long userId);

    /**
     * @param userIds
     */
    boolean deleteUserRoleByUserIds(String[] userIds);
    
    /**
     * 根据权限id查找用户id
     * @param ids
     * @return
     */
    List<UserRole> queryUsersIdListByRoleIds(String[] ids);
    
    /**
     * 根据角色ID查询拥有该角色的用户信息
     * @param
     * @return
     */
    List<UserRole> queryUsersByRoleId(Long roleId);
    
    /**
     * 根据角色ID，查询拥有该角色的用户信息，与queryUsersByRoleId区别，queryUsersByRoleId仅返回userId
     * @param
     * @return
     */
    List<UserRole> queryRoleUserList(UserRoleQuery query);
    
    /**
     * 根据角色ID删除信息
     * @param
     * @return
     */
    boolean deleteUserRoleByRoleId(Long roleId);
	
}
