package com.letv.css.portal.dao;

import java.util.List;

import com.letv.css.portal.domain.ResourceRole;
import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.domain.query.UserDepQuery;

/**
 * 数据权限接口
 *
 * @Author menghan
 * @Version 2017-01-22 15:59:29
 */
public interface UserDepDao {
	
	/**
     * 新增部门和用户关系
     * 
     * @param userDep
     * @return
     */
    boolean insert(UserDep userDep);

    /**
     * 删除部门和用户关系
     * 
     * @param userDep
     * @return
     */
    boolean deleteUserDep(UserDep userDep);

    /**
     * 根据用户获取已经分配的部门列表
     * 
     * @param userId
     * @return
     */
    List<UserDep> queryUserDepList(Long userId);

    /**
     * 根据用户ID集合查询拥有部门列表
     * 
     * @param resourceRoleQuery
     *            #roleIds
     * @return
     */
    List<UserDep> queryDepListByUserIds(UserDepQuery userDepQuery);
    
    /**
     * 根据部门ID，获得所有拥护该部门权限的用户
     * @param
     * @return
     */
    List<UserDep> queryUsersByDepId(Long depId);
}
