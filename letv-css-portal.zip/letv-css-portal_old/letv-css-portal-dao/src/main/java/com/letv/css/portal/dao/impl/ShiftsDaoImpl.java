package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.ShiftsDao;
import com.letv.css.portal.domain.Shifts;
import com.letv.css.portal.domain.query.ShiftsQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by yangxinghe on 2017/5/16.
 */

@Repository
@SuppressWarnings({"rawtypes", "unchecked"})
public class ShiftsDaoImpl extends BaseDao implements ShiftsDao {
    /**
     * {@inheritDoc}
     */
    @Override
    public List<Shifts> queryShiftsList(ShiftsQuery queryBean) {
        return (List<Shifts>) queryForList("Shifts.queryShiftsList", queryBean);
    }
    
    
    /**
     * {@inheritDoc}
     */
    @Override
    public List<Shifts> queryShiftsListByMinBeginTime(ShiftsQuery queryBean) {
        return (List<Shifts>) queryForList("Shifts.queryShiftsListByMinBeginTime", queryBean);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public List<Shifts> queryOptionShiftsList(ShiftsQuery queryBean) {
        return (List<Shifts>) queryForList("Shifts.queryOptionShiftsList", queryBean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Shifts> queryShiftsListWithPage(ShiftsQuery queryBean) {
        return (List<Shifts>) queryForList("Shifts.queryShiftsListWithPage", queryBean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int queryShiftsCount(ShiftsQuery queryBean) {
        return (Integer) queryForObject("Shifts.queryShiftsCount", queryBean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean insert(Shifts bean) {
        return insert("Shifts.insert", bean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean update(Shifts bean) {
        return update("Shifts.update", bean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean deleteShiftsById(Long id) {
        return delete("Shifts.deleteShiftsById", id);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Shifts getShiftsById(Long id) {
        return (Shifts) queryForObject("Shifts.getShiftsById", id);
    }
    /**
     * {@inheritDoc}
     */
    @Override
    public Shifts getShiftsByName(String shiftsName) {
        return (Shifts) queryForObject("Shifts.getShiftsByName", shiftsName);
    }

}
