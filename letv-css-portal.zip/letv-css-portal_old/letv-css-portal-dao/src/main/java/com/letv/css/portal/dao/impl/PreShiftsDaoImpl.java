package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.PreShiftsDao;
import com.letv.css.portal.dao.PreShiftsDao;
import com.letv.css.portal.domain.PreShifts;
import com.letv.css.portal.domain.query.PreShiftsQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author yangxinghe
 * yxh 2017年8月29日 12:33:19
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class PreShiftsDaoImpl extends BaseDao implements PreShiftsDao {

    @Override
    public boolean insert(PreShifts bean) {
        return insert("PreShifts.insert", bean);
    }

    @Override
    public boolean update(PreShifts bean) {
        return update("PreShifts.update", bean);
    }

    @Override
    public List<PreShifts> queryPreShiftsList(PreShiftsQuery queryBean) {
        return (List<PreShifts>) queryForList("PreShifts.queryPreShiftsList", queryBean);
    }
    @Override
    public int queryPreShiftsCount(PreShiftsQuery queryBean) {
        return (Integer) queryForObject("PreShifts.queryPreShiftsCount", queryBean);
    }
    
    @Override
    public int queryPreShiftsCount4Side(PreShiftsQuery queryBean) {
        return (Integer) queryForObject("PreShifts.queryPreShiftsCount4Side", queryBean);
    }

    @Override
    public List<PreShifts> queryPreShiftsListWithPage(PreShiftsQuery queryBean) {
        return (List<PreShifts>) queryForList("PreShifts.queryPreShiftsListWithPage", queryBean);
        
    }

    @Override
    public List<PreShifts> queryPreShiftsListWithPage4Side(PreShiftsQuery queryBean) {
        return (List<PreShifts>) queryForList("PreShifts.queryPreShiftsDepListWhere4Side", queryBean);
        
    }

    @Override
    public boolean delete(Long id) {
        return delete("PreShifts.deletePreShiftsById", id);
    }

    @Override
    public PreShifts getPreShiftsById(Long id) {
        return (PreShifts) queryForObject("PreShifts.getPreShiftsById", id);
    }
}
