package com.letv.css.portal.dao.impl;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.MenuLogsDao;
import com.letv.css.portal.domain.MenuLogs;
/**
 * 
 * @Author menghan
 * @Version 2017-05-17 18:30:24
 */
@Repository
@SuppressWarnings({ "rawtypes","unchecked" })
public class MenuLogsDaoImpl extends BaseDao implements MenuLogsDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean addLog(MenuLogs menuLogs) {
		return insert("MenuLogs.addLog", menuLogs);
	}

}
