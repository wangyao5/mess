package com.letv.css.portal.dao;

import com.letv.css.portal.domain.AdjustChange;

public interface AdjustChangeDao {

    /**
     * 新增对象
     *
     * @param
     * @return
     */
    boolean insert(AdjustChange bean);
    
    AdjustChange selectById(Long id);

}
