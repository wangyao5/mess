package com.letv.css.portal.dao.impl;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.ThresholdValueDao;
import com.letv.css.portal.domain.ThresholdValue;

/**
 * 阈值参数DAO实现类
 * @Author gexuliang
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class ThresholdValueDaoImpl extends BaseDao implements ThresholdValueDao{

	@Override
	public ThresholdValue getInfoByCode(String code) {
		return (ThresholdValue) queryForObject("ThresholdValue.getInfoByCode", code);
	}

	
}
