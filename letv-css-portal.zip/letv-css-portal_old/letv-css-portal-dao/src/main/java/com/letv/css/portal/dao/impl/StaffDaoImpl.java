package com.letv.css.portal.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.StaffDao;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.query.StaffQuery;

/**
 * 员工信息DAO实现类
 *
 * @Author menghan
 * @Version 2017-01-05 18:50:29
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class StaffDaoImpl extends BaseDao implements StaffDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(Staff bean) {
		return insert("Staff.insert", bean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean update(Staff bean) {
		return update("Staff.update", bean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deleteStaffById(Long id) {
		return delete("Staff.deleteStaffById", id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Staff getStaffById(Long id) {
		return (Staff) queryForObject("Staff.getStaffById", id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<Staff> queryStaffList(StaffQuery queryBean) {
		return (List<Staff>) queryForList("Staff.queryStaffList", queryBean);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<Staff> queryStaffListWithPage(StaffQuery queryBean) {
		return (List<Staff>) queryForList("Staff.queryStaffListWithPage", queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public int queryStaffCount(StaffQuery queryBean) {
		return (Integer) queryForObject("Staff.queryStaffCount", queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean online(Staff staff) {
		//更新部分信息，使用update即可
		return update("Staff.update", staff);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Staff getStaffByCsId(String csId) {
		return (Staff) queryForObject("Staff.getStaffByCsId",csId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Staff getStaffByLeAccount(String leAccount) {
		return (Staff) queryForObject("Staff.getStaffByLeAccount",leAccount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Staff getStaffByEmployeeNum(String employeeNum) {
		return (Staff) queryForObject("Staff.getStaffByEmployeeNum",employeeNum);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Long getStaffId(String name) {
		return (Long)queryForObject("Staff.getStaffId", name);
	}
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean updateSuperiorByDepId(Staff bean) {
        return update("Staff.updateSuperiorByDepId", bean);
    }
}
