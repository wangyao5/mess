package com.letv.css.portal.dao;

import com.letv.css.portal.domain.Leave;

import java.util.Date;
import java.util.List;

/***
 * 员工请假DAO接口
 */
public interface LeaveDao {

	/**
	 * 新增对象
	 * 
	 * @param
	 * @return
	 */
	boolean insert(Leave bean);

	/**
	 * 根据主键获取对象
	 *
	 * @param id
	 *            主键字段
	 * @return
	 */
	Leave getLeaveById(Long id);

	boolean updateStatus(Leave bean);

	/**
	 * 查找员工在此时间段重复的请假申请
	 * @param staffId
	 * @param leaveStartTime
	 * @param leaveEndTime
	 * @return
	 */
	List<Leave> queryRepeatedLeave(Long staffId, Date leaveStartTime, Date leaveEndTime);
}
