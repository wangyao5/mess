package com.letv.css.portal.dao;

import java.util.List;

import com.letv.css.portal.domain.ApprovalManage;
import com.letv.css.portal.domain.query.ApprovalManageQuery;

/**
 * 审批管理dao
 *
 * @Author menghan
 * @Version 2017-06-22 17:39:23
 */
public interface ApprovalManageDao {

	/**
	 * 插入
	 * @param
	 * @return
	 */
	boolean insert(ApprovalManage approvalManage);
	
	/**
	 * 批量插入
	 * @param
	 * @return
	 */
	boolean inserts(List<ApprovalManage> approvalManages);
	
	/**
	 * 修改
	 * @param
	 * @return
	 */
	boolean update(ApprovalManage approvalManage);

	/**
	 * 查询List
	 */
	public List<ApprovalManage> queryAppManageList(Long jdId);

	/**
	 * 更新记录已经确认
	 * @param siId
	 * @return
	 */
	boolean updateConfirmBySiId(String siId);

	/**
	 * 更新记录已经完成
	 */
	boolean updateFinishByJdId(String siId);

	/**
	 * 根据
	 *
	 * @param approvalManageQuery
	 * @return
	 */
	Integer queryAppManageCount(ApprovalManageQuery approvalManageQuery);

	Integer queryValidCount(ApprovalManageQuery approvalManageQuery);

	/**
	 * 更新记录已经确认
	 * @param jdId
	 * @return
	 */
	boolean updateByJdId(String jdId);

}
