package com.letv.css.portal.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.RoleDao;
import com.letv.css.portal.domain.Role;
import com.letv.css.portal.domain.query.ResourceRoleQuery;
import com.letv.css.portal.domain.query.RoleQuery;
import com.letv.css.portal.domain.query.UserRoleQuery;

/**
 * 角色信息实现类
 *
 * @Author menghan
 * @Version 2017-01-22 11:05:23
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class RoleDaoImpl extends BaseDao implements RoleDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<Role> queryRoleList(RoleQuery queryBean) {
        return (List<Role>) queryForList("Role.queryRoleList", queryBean);
    }

	/**
	 * {@inheritDoc}
	 */
    @Override
    public List<Role> queryRoles(RoleQuery queryBean) {
        return (List<Role>) queryForList("Role.queryRoles", queryBean);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public boolean insert(Role bean) {
        return insert("Role.insert", bean);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public boolean update(Role bean) {
        return update("Role.update", bean);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public int queryRoleCount(RoleQuery queryBean) {
        return (Integer) queryForObject("Role.queryRoleCount", queryBean);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public List<Role> queryRoleListWithPage(RoleQuery queryBean) {
        return (List<Role>) queryForList("Role.queryRoleListWithPage", queryBean);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public boolean deleteRoleById(Long id) {
        return delete("Role.deleteRoleById", id);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public Role getRoleById(Long id) {
        return (Role) queryForObject("Role.getRoleById", id);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public List<Role> queryConfigedRoleList(UserRoleQuery queryBean) {
        return (List<Role>) queryForList("Role.queryConfigedRoleList", queryBean);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public List<Role> queryAvailableRoleList(UserRoleQuery queryBean) {
        return (List<Role>) queryForList("Role.queryAvailableRoleList", queryBean);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public List<Role> queryResourceConfigedRoleList(ResourceRoleQuery query) {
        return (List<Role>) queryForList("Role.queryResourceConfigedRoleList", query);
    }

    /**
	 * {@inheritDoc}
	 */
    @Override
    public List<Role> queryResourceAvailableRoleList(ResourceRoleQuery query) {
        return (List<Role>) queryForList("Role.queryResourceAvailableRoleList", query);
    }
	
}
