package com.letv.css.portal.dao.impl;

import java.util.List;

import com.letv.css.portal.domain.query.ApprovalManageQuery;
import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.ApprovalManageDao;
import com.letv.css.portal.domain.ApprovalManage;

/**
 * 审批管理dao实现类
 *
 * @Author menghan
 * @Version 2017-06-22 17:41:11
 */
@Repository
@SuppressWarnings({ "rawtypes","unchecked" })
public class ApprovalManageDaoImpl extends BaseDao implements ApprovalManageDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(ApprovalManage approvalManage) {
		return insert("ApprovalManage.insert",approvalManage);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean update(ApprovalManage approvalManage) {
		return update("ApprovalManage.update",approvalManage);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean inserts(List<ApprovalManage> approvalManages) {
		return insert("ApprovalManage.inserts",approvalManages);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<ApprovalManage> queryAppManageList(Long jdId){
		return  queryForList("ApprovalManage.queryAppManageList",jdId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean updateConfirmBySiId(String siId){
		return update("ApprovalManage.updateConfirmBySiId",siId);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean updateFinishByJdId(String siId){
		return update("ApprovalManage.updateFinishByJdId",siId);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public Integer queryAppManageCount(ApprovalManageQuery approvalManageQuery) {
		return (Integer) queryForObject("ApprovalManage.queryAppManageCount", approvalManageQuery);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public Integer queryValidCount(ApprovalManageQuery approvalManageQuery) {
		return (Integer) queryForObject("ApprovalManage.queryValidCount", approvalManageQuery);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean updateByJdId(String jdId){
		return update("ApprovalManage.updateByJdId",jdId);
	}
}
