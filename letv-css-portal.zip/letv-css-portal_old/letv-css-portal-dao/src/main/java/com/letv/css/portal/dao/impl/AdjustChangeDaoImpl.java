package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.AdjustChangeDao;
import com.letv.css.portal.dao.StaffDao;
import com.letv.css.portal.domain.AdjustChange;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.query.StaffQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 员工信息DAO实现类
 *
 * @Author menghan
 * @Version 2017-01-05 18:50:29
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class AdjustChangeDaoImpl extends BaseDao<AdjustChange> implements AdjustChangeDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(AdjustChange bean) {
		return insert("AdjustChange.insert", bean);
	}
	
	@Override
    public AdjustChange selectById(Long id){
		AdjustChange a=new AdjustChange();
		a.setId(id);
		return queryForObject("AdjustChange.selectById", a);
	}

}
