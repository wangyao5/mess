package com.letv.css.portal.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.SchedulePlanDetailDao;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.query.SchedulePlanDetailQuery;

/**
 * 操作总班表明细dao实现类
 *
 * @Author menghan
 * @Version 2017-05-24 17:27:52
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class SchedulePlanDetailDaoImpl extends BaseDao implements SchedulePlanDetailDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(SchedulePlanDetail schedulePlanDetail) {
		return insert("SchedulePlanDetail.insert", schedulePlanDetail);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean inserts(List<SchedulePlanDetail> schedulePlanDetails) {
		return insert("SchedulePlanDetail.inserts", schedulePlanDetails);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<SchedulePlanDetail> querySchedulePlanDetailList(SchedulePlanDetailQuery query) {
		return queryForList("SchedulePlanDetail.querySchedulePlanDetailList", query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean update(SchedulePlanDetail schedulePlanDetail) {
		return update("SchedulePlanDetail.update", schedulePlanDetail);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean delete(Long id) {
		return update("SchedulePlanDetail.delete", id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deletes(SchedulePlanDetailQuery query) {
		return update("SchedulePlanDetail.deletes", query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean batchDelete(List<SchedulePlanDetail> list) {
		return insert("SchedulePlanDetail.batchDelete",list);
	}

}
