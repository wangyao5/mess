package com.letv.css.portal.dao;

import com.letv.css.portal.domain.JsonData;

/***
 * 审批提交数据信息dao
 *
 * @Author menghan
 * @Version 2017-06-22 16:35:35
 */
public interface JsonDataDao {

	/**
	 * 插入一条审批提交的数据
	 * @param
	 * @return
	 */
	boolean insert(JsonData jsonData);

	/**
	 * 根据ID查询实体
	 * @param id
	 * @return
	 */
	JsonData getById(Long id);
}
