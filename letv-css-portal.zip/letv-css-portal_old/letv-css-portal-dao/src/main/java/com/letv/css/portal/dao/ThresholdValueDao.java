package com.letv.css.portal.dao;

import com.letv.css.portal.domain.ThresholdValue;

/***
 * 阈值信息DAO接口
 * @Author gexuliang
 * 
 */
public interface ThresholdValueDao {
	
	ThresholdValue getInfoByCode(String code);
	
}
