package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.ResourceRoleDao;
import com.letv.css.portal.domain.ResourceRole;
import com.letv.css.portal.domain.query.ResourceRoleQuery;

import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-22 11:50:27
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class ResourceRoleDaoImpl extends BaseDao implements ResourceRoleDao {

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(ResourceRole bean) {
		return insert("ResourceRole.insert", bean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deleteResourceRole(ResourceRole resourceRole) {
		return delete("ResourceRole.deleteResourceRole", resourceRole);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<ResourceRole> queryResourceRoleList(Long roleId) {
		return queryForList("ResourceRole.queryResourceRoleList", roleId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<ResourceRole> queryResourceListByRoleIds(
			ResourceRoleQuery resourceRoleQuery) {
		return queryForList("ResourceRole.queryResourceListByRoleIds",
				resourceRoleQuery);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<ResourceRole> queryResourceListByResId(Long resId ){
		return queryForList("ResourceRole.queryResourceListByResId", resId);
	}
}
