package com.letv.css.portal.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.ModifyRecordDao;
import com.letv.css.portal.domain.ModifyRecord;
import com.letv.css.portal.domain.query.ModifyRecordQuery;

/***
 * 修来记录日志查询实现类
 *
 * @Author menghan
 * @Version 2017-01-14 11:49:21
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class ModifyRecordDaoImpl extends BaseDao implements ModifyRecordDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public ModifyRecord getModifyRecordById(Long id) {
		return (ModifyRecord) queryForObject("ModifyRecord.getModifyRecordById", id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(ModifyRecord modifyRecord) {
		return insert("ModifyRecord.insert", modifyRecord);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deleteModifyRecordById(Long id) {
		return delete("ModifyRecord.deleteModifyRecordById", id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public int queryModifyRecordCount(ModifyRecordQuery bean) {
		return (int) queryForObject("ModifyRecord.queryModifyRecordCount", bean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<ModifyRecord> queryModifyRecordListWithPage(ModifyRecordQuery bean) {
		return (List<ModifyRecord>)queryForList("ModifyRecord.queryModifyRecordListWithPage", bean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<ModifyRecord> queryEntryFlow(ModifyRecordQuery bean) {
		return (List<ModifyRecord>)queryForList("ModifyRecord.queryEntryFlow", bean);
	}

}
