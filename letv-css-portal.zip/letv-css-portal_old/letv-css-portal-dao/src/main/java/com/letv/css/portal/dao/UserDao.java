package com.letv.css.portal.dao;

import java.util.List;

import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.query.UserQuery;
import com.letv.css.portal.domain.query.UserRoleQuery;

/**
 * User: gaohongjing Date: 2014-04-08 Time: 18:43:58
 */
public interface UserDao {

    /**
     * 新增对象
     * 
     * @param bean
     * @return
     */
    boolean insert(User bean);

    /**
     * 更新对象
     * 
     * @param bean
     * @return
     */
    boolean update(User bean);

    /**
     * 根据登录账号更新对象
     * 
     * @param bean
     * @return
     */
    boolean updateByName(User bean);
    

    /**
     * 根据查询Bean获取对象集合，不带翻页
     * 
     * @param queryBean
     * @return
     */
    List<User> queryUserList(UserQuery queryBean);

    /**
     * 根据查询Bean获取总数
     * 
     * @param queryBean
     * @return
     */
    int queryUserCount(UserQuery queryBean);
    
    /**
     * 根据查询Bean获取总数
     * 
     * @param queryBean
     * @return
     */
    int queryUserCount4Side(UserQuery queryBean);

    /**
     * 根据查询Bean获取集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<User> queryUserListWithPage(UserQuery queryBean);
    
    /**
     * 根据查询Bean获取集合，带翻页
     * 
     * @param query
     * @return
     */
    List<User> queryUserDepStaffListWhere(UserQuery query);
    
    /**
     * 根据查询Bean获取集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<User> queryUserListWithPage4Side(UserQuery queryBean);
    

    /**
     * 根据主键删除记录
     * 
     * @param id
     * @return
     */
    boolean deleteUserById(Long id);

    /**
     * 根据主键获取对象
     * 
     * @param id
     *            主键字段
     * @return
     */
    User getUserById(Long id);

    /**
     * 根据登录账号获取用户信息
     * 
     * @param name
     * @return
     */
    User getUserByUsername(String name);
    
    /**
     * 根据域帐号邮箱前缀获取用户信息
     * 
     * @param name
     * @return
     */
    User getUserByEmail(String name);
   
    
    /**
     * 提供代下单 查询 成本中心,组织
     * 
     * @param queryBean
     * @return
     */
    List<User> queryUserCost(UserQuery queryBean);

    /**
     * 根据员工ID获取用户信息
     * 
     * @param name
     * @return
     */
    User getUserByStaffId(Long staffId);
    
    /**
     * 根据ids获得用户集合
     * @param
     * @return
     */
    List<User> queryUsersByIds(String[] ids);
    
    /**
     * 获得所有用户信息
     * @param
     * @return
     */
    List<User> getAllUsers();
    
    /**
     * 查询可用的（角色未已配置的）用户信息
     * @param
     * @return
     */
    List<User> queryAvailableUserList(Long roleId);
    
    /**
     * 查询已配置该角色的用户信息
     * @param
     * @return
     */
    List<User> queryConfigedUserList(Long roleId);
}
