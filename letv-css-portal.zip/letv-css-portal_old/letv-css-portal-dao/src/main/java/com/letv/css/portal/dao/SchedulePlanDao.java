package com.letv.css.portal.dao;

import java.util.List;

import com.letv.css.portal.domain.SchedulePlan;
import com.letv.css.portal.domain.query.SchedulePlanQuery;

/***
 * 总班表导入dao
 *
 * @Author menghan
 * @Version 2017-05-24 11:32:10
 */
public interface SchedulePlanDao {

	/**
	 * 插入一条总班表记录
	 * @param
	 * @return
	 */
	boolean insert(SchedulePlan schedulePlan);
	
	/**
	 * 插入多条总班表记录
	 * @param
	 * @return
	 */
	boolean inserts(List<SchedulePlan> schedulePlans);
	
	/**
	 * 根据id获得总班表信息
	 * @param
	 * @return
	 */
	SchedulePlan getSchedulePlanById(Long id);
	
	/**
	 * 根据query查询总班表信息，翻页
	 * @param
	 * @return
	 */
	List<SchedulePlan> querySchedulePlanListWithPage(SchedulePlanQuery query);
	
	/**
	 * 根据query查询总班表信息，不翻页
	 * @param
	 * @return
	 */
	List<SchedulePlan> querySchedulePlanList(SchedulePlanQuery query);
	
	/**
	 * 根据query获得总班表导入总数
	 * @param
	 * @return
	 */
	Integer querySchedulePlanCount(SchedulePlanQuery query);
	
	/**
	 * 更新总班表导入记录
	 * @param
	 * @return
	 */
	boolean update(SchedulePlan plan);
}
