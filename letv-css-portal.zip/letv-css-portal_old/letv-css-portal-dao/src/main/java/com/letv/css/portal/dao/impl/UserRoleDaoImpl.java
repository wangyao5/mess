package com.letv.css.portal.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.UserRoleDao;
import com.letv.css.portal.domain.UserRole;
import com.letv.css.portal.domain.query.UserRoleQuery;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-22 11:21:23
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class UserRoleDaoImpl extends BaseDao implements UserRoleDao {

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deleteUserRoleById(Long id) {
		return delete("UserRole.deleteUserById", id);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
    public UserRole getUserRoleById(Long id) {
		return (UserRole) queryForObject("UserRole.getUserById", id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(UserRole bean) {
		return insert("UserRole.insert", bean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public int queryUserRoleCount(UserRoleQuery queryBean) {
		return (Integer) queryForObject("UserRole.queryUserRoleCount",
				queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<UserRole> queryUserRoleList(UserRoleQuery queryBean) {
		return (List<UserRole>) queryForList("UserRole.queryUserRoleList",
				queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<UserRole> queryUserRoleListWithPage(UserRoleQuery queryBean) {
		return (List<UserRole>) queryForList(
				"UserRole.queryUserRoleListWithPage", queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean update(UserRole bean) {
		return update("UserRole.update", bean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deleteUserRoleByUserId(Long userId) {
		return delete("UserRole.deleteUserRoleByUserId", userId);
	}

	/**
	 * 批量删除角色用户关系
	 */
	@Override
    public boolean deleteUserRoleByUserIds(String[] userIds) {
		return delete("UserRole.deleteUserRoleByUserIds", userIds);
	}
	
	@Override
    public List<UserRole> queryUsersIdListByRoleIds(String[] ids){
		return queryForList("UserRole.queryUsersIdListByRoleIds", ids);
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
    public List<UserRole> queryUsersByRoleId(Long roleId) {
		return queryForList("UserRole.queryUsersByRoleId",roleId);
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
    public List<UserRole> queryRoleUserList(UserRoleQuery query) {
		return queryForList("UserRole.queryRoleUserList",query);
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
    public boolean deleteUserRoleByRoleId(Long roleId) {
		return update("UserRole.deleteUserRoleByRoleId", roleId);
	}

}
