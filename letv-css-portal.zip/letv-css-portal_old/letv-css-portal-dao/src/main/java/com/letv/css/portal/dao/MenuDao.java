package com.letv.css.portal.dao;

import java.util.List;
import java.util.Map;

import com.letv.css.portal.domain.Resource;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.dto.MenuDto;
import com.letv.css.portal.domain.dto.SystemMenuDto;

/**
 * 系统菜单查询DAO接口
 *
 * @Author menghan
 * @Version 2017-01-22 13:59:01
 */
public interface MenuDao {

    /**
     * 依据用户ID或账号查询菜单（一级和二级）列表
     * 
     * @param user
     * @return
     */
    List<MenuDto> getMenus(User user);

    /**
     * 根据用户ID集合查询拥有资源列表
     * 
     * @param user
     *            #id
     * @return
     */
    List<Resource> queryResourceListByUserId(User user);

    /**
     * 根据用户ID和父资源查询按钮资源列表
     * 
     * @param map
     * @return
     */
    List<Resource> queryButtonResources(Map<String, Object> map);

	/**
	 * 根据用户id和系统编码查询用户在当前系统有权菜单
	 * 
	 * @param paramMap
	 * @return
	 */
	List<MenuDto> getSystemMenus(Map<String, Object> paramMap);
	
	/**
	 * 根据用户id查询用户在所有系统有权菜单
	 * 
	 * @param paramMap
	 * @return
	 */
	List<SystemMenuDto> getAllSystemMenus(Map<String, Object> paramMap);

	/**
	 * 分级带权限查询菜单
	 * 
	 * @param paramMap
	 * @return
	 */
	List<MenuDto> queryAuthMenusWithLevel(Map<String, Object> paramMap);

	/**
	 * @param paramMap
	 * @return
	 */
	
	/**
	 * 分级查询菜单
	 * 
	 * @param paramMap
	 * @return
	 */
	List<MenuDto> queryMenusWithLevel(Map<String, Object> paramMap);

	/**
	 * 根据用户id查询用户快捷菜单
	 * 
	 * @param paramMap
	 * @return
	 */
	List<Resource> getShortCutMenus(User user);

	/***
	 * 获得所有子菜单
	 * @param
	 * @return
	 */
	List<Resource> queryAllSubMenu();
	
}
