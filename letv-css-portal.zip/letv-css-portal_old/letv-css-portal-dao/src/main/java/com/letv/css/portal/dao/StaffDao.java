package com.letv.css.portal.dao;

import java.util.List;

import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.query.StaffQuery;
import com.letv.css.portal.domain.query.UserQuery;

/***
 * 员工信息DAO接口
 *
 * @Author menghan
 * @Version 2017-01-05 18:17:13
 */
public interface StaffDao {

	/**
	 * 新增对象
	 * 
	 * @param
	 * @return
	 */
	boolean insert(Staff bean);
	
	/**
     * 更新对象
     * 
     * @param bean
     * @return
     */
    boolean update(Staff bean);
	
    /**
     * 根据主键删除记录
     * 
     * @param id
     * @return
     */
    boolean deleteStaffById(Long id);

    /**
     * 根据主键获取对象
     * 
     * @param id
     *            主键字段
     * @return
     */
    Staff getStaffById(Long id);
    
    
    /**
     * 根据查询Bean获取对象集合，不带翻页
     * 
     * @param queryBean
     * @return
     */
    List<Staff> queryStaffList(StaffQuery queryBean);
    
    /**
     * 根据查询Bean获取集合，带翻页
     * 
     * @param queryBean
     * @return
     */
    List<Staff> queryStaffListWithPage(StaffQuery queryBean);
    
    /**
     * 根据查询Bean获取总数
     * 
     * @param queryBean
     * @return
     */
    int queryStaffCount(StaffQuery queryBean);

    /***
     * 员工上线
     * @param
     * @return
     */
	boolean online(Staff staff);
    
	/**
	 * 通过客服工号获得员工信息
	 * @param
     * @return
	 */
	Staff getStaffByCsId(String csId);
	
	/**
	 * 通过乐视账号获得员工信息
	 * @param
     * @return
	 */
	Staff getStaffByLeAccount(String leAccount);
	
	/**
	 * 通过员工编号获得员工信息
	 * @param
     * @return
	 */
	Staff getStaffByEmployeeNum(String employeeNum);
	
	/**
	 * 通过员工姓名，获得最新插入的员工ID
	 * @param
	 * @return
	 */
	Long getStaffId(String name);
    /**
     *   //修改部门负责人时 将部门本层级坐席的组长更新为当前部门的负责人
     * @param staff
     * @return
     */
    boolean updateSuperiorByDepId(Staff staff);
}
