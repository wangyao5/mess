package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.CommonQueueDao;
import com.letv.css.portal.dao.DepDao;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.query.CommonQueue;
import com.letv.css.portal.domain.query.DepQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class CommonQueueDaoImpl extends BaseDao implements CommonQueueDao {

    @Override
    public boolean insert(CommonQueue commonQueue) {
        return insert("CommonQueue.insert", commonQueue);
    }

}
