package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.ScheduleDetailDao;
import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.query.ScheduleDetailQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作BPO排班表明细dao实现类
 *
 * @Author yxh
 * @Version 2017-05-31 22:58:24
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class ScheduleDetailDaoImpl extends BaseDao implements ScheduleDetailDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(ScheduleDetail scheduleDetail) {
		return insert("ScheduleDetail.insert", scheduleDetail);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean inserts(List<ScheduleDetail> scheduleDetails) {
		return insert("ScheduleDetail.inserts", scheduleDetails);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<ScheduleDetail> queryScheduleDetailList(ScheduleDetailQuery query) {
		return queryForList("ScheduleDetail.queryScheduleDetailList", query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean delete(Long id) {
		return update("ScheduleDetail.deleteScheduleDetailById", id);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean updateYnBySDetail(List<ScheduleDetail> scheduleDetails) {
		return update("ScheduleDetail.updateYnBySDetail", scheduleDetails);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deletes(ScheduleDetailQuery query) {
		return update("ScheduleDetail.deletes", query);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean batchDelete(List<ScheduleDetail> list) {
		return insert("ScheduleDetail.batchDelete",list);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean update(ScheduleDetail scheduleDetail){
		return update("ScheduleDetail.update",scheduleDetail);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deleteBySid(Long sId){
		return update("ScheduleDetail.deleteBySid",sId);
	}
}
