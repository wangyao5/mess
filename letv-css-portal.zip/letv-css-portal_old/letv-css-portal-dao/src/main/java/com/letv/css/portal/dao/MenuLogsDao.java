package com.letv.css.portal.dao;

import com.letv.css.portal.domain.MenuLogs;

/***
 * 访问菜单日志DAO
 *
 * @Author menghan
 * @Version 2017-05-17 18:26:05
 */
public interface MenuLogsDao {

	/**
	 * 添加日志记录
	 * @param
	 * @return
	 */
	public boolean addLog(MenuLogs menuLogs);
	
}
