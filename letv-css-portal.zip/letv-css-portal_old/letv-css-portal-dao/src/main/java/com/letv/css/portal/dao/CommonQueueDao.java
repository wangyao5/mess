package com.letv.css.portal.dao;


import com.letv.css.portal.domain.query.CommonQueue;

public interface CommonQueueDao {

    boolean insert(CommonQueue commonQueue);

}
