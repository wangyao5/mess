package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.DepBusinessDao;
import com.letv.css.portal.domain.DepBusiness;
import com.letv.css.portal.domain.Dic;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@SuppressWarnings({"rawtypes", "unchecked"})
public class DepBusinessDaoImpl extends BaseDao implements DepBusinessDao {


    @Override
    public List<DepBusiness> queryByDepId(Long depId) {
        return queryForList("DepBusiness.queryByDepId", depId);
    }

    @Override
    public boolean insert(DepBusiness depBusiness) {
        return insert("DepBusiness.insert", depBusiness);
    }

    @Override
    public boolean update(DepBusiness depBusiness) {
        return update("DepBusiness.deleteById",depBusiness);
    }
}
