package com.letv.css.portal.dao.impl;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.JsonDataDao;
import com.letv.css.portal.domain.JsonData;

/**
 * 审批提交数据dao实现类
 *
 * @Author menghan
 * @Version 2017-06-22 16:38:48
 */
@Repository
@SuppressWarnings({ "rawtypes","unchecked" })
public class JsonDataDaoImpl extends BaseDao implements JsonDataDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(JsonData jsonData) {
		return insert("JsonData.insert",jsonData);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public JsonData getById(Long id){
		return (JsonData)queryForObject("JsonData.getById",id);
	}
}
