package com.letv.css.portal.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.SchedulingInfoDao;
import com.letv.css.portal.domain.SchedulingInfo;
import com.letv.css.portal.domain.query.SchedulingInfoQuery;

/**
 * 排班表dao实现类
 *
 * @Author menghan
 * @Version 2017-06-21 11:23:24
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class SchedulingInfoDaoImpl extends BaseDao implements SchedulingInfoDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<SchedulingInfo> querySchedulingInfoList(
			SchedulingInfoQuery queryBean) { 
		return queryForList("SchedulingInfo.querySchedulingInfoList", queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<SchedulingInfo> querySchedulingInfoListWithPage(
			SchedulingInfoQuery queryBean) {
		return queryForList("SchedulingInfo.querySchedulingInfoListWithPage", queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public int querySchedulingInfoCount(SchedulingInfoQuery queryBean) {
		return (int) queryForObject("SchedulingInfo.querySchedulingInfoCount", queryBean);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean updateByApplyFlow(SchedulingInfoQuery queryBean){
		return update("SchedulingInfo.updateByApplyFlow",queryBean);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean update(SchedulingInfoQuery queryBean){
		return update("SchedulingInfo.update",queryBean);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(SchedulingInfo queryBean){
		return insert("SchedulingInfo.insert",queryBean);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<SchedulingInfo> querySchedulingInfoByTime(
			SchedulingInfo schedulingInfo) {
		return queryForList("SchedulingInfo.querySchedulingInfoByTime", schedulingInfo);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public SchedulingInfo getSchedulingInfoById(Long id) {
		return (SchedulingInfo) queryForObject("SchedulingInfo.getSchedulingInfoById", id);
	}

}
