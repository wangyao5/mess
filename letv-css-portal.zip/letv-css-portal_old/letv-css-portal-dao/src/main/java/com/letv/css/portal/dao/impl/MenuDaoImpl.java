package com.letv.css.portal.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.MenuDao;
import com.letv.css.portal.domain.Resource;
import com.letv.css.portal.domain.User;
import com.letv.css.portal.domain.dto.MenuDto;
import com.letv.css.portal.domain.dto.SystemMenuDto;

/**
 * 系统菜单查询DAO实现
 *
 * @Author menghan
 * @Version 2017-01-22 14:00:31
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class MenuDaoImpl extends BaseDao implements MenuDao {

    @Override
    public List<MenuDto> getMenus(User user) {
        return (List<MenuDto>) queryForList("Menu.getMenus", user);
    }

    @Override
    public List<Resource> queryResourceListByUserId(User user) {
        return (List<Resource>) queryForList("Menu.queryResourceListByUserId", user);
    }

    @Override
    public List<Resource> queryButtonResources(Map<String, Object> map) {
        return (List<Resource>) queryForList("Menu.queryButtonResources", map);
    }

	@Override
    public List<MenuDto> getSystemMenus(Map<String, Object> paramMap) {
		return (List<MenuDto>) queryForList("Menu.getSystemMenus", paramMap);
	}
	
	@Override
    public List<SystemMenuDto> getAllSystemMenus(Map<String, Object> paramMap) {
		return (List<SystemMenuDto>) queryForList("Menu.getAllSystemMenus", paramMap);
	}

	@Override
    public List<MenuDto> queryAuthMenusWithLevel(Map<String, Object> paramMap) {
		return (List<MenuDto>) queryForList("Menu.queryAuthMenusWithLevel", paramMap);
	}

	@Override
    public List<MenuDto> queryMenusWithLevel(Map<String, Object> paramMap) {
		return (List<MenuDto>) queryForList("Menu.queryMenusWithLevel", paramMap  );
	}

	@Override
    public List<Resource> getShortCutMenus(User user) {
		return (List<Resource>) queryForList("Menu.getShortCutMenus", user);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<Resource> queryAllSubMenu() {
		return queryForList("Menu.queryAllSubMenu");
	}
}
