package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.DepDao;
import com.letv.css.portal.domain.Dep;
import com.letv.css.portal.domain.query.DepQuery;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.stereotype.Repository;

/**
 * User: gaohongjing Date: 2014-04-08 Time: 18:43:58
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class DepDaoImpl extends BaseDao implements DepDao {

    @Override
    public List<Dep> queryDepList(DepQuery queryBean) {
        return (List<Dep>) queryForList("Dep.queryDepList", queryBean);
    }

    @Override
    public boolean insert(Dep bean) {
        return insert("Dep.insert", bean);
    }

    @Override
    public boolean update(Dep bean) {
        return update("Dep.update", bean);
    }

    @Override
    public int queryDepCount(DepQuery queryBean) {
        return (Integer) queryForObject("Dep.queryDepCount", queryBean);
    }

    @Override
    public List<Dep> queryDepListWithPage(DepQuery queryBean) {
        return (List<Dep>) queryForList("Dep.queryDepListWithPage", queryBean);
    }

    @Override
    public boolean deleteDepById(Long id) {
        return delete("Dep.deleteDepById", id);
    }

    @Override
    public Dep getDepById(Long id) {
        return (Dep) queryForObject("Dep.getDepById", id);
    }

	@Override
    public List<Dep> getDepListByIds(String ids) {
		return queryForList("Dep.getDepListByIds", ids);
	}

	@Override
    public List<String> getChildrenCodByParentId(Long parentId) {
		return queryForList("Dep.getChildrenCodByParentId",parentId);
	}

	@Override
    public List<Dep> queryTreeDepList(DepQuery query) {
		return queryForList("Dep.queryTreeDepList",query);
	}

	@Override
    public List<Dep> queryDepTree(Long userId) {
		return queryForList("Dep.queryDepTree",userId);
	}

	@Override
    public Integer queryDepPersonQuantity(Long depId) {
		return (Integer) queryForObject("Dep.queryDepPersonQuantity", depId);
	}

	@Override
    public Map<Integer, Integer> queryDepPersonQuantityByCode(String code) {
        Map<Integer, Integer> map = new HashedMap();

        List<Map<String, Object>> list = queryForList("Dep.queryDepPersonQuantityByCode", code);
        for (Map<String, Object> objectMap : list) {
            Integer key =  (Integer) objectMap.get("staff_contract");
            int count = (int)objectMap.get("count");
           map.put(key, count);
        }
        return map;
    }

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Dep getDepByName(String name) {
		return (Dep) queryForObject("Dep.getDepByName", name);
	}

}
