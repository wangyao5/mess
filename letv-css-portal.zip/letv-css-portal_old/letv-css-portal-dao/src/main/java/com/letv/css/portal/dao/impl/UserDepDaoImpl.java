package com.letv.css.portal.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.UserDepDao;
import com.letv.css.portal.domain.ResourceRole;
import com.letv.css.portal.domain.UserDep;
import com.letv.css.portal.domain.query.UserDepQuery;

/**
 * 
 *
 * @Author menghan
 * @Version 2017-01-22 16:07:02
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class UserDepDaoImpl extends BaseDao implements UserDepDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(UserDep userDep) {
		return insert("UserDep.insert", userDep);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deleteUserDep(UserDep userDep) {
		return delete("UserDep.deleteUserDep", userDep);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<UserDep> queryUserDepList(Long userId) {
		return queryForList("UserDep.queryUserDepList",userId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<UserDep> queryDepListByUserIds(UserDepQuery userDepQuery) {
		return queryForList("UserDep.queryDepListByUserIds",userDepQuery);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<UserDep> queryUsersByDepId(Long depId) {
		return queryForList("UserDep.queryUsersByDepId",depId);
	}

}
