package com.letv.css.portal.dao.impl;

import java.util.List;

import com.letv.css.portal.domain.DepBusiness;
import com.letv.css.portal.domain.query.DicBusinessQuery;
import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.DicDao;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.query.DicQuery;

/**
 * 数据字典 dao实现类
 *
 * @Author menghan
 * @Version 2017-02-14 20:31:28
 */
@Repository
@SuppressWarnings({ "rawtypes","unchecked" })
public class DicDaoImpl extends BaseDao implements DicDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean insert(Dic dic) {
		return insert("Dic.insert", dic);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean update(Dic dic) {
		return update("Dic.update", dic);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public boolean deleteById(Long id) {
		return delete("Dic.deleteById", id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Dic getDicById(Long id) {
		return (Dic) queryForObject("Dic.getDicById", id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<Dic> queryDicList(DicQuery query) {
		return (List<Dic>) queryForList("Dic.queryDicList",query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public List<Dic> queryDicListWithPage(DicQuery query) {
		return (List<Dic>) queryForList("Dic.queryDicListWithPage",query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Integer queryDicCount(DicQuery query) {
		return (Integer) queryForObject("Dic.queryDicCount",query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public Long getDicNum(Long parentId) {
		return (Long) queryForObject("Dic.getDicNum",parentId);
	}

	@Override
	public List<Dic> queryDicListById(DicBusinessQuery businessQuery) {
		return (List<Dic>) queryForList("Dic.queryDicListById",businessQuery);
	}

	@Override
	public Dic getDicByNum(Long parentNum, Long num) {
		DicQuery query = new DicQuery();
		query.setParentNum( parentNum );
		query.setNum( Integer.parseInt(String.valueOf(num))  );
		return (Dic) queryForObject("Dic.getDicByNum", query);
	}
}
