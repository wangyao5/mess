package com.letv.css.portal.dao;

import java.util.List;

import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.FunctionalStaffCalendar;
import com.letv.css.portal.domain.query.DicBusinessQuery;
import com.letv.css.portal.domain.query.DicQuery;
import com.letv.css.portal.domain.query.FunctionalStaffCalendarQuery;

/**
 * 职能岗工作日历
 * @Author gexuliang
 */
public interface FunctionalStaffCalendarDao {

	/**
	 * 新增
	 * @param
	 * @return
	 */
	boolean insert(FunctionalStaffCalendar functionalStaffCalendar);
	
	/**
	 * 更新
	 * @param
	 * @return
	 */
	boolean update(FunctionalStaffCalendar functionalStaffCalendar);
	
	/**
	 * 根据query，获得Dic实体集合，不分页
	 * @param
	 * @return
	 */
	List<FunctionalStaffCalendar> queryList(FunctionalStaffCalendarQuery query);
	
}
