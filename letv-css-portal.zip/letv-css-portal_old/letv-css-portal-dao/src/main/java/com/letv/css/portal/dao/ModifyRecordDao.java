package com.letv.css.portal.dao;

import java.util.List;

import com.letv.css.portal.domain.ModifyRecord;
import com.letv.css.portal.domain.query.ModifyRecordQuery;

/**
 * 查询修改记录日志信息接口
 *
 * @Author menghan
 * @Version 2017-01-14 11:23:52
 */
public interface ModifyRecordDao {

	/**
	 * 根据id获得修改记录
	 * @param
	 * @return
	 */
	ModifyRecord getModifyRecordById(Long id);
	
	/**
	 * 新增修改记录
	 * @param
	 * @return
	 */
	boolean insert(ModifyRecord modifyRecord);
	
	/**
	 * 删除修改记录
	 * @param
	 * @return
	 */
	boolean deleteModifyRecordById(Long id);
	
	/***
	 * 根据bean获得记录总数
	 * @param
	 * @return
	 */
	int queryModifyRecordCount(ModifyRecordQuery bean);
	
	/**
	 * 根据bean获得翻页查询结果
	 * @param
	 * @return
	 */
	List<ModifyRecord> queryModifyRecordListWithPage(ModifyRecordQuery bean);
	
	/**
	 * 根据bean获得入职流水信息
	 * @param
	 * @return
	 */
	List<ModifyRecord> queryEntryFlow(ModifyRecordQuery bean);
}
