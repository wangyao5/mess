package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.LeaveDao;
import com.letv.css.portal.dao.StaffDao;
import com.letv.css.portal.domain.Leave;
import com.letv.css.portal.domain.Staff;
import com.letv.css.portal.domain.query.StaffQuery;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * 员工请假DAO实现类
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class LeaveDaoImpl extends BaseDao implements LeaveDao {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean insert(Leave bean) {
		return insert("Leave.insert", bean);
	}

	@Override
	public Leave getLeaveById(Long id) {
		return (Leave) queryForObject("Leave.getLeaveById", id);
	}

	@Override
	public boolean updateStatus(Leave bean) {
		return update("Leave.updateStatus", bean);
	}

	@Override
	public List<Leave> queryRepeatedLeave(Long staffId, Date leaveStartTime, Date leaveEndTime) {
		Leave leaveQuery = new Leave();
		leaveQuery.setStaffId( staffId );
		leaveQuery.setLeaveStartTime( leaveStartTime );
		leaveQuery.setLeaveEndTime( leaveEndTime );
		return queryForList("Leave.queryRepeatedLeave",leaveQuery);
	}
}
