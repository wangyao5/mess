package com.letv.css.portal.dao;

import com.letv.css.portal.domain.Shifts;
import com.letv.css.portal.domain.query.ShiftsQuery;

import java.util.List;

/**
 * Created by yangxinghe on 2017/5/16.
 */
public interface ShiftsDao {


    /**
     * * 根据查询Bean获取对象集合，不带翻页
     *
     * @param queryBean
     * @return
     */
    List<Shifts> queryShiftsList(ShiftsQuery queryBean);
    
    /**
     * 根据查询Bean获取对象集合，不带翻页，按照班次最小开始时间排序
     * @param queryBean
     * @return
     */
    List<Shifts> queryShiftsListByMinBeginTime(ShiftsQuery queryBean);
    
    /**
     * * 根据查询Bean获取对象集合，不带翻页
     *
     * @param queryBean
     * @return
     */
    List<Shifts> queryOptionShiftsList(ShiftsQuery queryBean);

    /**
     * * 根据查询Bean获取对象集合，翻页
     *
     * @param queryBean
     * @return
     */
    List<Shifts> queryShiftsListWithPage(ShiftsQuery queryBean);

    /**
     * 根据查询Bean获取总数
     *
     * @param queryBean
     * @return
     */
    int queryShiftsCount(ShiftsQuery queryBean);


    /**
     * 新增对象
     *
     * @param bean
     * @return
     */
    boolean insert(Shifts bean);

    /**
     * 更新对象
     *
     * @param bean
     * @return
     */
    boolean update(Shifts bean);


    /**
     * 根据主键删除记录
     *
     * @param id
     * @return
     */
    boolean deleteShiftsById(Long id);

    /**
     * 根据主键获取对象
     *
     * @param id 主键字段
     * @return
     */
    Shifts getShiftsById(Long id);

    /**
     * 根据名称查询班次
     * @param shiftsName
     * @return
     */
    Shifts getShiftsByName(String shiftsName);


}
