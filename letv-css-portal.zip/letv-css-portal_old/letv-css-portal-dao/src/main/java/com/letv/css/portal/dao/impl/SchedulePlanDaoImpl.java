package com.letv.css.portal.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.SchedulePlanDao;
import com.letv.css.portal.domain.SchedulePlan;
import com.letv.css.portal.domain.query.SchedulePlanQuery;

/**
 * 总班表导入dao实现类
 *
 * @Author menghan
 * @Version 2017-05-24 17:28:21
 */
@Repository
@SuppressWarnings({ "rawtypes", "unchecked" })
public class SchedulePlanDaoImpl extends BaseDao implements SchedulePlanDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean insert(SchedulePlan schedulePlan) {
		return insert("SchedulePlan.insert", schedulePlan);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean inserts(List<SchedulePlan> schedulePlans) {
		return insert("SchedulePlan.inserts", schedulePlans);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public SchedulePlan getSchedulePlanById(Long id) {
		return (SchedulePlan) queryForObject("SchedulePlan.getSchedulePlanById", id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<SchedulePlan> querySchedulePlanListWithPage(SchedulePlanQuery query) {
		return queryForList("SchedulePlan.querySchedulePlanListWithPage", query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<SchedulePlan> querySchedulePlanList(SchedulePlanQuery query) {
		return queryForList("SchedulePlan.querySchedulePlanList", query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Integer querySchedulePlanCount(SchedulePlanQuery query) {
		return (Integer) queryForObject("SchedulePlan.querySchedulePlanCount", query);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean update(SchedulePlan plan) {
		return update("SchedulePlan.update", plan);
	}

}
