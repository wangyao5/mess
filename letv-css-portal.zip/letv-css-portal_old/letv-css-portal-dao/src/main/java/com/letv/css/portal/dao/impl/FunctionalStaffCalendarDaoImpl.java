package com.letv.css.portal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import com.letv.css.portal.domain.FunctionalStaffCalendar;
import com.letv.css.portal.domain.query.FunctionalStaffCalendarQuery;

import org.springframework.stereotype.Repository;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.FunctionalStaffCalendarDao;

/**
 * 数据字典 dao实现类
 * @Author greg
 */
@Repository
@SuppressWarnings({ "rawtypes","unchecked" })
public class FunctionalStaffCalendarDaoImpl extends BaseDao implements FunctionalStaffCalendarDao{


	@Override
	public boolean insert(FunctionalStaffCalendar functionalStaffCalendar) {
		// TODO Auto-generated method stub
		return insert("FunctionalStaffCalendar.insert", functionalStaffCalendar);
	}

	@Override
	public boolean update(FunctionalStaffCalendar functionalStaffCalendar) {
		// TODO Auto-generated method stub
		return update("FunctionalStaffCalendar.insert", functionalStaffCalendar);
	}

	@Override
	public List<FunctionalStaffCalendar> queryList(FunctionalStaffCalendarQuery query) {
		List<FunctionalStaffCalendar> resultList = 
				(List<FunctionalStaffCalendar>)queryForList("FunctionalStaffCalendar.queryList", query);
		if(resultList == null || resultList.size() <=0){
			resultList = new ArrayList<FunctionalStaffCalendar>();
		}
		System.out.println("GREG_DAO:"+ resultList.size());
		return resultList;
	}
}
