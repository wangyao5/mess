package com.letv.css.portal.dao;

import com.letv.css.portal.domain.Schedule;
import com.letv.css.portal.domain.ScheduleDetail;
import com.letv.css.portal.domain.SchedulePlanDetail;
import com.letv.css.portal.domain.query.ScheduleDetailQuery;

import java.util.List;

/***
 * BPO班表明细dao
 *
 * @Author yxh
 * @Version 2017-05-31 22:56:53
 */
public interface ScheduleDetailDao {

	/**
	 * 插入一条BPO排班表明细记录
	 * @param
	 * @return
	 */
	boolean insert(ScheduleDetail scheduleDetail);
	
	/**
	 * 批量插入BPO排班表明细记录
	 * @param
	 * @return
	 */
	boolean inserts(List<ScheduleDetail> scheduleDetails);
	
	/***
	 * 根据BPO排班表Id查询BPO排班表明细列表
	 * @param
	 * @return
	 */
	List<ScheduleDetail> queryScheduleDetailList(ScheduleDetailQuery query);
	
	/***
	 * 修改BPO排班表明细信息
	 * @param
	 * @return
	 */
	boolean update(ScheduleDetail scheduleDetail);
	
	/**
	 * 根据ID删除BPO排班表明细信息
	 * @param
	 * @return
	 */
	boolean delete(Long id);

	/**
	 * 根据班表明细中的 职场、日期 删除数据
	 * @param scheduleDetails
	 * @return
     */
	boolean updateYnBySDetail(List<ScheduleDetail> scheduleDetails);

	/**
	 * 根据query，批量删除BPO排班表明细信息
	 * @param
	 * @return
	 */
	boolean deletes(ScheduleDetailQuery query);
	/**
	 * 进行批量标记删除
	 * @param
	 * @return
	 */
	boolean batchDelete(List<ScheduleDetail> list);

	/**
	 * 根据排班任务更新数据
	 * @param sId
	 * @return
	 */

	boolean deleteBySid(Long sId);
}
