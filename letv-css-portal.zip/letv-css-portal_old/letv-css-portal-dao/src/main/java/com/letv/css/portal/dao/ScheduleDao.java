package com.letv.css.portal.dao;

import com.letv.css.portal.domain.Schedule;
import com.letv.css.portal.domain.query.ScheduleQuery;

import java.util.List;

/***
 * BPO排班表导入dao
 *
 * @Author yxh
 * @Version 2017-05-31 22:05:09
 */
public interface ScheduleDao {

	/**
	 * 插入一条记录
	 * @param
	 * @return
	 */
	boolean insert(Schedule schedule);

	/**
	 * 更新记录
	 * @param
	 * @return
	 */
	boolean update(Schedule schedule);
	/**
	 * 插入多条记录
	 * @param
	 * @return
	 */
	boolean inserts(List<Schedule> schedules);
	
	/**
	 * 根据id获得BPO排班表信息
	 * @param
	 * @return
	 */
	Schedule getScheduleById(Long id);
	
	/**
	 * 根据班表ID获取BPO排班表信息
	 * @param spid
	 * @return
	 * greg
	 */
	Schedule getScheduleBySpid(Long spid);
	
	/**
	 * 根据query查询BPO排班表信息，翻页
	 * @param
	 * @return
	 */
	List<Schedule> queryScheduleListWithPage(ScheduleQuery query);
	
	/**
	 * 根据query查询BPO排班表信息，不翻页
	 * @param
	 * @return
	 */
	List<Schedule> queryScheduleList(ScheduleQuery query);
	
	/**
	 * 根据query获得BPO排班表导入总数
	 * @param
	 * @return
	 */
	Integer queryScheduleCount(ScheduleQuery query);
}
