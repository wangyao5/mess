package com.letv.css.portal.dao;

import com.letv.css.portal.domain.DepBusiness;
import com.letv.css.portal.domain.Dic;
import com.letv.css.portal.domain.Staff;

import java.util.List;

public interface DepBusinessDao {

    List<DepBusiness> queryByDepId(Long depId);

    boolean insert(DepBusiness depBusiness);

    boolean update(DepBusiness depBusiness);
}
