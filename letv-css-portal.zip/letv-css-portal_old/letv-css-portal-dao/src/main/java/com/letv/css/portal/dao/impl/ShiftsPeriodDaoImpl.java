package com.letv.css.portal.dao.impl;

import com.letv.common.dao.mybatis.BaseDao;
import com.letv.css.portal.dao.ShiftsPeriodDao;
import com.letv.css.portal.domain.ShiftsPeriod;
import com.letv.css.portal.domain.query.ShiftsPeriodQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by yangxinghe on 2017/5/16.
 */

@Repository
@SuppressWarnings({"rawtypes", "unchecked"})
public class ShiftsPeriodDaoImpl extends BaseDao implements ShiftsPeriodDao {
    /**
     * {@inheritDoc}
     */
    @Override
    public List<ShiftsPeriod> queryShiftsPeriodList(ShiftsPeriodQuery queryBean) {
        return (List<ShiftsPeriod>) queryForList("ShiftsPeriod.queryShiftsPeriodList", queryBean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<ShiftsPeriod> queryShiftsPeriodListWithPage(ShiftsPeriodQuery queryBean) {
        return (List<ShiftsPeriod>) queryForList("ShiftsPeriod.queryShiftsPeriodListWithPage", queryBean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int queryShiftsPeriodCount(ShiftsPeriodQuery queryBean) {
        return (Integer) queryForObject("ShiftsPeriod.queryShiftsPeriodCount", queryBean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean insert(ShiftsPeriod bean) {
        return insert("ShiftsPeriod.insert", bean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean update(ShiftsPeriod bean) {
        return update("ShiftsPeriod.update", bean);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean deleteShiftsPeriodById(Long id) {
        return delete("ShiftsPeriod.deleteShiftsPeriodById", id);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ShiftsPeriod getShiftsPeriodById(Long id) {
        return (ShiftsPeriod) queryForObject("ShiftsPeriod.getShiftsPeriodById", id);
    }

}
